import React from 'react';
import {Box} from '@mui/material';
import PropsTypes from 'prop-types';

const AppAnimateGroup = ({loading, children, ...props}) => {
  return <Box {...props}>{children}</Box>;
};

export default AppAnimateGroup;
AppAnimateGroup.propTypes = {
  children: PropsTypes.node,
  loading: PropsTypes.node,
};