import React from 'react';

import {useSelector} from 'react-redux';
import AppMessageView from '@crema/core/AppMessageView';
import AppLoader from '@crema/core/AppLoader';

const AppInfoView = () => {
  const {error, loading, message, info, warning} = useSelector(({common}) => common);

  const showMessage = () => {
    return <AppMessageView variant='success' message={message.toString()} />;
  };

  const showError = () => {
    return <AppMessageView variant='error' message={error.toString()} />;
  };

  const showWarning = () => {
    return <AppMessageView variant='warning' message={warning.toString()} />;
  };

  const showInfo = () => {
    return <AppMessageView variant='info' message={info.toString()} />;
  };

  return (
    <>
      {loading && <AppLoader />}

      {message && showMessage()}
      {error && showError()}
      {warning && showWarning()}
      {info && showInfo()}
    </>
  );
};

export default AppInfoView;
