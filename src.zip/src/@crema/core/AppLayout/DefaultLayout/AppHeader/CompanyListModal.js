import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';
import Stack from '@mui/material/Stack';
import {useDispatch, useSelector} from 'react-redux';
import Router from 'next/router';
import {AgGridReact} from 'ag-grid-react';
import {
  selectCompany, closeCompanyModel
} from '../../../../../redux/actions';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import {InputAdornment, TextField} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import FormDirtyNotification from 'shared/commonComponent/formDirtyNotification';
import { isEmptyNullUndefined } from 'shared/utils/CommonUtils';
import { useCallback } from 'react';

export default function CompanyListModal() {
  const dispatch = useDispatch();
  const [rowData, setRowData] = React.useState(null);
  const gridRef = React.useRef();
  const [overlayMessage, setOverlayMessage] = React.useState('No Rows To Show');
  let getIsDirty = useSelector(
    ({moduleProperty}) => moduleProperty.isFormDirty,
  );

  let companyData = useSelector(({company}) => company.companyData);

  const getRowStyle = (params) => {
    if (
      selectedCompany != null &&
      selectedCompany != undefined &&
      selectedCompany.id == params.data.id
    ) {
      return {background: '#A6BCEF'};
    }
  };
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const handleSelectCompany = (params) => {
    closeCompanySelector();
    dispatch(selectCompany(params.data));
    localStorage.setItem(
      'localSorageRefForSelectedCompany',
      JSON.stringify(params.data),
    );
    // Router.push(`/dashboard`);
    Router.push(`/home`);
  };
  const defaultColDef = React.useMemo(() => ({
    sortable: true,
  }));
  const [columnDefs] = React.useState([
    {
      headerName: 'Select',
      cellRenderer: function (params) {
        return (
          <Button
            size='small'
            name='select'
            disabled={
              selectedCompany != null &&
              selectedCompany != undefined &&
              selectedCompany.id == params.data.id
            }
            variant={
              selectedCompany != null &&
              selectedCompany != undefined &&
              selectedCompany.id == params.data.id
                ? 'contained'
                : 'outlined'
            }
            onClick={() => handleSelectCompany(params)}
          >
            Select
          </Button>
        );
      },
      minWidth: 50,
    },
    {
      field: 'companyName',
      filter: true,
      headerName: 'Company Name',
      minWidth: 200,
    },
    {field: 'address.city', filter: true, headerName: 'City', minWidth: 200},
    {
      field: 'address.country',
      filter: true,
      headerName: 'Country',
      minWidth: 200,
    },
  ]);

  React.useEffect(() => {
    setRowData(companyData);
  }, [companyData]);

  const closeCompanySelector = () => {
    dispatch(closeCompanyModel());
  };

  const [gridApi, setGridApi] = React.useState(null);
  const [open, setOpen] = React.useState(false);

  React.useEffect(() => {
    if (getIsDirty) {
      setOpen(() => true);
    }
  }, [getIsDirty]);

  
  const onFilterTextBoxChanged = useCallback(() => {
    const filterText = document.getElementById("filter-text-box").value;
    gridRef.current.api.setGridOption("quickFilterText", filterText);
    const totalResults = gridRef.current.api.getDisplayedRowCount();
    if (!isEmptyNullUndefined(rowData) && rowData.length > 0) {
      if (totalResults === 0 && !isEmptyNullUndefined(filterText)) {
        setOverlayMessage('No Record Found');
        gridRef.current.api.showNoRowsOverlay();
      } else if (totalResults !== 0) {
        setOverlayMessage('No Rows To Show');
        gridRef.current.api.hideOverlay();
      }
    }
  }, []);

 
  return (
    <Dialog
        fullWidth
        style={{height: '100vh'}}
        maxWidth={'md'}
        open={true}
        onClose={closeCompanySelector}
      >
        <DialogTitle fontSize={14}>
          <h3>Company</h3>
          <Stack
            display='flex'
            alignItems='flex-end'
            justifyContent='space-between'
            width={{xs: '100%', sm: '25%'}}
            sx={{mb: 1, ml: 155}}
          >
            <TextField
              size='small'
              label='Search'
              variant='outlined'
              name='search'
              id="filter-text-box"
              onInput={onFilterTextBoxChanged}
              InputProps={{
                startAdornment: (
                  <InputAdornment position='start'>
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
            />
          </Stack>
        </DialogTitle>

        <DialogContent>
          <Stack
            className='ag-theme-alpine'
            style={{height: 500, width: '100%'}}
          >
            <AgGridReact
              ref={gridRef}
              rowData={rowData}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              getRowStyle={getRowStyle}
              animateRows={true}
              overlayLoadingTemplate={
                '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'
              }
              overlayNoRowsTemplate={`<span class="ag-overlay-loading-center">${overlayMessage}</span>`}
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button onClick={closeCompanySelector}>Close</Button>
        </DialogActions>
        <FormDirtyNotification
          isGetDirty={true}
          // currentRoute={currentRoute}
          // functionForChangeRoute={routeChangeFunction()}
          functionForNo={closeCompanySelector}
          eClickk={() => eclickk()}
          open={open}
          setOpen={setOpen}
        />
      </Dialog>
  );
}
