import React , {useState , useEffect} from 'react';
import HorizontalGroup from './HorizontalGroup';
import HorizontalCollapse from './HorizontalCollapse';
import HorizontalItem from './HorizontalItem';
import Divider from '@mui/material/Divider';
import List from '@mui/material/List';
import routesConfig from '../../../../../modules/routesConfig';

const HorizontalNav = () => {

   
 const [renderRoutes , setRenderRoutes] = useState(routesConfig);
  useEffect(()=>{
   let admin_role = JSON.parse(localStorage.getItem("admin_role"));
   console.log("finalRoutes",admin_role)
   if(admin_role == "ROLE_HR"){
    const finalRoutes = renderRoutes.filter((routes) => {
      return routes.title.toLowerCase() !== "master"
    })
    setRenderRoutes(finalRoutes);
    console.log("finalRoutes",finalRoutes)
   }
   
},[])


  return (
    <List className='navbarNav'>
      {renderRoutes.map((item) => (
        <React.Fragment key={item.id}>
          {item.type === 'group' && (
            <HorizontalGroup item={item} nestedLevel={0} />
          )}

          {item.type === 'collapse' && (
            <HorizontalCollapse item={item} nestedLevel={0} />
          )}

          {item.type === 'item' && (
            <HorizontalItem item={item} nestedLevel={0} />
          )}

          {item.type === 'divider' && <Divider sx={{my: 5}} />}
        </React.Fragment>
      ))}
    </List>
  );
};

export default HorizontalNav;
