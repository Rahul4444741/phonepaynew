import React, {useMemo, useState} from 'react';
import {Icon, ListItemText} from '@mui/material';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import AppBadge from '@crema/core/AppBadge';
import Box from '@mui/material/Box';
import IntlMessages from '../../../../../utility/IntlMessages';
import {checkPermission} from '../../../../../utility/helper/RouteHelper';
import {useAuthUser} from '../../../../../utility/AuthHooks';
import VerticalNavItem from './VerticalNavItem';
import {useSelector} from 'react-redux';
import Router from 'next/router';
import FormDirtyNotification from 'shared/commonComponent/formDirtyNotification';
import {isEmptyNullUndefined} from 'shared/utils/CommonUtils';

const VerticalItem = ({level, router, item}) => {
  let getIsDirty = useSelector(
    ({moduleProperty}) => moduleProperty.isFormDirty,
  );
  const {user} = useAuthUser();
  const hasPermission = useMemo(
    () => checkPermission(item.permittedRole, user.role),
    [item.permittedRole, user.role],
  );
  if (!hasPermission) {
    return null;
  }

  const [isGetDirty, setIsGetDirty] = useState(false);
  const [open, setOpen] = useState(false);
  
  React.useEffect(() => {
    setIsGetDirty(() => getIsDirty);
  }, [getIsDirty]);

  const handleAlertNotification = () => {
    if (isGetDirty) {
      setOpen(() => true);
    } else {
      // Router.push(item.url)
      if (!isEmptyNullUndefined(item.url)) {
        Router.push(item.url);
      }
    }
  };

  return (
    <>
      <FormDirtyNotification
        isGetDirty={isGetDirty}
        currentRoute={item.url}
        eClickk={() => eclickk()}
        open={open}
        setOpen={setOpen}
      />
      {/* <div style={{cursor: `${isGetDirty ? 'not-allowed' : 'pointer'}`}} onClick={() => notifyUserToRouterChangeIfFormDirty() }> */}
      <div
        onClick={() => handleAlertNotification()}
        style={{cursor: 'pointer'}}
      >
        <div style={{pointerEvents: `${isGetDirty ? 'none' : 'all'}`}}>
          {/* <Link href={item.url} as={item.as}> */}
          <div onClick={() => handleAlertNotification()}>
            <a style={{textDecoration: 'none'}}>
              <VerticalNavItem
                item={item}
                level={level}
                router={router}
                exact={item.exact}
              >
                {item.icon && (
                  <Box component='span'>
                    <Icon
                      sx={{
                        fontSize: 18,
                        display: 'block',
                        mr: 4,
                        width: 'auto',
                        height: 'auto',
                      }}
                      className={clsx(
                        'nav-item-icon',
                        'material-icons-outlined',
                      )}
                      color='action'
                    >
                      {item.icon}
                    </Icon>
                  </Box>
                )}
                <ListItemText
                  className='nav-item-content'
                  primary={<IntlMessages id={item.messageId} />}
                  classes={{primary: 'nav-item-text'}}
                />
                {item.count && (
                  <Box sx={{mr: 3.5}} className='menu-badge'>
                    <AppBadge count={item.count} color={item.color} />
                  </Box>
                )}
              </VerticalNavItem>
            </a>
          </div>
        </div>
      </div>
    </>
  );
};

VerticalItem.propTypes = {
  item: PropTypes.shape({
    id: PropTypes.string.isRequired,
    title: PropTypes.string,
    icon: PropTypes.oneOfType([PropTypes.node, PropTypes.string]),
    permittedRole: PropTypes.oneOfType([PropTypes.array, PropTypes.string]),
    exact: PropTypes.bool,
    messageId: PropTypes.string,
    count: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
    url: PropTypes.string,
    color: PropTypes.string,
    as: PropTypes.string,
  }),
  level: PropTypes.number,
  router: PropTypes.object,
};

VerticalItem.defaultProps = {};

export default React.memo(VerticalItem);
