import React from 'react';
import List from '@mui/material/List';

import routesConfig from '../../../../../modules/routesConfig';
import NavVerticalGroup from './VerticalNavGroup';
import VerticalCollapse from './VerticalCollapse';
import VerticalItem from './VerticalItem';
import {useRouter} from 'next/router';
import {useState, useEffect} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {
  getALLNotificationCount,
  getALLNotification,
} from 'redux/actions/Notification';
import {isAllowedUser} from 'shared/utils/CommonUtils';

const VerticalNav = () => {
  const router = useRouter();
  const dispatch = useDispatch();
  const {AllNotificationData} = useSelector(({Notification}) => Notification);
  let companyConfigurationData = useSelector(
    ({companyConfigurationReducer}) =>
      companyConfigurationReducer.companyConfigurationData,
  );
  const {id} = JSON.parse(localStorage.getItem('userDetails'));

  const [renderRoutes, setRenderRoutes] = useState(deepClone(routesConfig));

  useEffect(() => {
    const filterRoutes = (routes) => {
      return routes
        .filter((route) => isAllowedUser(route.permission)) // Check if the current route is allowed
        .map((route) => {
          // If the route has children, recursively filter them
          if (route.children) {
            const filteredChildren = filterRoutes(route.children);
            return {...route, children: filteredChildren};
          }
          return route;
        });
    };

    const finalRoutes = filterRoutes(routesConfig);

    setRenderRoutes(finalRoutes);
    // console.log('finalRoutes Vertical', finalRoutes);
  }, [companyConfigurationData]);

  function deepClone(obj) {
    if (obj === null || typeof obj !== 'object') {
      return obj;
    }

    if (Array.isArray(obj)) {
      const copy = [];
      for (let i = 0; i < obj.length; i++) {
        copy[i] = deepClone(obj[i]);
      }
      return copy;
    }

    if (obj instanceof Object) {
      const copy = {};
      for (const attr in obj) {
        if (Object.hasOwn(obj, attr)) {
          copy[attr] = deepClone(obj[attr]);
        }
      }
      return copy;
    }
  }

  React.useEffect(() => {
    const interval = setInterval(() => {
      dispatch(getALLNotificationCount(id));
    }, 300000);
    if (AllNotificationData.length == 0) {
      dispatch(
        getALLNotification({
          type: 'ALL',
          employeeId: id,
        }),
      );
    }
    return () => clearInterval(interval);
  }, []);

  return (
    <List
      sx={{
        position: 'relative',
        padding: 0,
      }}
      component='div'
    >
      {renderRoutes.map((item, index) => (
        <React.Fragment key={item.id}>
          {item.type === 'group' && (
            <NavVerticalGroup item={item} level={0} router={router} />
          )}

          {item.type === 'collapse' && (
            <VerticalCollapse
              item={item}
              idType={item.id}
              routes={index}
              level={0}
              router={router}
            />
          )}

          {item.type === 'item' && (
            <VerticalItem item={item} level={0} router={router} />
          )}
        </React.Fragment>
      ))}
    </List>
  );
};

export default VerticalNav;
