const languageData = [
  {
    languageId: 'english',
    locale: 'en',
    name: 'English',
  },
  {
    languageId: 'chinese',
    locale: 'zh',
    name: '中国人',
  },
  {
    languageId: 'spanish',
    locale: 'es',
    name: 'Español',
  },
  {
    languageId: 'french',
    locale: 'fr',
    name: 'français',
  },
  {
    languageId: 'italian',
    locale: 'it',
    name: 'Italiano',
  },
  {
    languageId: 'saudi-arabia',
    locale: 'ar',
    name: 'عربي',
  },
  {
    languageId: 'japanese',
    locale: 'ja',
    name: '日本人',
  },
  {
    languageId: 'russian',
    locale: 'ru',
    name: 'Русский',
  },
  {
    languageId: 'hindi',
    locale: 'hi',
    name: 'हिन्दी',
  },
  {
    languageId: 'arabic',
    locale: 'ar',
    name: 'العربية',
  },
  {
    languageId: 'bengali',
    locale: 'bn',
    name: 'বাংলা',
  },
  {
    languageId: 'portuguese',
    locale: 'pt',
    name: 'Português',
  },
  {
    languageId: 'punjabi',
    locale: 'pa',
    name: 'ਪੰਜਾਬੀ',
  },
  {
    languageId: 'german',
    locale: 'de',
    name: 'Deutsch',
  },
  {
    languageId: 'javanese',
    locale: 'jv',
    name: 'Basa Jawa',
  },
  {
    languageId: 'indonesian',
    locale: 'id',
    name: 'Bahasa Indonesia',
  },
];
export default languageData;
