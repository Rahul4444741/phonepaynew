import React, {useEffect, useState} from 'react';
import {IconButton, Skeleton} from '@mui/material';
import List from '@mui/material/List';
import AppScrollbar from '@crema/core/AppScrollbar';
import IntlMessages from '@crema/utility/IntlMessages';
import NotificationItem from './NotificationItem';
import CancelOutlinedIcon from '@mui/icons-material/CancelOutlined';
import emptyNotification from '../../../assets/notification/no-notifications.png';
import PropTypes from 'prop-types';
import Typography from '@mui/material/Typography';
import Switch from '@mui/material/Switch';
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import {
  getALLNotification,
  getALLNotificationCount,
} from '../../../redux/actions/Notification';
import {useDispatch, useSelector} from 'react-redux';
import FormGroup from '@mui/material/FormGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {fetchError} from 'redux/actions';

const AppNotificationContent = ({onClose, sxStyle, count}) => {
  const {AllNotificationData, NotificationCount, loader} = useSelector(
    ({Notification}) => Notification,
  );
  const [checked, setChecked] = useState(false);
  const dispatch = useDispatch();
  const [notificationState, setNotificationState] = useState([]);
  const [readState, setReadState] = useState(null);
  const {id} = JSON.parse(localStorage.getItem('userDetails'));

  const getNotification = (typeOf) => {
    let obj = {
      type: typeOf,
      employeeId: id,
    };

    dispatch(getALLNotification(obj));
  };

  useEffect(() => {
    if (!checked) {
      getNotification('ALL');
    } else {
      getNotification('UNREAD');
    }
  }, [NotificationCount, checked]);

  useEffect(() => {
    dispatch(getALLNotificationCount(id));
  }, []);

  useEffect(() => {
    if (!loader) {
      if (AllNotificationData.length > 0) {
        const sortNotifications = AllNotificationData.sort(function (a, b) {
          // Turn your strings into dates, and then subtract them
          // to get a value that is either negative, positive, or zero.
          return new Date(b.createdDate) - new Date(a.createdDate);
        });
        setNotificationState(sortNotifications);
      } else {
        setNotificationState([]);
      }
    }
  }, [loader, AllNotificationData]);

  useEffect(() => {
    const value = notificationState.every((val) => {
      return val.read == true;
    });
    setReadState(value);
  }, [notificationState]);

  const markRead = () => {
    let id = [];

    notificationState.forEach((value) => {
      id.push(value.id);
    });

    updateNotification(id);
  };

  const notificationSkeleton = () => {
    let skeletonJSX = [];
    for (let i = 0; i <= (screen.height > 870 ? 12 : 8); i++) {
      skeletonJSX.push(
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            paddingBottom: '0.5rem',
          }}
        >
          <Skeleton variant='circular' width={48} height={48} />
          <Skeleton variant='rect' width={246} height={65} sx={{ml: 0.5}} />
        </div>,
      );
    }
    return skeletonJSX;
  };

  const updateNotification = async (idArray) => {
    let mainArray = [...idArray];

    try {
      const {status} = await jwtAxios.put(`${API_ROUTS.update_notification}`, {
        ids: mainArray,
      });
      if (status == 201) {
        getNotification(!checked ? 'ALL' : 'UNREAD');
        dispatch(getALLNotificationCount(id));
      }
    } catch (error) {
      dispatch(fetchError(error?.response?.data?.title));
    }
  };

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: 'column',
        width: 350,
        height: 'calc( 100% - 124px)',
        ...sxStyle,
      }}
    >
      <Box
        sx={{
          padding: '5px 20px',
          display: 'flex',
          alignItems: 'center',
          borderBottom: 1,
          borderBottomColor: (theme) => theme.palette.divider,
          minHeight: {xs: 56, sm: 70},
        }}
      >
        <Typography component='h3' variant='h3'>
          <IntlMessages id='common.notifications' />({count})
        </Typography>
        <IconButton
          sx={{
            height: 40,
            width: 40,
            marginLeft: 'auto',
            color: 'text.secondary',
          }}
          onClick={onClose}
          size='large'
        >
          <CancelOutlinedIcon />
        </IconButton>
      </Box>
      <Stack
        direction='row'
        alignItems='center'
        px={4}
        py={2}
        justifyContent='space-between'
      >
        {!readState && (
          <Typography onClick={markRead} style={{cursor: 'pointer'}}>
            Mark all as read
          </Typography>
        )}

        <FormGroup>
          <FormControlLabel
            labelPlacement='start'
            control={
              <Switch checked={checked} onChange={() => setChecked(!checked)} />
            }
            label='Only show unread'
          />
        </FormGroup>
      </Stack>
      {loader ? (
        <AppScrollbar>
          <List sx={{py: 0}}>
            <div style={{paddingInline: '20px', paddingTop: '0.5rem'}}>
              {notificationSkeleton()}
            </div>
          </List>
        </AppScrollbar>
      ) : (
        <AppScrollbar>
          <List sx={{py: 0}}>
            {notificationState.length > 0 ? (
              notificationState.map((item) => (
                <NotificationItem
                  updateRead={updateNotification}
                  key={item.id}
                  item={item}
                  style={{cursor: 'pointer'}}
                />
              ))
            ) : (
              <Stack alignItems='center'>
                <img src={emptyNotification.src} width='220px' alt='img' />
              </Stack>
            )}
          </List>
        </AppScrollbar>
      )}
    </Box>
  );
};

export default AppNotificationContent;

AppNotificationContent.propTypes = {
  onClose: PropTypes.func,
  sxStyle: PropTypes.object,
  count: PropTypes.number,
};
