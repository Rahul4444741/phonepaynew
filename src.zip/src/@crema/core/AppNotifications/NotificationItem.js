import React from 'react';
import ListItemAvatar from '@mui/material/ListItemAvatar';
import Avatar from '@mui/material/Avatar';
import PropTypes from 'prop-types';
import {Box, ListItem, Typography} from '@mui/material';
import {BsCircleFill} from 'react-icons/bs';
import {Fonts} from '../../../shared/constants/AppEnums';
import moment from 'moment';
const NotificationItem = ({updateRead, item}) => {

  const renderHTML = (htmlContent) => {
    return { __html: htmlContent };
  };

  return (
    <ListItem
      sx={{
        cursor: 'pointer',
        padding: '8px 20px',
      }}
      className='item-hover'
      onClick={() => {
        if (!item?.read) {
          updateRead([item.id]);
        }
      }}
    >
      <ListItemAvatar
        sx={{
          minWidth: 0,
          mr: 4,
        }}
      >
        <Avatar
          sx={{
            width: 48,
            height: 48,
          }}
          alt='Remy Sharp'
        >
          {item?.employee?.firstName ? item.employee.firstName[0] : null}
        </Avatar>
      </ListItemAvatar>
      <Box
        sx={{
          fontSize: 14,
          width: '100%',
          color: (theme) => theme.palette.text.secondary,
        }}
      >
        <Typography>
          <Box
            component='span'
            sx={{
              fontSize: 14,
              fontWeight: Fonts.MEDIUM,
              mb: 0.5,
              color: (theme) => theme.palette.text.primary,
              mr: 1,
              display: 'inline-block',
            }}
            style={!item?.read ? {fontWeight: '600'} : {}}
          >
            {item.title}
          </Box>
          <div dangerouslySetInnerHTML={renderHTML(item.message)} />
          <br />
          <p style={{textAlign: 'end'}}>
            {' '}
            {moment(item?.createdDate).calendar()}
          </p>
        </Typography>
      </Box>

      <div
        style={{
          height: '8px',
          justifySelf: 'flex-end',
          paddingInline: '4px',
        }}
      >
        {!item?.read ? (
          <BsCircleFill style={{color: '#1976d2'}} />
        ) : (
          <BsCircleFill style={{color: 'transparent'}} />
        )}
      </div>
    </ListItem>
  );
};

export default NotificationItem;

NotificationItem.propTypes = {
  item: PropTypes.object.isRequired,
  updateRead: PropTypes.func.isRequired,
};
