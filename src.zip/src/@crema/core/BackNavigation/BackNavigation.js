import React from 'react'
import Stack from '@mui/material/Stack';
import { useRouter } from 'next/router'
import Button from '@mui/material/Button';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

const BackNavigation = () => {
    const router = useRouter()
    return (
        <Stack onClick={() => router.back()} direction="row" alignItems="center">

            <Button variant="text" startIcon={<ArrowBackIcon />}>
                Back
            </Button>
        </Stack>

    )
}

export default BackNavigation

