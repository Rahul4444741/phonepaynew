import React, {useEffect} from 'react';
import Router, {useRouter} from 'next/router';
import AppLoader from '../../core/AppLoader';
import {useAuthUser} from '../../utility/AuthHooks';
import {useDispatch, useSelector} from 'react-redux';
import {
  fetchCompanyData,
  fetchError,
  selectCompany,
} from '../../../redux/actions';

const withData = (ComposedComponent) => (props) => {
  const {user, isLoading} = useAuthUser();
  const dispatch = useDispatch();
  const {asPath} = useRouter();
  const queryParams = asPath.split('?')[1];
  let companyData = useSelector(({company}) => company.companyData);

  useEffect(() => {
    const fetchData=async()=>{
    try {
      if (!user && !isLoading) {
        Router.push('/signin' + (queryParams ? '?' + queryParams : ''));
      }
      if (companyData == null) {
        dispatch(fetchCompanyData());
        dispatch(
          selectCompany(
            JSON.parse(localStorage.getItem('userDetails')).company,
          ),
        );
      }
    } catch (error) {
      dispatch(fetchError(error));
    }
    }
    fetchData();
  }, [user, isLoading]);

  if (!user || isLoading) return <AppLoader />;

  return <ComposedComponent {...props} />;
};
export default withData;
