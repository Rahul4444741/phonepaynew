import React, {useEffect} from 'react';
import Router, {useRouter} from 'next/router';
import {initialUrl} from '../../../shared/constants/AppConst';
import AppLoader from '../../core/AppLoader';
import {useAuthUser} from '../../utility/AuthHooks';
import {useDispatch} from 'react-redux';
import {fetchCompanyData, fetchCompanyDataInactive, selectCompany} from '../../../redux/actions';

const withData = (ComposedComponent) => (props) => {
  const {user, isLoading} = useAuthUser();
  const {asPath} = useRouter();
  const dispatch = useDispatch();
  const queryParams = asPath.split('?')[1];
  useEffect(() => {
    if (user) {
      Router.push(initialUrl + (queryParams ? '?' + queryParams : ''));
      dispatch(fetchCompanyData());
      dispatch(fetchCompanyDataInactive())
      dispatch(
        selectCompany(JSON.parse(localStorage.getItem('userDetails')).company),
      );
    }
  }, [user]);
  if (isLoading) return <AppLoader />;
  if (user) return <AppLoader />;

  return <ComposedComponent {...props} />;
};

export default withData;
