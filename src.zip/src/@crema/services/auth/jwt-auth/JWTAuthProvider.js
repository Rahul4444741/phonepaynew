import React, {createContext, useContext, useEffect, useState} from 'react';
import PropTypes from 'prop-types';
import {useDispatch} from 'react-redux';
import {fetchError, showMessage, showWarning} from 'redux/actions/Common';
import {getALLNotificationCount} from 'redux/actions/Notification';

import {
  FETCH_ERROR,
  FETCH_START,
  FETCH_SUCCESS,
} from 'shared/constants/ActionTypes';
import jwtAxios, {setAuthToken} from './index';
import {account, API_ROUTS, employee_email} from 'shared/constants/ApiRouts';
import {apiCatchErrorMessage} from 'shared/utils/CommonUtils';

const JWTAuthContext = createContext();
const JWTAuthActionsContext = createContext();

export const useJWTAuth = () => useContext(JWTAuthContext);
export const useJWTAuthActions = () => useContext(JWTAuthActionsContext);

const JWTAuthAuthProvider = ({children}) => {
  const [firebaseData, setJWTAuthData] = useState({
    user: null,
    isAuthenticated: false,
    isLoading: true,
  });

  const dispatch = useDispatch();

  // Axios interceptor to handle expired tokens globally
  jwtAxios.interceptors.response.use(
    (response) => response,
    (error) => {
      if (error.response?.status === 401) {
        // Clear token and reset state only once on token expiration
        localStorage.removeItem('token');
        setAuthToken(null);
        setJWTAuthData({
          user: null,
          isLoading: false,
          isAuthenticated: false,
        });
        dispatch(fetchError('Session expired. Please login again.'));
      }
      return Promise.reject(error);
    },
  );

  useEffect(() => {
    const getAuthUser = async () => {
      const token = localStorage.getItem('token');

      if (!token) {
        setJWTAuthData({
          user: undefined,
          isLoading: false,
          isAuthenticated: false,
        });
        return;
      }
      setAuthToken(token);

      try {
        const adminDetails = await jwtAxios.get(`${account}`);
        localStorage.setItem('adminDetails', JSON.stringify(adminDetails.data));

        const userDetails = await jwtAxios.get(`${employee_email}`);
        localStorage.setItem('userDetails', JSON.stringify(userDetails.data));
        dispatch(getALLNotificationCount(userDetails?.data?.id));

        setJWTAuthData({
          user: userDetails.data,
          isLoading: false,
          isAuthenticated: true,
        });
      } catch (error) {
        console.error('Authentication error:', error);
        localStorage.removeItem('token');
        setAuthToken(null);
        setJWTAuthData({
          user: undefined,
          isLoading: false,
          isAuthenticated: false,
        });
      }
    };

    getAuthUser();
  }, []);

  const accountPriority = (array) => {
    if (array.includes('SUPER_ADMIN')) {
      return 'SUPER_ADMIN';
    } else if (array.includes('ROLE_ADMIN')) {
      return 'ROLE_ADMIN';
    } else if (array.includes('ROLE_HR')) {
      return 'ROLE_HR';
    } else {
      return 'ROLE_USER';
    }
  };

  const signInUser = async ({email, password}) => {
    dispatch({type: FETCH_START});
    try {
      const {data} = await jwtAxios.post(`${API_ROUTS.authenticate}`, {
        username: email,
        password: password,
      });

      localStorage.setItem('token', data.id_token);
      setAuthToken(data.id_token);

      const {data: accountData} = await jwtAxios.get(`${account}`);
      let localUser = accountPriority(accountData?.authorities);

      if (localUser === 'ROLE_USER') {
        dispatch(showWarning('Insufficient permissions.'));
        setJWTAuthData({
          user: null,
          isAuthenticated: false,
          isLoading: false,
        });
        localStorage.removeItem('token');
      } else {
        localStorage.setItem('admin_role', JSON.stringify(localUser));
        localStorage.setItem('adminDetails', JSON.stringify(accountData));
        const userDetails = await jwtAxios.get(`${employee_email}`);
        localStorage.setItem('userDetails', JSON.stringify(userDetails.data));
        dispatch(getALLNotificationCount(userDetails?.data?.id));

        setJWTAuthData({
          user: userDetails.data,
          isAuthenticated: true,
          isLoading: false,
        });
        dispatch({type: FETCH_SUCCESS});
      }
    } catch (error) {
      localStorage.removeItem('token');
      setAuthToken(null);
      setJWTAuthData({
        ...firebaseData,
        user: null,
        isAuthenticated: false,
        isLoading: false,
      });
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const signUpUser = async ({name, email, password}) => {
    dispatch({type: FETCH_START});
    try {
      const {data} = await jwtAxios.post('users', {
        name: name,
        username: email,
        password: password,
      });

      localStorage.setItem('token', data.token);
      setAuthToken(data.token);
      const res = await jwtAxios.get('/authenticate');

      setJWTAuthData({
        user: res.data,
        isAuthenticated: true,
        isLoading: false,
      });
      dispatch({type: FETCH_SUCCESS});
    } catch (error) {
      setJWTAuthData({
        ...firebaseData,
        isAuthenticated: false,
        isLoading: false,
      });
      console.log('error:', error.response.data.error);
      dispatch({
        type: FETCH_ERROR,
        payload: error?.response?.data?.error || 'Something went wrong',
      });
    }
  };

  const logout = async () => {
    localStorage.removeItem('token');
    localStorage.removeItem('admin_role');
    localStorage.removeItem('setInitialCompanyName');
    localStorage.removeItem('localSorageRefForSelectedCompany');
    localStorage.clear();
    setAuthToken('');
    setJWTAuthData({
      user: null,
      isLoading: false,
      isAuthenticated: false,
    });
  };

  return (
    <JWTAuthContext.Provider
      value={{
        ...firebaseData,
      }}
    >
      <JWTAuthActionsContext.Provider
        value={{
          signUpUser,
          signInUser,
          logout,
        }}
      >
        {children}
      </JWTAuthActionsContext.Provider>
    </JWTAuthContext.Provider>
  );
};

export default JWTAuthAuthProvider;

JWTAuthAuthProvider.propTypes = {
  children: PropTypes.node.isRequired,
};
