import axios from 'axios';
import {baseURL} from 'shared/constants/ApiRouts';

const jwtAxios = axios.create({
  baseURL: baseURL,

  headers: {
    'Content-Type': 'application/json',
  },
});

// Add a request interceptor to handle FormData
jwtAxios.interceptors.request.use(config => {
  // Remove Content-Type header for FormData requests
  if (config.data instanceof FormData) {
    delete config.headers['Content-Type'];
  }
  return config;
}, error => {
  return Promise.reject(error);
});

jwtAxios.interceptors.response.use(
  (res) => res,
  (error) => {
    if (error?.response?.status === 401) {
      console.log('----------------->logout', error);
      // store.dispatch({type: LOGOUT});
      delete jwtAxios.defaults.headers.common['Authorization'];
      localStorage.removeItem('token');
    }
    console.log('-----------------------', error);
    throw error;
  },
);

export const setAuthToken = (token) => {
  if (token) {
    jwtAxios.defaults.headers.common['Authorization'] = 'Bearer ' + token;
    localStorage.setItem('token', token);
  } else {
    delete jwtAxios.defaults.headers.common['Authorization'];
    localStorage.removeItem('token');
  }
};

export default jwtAxios;
