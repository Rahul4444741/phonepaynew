export const generalFaq = [
  {
    id: 1001,
    ques: 'Do you have any document to demonstrate the installation process',
    ans: 'Yes, We have prepared a document stating the complete process of installation along with the tools needed for the installation.',
  },
  {
    id: 1002,
    ques: 'Is there any need of external softwares for installing this AppThemeProvider ?',
    ans: 'No, you just have to run this app, everything is integrated in it, so there is no need of any extra installation.',
  },
  {
    id: 1003,
    ques: 'Do you have any document to demonstrate the installation process',
    ans: 'Yes, We have prepared a document stating the complete process of installation along with the tools needed for the installation.',
  },
  {
    id: 1004,
    ques: 'Is there any need of external softwares for installing this AppThemeProvider ?',
    ans: 'No, you just have to run this app, everything is integrated in it, so there is no need of any extra installation.',
  },
  {
    id: 1005,
    ques: 'Do you have any document to demonstrate the installation process',
    ans: 'Yes, We have prepared a document stating the complete process of installation along with the tools needed for the installation.',
  },
  {
    id: 1006,
    ques: 'Is there any need of external softwares for installing this AppThemeProvider ?',
    ans: 'No, you just have to run this app, everything is integrated in it, so there is no need of any extra installation.',
  },
];
