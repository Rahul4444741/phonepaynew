import {authRole} from '../../../shared/constants/AppConst';

export const getUserFromJwtAuth = (user) => {
  if (user) {
    return {
      id: 1,
      uid: user._id,
      displayName: `${user.name}`,
      email: user.email,
      photoURL: user.avatar,
      role: authRole.user,
      // employeeRoleName: user.employeeRole.name,
      company: user?.company?.companyName,
      birthDate: user.dateOfBirth,
      country: user?.address?.country,
      phone: user?.company?.primaryPhone
    };
  }
  return user;
};
