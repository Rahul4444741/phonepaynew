import * as React from "react";
const SVGInbox = (props) => (
  <svg
    width={20}
    height={16}
    viewBox="0 0 20 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    {...props}
  >
    <path
      d="M18.5 8.875H13.25L11.5 11.5H8L6.25 8.875H1"
      stroke="black"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M4.03625 2.04125L1 8.875V13.25C1 13.7141 1.18437 14.1592 1.51256 14.4874C1.84075 14.8156 2.28587 15 2.75 15H16.75C17.2141 15 17.6592 14.8156 17.9874 14.4874C18.3156 14.1592 18.5 13.7141 18.5 13.25V8.875L15.4638 2.04125C15.3264 1.73122 15.102 1.46776 14.8177 1.28291C14.5334 1.09805 14.2016 0.999769 13.8625 1H5.6375C5.29841 0.999769 4.96656 1.09805 4.68229 1.28291C4.39802 1.46776 4.17358 1.73122 4.03625 2.04125V2.04125Z"
      stroke="black"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);
export default SVGInbox;
