import * as React from 'react';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import Button from '@mui/material/Button';
import {
  Checkbox,
  FormControl,
  FormLabel,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  Stack,
} from '@mui/material';
import RadioGroup from '@mui/material/RadioGroup';
import Radio from '@mui/material/Radio';
import Divider from '@mui/material/Divider';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import FormControlLabel from '@mui/material/FormControlLabel';
import IntlMessages from '@crema/utility/IntlMessages';
import PropTypes from 'prop-types';
import {useState, useEffect} from 'react';
import dynamic from 'next/dynamic';
import {
  align,
  font,
  fontColor,
  fontSize,
  formatBlock,
  hiliteColor,
  horizontalRule,
  lineHeight,
  list,
  paragraphStyle,
  table,
  template,
  textStyle,
  image,
  link,
} from '../../../node_modules/suneditor/src/plugins';
import {
  getIdListFromObjects,
  getListItemDescription,
  isEmptyNullUndefined,
  onlyAcceptWholeNumbers,
} from 'shared/utils/CommonUtils';
import CloseIcon from '@mui/icons-material/Close';
import {footerButton} from 'shared/constants/AppConst';
import {useRouter} from 'next/router';
import ReferenceFormConfig from './ReferenceFormConfig';

const SunEditor = dynamic(() => import('suneditor-react'), {
  ssr: false,
});

const requiredStyled = {
  backgroundColor: 'white',
  mb: 2,
  width: {xs: '100%', xl: '60%', md: '75%'},
  '& .MuiOutlinedInput-root': {
    '& fieldset': {
      borderLeftColor: 'red',
      borderLeftWidth: 3,
    },
  },
};

const menuItems = [
  {
    key: 'competency',
    value: 'competency',
    label: 'Competency',
  },
];

export default function TemporaryDrawer({
  drowerFormIsOpen,
  handleNo,
  sections,
  selectedSectionForEdit,
  valuesData,
  ratingsData,
  SelfAppraisalReferredSectionsData,
  PeerReferredSectionsData,
  refferedSelfAppraisalForm,
  refferedPeerFeedbackForm,
  formFor,
  pmsCycle,
}) {
  const router = useRouter();
  const {view} = router.query;
  useEffect(() => {
    if (
      selectedSectionForEdit.nestedSubSection == null &&
      selectedSectionForEdit.tile == null &&
      selectedSectionForEdit.tab == null
    ) {
      // TODO document why this block is empty
    } else if (
      selectedSectionForEdit.nestedSubSection == null &&
      selectedSectionForEdit.tile == null
    ) {
      setConfigObj(sections[selectedSectionForEdit.tab].configObj);
      setReferenceEmployeeSections(
        sections[selectedSectionForEdit.tab].referenceEmployeeSections,
      );
      setReferencePeerSections(
        sections[selectedSectionForEdit.tab].referencePeerSections,
      );
    } else if (selectedSectionForEdit.nestedSubSection == null) {
      setConfigObj(
        sections[selectedSectionForEdit.tab].subSections[
          selectedSectionForEdit.tile
        ].configObj,
      );
      setReferenceEmployeeSections(
        sections[selectedSectionForEdit.tab].subSections[
          selectedSectionForEdit.tile
        ].referenceEmployeeSections,
      );
      setReferencePeerSections(
        sections[selectedSectionForEdit.tab].subSections[
          selectedSectionForEdit.tile
        ].referencePeerSections,
      );
    } else {
      setConfigObj(
        sections[selectedSectionForEdit.tab].subSections[
          selectedSectionForEdit.tile
        ].subSections[selectedSectionForEdit.nestedSubSection].configObj,
      );
      setReferenceEmployeeSections(
        sections[selectedSectionForEdit.tab].subSections[
          selectedSectionForEdit.tile
        ].subSections[selectedSectionForEdit.nestedSubSection]
          .referenceEmployeeSections,
      );
      setReferencePeerSections(
        sections[selectedSectionForEdit.tab].subSections[
          selectedSectionForEdit.tile
        ].subSections[selectedSectionForEdit.nestedSubSection]
          .referencePeerSections,
      );
    }
  }, [drowerFormIsOpen]);

  const [configObj, setConfigObj] = useState({
    doesThisQuestionHaveSelection: null, //bool
    selectionType: null, //single or multiple
    selectableValues: [], // {id: null, name: null, status: null, company: null}
    selectableRatings: null,
    doesThisQuestionHaveResponse: null, //bool
    responseType: null, //string
    isInfoRequired: null, //bool
    info: null, //string Additional information
    minCharacterLimit: null, //integer
    maxCharacterLimit: null, //int
    isSelectionMandatory: null, //bool
    isResponseMandatory: null, //bool
    isRatingMandatory: null,
    label: null, // new added for question or section label
    arePresetLabelsAdded: null,
    isRatingPartOfPMS: null,
    isRatingRequired: null,
    isWeightageRequired: null,
    overallSectionalRatingRequired: null,
    showPeerFeedback: null,
    showEmployeeSelfAppraisal: null,
    maxSelectionLimit: null,

    // new variable for dynamic selection type 24-10-24
    isThisAQuestion: null, //boolean
    dynamicSelectionMenuType: null, //string
    doesThisQuestionHaveDynamicSelection: null, //boolean
    isDynamicSelectionMandatory: null, //boolean
    dynamicSelectionType: null, //single or multiple
    maxDynamicSelectionLimit: null // integer
  });
  const [isInfoEditActive, setIsInfoEditActive] = useState(false);
  const [tileDescription, setTileDescription] = useState('');
  const [isLabelEditActive, setIsLabelEditActive] = useState(false);
  const [sectionLabelDescription, setSectionLabelDescription] = useState('');

  const [referenceEmployeeSections, setReferenceEmployeeSections] =
    useState(null);
  const [referencePeerSections, setReferencePeerSections] = useState(null);

  const handleChangeFormData = (event, inputType) => {
    const tempconfigObj = {...configObj};
    if (inputType == 'ratio') {
      tempconfigObj[event.target.name] = event.target.value;
      if (event.target.name === 'doesThisQuestionHaveSelection') {
        if (event.target.value === false || event.target.value === 'false') {
          tempconfigObj.isSelectionMandatory = false;
          tempconfigObj.selectableValues.length = 0;
          tempconfigObj.selectionType = null;
          tempconfigObj.maxSelectionLimit = null;
        }
      }
      if (event.target.name === 'doesThisQuestionHaveDynamicSelection') {
        if (event.target.value === false || event.target.value === 'false') {
          tempconfigObj.isDynamicSelectionMandatory = false;
          tempconfigObj.dynamicSelectionMenuType = null
          tempconfigObj.dynamicSelectionType = null;
          tempconfigObj.maxDynamicSelectionLimit = null;
        }
      }
      if (event.target.name === 'showEmployeeSelfAppraisal') {
        if (event.target.value === false || event.target.value === 'false') {
          setReferenceEmployeeSections(null);
        }
      }
      if (event.target.name === 'showPeerFeedback') {
        if (event.target.value === false || event.target.value === 'false') {
          setReferencePeerSections(null);
        }
      }
      if (
        event.target.name == 'selectionType' &&
        event.target.value == 'Single'
      ) {
        tempconfigObj.maxSelectionLimit = null;
      }

      if (
        event.target.name == 'dynamicSelectionType' &&
        event.target.value == 'Single'
      ) {
        tempconfigObj.maxDynamicSelectionLimit = null;
      }
      if (event.target.name === 'isRatingRequired') {
        if (event.target.value === false || event.target.value === 'false') {
          tempconfigObj.selectableRatings = null;
          tempconfigObj.isRatingMandatory = null;
        }
      }
      if (event.target.name === 'doesThisQuestionHaveResponse') {
        if (event.target.value === false || event.target.value === 'false') {
          tempconfigObj.isResponseMandatory = false;
          tempconfigObj.responseType = null;
          tempconfigObj.minCharacterLimit = null;
          tempconfigObj.maxCharacterLimit = null;
        }
      }
      if (
        event.target.name === 'responseType' &&
        event.target.value != 'String'
      ) {
        tempconfigObj.minCharacterLimit = null;
        tempconfigObj.maxCharacterLimit = null;
      }
      if (
        event.target.name === 'isInfoRequired' &&
        (event.target.value === 'false' || event.target.value === false)
      ) {
        tempconfigObj.info = null;
      }
    } else if (inputType == 'description') {
      tempconfigObj[event.target.name] = event.target.value;
    } else if (inputType == 'numberField') {
      tempconfigObj[event.target.name] = onlyAcceptWholeNumbers(
        event.target.value,
      );
    } else if (inputType == 'textField') {
      tempconfigObj[event.target.name] = event.target.value;
    } else if (inputType == 'dropdown') {
      tempconfigObj[event.target.name] = event.target.value;
    }
    setConfigObj(() => tempconfigObj);
  };

  const handleRefferedSelfAppraisalForm = (updatedData) => {
    setReferenceEmployeeSections(updatedData);
  };
  const handlePeerFeedbackForm = (updatedData) => {
    setReferencePeerSections(updatedData);
  };

  const submitInfoDescriptionHandler = (event) => {
    if (isInfoEditActive) {
      handleChangeFormData(
        {
          target: {
            name: 'info',
            value: event.target.value,
          },
        },
        'description',
      );
      setIsInfoEditActive(() => false);
    } else {
      handleChangeTileDescription(configObj.info);
      setIsInfoEditActive(() => true);
    }
  };

  const submitLabelDescriptionHandler = (event) => {
    if (isLabelEditActive) {
      handleChangeFormData(
        {
          target: {
            name: 'label',
            value: event.target.value,
          },
        },
        'description',
      );
      setIsLabelEditActive(() => false);
    } else {
      handleChangeTileLabelDescription(configObj.label);
      setIsLabelEditActive(() => true);
    }
  };

  const handleSubmitLabelAndInfoBeforeClose = (handleNoFunction) => {
    const tempconfigObj = {...configObj};
    if (isInfoEditActive || isLabelEditActive) {
      if (isInfoEditActive) {
        setIsInfoEditActive(() => false);
        tempconfigObj.info = tileDescription;
      }
      if (isLabelEditActive) {
        setIsLabelEditActive(() => false);
        tempconfigObj.label = sectionLabelDescription;
      }
      handleNo(tempconfigObj, referenceEmployeeSections, referencePeerSections);
    } else {
      handleNoFunction();
    }
  };

  const handleChangeTileDescription = (event) => {
    setTileDescription(() => event);
  };

  const handleChangeTileLabelDescription = (event) => {
    setSectionLabelDescription(() => event);
  };

  const handleSelectableRatings = (event) => {
    const value = event.target.value;
    const tempConfigObj = {...configObj};
    tempConfigObj.selectableRatings = value;

    setConfigObj(tempConfigObj);
  };

  const handleSelectableValues = (event) => {
    const value = event.target.value;
    const tempConfigObj = {...configObj};
    let preventDuplicate = value.filter(
      (v, i, a) => a.findIndex((t) => t === v) === i,
    );
    if (value[value?.length - 1] === 'All') {
      preventDuplicate =
        preventDuplicate?.length - 1 === valuesData?.length
          ? []
          : getIdListFromObjects(valuesData, 'id');
    }
    const mappedPreventDuplicate = preventDuplicate.map((e) => ({id: e}));
    tempConfigObj.selectableValues = mappedPreventDuplicate;
    setConfigObj(tempConfigObj);
  };

  const randerValueofselectableValues = (objValues) => {
    if (objValues) {
      let tempValue = [];
      objValues.map((e) => tempValue.push(e.id));
      return tempValue;
    } else {
      return [];
    }
  };

  const checkIsThisSubSection = () => {
    if (
      selectedSectionForEdit.nestedSubSection == null &&
      selectedSectionForEdit.tile == null &&
      selectedSectionForEdit.tab == null
    ) {
      // TODO document why this block is empty
    } else if (
      selectedSectionForEdit.nestedSubSection == null &&
      selectedSectionForEdit.tile == null
    ) {
      return !sections[selectedSectionForEdit.tab].subSections.length;
    } else if (selectedSectionForEdit.nestedSubSection == null) {
      return !sections[selectedSectionForEdit.tab].subSections[
        selectedSectionForEdit.tile
      ].subSections.length;
    } else {
      return true;
    }
  };
  const checkWhichLevel = () => {
    if (
      selectedSectionForEdit.nestedSubSection == null &&
      selectedSectionForEdit.tile == null
      // selectedSectionForEdit.tab == null
    ) {
      return 'SECTION';
    } else if (
      selectedSectionForEdit.nestedSubSection == null
      // selectedSectionForEdit.tile == null
    ) {
      return 'SUBSECTION';
    } else {
      return 'QUESTION';
    }
  };

  const referredDropDown = (referredSectionsData, selectedItem) => {
    if (isEmptyNullUndefined(referredSectionsData)) {
      return;
    }
    let ReffAppObj = {};
    let menuItem = [];

    for (const element of referredSectionsData) {
      if (element.parentConfigObj === null) {
        if (ReffAppObj?.noParent) {
          ReffAppObj.noParent.push(element);
        } else {
          ReffAppObj.noParent = [element];
        }
      } else if (ReffAppObj?.[element.parentConfigObj.id]) {
        ReffAppObj[element.parentConfigObj.id].push(element);
      } else {
        ReffAppObj[element.parentConfigObj.id] = [element];
      }
    }

    if (ReffAppObj.noParent) {
      // Use map instead of forEach to generate an array of JSX elements
      const noParentItems = ReffAppObj.noParent.map((item) => (
        <MenuItem
          style={{
            backgroundColor:
              selectedItem?.id == item.id ? 'rgba(10, 143, 220, 0.08)' : '',
          }}
          key={'class_' + item.id}
          value={item}
        >
          <ListItemText
            primary={
              <div
                className='referred-dropdown'
                dangerouslySetInnerHTML={{
                  __html: item.configObj.label,
                }}
              ></div>
            }
          />
        </MenuItem>
      ));

      // Push the array of JSX elements to menuItem
      menuItem.push(noParentItems);
    } else {
      // TODO document why this block is empty
    }
    for (let key in ReffAppObj) {
      if (key != 'noParent') {
        menuItem.push(
          <MenuItem
            style={{pointerEvents: 'none'}}
            onClick={(e) => e.stopPropagation}
            key={'class_' + ReffAppObj[key][0].parentConfigObj.id}
            value={ReffAppObj[key][0].parentConfigObj}
          >
            <ListItemText
              primary={
                <div
                  className='referred-dropdown-parent'
                  dangerouslySetInnerHTML={{
                    __html: ReffAppObj[key][0].parentConfigObj.label,
                  }}
                ></div>
              }
            />
          </MenuItem>,
        );
        let keyMunu = ReffAppObj[key].map((item) => (
          <MenuItem
            style={{
              backgroundColor:
                selectedItem?.id == item.id ? 'rgba(10, 143, 220, 0.08)' : '',
            }}
            key={'class_' + item.id}
            value={item}
          >
            <ListItemText
              primary={
                <div
                  className='referred-dropdown'
                  dangerouslySetInnerHTML={{
                    __html: item.configObj.label,
                  }}
                ></div>
              }
            />
          </MenuItem>
        ));
        menuItem.push(keyMunu);
      }
    }

    return menuItem;
  };

  return (
    <div
      className={`form-page-main-container ${
        view ? 'disabled-button-for-view-only' : ''
      }`}
    >
      {sections && (
        <Drawer
          anchor={'right'}
          open={drowerFormIsOpen}
          onClose={async () => {
            handleNo();
          }}
        >
          <Stack
            className={`form-page-main-container ${
              view ? 'disabled-button-for-view-only' : ''
            }`}
            sx={{width: '1000px'}}
          >
            <CloseIcon
              onClick={() => handleNo()}
              sx={{
                color: '#0A8FDC',
                margin: '13px',
                cursor: 'pointer',
              }}
            />
            <Box sx={{width: '90%', margin: '0 auto'}}>
              <Stack
                direction='row'
                sx={{mt: 2, ml: 3}}
                justifyContent='space-between'
                alignItems='center'
                spacing={2}
              >
                <Stack sx={{width: '50%'}}>
                  <FormLabel id='demo-row-radio-buttons-group-label'>
                    <Stack direction='row'>
                      <Stack fontWeight={500}>{'Label'}</Stack>
                    </Stack>
                  </FormLabel>
                </Stack>
              </Stack>

              {
                <Stack>
                  {' '}
                  {!isLabelEditActive ? (
                    <Stack className='description-modal-style-popup'>
                      <div
                        dangerouslySetInnerHTML={{
                          __html: configObj.label,
                        }}
                      ></div>
                    </Stack>
                  ) : (
                    <SunEditor
                      id={`sunEditor`}
                      setOptions={{
                        showPathLabel: false,
                        minHeight: '50vh',
                        placeholder: 'Enter your text here!!!',

                        mode: 'classic',
                        rtl: false,
                        katex: 'window.katex',
                        imageGalleryUrl:
                          'https://etyswjpn79.execute-api.ap-northeast-1.amazonaws.com/suneditor-demo',
                        videoFileInput: false,
                        tableCellControllerPosition: '',
                        tabDisable: false,

                        plugins: [
                          align,
                          font,
                          fontColor,
                          fontSize,
                          formatBlock,
                          hiliteColor,
                          horizontalRule,
                          lineHeight,
                          list,
                          paragraphStyle,
                          table,
                          template,
                          textStyle,
                          image,
                          link,
                        ],
                        buttonList: [
                          ['undo', 'redo'],
                          ['font', 'fontSize', 'formatBlock'],
                          ['paragraphStyle'],
                          [
                            'bold',
                            'underline',
                            'italic',
                            'strike',
                            'subscript',
                            'superscript',
                          ],
                          ['fontColor', 'hiliteColor'],
                          ['removeFormat'],
                          '/', // Line break
                          // ['outdent', 'indent'],
                          [
                            'align',
                            'horizontalRule',
                            'list',
                            // 'lineHeight'
                          ],
                          // ['table', 'link', 'image'],
                          // [
                          //   'blockquote',
                          //   'textStyle',
                          //   'math',
                          //   'imageGallery',
                          //   'fullScreen',
                          //   'showBlocks',
                          //   'codeView',
                          //   'preview',
                          //   'print',
                          //   'save',
                          //   'template',
                          // ],
                        ],

                        formats: [
                          'p',
                          'div',
                          'h1',
                          'h2',
                          'h3',
                          'h4',
                          'h5',
                          'h6',
                        ],
                        font: [
                          'Arial',
                          'Calibri',
                          'Comic Sans',
                          'Courier',
                          'Garamond',
                          'Georgia',
                          'Impact',
                          'Lucida Console',
                          'Palatino Linotype',
                          'Segoe UI',
                          'Tahoma',
                          'Times New Roman',
                          'Trebuchet MS',
                        ],
                      }}
                      onChange={(event) =>
                        handleChangeTileLabelDescription(event)
                      }
                      defaultValue={configObj.label}
                    />
                  )}
                  <Button
                    style={{marginTop: '10px'}}
                    color={footerButton.back.color}
                    variant={footerButton.back.variant}
                    sx={footerButton.back.sx}
                    size={footerButton.back.size}
                    id={`edit-submit-description`}
                    onClick={() =>
                      submitLabelDescriptionHandler({
                        target: {
                          name: 'description',
                          value: sectionLabelDescription,
                        },
                      })
                    }
                  >
                    {isLabelEditActive ? 'Submit Label' : 'Edit Label'}
                  </Button>
                </Stack>
              }
              <Divider sx={{marginTop: '10px'}} />
              {checkIsThisSubSection() && (
                <Stack
                  direction='row'
                  sx={{mt: 2, ml: 3}}
                  justifyContent='space-between'
                  alignItems='center'
                  spacing={2}
                >
                  <Stack sx={{width: '50%'}}>
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>
                          {'Does this row have only label ?'}
                        </Stack>
                      </Stack>
                    </FormLabel>
                  </Stack>
                  <Stack sx={{width: '50%'}}>
                    <RadioGroup
                      name='isThisAQuestion'
                      value={configObj.isThisAQuestion}
                      onChange={(e) => handleChangeFormData(e, 'ratio')}
                      row
                      aria-labelledby='demo-row-radio-buttons-group-label'
                    >
                      <FormControlLabel
                        value={true}
                        control={<Radio />}
                        label={<IntlMessages id='common.button.Yes' />}
                      />
                      <FormControlLabel
                        value={false}
                        control={<Radio />}
                        label={<IntlMessages id='common.button.No' />}
                      />
                    </RadioGroup>
                  </Stack>
                </Stack>
              )}
              <Divider sx={{marginTop: '3px', width: '50%'}} />
              {checkIsThisSubSection() && (
                <Stack
                  direction='row'
                  sx={{mt: 2, ml: 3}}
                  justifyContent='space-between'
                  alignItems='center'
                  spacing={2}
                >
                  <Stack sx={{width: '50%'}}>
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>
                          {'Does this question have selection ?'}
                        </Stack>
                      </Stack>
                    </FormLabel>
                  </Stack>
                  <Stack sx={{width: '50%'}}>
                    <RadioGroup
                      name='doesThisQuestionHaveSelection'
                      value={configObj.doesThisQuestionHaveSelection}
                      onChange={(e) => handleChangeFormData(e, 'ratio')}
                      row
                      aria-labelledby='demo-row-radio-buttons-group-label'
                    >
                      <FormControlLabel
                        value={true}
                        control={<Radio />}
                        label={<IntlMessages id='common.button.Yes' />}
                      />
                      <FormControlLabel
                        value={false}
                        control={<Radio />}
                        label={<IntlMessages id='common.button.No' />}
                      />
                    </RadioGroup>
                  </Stack>
                </Stack>
              )}

              {checkIsThisSubSection() &&
                (configObj.doesThisQuestionHaveSelection == true ||
                  configObj.doesThisQuestionHaveSelection == 'true') && (
                  <Stack
                    direction='row'
                    sx={{mt: 2, ml: 3}}
                    justifyContent='space-between'
                    alignItems='center'
                    spacing={2}
                  >
                    <Stack sx={{width: '50%'}}>
                      <FormLabel id='demo-row-radio-buttons-group-label'>
                        <Stack direction='row'>
                          <Stack fontWeight={500}>
                            <div style={{display: 'flex'}}>
                              {'Selection type'}
                              <div style={{color: 'red'}}>*</div>
                            </div>
                          </Stack>
                        </Stack>
                      </FormLabel>
                    </Stack>
                    <Stack sx={{width: '50%'}}>
                      <RadioGroup
                        name='selectionType'
                        value={configObj.selectionType}
                        onChange={(e) => handleChangeFormData(e, 'ratio')}
                        row
                        aria-labelledby='demo-row-radio-buttons-group-label'
                      >
                        <FormControlLabel
                          value={'Single'}
                          control={<Radio />}
                          label={'Single'}
                        />
                        <FormControlLabel
                          value={'Multiple'}
                          control={<Radio />}
                          label={'Multiple'}
                        />
                      </RadioGroup>
                    </Stack>
                  </Stack>
                )}
              {checkIsThisSubSection() &&
                (configObj.doesThisQuestionHaveSelection == true ||
                  configObj.doesThisQuestionHaveSelection == 'true') &&
                configObj.selectionType === 'Multiple' && (
                  <Stack
                    direction='row'
                    sx={{mt: 2, ml: 3}}
                    justifyContent='space-between'
                    alignItems='center'
                    spacing={2}
                  >
                    <Stack sx={{width: '50%'}}>
                      <FormLabel id='demo-row-radio-buttons-group-label'>
                        <Stack direction='row'>
                          <Stack fontWeight={500}>
                            <div style={{display: 'flex'}}>
                              {'Max selection limit'}
                            </div>
                          </Stack>
                        </Stack>
                      </FormLabel>
                    </Stack>
                    <Stack sx={{width: '50%'}}>
                      <TextField
                        onChange={(event) => {
                          handleChangeFormData(event, 'numberField');
                        }}
                        value={configObj.maxSelectionLimit}
                        size='small'
                        name='maxSelectionLimit'
                        variant='outlined'
                        sx={{
                          backgroundColor: 'white',
                          mb: 2,
                          width: {xs: '100%', xl: '60%', md: '75%'},
                        }}
                      />
                    </Stack>
                  </Stack>
                )}
              {checkIsThisSubSection() &&
                (configObj.doesThisQuestionHaveSelection == true ||
                  configObj.doesThisQuestionHaveSelection == 'true') && (
                  <Stack sx={{width: '100%', margin: '10px'}}>
                    <FormControl>
                      <InputLabel size='small' id='label_employeeTypes'>
                        Selectable Values
                      </InputLabel>
                      <Select
                        name='selectableValues'
                        labelId='label_employeeTypes'
                        label='selectableValues'
                        value={randerValueofselectableValues(
                          configObj?.selectableValues,
                        )}
                        onChange={(event) => handleSelectableValues(event)}
                        variant='outlined'
                        multiple
                        renderValue={(selected) =>
                          getListItemDescription(selected, valuesData, 'name')
                        }
                        size='small'
                        sx={{
                          backgroundColor: 'white',
                          mb: 2,
                          '& fieldset': {
                            borderLeftColor: 'red',
                            borderLeftWidth: 3,
                          },
                        }}
                      >
                        {valuesData?.length > 0 && (
                          <MenuItem value='All'>
                            <ListItemIcon>
                              <Checkbox
                                checked={
                                  randerValueofselectableValues(
                                    configObj?.selectableValues,
                                  )?.length == valuesData?.length
                                }
                                indeterminate={
                                  randerValueofselectableValues(
                                    configObj?.selectableValues,
                                  )?.length > 0 &&
                                  randerValueofselectableValues(
                                    configObj?.selectableValues,
                                  )?.length < valuesData?.length
                                }
                              />
                            </ListItemIcon>
                            <ListItemText primary='Select All' />
                          </MenuItem>
                        )}
                        {valuesData?.map((item) => (
                          <MenuItem key={'class_' + item.id} value={item.id}>
                            <Checkbox
                              checked={
                                randerValueofselectableValues(
                                  configObj?.selectableValues,
                                )?.findIndex((xType) => xType === item.id) > -1
                              }
                            />
                            <ListItemText primary={item.name} />
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Stack>
                )}
                {checkIsThisSubSection() &&
                (configObj.doesThisQuestionHaveSelection == true ||
                  configObj.doesThisQuestionHaveSelection == 'true') && (
                  <Stack
                    direction='row'
                    sx={{mt: 2, ml: 3}}
                    justifyContent='space-between'
                    alignItems='center'
                    spacing={2}
                  >
                    <Stack sx={{width: '50%'}}>
                      <FormLabel id='demo-row-radio-buttons-group-label'>
                        <Stack direction='row'>
                          <Stack fontWeight={500}>
                            Is selection mandatory ?
                          </Stack>
                        </Stack>
                      </FormLabel>
                    </Stack>
                    <Stack sx={{width: '50%'}}>
                      <RadioGroup
                        name='isSelectionMandatory'
                        value={configObj.isSelectionMandatory}
                        onChange={(e) => handleChangeFormData(e, 'ratio')}
                        row
                        aria-labelledby='demo-row-radio-buttons-group-label'
                      >
                        <FormControlLabel
                          value={true}
                          control={<Radio />}
                          label={<IntlMessages id='common.button.Yes' />}
                        />
                        <FormControlLabel
                          value={false}
                          control={<Radio />}
                          label={<IntlMessages id='common.button.No' />}
                        />
                      </RadioGroup>
                    </Stack>
                  </Stack>
                )}
              <Divider sx={{marginTop: '3px', width: '50%'}} />
              {checkIsThisSubSection() && (
                <Stack
                  direction='row'
                  sx={{mt: 2, ml: 3}}
                  justifyContent='space-between'
                  alignItems='center'
                  spacing={2}
                >
                  <Stack sx={{width: '50%'}}>
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>
                          {'Does this question have dynamic selection ?'}
                        </Stack>
                      </Stack>
                    </FormLabel>
                  </Stack>
                  <Stack sx={{width: '50%'}}>
                    <RadioGroup
                      name='doesThisQuestionHaveDynamicSelection'
                      value={configObj.doesThisQuestionHaveDynamicSelection}
                      onChange={(e) => handleChangeFormData(e, 'ratio')}
                      row
                      aria-labelledby='demo-row-radio-buttons-group-label'
                    >
                      <FormControlLabel
                        value={true}
                        control={<Radio />}
                        label={<IntlMessages id='common.button.Yes' />}
                      />
                      <FormControlLabel
                        value={false}
                        control={<Radio />}
                        label={<IntlMessages id='common.button.No' />}
                      />
                    </RadioGroup>
                  </Stack>
                </Stack>
              )}
              {checkIsThisSubSection() &&
                (configObj.doesThisQuestionHaveDynamicSelection == true ||
                  configObj.doesThisQuestionHaveDynamicSelection == 'true') && (
                  <Stack
                    direction='row'
                    sx={{mt: 2, ml: 3}}
                    justifyContent='space-between'
                    alignItems='center'
                    spacing={2}
                  >
                    <Stack sx={{width: '50%'}}>
                      <FormLabel id='demo-row-radio-buttons-group-label'>
                        <Stack direction='row'>
                          <Stack fontWeight={500}>
                            <div style={{display: 'flex'}}>
                              {'Dynamic Selection type'}
                              <div style={{color: 'red'}}>*</div>
                            </div>
                          </Stack>
                        </Stack>
                      </FormLabel>
                    </Stack>
                    <Stack sx={{width: '50%'}}>
                      <RadioGroup
                        name='dynamicSelectionType'
                        value={configObj.dynamicSelectionType}
                        onChange={(e) => handleChangeFormData(e, 'ratio')}
                        row
                        aria-labelledby='demo-row-radio-buttons-group-label'
                      >
                        <FormControlLabel
                          value={'Single'}
                          control={<Radio />}
                          label={'Single'}
                        />
                        <FormControlLabel
                          value={'Multiple'}
                          control={<Radio />}
                          label={'Multiple'}
                        />
                      </RadioGroup>
                    </Stack>
                  </Stack>
                )}

                {checkIsThisSubSection() &&
                (configObj.doesThisQuestionHaveDynamicSelection == true ||
                  configObj.doesThisQuestionHaveDynamicSelection == 'true') &&
                  configObj.dynamicSelectionType === 'Multiple' && (
                  <Stack
                    direction='row'
                    sx={{mt: 2, ml: 3}}
                    justifyContent='space-between'
                    alignItems='center'
                    spacing={2}
                  >
                    <Stack sx={{width: '50%'}}>
                      <FormLabel id='demo-row-radio-buttons-group-label'>
                        <Stack direction='row'>
                          <Stack fontWeight={500}>
                            <div style={{display: 'flex'}}>
                              {'Max dynamic selection limit'}
                            </div>
                          </Stack>
                        </Stack>
                      </FormLabel>
                    </Stack>
                    <Stack sx={{width: '50%'}}>
                      <TextField
                        onChange={(event) => {
                          handleChangeFormData(event, 'numberField');
                        }}
                        value={configObj.maxDynamicSelectionLimit}
                        size='small'
                        name='maxDynamicSelectionLimit'
                        variant='outlined'
                        sx={{
                          backgroundColor: 'white',
                          mb: 2,
                          width: {xs: '100%', xl: '60%', md: '75%'},
                        }}
                      />
                    </Stack>
                  </Stack>
                )}
              {checkIsThisSubSection() &&
                (configObj.doesThisQuestionHaveDynamicSelection == true ||
                  configObj.doesThisQuestionHaveDynamicSelection == 'true') && (
                  <Stack
                    direction='row'
                    sx={{mt: 2, ml: 3, width: '100%'}}
                    justifyContent='space-between'
                    alignItems='center'
                    spacing={2}
                  >
                    <Stack sx={{width: '50%'}}>
                      <FormLabel id='demo-row-radio-buttons-group-label'>
                        <Stack direction='row'>
                          <Stack fontWeight={500}>
                            Select menu dynamic type ?
                          </Stack>
                        </Stack>
                      </FormLabel>
                    </Stack>

                    <Stack sx={{width: '50%'}}>
                      <FormControl>
                        <InputLabel size='small' id='label_employeeTypes'>
                          Selection menu dynamic type
                        </InputLabel>
                        <Select
                          name='dynamicSelectionMenuType'
                          labelId='label_employeeTypes'
                          label='Selection menu dynamic type'
                          value={configObj?.dynamicSelectionMenuType}
                          onChange={(e) => handleChangeFormData(e, 'dropdown')}
                          variant='outlined'
                          size='small'
                          sx={{
                            backgroundColor: 'white',
                            mb: 2,
                            '& fieldset': {
                              borderLeftColor: 'red',
                              borderLeftWidth: 3,
                            },
                          }}
                        >
                          {menuItems.map((item) => (
                            <MenuItem key={item.key} value={item.value}>
                              <ListItemText primary={item.label} />
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Stack>
                  </Stack>
                )}
              {checkIsThisSubSection() &&
                (configObj.doesThisQuestionHaveDynamicSelection == true ||
                  configObj.doesThisQuestionHaveDynamicSelection == 'true') && (
                  <Stack
                    direction='row'
                    sx={{mt: 2, ml: 3}}
                    justifyContent='space-between'
                    alignItems='center'
                    spacing={2}
                  >
                    <Stack sx={{width: '50%'}}>
                      <FormLabel id='demo-row-radio-buttons-group-label'>
                        <Stack direction='row'>
                          <Stack fontWeight={500}>
                            Is selection mandatory ?
                          </Stack>
                        </Stack>
                      </FormLabel>
                    </Stack>
                    <Stack sx={{width: '50%'}}>
                      <RadioGroup
                        name='isDynamicSelectionMandatory'
                        value={configObj.isDynamicSelectionMandatory}
                        onChange={(e) => handleChangeFormData(e, 'ratio')}
                        row
                        aria-labelledby='demo-row-radio-buttons-group-label'
                      >
                        <FormControlLabel
                          value={true}
                          control={<Radio />}
                          label={<IntlMessages id='common.button.Yes' />}
                        />
                        <FormControlLabel
                          value={false}
                          control={<Radio />}
                          label={<IntlMessages id='common.button.No' />}
                        />
                      </RadioGroup>
                    </Stack>
                  </Stack>
                )}
                <Divider sx={{marginTop: '3px', width: '50%'}} />
              {checkIsThisSubSection() && (
                <Stack
                  direction='row'
                  sx={{mt: 2, ml: 3}}
                  justifyContent='space-between'
                  alignItems='center'
                  spacing={2}
                >
                  <Stack sx={{width: '50%'}}>
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>
                          Does this question have response?
                        </Stack>
                      </Stack>
                    </FormLabel>
                  </Stack>
                  <Stack sx={{width: '50%'}}>
                    <RadioGroup
                      name='doesThisQuestionHaveResponse'
                      value={configObj.doesThisQuestionHaveResponse}
                      onChange={(e) => handleChangeFormData(e, 'ratio')}
                      row
                      aria-labelledby='demo-row-radio-buttons-group-label'
                    >
                      <FormControlLabel
                        value={true}
                        control={<Radio />}
                        label={<IntlMessages id='common.button.Yes' />}
                      />
                      <FormControlLabel
                        value={false}
                        control={<Radio />}
                        label={<IntlMessages id='common.button.No' />}
                      />
                    </RadioGroup>
                  </Stack>
                </Stack>
              )}

              {checkIsThisSubSection() &&
                (configObj.doesThisQuestionHaveResponse == true ||
                  configObj.doesThisQuestionHaveResponse == 'true') && (
                  <Stack
                    direction='row'
                    sx={{mt: 2, ml: 3}}
                    justifyContent='space-between'
                    alignItems='center'
                    spacing={2}
                  >
                    <Stack sx={{width: '50%'}}>
                      <FormLabel id='demo-row-radio-buttons-group-label'>
                        <Stack direction='row'>
                          <Stack fontWeight={500}>
                            <div style={{display: 'flex'}}>
                              {'Response type'}
                              <div style={{color: 'red'}}>*</div>
                            </div>
                          </Stack>
                        </Stack>
                      </FormLabel>
                    </Stack>
                    <Stack sx={{width: '50%'}}>
                      <RadioGroup
                        name='responseType'
                        value={configObj.responseType}
                        onChange={(e) => handleChangeFormData(e, 'ratio')}
                        row
                        aria-labelledby='demo-row-radio-buttons-group-label'
                      >
                        <FormControlLabel
                          value={'String'}
                          control={<Radio />}
                          label={'String'}
                        />
                        <FormControlLabel
                          value={'Boolean'}
                          control={<Radio />}
                          label={'Boolean'}
                        />
                        <FormControlLabel
                          value={'Integer'}
                          control={<Radio />}
                          label={'Integer'}
                        />
                      </RadioGroup>
                    </Stack>
                  </Stack>
                )}
              {checkIsThisSubSection() &&
                (configObj.doesThisQuestionHaveResponse == true ||
                  configObj.doesThisQuestionHaveResponse == 'true') &&
                configObj.responseType == 'String' && (
                  <Stack
                    direction='row'
                    sx={{mt: 2, ml: 3}}
                    justifyContent='space-between'
                    alignItems='center'
                    spacing={2}
                  >
                    <Stack sx={{width: '50%'}}>
                      <TextField
                        onChange={(event) => {
                          handleChangeFormData(event, 'numberField');
                        }}
                        value={configObj.minCharacterLimit}
                        size='small'
                        name='minCharacterLimit'
                        label={'Min Character Limit'}
                        variant='outlined'
                        sx={{...requiredStyled}}
                      />
                    </Stack>
                    <Stack sx={{width: '50%'}}>
                      <TextField
                        onChange={(event) => {
                          handleChangeFormData(event, 'numberField');
                        }}
                        value={configObj.maxCharacterLimit}
                        size='small'
                        name='maxCharacterLimit'
                        label={'Max Character Limit'}
                        variant='outlined'
                        sx={{...requiredStyled}}
                      />
                    </Stack>
                  </Stack>
                )}
              {checkIsThisSubSection() &&
                (configObj.doesThisQuestionHaveResponse == true ||
                  configObj.doesThisQuestionHaveResponse == 'true') && (
                  <Stack
                    direction='row'
                    sx={{mt: 2, ml: 3}}
                    justifyContent='space-between'
                    alignItems='center'
                    spacing={2}
                  >
                    <Stack sx={{width: '50%'}}>
                      <FormLabel id='demo-row-radio-buttons-group-label'>
                        <Stack direction='row'>
                          <Stack fontWeight={500}>
                            Is response mandatory ?
                          </Stack>
                        </Stack>
                      </FormLabel>
                    </Stack>
                    <Stack sx={{width: '50%'}}>
                      <RadioGroup
                        name='isResponseMandatory'
                        value={configObj.isResponseMandatory}
                        onChange={(e) => handleChangeFormData(e, 'ratio')}
                        row
                        aria-labelledby='demo-row-radio-buttons-group-label'
                      >
                        <FormControlLabel
                          value={true}
                          control={<Radio />}
                          label={<IntlMessages id='common.button.Yes' />}
                        />
                        <FormControlLabel
                          value={false}
                          control={<Radio />}
                          label={<IntlMessages id='common.button.No' />}
                        />
                      </RadioGroup>
                    </Stack>
                  </Stack>
                )}
              {/* <Divider /> */}
              <Stack>
                <Stack
                  direction='row'
                  sx={{mt: 2, ml: 3}}
                  justifyContent='space-between'
                  alignItems='center'
                  spacing={2}
                >
                  <Stack sx={{width: '50%'}}>
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>Is info required ?</Stack>
                      </Stack>
                    </FormLabel>
                  </Stack>
                  <Stack sx={{width: '50%'}}>
                    <RadioGroup
                      name='isInfoRequired'
                      value={configObj.isInfoRequired}
                      onChange={(e) => handleChangeFormData(e, 'ratio')}
                      row
                      aria-labelledby='demo-row-radio-buttons-group-label'
                    >
                      <FormControlLabel
                        value={true}
                        control={<Radio />}
                        label={<IntlMessages id='common.button.Yes' />}
                      />
                      <FormControlLabel
                        value={false}
                        control={<Radio />}
                        label={<IntlMessages id='common.button.No' />}
                      />
                    </RadioGroup>
                  </Stack>
                </Stack>

                {(configObj.isInfoRequired == true ||
                  configObj.isInfoRequired == 'true') && (
                  <div style={{marginTop: '25px'}}>
                    <Divider />
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>Info</Stack>
                      </Stack>
                    </FormLabel>
                    <Stack>
                      {' '}
                      {!isInfoEditActive ? (
                        <Stack className='description-modal-style-popup'>
                          <div
                            dangerouslySetInnerHTML={{
                              __html: configObj.info,
                            }}
                          ></div>
                        </Stack>
                      ) : (
                        <SunEditor
                          id={`sunEditor`}
                          setOptions={{
                            showPathLabel: false,
                            minHeight: '50vh',
                            placeholder: 'Enter your text here!!!',

                            mode: 'classic',
                            rtl: false,
                            katex: 'window.katex',
                            imageGalleryUrl:
                              'https://etyswjpn79.execute-api.ap-northeast-1.amazonaws.com/suneditor-demo',
                            videoFileInput: false,
                            tableCellControllerPosition: '',
                            tabDisable: false,

                            plugins: [
                              align,
                              font,
                              fontColor,
                              fontSize,
                              formatBlock,
                              hiliteColor,
                              horizontalRule,
                              lineHeight,
                              list,
                              paragraphStyle,
                              table,
                              template,
                              textStyle,
                              image,
                              link,
                            ],
                            buttonList: [
                              ['undo', 'redo'],
                              ['font', 'fontSize', 'formatBlock'],
                              ['paragraphStyle'],
                              [
                                'bold',
                                'underline',
                                'italic',
                                'strike',
                                'subscript',
                                'superscript',
                              ],
                              ['fontColor', 'hiliteColor'],
                              ['removeFormat'],
                              '/', // Line break
                              ['outdent', 'indent'],
                              ['align', 'horizontalRule', 'list', 'lineHeight'],
                              ['table', 'link', 'image'],
                              [
                                'blockquote',
                                'textStyle',
                                'math',
                                'imageGallery',
                                'fullScreen',
                                'showBlocks',
                                'codeView',
                                'preview',
                                'print',
                                'save',
                                'template',
                              ],
                            ],

                            formats: [
                              'p',
                              'div',
                              'h1',
                              'h2',
                              'h3',
                              'h4',
                              'h5',
                              'h6',
                            ],
                            font: [
                              'Arial',
                              'Calibri',
                              'Comic Sans',
                              'Courier',
                              'Garamond',
                              'Georgia',
                              'Impact',
                              'Lucida Console',
                              'Palatino Linotype',
                              'Segoe UI',
                              'Tahoma',
                              'Times New Roman',
                              'Trebuchet MS',
                            ],
                          }}
                          onChange={(event) =>
                            handleChangeTileDescription(event)
                          }
                          defaultValue={configObj.info}
                        />
                      )}
                      <Button
                        style={{marginTop: '10px'}}
                        color={footerButton.back.color}
                        variant={footerButton.back.variant}
                        sx={footerButton.back.sx}
                        size={footerButton.back.size}
                        id={`edit-submit-description`}
                        onClick={() =>
                          submitInfoDescriptionHandler({
                            target: {
                              name: 'description',
                              value: tileDescription,
                            },
                          })
                        }
                      >
                        {isInfoEditActive ? 'Submit Info' : 'Edit Info'}
                      </Button>
                    </Stack>
                    <Divider sx={{marginTop: '10px'}} />
                  </div>
                )}
              </Stack>
              {checkIsThisSubSection() && (
                <Stack
                  direction='row'
                  sx={{mt: 2, ml: 3}}
                  justifyContent='space-between'
                  alignItems='center'
                  spacing={2}
                >
                  <Stack sx={{width: '50%'}}>
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>Is rating required ?</Stack>
                      </Stack>
                    </FormLabel>
                  </Stack>
                  <Stack sx={{width: '50%'}}>
                    <RadioGroup
                      value={configObj.isRatingRequired}
                      name='isRatingRequired'
                      onChange={(e) => handleChangeFormData(e, 'ratio')}
                      row
                      aria-labelledby='demo-row-radio-buttons-group-label'
                    >
                      <FormControlLabel
                        value={true}
                        control={<Radio />}
                        label={<IntlMessages id='common.button.Yes' />}
                      />
                      <FormControlLabel
                        value={false}
                        control={<Radio />}
                        label={<IntlMessages id='common.button.No' />}
                      />
                    </RadioGroup>
                  </Stack>
                </Stack>
              )}
              {checkIsThisSubSection() &&
                (configObj.isRatingRequired == true ||
                  configObj.isRatingRequired == 'true') && (
                  <Stack sx={{width: '100%', margin: '10px'}}>
                    <FormControl>
                      <InputLabel size='small' id='label_employeeTypes'>
                        Selectable Rating
                      </InputLabel>
                      <Select
                        name='selectableRatings'
                        labelId='label_employeeTypes'
                        label='selectableRatings'
                        value={configObj?.selectableRatings}
                        renderValue={(selected) => selected.ratingParameter}
                        onChange={(event) => handleSelectableRatings(event)}
                        variant='outlined'
                        size='small'
                        sx={{
                          backgroundColor: 'white',
                          mb: 2,
                          '& fieldset': {
                            borderLeftColor: 'red',
                            borderLeftWidth: 3,
                          },
                        }}
                      >
                        {ratingsData?.map((item) => (
                          <MenuItem key={'class_' + item.id} value={item}>
                            <ListItemText primary={item.ratingParameter} />
                          </MenuItem>
                        ))}
                      </Select>
                    </FormControl>
                  </Stack>
                )}
              {checkIsThisSubSection() &&
                (configObj.isRatingRequired == true ||
                  configObj.isRatingRequired == 'true') && (
                  <Stack
                    direction='row'
                    sx={{mt: 2, ml: 3}}
                    justifyContent='space-between'
                    alignItems='center'
                    spacing={2}
                  >
                    <Stack sx={{width: '50%'}}>
                      <FormLabel id='demo-row-radio-buttons-group-label'>
                        <Stack direction='row'>
                          <Stack fontWeight={500}>Is rating mandatory ?</Stack>
                        </Stack>
                      </FormLabel>
                    </Stack>
                    <Stack sx={{width: '50%'}}>
                      <RadioGroup
                        name='isRatingMandatory'
                        value={configObj.isRatingMandatory}
                        onChange={(e) => handleChangeFormData(e, 'ratio')}
                        row
                        aria-labelledby='demo-row-radio-buttons-group-label'
                      >
                        <FormControlLabel
                          value={true}
                          control={<Radio />}
                          label={<IntlMessages id='common.button.Yes' />}
                        />
                        <FormControlLabel
                          value={false}
                          control={<Radio />}
                          label={<IntlMessages id='common.button.No' />}
                        />
                      </RadioGroup>
                    </Stack>
                  </Stack>
                )}
              {checkIsThisSubSection() && (
                <Stack
                  direction='row'
                  sx={{mt: 2, ml: 3}}
                  justifyContent='space-between'
                  alignItems='center'
                  spacing={2}
                >
                  <Stack sx={{width: '50%'}}>
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>Is weightage required?</Stack>
                      </Stack>
                    </FormLabel>
                  </Stack>
                  <Stack sx={{width: '50%'}}>
                    <RadioGroup
                      row
                      aria-labelledby='demo-row-radio-buttons-group-label'
                      value={configObj.isWeightageRequired}
                      name='isWeightageRequired'
                      onChange={(e) => handleChangeFormData(e, 'ratio')}
                    >
                      <FormControlLabel
                        value={true}
                        control={<Radio />}
                        label={<IntlMessages id='common.button.Yes' />}
                      />
                      <FormControlLabel
                        value={false}
                        control={<Radio />}
                        label={<IntlMessages id='common.button.No' />}
                      />
                    </RadioGroup>
                  </Stack>
                </Stack>
              )}
              {checkIsThisSubSection() &&
                (configObj.isWeightageRequired == true ||
                  configObj.isWeightageRequired == 'true') && (
                  <Stack
                    direction='row'
                    sx={{mt: 2, ml: 3}}
                    justifyContent='space-between'
                    alignItems='center'
                    spacing={2}
                  >
                    <Stack sx={{width: '50%'}}>
                      <TextField
                        onChange={(event) => {
                          handleChangeFormData(event, 'numberField');
                        }}
                        value={configObj.weightage}
                        size='small'
                        name='weightage'
                        label={'Weightage'}
                        variant='outlined'
                        sx={{...requiredStyled}}
                      />
                    </Stack>
                  </Stack>
                )}

              {formFor == 'ManagerFeedBack' && (
                <Stack
                  direction='row'
                  sx={{mt: 2, ml: 3}}
                  justifyContent='space-between'
                  alignItems='center'
                  spacing={2}
                >
                  <Stack sx={{width: '50%'}}>
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>
                          {checkWhichLevel() == 'SECTION' &&
                            `Select employee assessment question to be mapped ?`}
                          {checkWhichLevel() == 'SUBSECTION' &&
                            `Select employee assessment question to be mapped ?`}
                          {checkWhichLevel() == 'QUESTION' &&
                            `Select employee assessment question to be mapped ?`}
                          {/* {checkWhichLevel()=='SECTION' && `Is Employee Self Appraisal to be shown at section level?`}
                          {checkWhichLevel()=='SUBSECTION' && `Is Employee Self Appraisal to be shown at subsection level ?`}
                          {checkWhichLevel()=='QUESTION' && `Is Employee Self Appraisal to be shown at question level ?`} */}
                        </Stack>
                      </Stack>
                    </FormLabel>
                  </Stack>
                  <Stack sx={{width: '50%'}}>
                    <RadioGroup
                      row
                      aria-labelledby='demo-row-radio-buttons-group-label'
                      value={configObj.showEmployeeSelfAppraisal}
                      name='showEmployeeSelfAppraisal'
                      onChange={(e) => handleChangeFormData(e, 'ratio')}
                    >
                      <FormControlLabel
                        value={true}
                        control={<Radio />}
                        label={<IntlMessages id='common.button.Yes' />}
                      />
                      <FormControlLabel
                        value={false}
                        control={<Radio />}
                        label={<IntlMessages id='common.button.No' />}
                      />
                    </RadioGroup>
                  </Stack>
                </Stack>
              )}
              {formFor == 'ManagerFeedBack' &&
                (configObj.showEmployeeSelfAppraisal == true ||
                  configObj.showEmployeeSelfAppraisal == 'true') &&
                SelfAppraisalReferredSectionsData && (
                  <Stack sx={{mt: 2, ml: 3, mr: 3, mb: 5}}>
                    <ReferenceFormConfig
                      name={
                        refferedSelfAppraisalForm?.displayName ||
                        'Self Appraisal Feedback Form'
                      }
                      configData={
                        referenceEmployeeSections
                          ? JSON.parse(
                              JSON.stringify(referenceEmployeeSections),
                            )
                          : SelfAppraisalReferredSectionsData
                          ? JSON.parse(
                              JSON.stringify(SelfAppraisalReferredSectionsData),
                            )
                          : {}
                      }
                      onDataChange={handleRefferedSelfAppraisalForm}
                    />
                  </Stack>
                )}

              {/* {checkIsThisSubSection() && formFor == 'ManagerFeedBack' && ( */}
              {formFor == 'ManagerFeedBack' && (
                <Stack
                  direction='row'
                  sx={{mt: 2, ml: 3}}
                  justifyContent='space-between'
                  alignItems='center'
                  spacing={2}
                >
                  <Stack sx={{width: '50%'}}>
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>
                          {/* Is peer feedback to be shown ? */}
                          {/* {checkWhichLevel()=='SECTION' && `Is peer feedback to be shown at section level?`}
                          {checkWhichLevel()=='SUBSECTION' && `Is peer feedback to be shown at subsection level ?`}
                          {checkWhichLevel()=='QUESTION' && `Is peer feedback to be shown at question level ?`} */}
                          {checkWhichLevel() == 'SECTION' &&
                            `Select peer feedback question to be mapped ?`}
                          {checkWhichLevel() == 'SUBSECTION' &&
                            `Select peer feedback question to be mapped ?`}
                          {checkWhichLevel() == 'QUESTION' &&
                            `Select peer feedback question to be mapped ?`}
                        </Stack>
                      </Stack>
                    </FormLabel>
                  </Stack>
                  <Stack sx={{width: '50%'}}>
                    <RadioGroup
                      row
                      aria-labelledby='demo-row-radio-buttons-group-label'
                      value={configObj.showPeerFeedback}
                      name='showPeerFeedback'
                      onChange={(e) => handleChangeFormData(e, 'ratio')}
                    >
                      <FormControlLabel
                        value={true}
                        control={<Radio />}
                        label={<IntlMessages id='common.button.Yes' />}
                      />
                      <FormControlLabel
                        value={false}
                        control={<Radio />}
                        label={<IntlMessages id='common.button.No' />}
                      />
                    </RadioGroup>
                  </Stack>
                </Stack>
              )}
              {formFor == 'ManagerFeedBack' &&
                (configObj.showPeerFeedback == true ||
                  configObj.showPeerFeedback == 'true') &&
                PeerReferredSectionsData && (
                  <Stack sx={{mt: 2, ml: 3, mr: 3, mb: 5}}>
                    <ReferenceFormConfig
                      name={
                        refferedPeerFeedbackForm.displayName ||
                        'Referred Peer Feedback Form'
                      }
                      configData={
                        referencePeerSections
                          ? JSON.parse(JSON.stringify(referencePeerSections))
                          : PeerReferredSectionsData
                          ? JSON.parse(JSON.stringify(PeerReferredSectionsData))
                          : {}
                      }
                      onDataChange={handlePeerFeedbackForm}
                    />
                  </Stack>
                )}
            </Box>
            <Stack
              sx={{
                display: 'flex',
                justifyContent: 'start',
                margin: '29px',
              }}
            >
              <Button
                id='health-hnsurance-submit-button'
                color={footerButton.submit.color}
                variant={footerButton.submit.variant}
                sx={footerButton.submit.sx}
                size={footerButton.submit.size}
                onClick={() =>
                  handleSubmitLabelAndInfoBeforeClose(() =>
                    handleNo(
                      configObj,
                      referenceEmployeeSections,
                      referencePeerSections,
                    ),
                  )
                }
              >
                <IntlMessages id='common.button.Submit' />
              </Button>
            </Stack>
          </Stack>
        </Drawer>
      )}
    </div>
  );
}

TemporaryDrawer.propTypes = {
  handleNo: PropTypes.func.isRequired,
  drowerFormIsOpen: PropTypes.bool,
  valuesData: PropTypes.array,
  ratingsData: PropTypes.array,
  SelfAppraisalReferredSectionsData: PropTypes.array,
  PeerReferredSectionsData: PropTypes.array,
  formFor: PropTypes.string,
  pmsCycle: PropTypes.object,
  sections: PropTypes.object,
  selectedSectionForEdit: PropTypes.object,
  refferedSelfAppraisalForm: PropTypes.object,
  refferedPeerFeedbackForm: PropTypes.object,
};
