import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import PropTypes from 'prop-types';
import AppInfoView from '../../@crema/core/AppInfoView';
import Modal from './modal'
import ManagerPreviewPage from './ManagerPreviewPage';

const PreviewPage = ({
  dynamicFormData,
  handleClose,
  valuesData
}) => {
  return (
    <Dialog
      sx={{
        '& .MuiDialogContent-root': {
          padding: 0,
        },
      }}
      maxWidth={'90%'}
      open={true}
    >
      <DialogContent>
        <div className='preview-popup-main-container'>
          {
            dynamicFormData.formFor=='ManagerFeedBack' && <ManagerPreviewPage dynamicFormData={dynamicFormData} valuesData={valuesData} />
          }
          {dynamicFormData.formFor !='ManagerFeedBack' && <Modal dynamicFormData={dynamicFormData} valuesData={valuesData} />}
        </div>
      </DialogContent>
      <DialogActions>
        <Button
          onClick={() => handleClose()}
          sx={{backdropFilter: 'blur(10px)', zIndex: 11}}
        >
          Close
        </Button>
      </DialogActions>
      <AppInfoView />
    </Dialog>
  );
};

export default PreviewPage;
PreviewPage.propTypes = {
  handleClose: PropTypes.func,
  dynamicFormData: PropTypes.any,
  valuesData: PropTypes.array
};
