import React, {useState} from 'react';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  FormControlLabel,
  Stack,
  Typography,
  Divider,
  Checkbox,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import {useEffect} from 'react';

const ReferenceFormConfig = ({name, configData, onDataChange}) => {
  const initializeSequence = (sections) => {
    return sections.map((section, index) => {
      if (section.sequenceNo === null) {
        section.sequenceNo = index + 1; // Assign sequence number if null
      }
      
      if(section.visible==null){
        section.visible=true;
      }

      if (
        section.subSectionReferences &&
        section.subSectionReferences.length > 0
      ) {
        section.subSectionReferences = initializeSequence(
          section.subSectionReferences,
        );
      }
      return section;
    });
  };
  const [localData, setLocalData] = useState(initializeSequence(configData));

  useEffect(() => {
    // Sort sections and subsections by sequenceNo
    const sortSections = (sections) => {
      return sections
        .sort((a, b) => a.sequenceNo - b.sequenceNo)
        .map((section) => ({
          ...section,
          subSectionReferences: sortSections(
            section.subSectionReferences || [],
          ),
        }));
    };

    const sortedData = sortSections(localData);
    setLocalData(sortedData);
    onDataChange(sortedData); // Notify parent of initial data.
  }, []);

  // Recursive function to update `visible` property
  const handleVisibilityChange = (isChecked, sectionId) => {
    const updateVisibility = (sections, parentVisible = true) => {
      return sections.map((section) => {
        if (section.sectionId === sectionId) {
          section.visible = isChecked;
        }

        // If the parent section is not visible, recursively set all child sections to false
        if (!section.visible) {
          const setAllChildrenInvisible = (subSections) => {
            return subSections.map((subSection) => ({
              ...subSection,
              visible: false,
              subSectionReferences: setAllChildrenInvisible(
                subSection.subSectionReferences || [],
              ),
            }));
          };
          section.subSectionReferences = setAllChildrenInvisible(
            section.subSectionReferences || [],
          );
        } else {
          section.subSectionReferences = updateVisibility(
            section.subSectionReferences,
            section.visible,
          );
        }

        return section;
      });
    };

    const updatedData = updateVisibility(localData);
    setLocalData(updatedData);
    onDataChange(updatedData);
  };

  // Recursive function to render nested subsections
  const renderSubSections = (subSections, parentVisible = true) => {
    return subSections.map((subSection, subIndex) => (
      <Accordion
        key={subIndex}
        sx={{
          backgroundColor: '#e4f5e8',
          mb: 2,
          mt: 2,
        }}
        defaultExpanded
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls={`subsection-content-${subIndex}`}
          id={`subsection-header-${subIndex}`}
          sx={{backgroundColor: '#e4f5e8'}}
        >
          <Stack direction='row' spacing={2} alignItems='center' sx={{ml: 5}}>
            <FormControlLabel
              control={
                <Checkbox
                  name={`visible`}
                  checked={subSection.visible}
                  disabled={!parentVisible}
                  onChange={(e) =>
                    handleVisibilityChange(
                      e.target.checked,
                      subSection.sectionId,
                    )
                  }
                  onClick={(e) => e.stopPropagation()}
                />
              }
            />
            <Typography
              alignItems='center'
              variant='h5'
              dangerouslySetInnerHTML={{
                __html: subSection.label,
              }}
              sx={{
                ml: 2,
                color: subSection.visible ? 'inherit' : 'rgba(0, 0, 0, 0.5)',
              }}
            />
          </Stack>
        </AccordionSummary>
        <AccordionDetails>
          {subSection.subSectionReferences &&
            subSection.subSectionReferences.length > 0 && (
              <>
                <Divider />
                <Stack
                  direction='column'
                  sx={{mt: 1, borderRadius: 4, padding: 2}}
                >
                  {renderSubSections(
                    subSection.subSectionReferences,
                    subSection.visible && parentVisible,
                  )}
                </Stack>
              </>
            )}
        </AccordionDetails>
      </Accordion>
    ));
  };

  return (
    <Accordion
      sx={{
        width: '100%',
        backgroundColor: '#d7e8d3',
        border: '1px solid #ccc',
        mt: 2,
      }}
      defaultExpanded
    >
      <AccordionSummary
        expandIcon={<ExpandMoreIcon />}
        aria-controls='outer-section-content'
        id='outer-section-header'
        sx={{backgroundColor: '#d7e8d3'}}
      >
        <Typography variant='h4' sx={{ml: 5}}>
          {name}
        </Typography>
      </AccordionSummary>
      <AccordionDetails sx={{backgroundColor: '#d7e8d3'}}>
        <Stack
          id='addEnrollmentStack'
          direction='column'
          sx={{mt: 2, ml: 3}}
          justifyContent='center'
          alignItems='flex-start'
          spacing={2}
        >
          {localData?.map((section, sectionIndex) => (
            <Accordion
              key={sectionIndex}
              sx={{
                width: '100%',
                backgroundColor: '#edf5ef', // Your existing background color
                border: '1px solid #ccc',
              }}
              defaultExpanded
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls={`section-content-${sectionIndex}`}
                id={`section-header-${sectionIndex}`}
                sx={{backgroundColor: '#edf5ef'}} // Match your existing background color
              >
                <Stack
                  direction='row'
                  spacing={2}
                  alignItems='center'
                  sx={{ml: 5}}
                >
                  <FormControlLabel
                    control={
                      <Checkbox
                        name={`visible`}
                        checked={section.visible}
                        onChange={(e) =>
                          handleVisibilityChange(
                            e.target.checked,
                            section.sectionId,
                          )
                        }
                        onClick={(e) => e.stopPropagation()}
                      />
                    }
                  />
                  <Typography
                    variant='h4'
                    dangerouslySetInnerHTML={{
                      __html: section.label,
                    }}
                    sx={{
                      ml: 2,
                      color: section.visible ? 'inherit' : 'rgba(0, 0, 0, 0.5)',
                    }}
                  />
                </Stack>
              </AccordionSummary>
              <AccordionDetails sx={{backgroundColor: '#edf5ef'}}>
                {section.subSectionReferences &&
                  section.subSectionReferences.length > 0 && (
                    <>
                      <Divider />
                      <Stack
                        direction='column'
                        sx={{mt: 1, borderRadius: 4, padding: 2}}
                      >
                        {renderSubSections(
                          section.subSectionReferences,
                          section.visible,
                        )}
                      </Stack>
                    </>
                  )}
              </AccordionDetails>
            </Accordion>
          ))}
        </Stack>
      </AccordionDetails>
    </Accordion>
  );
};

export default ReferenceFormConfig;
