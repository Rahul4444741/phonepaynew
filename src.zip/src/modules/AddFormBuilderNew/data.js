export const dropdownData = {
  coding: [
    {
      id: 1,
      name: 'Not Demonstrated',
    },
    {
      id: 2,
      name: 'Is able to write SQL queries of low to moderate complexity. Performs exploratory analysis of data to understand distributions and correlations and is able to create visualizations (using line/bar charts, histograms, pivot tables, etc.) and use them to explain findings.',
    },
    {
      id: 3,
      name: 'Understands more advanced concepts in statistics that are used in data science such as distributions, moments, hypothesis testing. Is able to independently determine the right tools and techniques to use for simpler analyses. Is aware of the right practices in writing SQL queries and the impact of query structure on runtime performance. Exhibits awareness of probabilistic approaches to querying and when they can be used.',
    },
    {
      id: 4,
      name: 'Has a solid grounding in the probability and statistics that data science work requires. Understands frequentist and Bayesian approaches, and the formal notions behind moments and parameter estimations. Understands techniques for parameter estimation and can guide junior members to use the appropriate techniques.',
    },
    {
      id: 5,
      name: 'Understands how data science algorithms (e.g., regression) make assumptions about data, and are able to utilize the right algorithms for the requirement. Understands statistical aspects behind algorithms and the design of experiments and how they can be used to generate reliable results. Is able to determine the most appropriate algorithms, and understand the applicability of results obtained with respect to their validity, reliability, and generality. Is able to guide members of other teams for any analytical requirements. Is able to independently explain and present your analysis to members of other pods, and answer their questions.',
    },
    {
      id: 6,
      name: 'Aware of the advances in tools and techniques in analysis and statistics. Writes model SQL queries for others to emulate. Defines the right practices for exploratory analysis and presentation and educates team members. Able to identify techniques that can help across pods at an organizational level, and ensure that they become a standard part of projects and workflows.',
    },
  ],
  design: [
    {id: 1, name: 'Not Demonstrated'},
    {
      id: 2,
      name: 'Has know-how in scripting, coding, and is able to gain context of the tasks assigned i.e. by having understanding around scaling up structures, setting up nodes and multiple application support environment',
    },
    {
      id: 3,
      name: 'Expertise in logging infrastructure, contributing into the config management system, containerizing our system etc. Learns technical know-how quickly from peers and various platforms to support the environment',
    },
    {
      id: 4,
      name: 'Has subject matter expertise in 1 or 2 areas, such that efficiently manages the databases to stay up and operate effectively. e.g. Handles OS Upgrades by creating a parallel cluster and ensures the system uptime and working of the databases',
    },
    {
      id: 5,
      name: 'Demonstrates as the subject matter expert 1 or 2 areas and supports solutioning on the same across multiple horizontal complexities',
    },
    {
      id: 6,
      name: 'Demonstrates expertise in critical technical areas, and has overall understanding on databases and systems. Provides proactive guidance to improve the availability and performance of the system.',
    },
    {id: 7, name: 'I have no view on the parameter'},
  ],
  understanding_systems: [
    {id: 1, name: 'Not Demonstrated'},
    {
      id: 2,
      name: 'Understands the entire topology and acts as an ultimate escalation point for critical issues that have not yet been documented as Standard Operating Procedures (SOPs). Also has in-depth know-how on SRE philosophy, technologies, platforms and tools, SLA management, incident resolution, and automation',
    },
    {
      id: 3,
      name: 'Technically sounds with larger and complex philosophies/platforms of DevOps, Cloud Services, IT Infrastructure and Operations, server builds, firewalls, security and regulatory compliance',
    },
    {
      id: 4,
      name: 'Envisions impact of all systems through in-depth understanding of technology across SRE. Has experience of building systems, processes, and teams to support rapid business and system traffic growth',
    },
    {
      id: 5,
      name: 'Holds the responsibility of bigger and complex picture on how the systems across SRE in Phone Pe talk to each other',
    },
    {id: 6, name: 'I have no view on the parameter'},
  ],
};
