import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { isEmptyNullUndefined } from 'shared/utils/CommonUtils';
import { Divider } from '@mui/material';
const parse = require('html-react-parser');

// ReadMoreLess Component
const ReadMoreLess = ({ text }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const toggleReadMore = () => setIsExpanded(!isExpanded);

  if (text.length <= 150) {
    return <div>{parse(text)}</div>;
  }

  return (
    <div>
      {isExpanded ? parse(text) : parse(text.slice(0, 150) + '...')}
      <button onClick={toggleReadMore} className="read-more-less">
        {isExpanded ? 'Read Less' : 'Read More'}
      </button>
    </div>
  );
};

// Helper function to render feedback
const renderFeedback = (feedback) => (
  <div key={feedback.employeeId} className="emp-response">
    <div className="text-responses">
      {!isEmptyNullUndefined(feedback?.responseObject?.responseString) && (
        <ReadMoreLess text={feedback?.responseObject?.responseString} />
      )}
      {!isEmptyNullUndefined(feedback?.responseObject?.responseBoolean) &&
        (feedback?.responseObject?.responseBoolean ? 'Yes' : 'No')}
      {!isEmptyNullUndefined(feedback?.responseObject?.responseInteger) &&
        feedback?.responseObject?.responseInteger}
    </div>
    {!isEmptyNullUndefined(feedback?.responseObject?.rating?.name) && (
      <div className="ratings">
        Rating: {feedback?.responseObject?.rating?.name}
      </div>
    )}
    {!isEmptyNullUndefined(feedback?.responseObject?.selection) && (
      <div className="selections">
        {feedback?.responseObject?.selection?.map((selected, index) => (
          <div key={index} className="selected-value">
            {selected?.name}
          </div>
        ))}
      </div>
    )}
  </div>
);

// Helper function to render sections and subsections
const renderSubSection = (subSection) => (
  <div key={subSection?.id} className="sub-section-main">
    <div
      className="question-label"
      dangerouslySetInnerHTML={{ __html: subSection?.label }}
    />
    {subSection?.subSectionReferences &&
      subSection?.subSectionReferences?.filter((nsub) => nsub?.visible).map(renderSubSection)}
    {subSection?.feedbacks && (
      <div className="feedback-text">
        {subSection?.feedbacks?.map(renderFeedback)}
      </div>
    )}
    <Divider />
  </div>
);

const EmpAssesmentStatic = ({ data }) => {
  console.log('EmpAssesmentStatic data:', data);

  return (
    <div className="assessment-show-in-sidebar">
      <div className="main-heading">Self Assessment</div>
      {data?.filter((section) => section?.visible).map((section) => (
        <div key={section?.id} className="section-main">
          <div
            className="section-label"
            dangerouslySetInnerHTML={{ __html: section?.label }}
          />
          {section?.subSectionReferences
            ? section?.subSectionReferences
                ?.filter((subSection) => subSection?.visible)
                .map(renderSubSection)
            : section?.feedbacks && (
                <div className="feedback-text">
                  {section?.feedbacks?.map(renderFeedback)}
                </div>
              )}
        </div>
      ))}
    </div>
  );
};

EmpAssesmentStatic.propTypes = {
  data: PropTypes.array,
};

export default EmpAssesmentStatic;


// import React, {useState} from 'react';
// import PropTypes from 'prop-types';
// import {isEmptyNullUndefined} from 'shared/utils/CommonUtils';
// import { Divider } from '@mui/material';

// const parse = require('html-react-parser');

// const EmpAssesmentStatic = ({data}) => {
//   console.log('EmpAssesmentStatic data:', data);

//   const ReadMoreLess = ({text}) => {
//     const [isExpanded, setIsExpanded] = useState(false);
//     const toggleReadMore = () => setIsExpanded(!isExpanded);

//     if (text.length <= 150) {
//       return <div>{parse(text)}</div>;
//     }

//     return (
//       <div>
//         {isExpanded ? parse(text) : parse(text.slice(0, 150) + '...')}
//         <button onClick={toggleReadMore} className='read-more-less'>
//           {isExpanded ? 'Read Less' : 'Read More'}
//         </button>
//       </div>
//     );
//   };

//   return (
//     <div className='assessment-show-in-sidebar'>
//       <div className='main-heading'>Self Assessment</div>
//       {data
//         ?.filter((section) => section?.visible)
//         .map((section) => {
//           console.log('Rendering section:', section);
//           return (
//             <div key={section?.id} className='section-main'>
//               <div
//                 className='section-label'
//                 dangerouslySetInnerHTML={{__html: section?.label}}
//               />
//               {!isEmptyNullUndefined(section?.subSectionReferences) ? (
//                 section?.subSectionReferences
//                   ?.filter((subSection) => subSection?.visible)
//                   .map((subSection) => {
//                     console.log('Rendering subSection:', subSection);
//                     return (
//                       <div key={subSection?.id} className='sub-section-main'>
//                         <div
//                           className='question-label'
//                           dangerouslySetInnerHTML={{__html: subSection?.label}}
//                         />
//                         {/* ******************************************************* */}
//                         {!isEmptyNullUndefined(
//                           subSection?.subSectionReferences,
//                         ) ? (
//                           subSection?.subSectionReferences
//                             ?.filter((nsubSection) => nsubSection?.visible)
//                             .map((nsubSection) => {
//                               console.log('Rendering subSection:', subSection);
//                               return (
//                                 <div
//                                   key={nsubSection?.id}
//                                   className='sub-section-main'
//                                 >
//                                   <div
//                                     className='question-label'
//                                     dangerouslySetInnerHTML={{
//                                       __html: nsubSection?.label,
//                                     }}
//                                   />
//                                   {nsubSection?.feedbacks && (
//                                     <div className='feedback-text'>
//                                       {nsubSection?.feedbacks?.map(
//                                         (feedback, index) => {
//                                           return (
//                                             <div
//                                               key={feedback.employeeId || index}
//                                               className='emp-response'
//                                             >
//                                               <div className='text-responses'>
//                                                 {!isEmptyNullUndefined(
//                                                   feedback?.responseObject
//                                                     ?.responseString,
//                                                 ) &&
//                                                   feedback?.responseObject
//                                                     ?.responseString?.length >
//                                                     0 && (
//                                                     <ReadMoreLess
//                                                       text={
//                                                         feedback?.responseObject
//                                                           ?.responseString
//                                                       }
//                                                     />
//                                                   )}
//                                                 {!isEmptyNullUndefined(
//                                                   feedback?.responseObject
//                                                     ?.responseBoolean,
//                                                 )
//                                                   ? feedback?.responseObject
//                                                       ?.responseBoolean
//                                                     ? 'Yes'
//                                                     : 'No'
//                                                   : ''}
//                                                 {!isEmptyNullUndefined(
//                                                   feedback?.responseObject
//                                                     ?.responseInteger,
//                                                 ) &&
//                                                   feedback?.responseObject
//                                                     ?.responseInteger}
//                                               </div>
//                                               {!isEmptyNullUndefined(
//                                                 feedback?.responseObject?.rating
//                                                   ?.name,
//                                               ) && (
//                                                 <div className='ratings'>
//                                                   Rating :{' '}
//                                                   {
//                                                     feedback?.responseObject
//                                                       ?.rating?.name
//                                                   }
//                                                 </div>
//                                               )}
//                                               {!isEmptyNullUndefined(
//                                                 feedback?.responseObject
//                                                   ?.selection,
//                                               ) && (
//                                                 <div className='selections'>
//                                                   {feedback?.responseObject?.selection?.map(
//                                                     (selected, sIndex) => {
//                                                       return (
//                                                         <div className='selected-value'>
//                                                           {selected?.name}
//                                                         </div>
//                                                       );
//                                                     },
//                                                   )}
//                                                 </div>
//                                               )}
//                                             </div>
//                                           );
//                                         },
//                                       )}
//                                     </div>
//                                   )}
//                                 </div>
//                               );
//                             })
//                         ) : (
//                           <div className='sub-section-main'>
//                             {/* <div className="question-label" dangerouslySetInnerHTML={{ __html: section?.label }} /> */}
//                             {section?.feedbacks && (
//                               <div className='feedback-text'>
//                                 {section?.feedbacks?.map((feedback, index) => {
//                                   return (
//                                     <div
//                                       key={feedback.employeeId || index}
//                                       className='emp-response'
//                                     >
//                                       <div className='text-responses'>
//                                         {!isEmptyNullUndefined(
//                                           feedback?.responseObject
//                                             ?.responseString,
//                                         ) &&
//                                           feedback?.responseObject
//                                             ?.responseString?.length > 0 && (
//                                             <ReadMoreLess
//                                               text={
//                                                 feedback?.responseObject
//                                                   ?.responseString
//                                               }
//                                             />
//                                           )}
//                                         {!isEmptyNullUndefined(
//                                           feedback?.responseObject
//                                             ?.responseBoolean,
//                                         )
//                                           ? feedback?.responseObject
//                                               ?.responseBoolean
//                                             ? 'Yes'
//                                             : 'No'
//                                           : ''}
//                                         {!isEmptyNullUndefined(
//                                           feedback?.responseObject
//                                             ?.responseInteger,
//                                         ) &&
//                                           feedback?.responseObject
//                                             ?.responseInteger}
//                                       </div>
//                                       {!isEmptyNullUndefined(
//                                         feedback?.responseObject?.rating?.name,
//                                       ) && (
//                                         <div className='ratings'>
//                                           Rating :{' '}
//                                           {
//                                             feedback?.responseObject?.rating
//                                               ?.name
//                                           }
//                                         </div>
//                                       )}
//                                       {!isEmptyNullUndefined(
//                                         feedback?.responseObject?.selection,
//                                       ) && (
//                                         <div className='selections'>
//                                           {feedback?.responseObject?.selection?.map(
//                                             (selected, sIndex) => {
//                                               return (
//                                                 <div className='selected-value'>
//                                                   {selected?.name}
//                                                 </div>
//                                               );
//                                             },
//                                           )}
//                                         </div>
//                                       )}
//                                     </div>
//                                   );
//                                 })}
//                               </div>
//                             )}
//                           </div>
//                         )}
//                         {/* ******************************************************* */}
//                         <Divider/>
//                         {subSection?.feedbacks && (
//                           <div className='feedback-text'>
//                             {subSection?.feedbacks?.map((feedback, index) => {
//                               return (
//                                 <div
//                                   key={feedback.employeeId || index}
//                                   className='emp-response'
//                                 >
//                                   <div className='text-responses'>
//                                     {!isEmptyNullUndefined(
//                                       feedback?.responseObject?.responseString,
//                                     ) &&
//                                       feedback?.responseObject?.responseString
//                                         ?.length > 0 && (
//                                         <ReadMoreLess
//                                           text={
//                                             feedback?.responseObject
//                                               ?.responseString
//                                           }
//                                         />
//                                       )}
//                                     {!isEmptyNullUndefined(
//                                       feedback?.responseObject?.responseBoolean,
//                                     )
//                                       ? feedback?.responseObject
//                                           ?.responseBoolean
//                                         ? 'Yes'
//                                         : 'No'
//                                       : ''}
//                                     {!isEmptyNullUndefined(
//                                       feedback?.responseObject?.responseInteger,
//                                     ) &&
//                                       feedback?.responseObject?.responseInteger}
//                                   </div>
//                                   {!isEmptyNullUndefined(
//                                     feedback?.responseObject?.rating?.name,
//                                   ) && (
//                                     <div className='ratings'>
//                                       Rating :{' '}
//                                       {feedback?.responseObject?.rating?.name}
//                                     </div>
//                                   )}
//                                   {!isEmptyNullUndefined(
//                                     feedback?.responseObject?.selection,
//                                   ) && (
//                                     <div className='selections'>
//                                       {feedback?.responseObject?.selection?.map(
//                                         (selected, sIndex) => {
//                                           return (
//                                             <div className='selected-value'>
//                                               {selected?.name}
//                                             </div>
//                                           );
//                                         },
//                                       )}
//                                     </div>
//                                   )}
//                                 </div>
//                               );
//                             })}
//                           </div>
//                         )}
//                       </div>
//                     );
//                   })
//               ) : (
//                 <div className='sub-section-main'>
//                   {/* <div className="question-label" dangerouslySetInnerHTML={{ __html: section?.label }} /> */}
//                   {section?.feedbacks && (
//                     <div className='feedback-text'>
//                       {section?.feedbacks?.map((feedback, index) => {
//                         return (
//                           <div
//                             key={feedback.employeeId || index}
//                             className='emp-response'
//                           >
//                             <div className='text-responses'>
//                               {!isEmptyNullUndefined(
//                                 feedback?.responseObject?.responseString,
//                               ) &&
//                                 feedback?.responseObject?.responseString
//                                   ?.length > 0 && (
//                                   <ReadMoreLess
//                                     text={
//                                       feedback?.responseObject?.responseString
//                                     }
//                                   />
//                                 )}
//                               {!isEmptyNullUndefined(
//                                 feedback?.responseObject?.responseBoolean,
//                               )
//                                 ? feedback?.responseObject?.responseBoolean
//                                   ? 'Yes'
//                                   : 'No'
//                                 : ''}
//                               {!isEmptyNullUndefined(
//                                 feedback?.responseObject?.responseInteger,
//                               ) && feedback?.responseObject?.responseInteger}
//                             </div>
//                             {!isEmptyNullUndefined(
//                               feedback?.responseObject?.rating?.name,
//                             ) && (
//                               <div className='ratings'>
//                                 Rating :{' '}
//                                 {feedback?.responseObject?.rating?.name}
//                               </div>
//                             )}
//                             {!isEmptyNullUndefined(
//                               feedback?.responseObject?.selection,
//                             ) && (
//                               <div className='selections'>
//                                 {feedback?.responseObject?.selection?.map(
//                                   (selected, sIndex) => {
//                                     return (
//                                       <div className='selected-value'>
//                                         {selected?.name}
//                                       </div>
//                                     );
//                                   },
//                                 )}
//                               </div>
//                             )}
//                           </div>
//                         );
//                       })}
//                     </div>
//                   )}
//                 </div>
//               )}
//             </div>
//           );
//         })}
//     </div>
//   );
// };

// EmpAssesmentStatic.propTypes = {
//   data: PropTypes.array,
// };

// export default EmpAssesmentStatic;
