import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../@crema/core/AppAnimate';
import {AppCard, AppInfoView} from '../../@crema';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import AppPageMeta from '../../@crema/core/AppPageMeta';
import MenuItem from '@mui/material/MenuItem';
import EditIcon from '@mui/icons-material/Edit';
import AlertDialog from '../Common/AlertDialog';
import {
  CardContent,
  Select,
  Switch,
  TextField,
  Divider,
  FormControl,
  FormLabel,
  FormControlLabel,
  InputLabel,
  RadioGroup,
  Radio,
} from '@mui/material';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import DeleteIcon from '@mui/icons-material/Delete';
import {useDispatch, useSelector} from 'react-redux';
import Skeleton from '@mui/material/Skeleton';
import Box from '@mui/material/Box';
import FormPage from './FormPage';
import {showInfo, showMessage, fetchError} from '../../redux/actions';
import Typography from '@mui/material/Typography';

import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {useState, useEffect, useCallback} from 'react';
import {
  apiCatchErrorMessage,
  handleAlertNo,
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';
import {footerButton} from 'shared/constants/AppConst';
////////////// Accordion /////////////
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import {styled} from '@mui/material/styles';
import MuiAccordion from '@mui/material/Accordion';
import MuiAccordionSummary from '@mui/material/AccordionSummary';
import MuiAccordionDetails from '@mui/material/AccordionDetails';
import ArrowForwardIosSharpIcon from '@mui/icons-material/ArrowForwardIosSharp';
import 'suneditor/dist/css/suneditor.min.css';
import PreviewPage from './PreviewPage';
import {DragDropContext, Droppable, Draggable} from '@hello-pangea/dnd';
import IntlMessages from '@crema/utility/IntlMessages';
import axios from 'axios';
import {useRouter} from 'next/router';
import {fieldRequired} from '../../shared/utils/CommonUtils';
import {managerRefferedSection} from 'shared/demoApi/formBuilder';
import ReferenceFormConfig from './ReferenceFormConfig';

const iconButtonStyled = {padding: '2px 10px'};

const Accordion = styled((props) => (
  <MuiAccordion disableGutters elevation={0} square {...props} />
))(({theme}) => ({
  border: `1px solid ${theme.palette.divider}`,
  '&:not(:last-child)': {
    borderBottom: 0,
  },
  '&:before': {
    display: 'none',
  },
}));

const AccordionDetails = styled(MuiAccordionDetails)(({theme}) => ({
  padding: theme.spacing(2),
  borderTop: '1px solid rgba(0, 0, 0, .125)',
}));

const AccordionSummary = styled((props) => (
  <MuiAccordionSummary
    expandIcon={<ArrowForwardIosSharpIcon sx={{fontSize: '0.9rem'}} />}
    {...props}
  />
))(({theme}) => ({
  backgroundColor:
    theme.palette.mode === 'dark'
      ? 'rgba(255, 255, 255, .05)'
      : 'rgba(0, 0, 0, .03)',
  flexDirection: 'row-reverse',
  '& .MuiAccordionSummary-expandIconWrapper.Mui-expanded': {
    transform: 'rotate(90deg)',
  },
  '& .MuiAccordionSummary-content': {
    marginLeft: theme.spacing(1),
  },
}));

const textFieldStyled = {
  backgroundColor: 'white',
  mb: 2,
  width: {xs: '100%', xl: '60%', md: '75%'},
};

const getItemStyle = (isDragging, draggableStyle) => ({
  background: isDragging ? '#C8E6C9' : 'white',
  boxShadow: isDragging ? '0 0 .4rem #666' : 'none',
  ...draggableStyle,
  userSelect: 'none',
});

const initialFormForList = [
  {
    key: 'Self_Assesment',
    value: 'SelfAppraisal',
    name: 'Self Assesment',
  },
  {
    key: 'Manager_feedback',
    value: 'ManagerFeedBack',
    name: 'Manager feedback',
  },
  {
    key: 'Peer_Feedback',
    value: 'PeerFeedBack',
    name: 'Peer Feedback',
  },
];

const FormBuilderNew = () => {
  const history = useRouter();
  const router = useRouter();
  const {id, replica, view} = router.query;
  const dispatch = useDispatch();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const [formPageId, setFormPageId] = React.useState(null);
  const [isEdit, setIsEdit] = React.useState(false);
  const [expanded, setExpanded] = React.useState(false);
  const [formForList, setFormForList] = useState(initialFormForList);
  const [isLoading, setIsLoading] = useState(true);
  const [accordianTabExpended, setAccordianTabExpended] = useState(false);
  const [accordianTileExpended, setAccordianTileExpended] = useState(false);
  const [expandedTile, setExpandedTile] = React.useState(false);
  const [expandedNestedSubSection, setExpandedNestedSubSection] =
    React.useState(false);
  const [sections, setSections] = useState([]);
  const [drowerFormIsOpen, setDrowerFormIsOpen] = React.useState(false);
  const [selectedSectionForEdit, setSelectedSectionForEdit] = useState({
    nestedSubSection: null,
    tile: null,
    tab: null,
  });
  const [formFor, setFormFor] = React.useState(null);
  const [isPaginationRequired, setIsPaginationRequired] = React.useState(false);
  const [valuesData, setValuesData] = React.useState(null);
  const [ratingsData, setRatingData] = React.useState(null);
  const [
    SelfAppraisalReferredSectionsData,
    setSelfAppraisalReferredSectionsData,
  ] = React.useState(null);
  const [PeerReferredSectionsData, setPeerReferredSectionsData] =
    React.useState(null);
  const [pmsCycle, setPmsCycle] = React.useState(null);
  const [displayName, setDisplayName] = React.useState(null);
  const [isPreviewPageOpen, setIsPreviewPageOpen] = useState(false);
  const [alertProps, setAlertProps] = React.useState({
    isHideShow: false,
    message: '',
    title: '',
    alertType: '',
    actionParams: null,
  });
  const [status, setStatus] = React.useState(null);
  const [isDraft, setIsDraft] = React.useState(null);

  const [refferedSelfAppraisalFormData, setRefferedSelfAppraisalFormData] =
    React.useState(null);
  const [refferedPeerFeedbackFormData, setRefferedPeerFeedbackFormData] =
    React.useState(null);
  const [refferedSelfAppraisalForm, setRefferedSelfAppraisalForm] =
    React.useState(null);
  const [refferedPeerFeedbackForm, setRefferedPeerFeedbackForm] =
    React.useState(null);

  const [showSelfAppraisal, setShowSelfAppraisal] = React.useState(false);
  const [showPeerFeedback, setShowPeerFeedback] = React.useState(false);
  const [selfAppraisalUpdatedSection, setSelfAppraisalUpdatedSection] =
    React.useState(null);
  const [peerFeedbackUpdatedSection, setPeerFeedbackUpdatedSection] =
    React.useState(null);

  useEffect(() => {
    getBackendData();
    if (id) {
      getSavedFormData(id);
    } else if (replica) {
      getReplicaFormData(replica);
    } else if (view) {
      getSavedFormData(view);
    }
  }, []);

  const getBackendData = () => {
    const getAllActiveValues = async (companyId) => {
      setIsLoading(() => true);
      try {
        const res = await jwtAxios.get(
          `${API_ROUTS.employeeValue_companyID}${companyId}?status=ACTIVE`,
        );
        if (res.status == 200) {
          if (res.data.length == 0) {
            dispatch(showInfo('You have no value for selected company'));
            setValuesData([]);
          } else {
            setValuesData(res.data);
          }
          setIsLoading(() => false);
        } else {
          setValuesData([]);
          setIsLoading(() => false);
        }
      } catch (error) {
        console.log('error from 223')
        if (axios.isCancel(error)) {
        } else {
          apiCatchErrorMessage(error, dispatch, fetchError);
        }
        setValuesData([]);
        setIsLoading(() => false);
      }
    };
    const getAllActiveRatings = async (companyId) => {
      setIsLoading(() => true);
      try {
        const res = await jwtAxios.get(
          `${API_ROUTS.ratings}/companyID/${companyId}?status=ACTIVE`,
        );
        if (res.status == 200) {
          if (res.data.length == 0) {
            dispatch(showInfo('You have no value for selected company'));
            setRatingData([]);
          } else {
            setRatingData(res.data);
          }
          setIsLoading(() => false);
        } else {
          setRatingData([]);
          setIsLoading(() => false);
        }
      } catch (error) {
        console.log('error from 251')
        if (axios.isCancel(error)) {
        } else {
          apiCatchErrorMessage(error, dispatch, fetchError);
        }
        setRatingData([]);
        setIsLoading(() => false);
      }
    };

    const getAllRefferedSelfAppraisalFormData = async (companyId) => {
      setIsLoading(() => true);
      try {
        const res = await jwtAxios.get(
          `${API_ROUTS.assessment_all_by_formfor_and_company_new(
            'SelfAppraisal',
            companyId,
          )}`,
        );
        if (res.status == 200) {
          if (res.data.length == 0) {
            dispatch(
              showInfo('You have no self appraisal form for selected company'),
            );
            setRefferedSelfAppraisalFormData([]);
          } else {
            setRefferedSelfAppraisalFormData(res.data);
          }
          setIsLoading(() => false);
        } else {
          setRefferedSelfAppraisalFormData([]);
          setIsLoading(() => false);
        }
      } catch (error) {
        console.log('error from 285')
        if (axios.isCancel(error)) {
        } else {
          apiCatchErrorMessage(error, dispatch, fetchError);
        }
        setRefferedSelfAppraisalFormData([]);
        setIsLoading(() => false);
      }
    };
    const getAllRefferedPeerFeedbackFormData = async (companyId) => {
      setIsLoading(() => true);
      try {
        const res = await jwtAxios.get(
          `${API_ROUTS.assessment_all_by_formfor_and_company_new(
            'PeerFeedBack',
            companyId,
          )}`,
        );
        if (res.status == 200) {
          if (res.data.length == 0) {
            dispatch(
              showInfo('You have no peer feedback form for selected company'),
            );
            setRefferedPeerFeedbackFormData([]);
          } else {
            setRefferedPeerFeedbackFormData(res.data);
          }
          setIsLoading(() => false);
        } else {
          setRefferedPeerFeedbackFormData([]);
          setIsLoading(() => false);
        }
      } catch (error) {
        console.log('error from 318')
        if (axios.isCancel(error)) {
        } else {
          apiCatchErrorMessage(error, dispatch, fetchError);
        }
        setRefferedPeerFeedbackFormData([]);
        setIsLoading(() => false);
      }
    };
    getAllActiveValues(selectedCompany.id);
    getAllActiveRatings(selectedCompany.id);
    getAllRefferedSelfAppraisalFormData(selectedCompany.id);
    getAllRefferedPeerFeedbackFormData(selectedCompany.id);
  };

  const updateVisibilityToNull = (sections) => {
    return sections.map((section) => {
      section.visible = null;

      // Recursively update subsections
      if (
        section.subSectionReferences &&
        section.subSectionReferences.length > 0
      ) {
        section.subSectionReferences = updateVisibilityToNull(
          section.subSectionReferences,
        );
      }

      return section;
    });
  };

  const getAllSelfAppraisalReferredSections = async (formID) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.assessment_referred_sections_by_formId_new(formID)}`,
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(
            showInfo('You have no referred sections for selected company'),
          );
          setSelfAppraisalReferredSectionsData([]);
        } else {
          // setSelfAppraisalReferredSectionsData(res.data);
          // Apply the visibility update
          const tempResponse = updateVisibilityToNull(res.data);
          setSelfAppraisalReferredSectionsData(tempResponse);
        }
        setIsLoading(() => false);
      } else {
        setSelfAppraisalReferredSectionsData([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      console.log('error from 375')
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setSelfAppraisalReferredSectionsData([]);
      setIsLoading(() => false);
    }
  };
  const getAllPeerReferredSections = async (formID) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.assessment_referred_sections_by_formId_new(formID)}`,
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(
            showInfo('You have no referred sections for selected company'),
          );
          setPeerReferredSectionsData([]);
        } else {
          // setPeerReferredSectionsData(res.data);

          const tempResponse = updateVisibilityToNull(res.data);
          setPeerReferredSectionsData(tempResponse);
        }
        setIsLoading(() => false);
      } else {
        setPeerReferredSectionsData([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      console.log('error from 407')
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setPeerReferredSectionsData([]);
      setIsLoading(() => false);
    }
  };

  const getSavedFormData = (id) => {
    const getFormData = async () => {
      setIsLoading(() => true);
      try {
        const response = await jwtAxios.get(`${API_ROUTS.assessmentNew}/${id}`);
        if (response.status == 200) {
          if (response?.data) {
            setSections(() => response?.data?.sections);
            setIsEdit(() => true);
            setFormPageId(() => response?.data?.id);
            setIsPaginationRequired(response?.data?.isPaginationRequired);
            setFormFor(() => response?.data?.formFor);
            setIsLoading(() => false);
            setStatus(() => response?.data?.status);
            setPmsCycle(() => response?.data.pmsCycle);
            setDisplayName(() => response?.data?.displayName);
            setIsDraft(response?.data?.isDraft);
            if (response?.data?.formFor == 'ManagerFeedBack') {
              if (
                !isEmptyNullUndefined(
                  response?.data?.refferedSelfAppraisalForm?.id,
                )
              ) {
                getAllSelfAppraisalReferredSections(
                  response?.data?.refferedSelfAppraisalForm?.id,
                );
              }else{
                console.log('id not found for refferedSelfAppraisalForm ')
              }
              if (
                !isEmptyNullUndefined(
                  response?.data?.refferedPeerFeedbackForm?.id,
                )
              ) {
                getAllPeerReferredSections(
                  response?.data?.refferedPeerFeedbackForm?.id,
                );
              }else{
                console.log('id not found for refferedPeerFeedbackForm ')
              }
              setShowPeerFeedback(response?.data?.showPeerFeedback);

              setShowSelfAppraisal(response?.data?.showSelfAppraisal);

              setSelfAppraisalReferredSectionsData(
                response?.data?.referenceEmployeeSections,
              );
              setPeerReferredSectionsData(
                response?.data?.referencePeerSections,
              );

              setRefferedSelfAppraisalForm(
                response?.data?.refferedSelfAppraisalForm,
              );
              setRefferedPeerFeedbackForm(
                response?.data?.refferedPeerFeedbackForm,
              );
            }
          } else {
            setSections(() => []);
            setIsEdit(() => false);
            setFormPageId(() => null);
            setIsPaginationRequired(false);
            setIsLoading(() => false);
          }
        } else {
          setSections(() => []);
          setIsEdit(() => false);
          setFormPageId(() => null);
          setIsPaginationRequired(false);
          setIsLoading(() => false);
        }
      } catch (error) {
        console.log('error from 485')
        apiCatchErrorMessage(error, dispatch, fetchError);
        setSections(() => []);
        setIsEdit(() => false);
        setFormPageId(() => null);
        setIsPaginationRequired(false);
        setIsLoading(() => false);
      }
    };
    getFormData();
  };

  const getReplicaFormData = (replica) => {
    const getFormData = async () => {
      setIsLoading(() => true);
      try {
        const response = await jwtAxios.get(
          `${API_ROUTS.assessmentNew}/${replica}`,
        );
        if (response.status == 200) {
          if (response?.data) {
            const tempSection = RemovereferredAppraisalPeerFeedback(
              response?.data?.sections,
            );
            setSections(() => tempSection);
            setIsPaginationRequired(response?.data?.isPaginationRequired);
            setFormFor(() => response?.data?.formFor);
            setIsLoading(() => false);
            setStatus(() => 'INACTIVE');
            setPmsCycle(() => response?.data.pmsCycle);
            setDisplayName(() => response?.data?.displayName);
            if (response?.data?.formFor == 'ManagerFeedBack') {
              if(!isEmptyNullUndefined(response?.data?.refferedSelfAppraisalForm?.id)){
              getAllSelfAppraisalReferredSections(
                response?.data?.refferedSelfAppraisalForm?.id,
              );
            }
            if(!isEmptyNullUndefined(response?.data?.refferedPeerFeedbackForm?.id)){
              getAllPeerReferredSections(
                response?.data?.refferedPeerFeedbackForm?.id,
              );
            }
              setRefferedSelfAppraisalForm(
                response?.data?.refferedSelfAppraisalForm,
              );
              setRefferedPeerFeedbackForm(
                response?.data?.refferedPeerFeedbackForm,
              );
              setShowPeerFeedback(response?.data?.showPeerFeedback);
              setShowSelfAppraisal(response?.data?.showSelfAppraisal);

              const tempReferenceEmployeeSections = updateIdsToNull(
                response?.data?.referenceEmployeeSections,
              );
              setSelfAppraisalReferredSectionsData(
                tempReferenceEmployeeSections,
              );

              const tempReferencePeerSections = updateIdsToNull(
                response?.data?.referencePeerSections,
              );
              setPeerReferredSectionsData(tempReferencePeerSections);
            }
          } else {
            setSections(() => []);
            setIsEdit(() => false);
            setFormPageId(() => null);
            setIsPaginationRequired(false);
            setIsLoading(() => false);
          }
        } else {
          setSections(() => []);
          setIsEdit(() => false);
          setFormPageId(() => null);
          setIsPaginationRequired(false);
          setIsLoading(() => false);
        }
      } catch (error) {
        console.log('error from 563')
        apiCatchErrorMessage(error, dispatch, fetchError);
        setSections(() => []);
        setIsEdit(() => false);
        setFormPageId(() => null);
        setIsPaginationRequired(false);
        setIsLoading(() => false);
      }
    };
    getFormData();
  };

  const updateIdsToNull = (sections) => {
    return sections.map((section) => {
      // Set the section's id to null
      section.id = null;

      // If there are subsections, recursively set their ids to null
      if (
        section.subSectionReferences &&
        section.subSectionReferences.length > 0
      ) {
        section.subSectionReferences = updateIdsToNull(
          section.subSectionReferences,
        );
      }

      return section;
    });
  };

  const rawTab = {
    sequenceNumber: null,
    configObj: {
      doesThisQuestionHaveSelection: null, //bool
      selectionType: null, //single or multiple
      selectableValues: [], // {id: null, name: null, status: null, company: null}
      selectableRatings: null,
      doesThisQuestionHaveResponse: null, //bool
      responseType: null, //string
      isInfoRequired: null, //bool
      info: null, //string Additional information
      minCharacterLimit: null, //integer
      maxCharacterLimit: null, //int
      isSelectionMandatory: null, //bool
      isResponseMandatory: null, //bool
      isRatingMandatory: null, //bool
      label: null, // new added for question or section label
      arePresetLabelsAdded: null,
      isRatingPartOfPMS: null,
      isRatingRequired: null,
      isWeightageRequired: null,
      overallSectionalRatingRequired: null,
    },
    subSections: [],
    assessmentResponseObjectDTO: {
      responseString: null,
      responseBoolean: null,
      responseInteger: null,
      selection: [],
      rating: null,
    },
    referenceEmployeeSections: null,
    referencePeerSections: null,
  };

  const rawTile = (tileLength) => {
    return {
      sequenceNumber: null,
      configObj: {
        doesThisQuestionHaveSelection: null, //bool
        selectionType: null, //single or multiple
        selectableValues: [], // {id: null, name: null, status: null, company: null}
        selectableRatings: null,
        doesThisQuestionHaveResponse: null, //bool
        responseType: null, //string
        isInfoRequired: null, //bool
        info: null, //string Additional information
        minCharacterLimit: null, //integer
        maxCharacterLimit: null, //int
        isSelectionMandatory: null, //bool
        isResponseMandatory: null, //bool
        isRatingMandatory: null,
        label: null, // new added for question or section label
        arePresetLabelsAdded: null,
        isRatingPartOfPMS: null,
        isRatingRequired: null,
        isWeightageRequired: null,
        overallSectionalRatingRequired: null,
      },
      subSections: [],
      assessmentResponseObjectDTO: {
        responseString: null,
        responseBoolean: null,
        responseInteger: null,
        selection: [],
        rating: null,
      },
      referenceEmployeeSections: null,
      referencePeerSections: null,
    };
  };

  const rawNestedSubSection = () => {
    return {
      sequenceNumber: null,
      configObj: {
        doesThisQuestionHaveSelection: null, //bool
        selectionType: null, //single or multiple
        selectableValues: [], // {id: null, name: null, status: null, company: null}
        selectableRatings: null,
        doesThisQuestionHaveResponse: null, //bool
        responseType: null, //string
        isInfoRequired: null, //bool
        info: null, //string Additional information
        minCharacterLimit: null, //integer
        maxCharacterLimit: null, //int
        isSelectionMandatory: null, //bool
        isResponseMandatory: null, //bool
        isRatingMandatory: null,
        label: null, // new added for question or section label
        arePresetLabelsAdded: null,
        isRatingPartOfPMS: null,
        isRatingRequired: null,
        isWeightageRequired: null,
        overallSectionalRatingRequired: null,
      },
      assessmentResponseObjectDTO: {
        responseString: null,
        responseBoolean: null,
        responseInteger: null,
        selection: [],
        rating: null,
      },
      referenceEmployeeSections: null,
      referencePeerSections: null,
    };
  };

  const handleInsertTab = (tempTabs) => {
    tempTabs.push(rawTab);
    setSections(() => tempTabs);
  };

  const handleChange = (panel) => (event, isExpanded) => {
    if (isExpanded) {
      setAccordianTabExpended(() => true);
      setTimeout(() => {
        setExpanded(isExpanded ? panel : false);
      }, 250);
    } else {
      setExpanded(isExpanded ? panel : false);
      setTimeout(() => {
        setAccordianTabExpended(() => false);
      }, 400);
    }
  };

  const handleChangeTile = (panel) => (event, expandedTile) => {
    if (expandedTile) {
      setAccordianTileExpended(() => true);
      setTimeout(() => {
        setExpandedTile(expandedTile ? panel : false);
      }, 250);
    } else {
      setExpandedTile(expandedTile ? panel : false);
      setTimeout(() => {
        setAccordianTileExpended(() => false);
      }, 400);
    }
  };

  const handleChangeNestedSubSection =
    (panel) => (event, expandedNestedSubSection) => {
      setExpandedNestedSubSection(expandedNestedSubSection ? panel : false);
    };

  const onDragEndTab = (result) => {
    if (!result.destination) {
      return;
    }
    let tempSections = structuredClone(sections);

    let selectedSections = result.draggableId.split('-')[1];

    let movedItems = reorder(
      tempSections,
      result.source.index,
      result.destination.index,
    );

    tempSections = movedItems;
    setSections(() => tempSections);
  };

  const onDragEndNestedSubSection = (result) => {
    if (!result.destination) {
      return;
    }
    let tempSections = structuredClone(sections);

    let selectedSections = result.draggableId.split('-')[1];
    let selectedTile = result.draggableId.split('-')[3];
    let selectedNestedSubSection = result.draggableId.split('-')[5];

    let movedItems = reorder(
      tempSections[selectedSections].subSections[selectedTile].subSections,
      result.source.index,
      result.destination.index,
    );

    tempSections[selectedSections].subSections[selectedTile].subSections =
      movedItems;
    setSections(() => tempSections);
  };

  const onDragEnd = (result) => {
    if (!result.destination) {
      return;
    }
    let tempSections = structuredClone(sections);

    let selectedSections = result.draggableId.split('-')[3];

    let movedItems = reorder(
      tempSections[selectedSections].subSections,
      result.source.index,
      result.destination.index,
    );

    tempSections[selectedSections].subSections = movedItems;
    setSections(() => tempSections);
  };

  const reorder = (list, startIndex, endIndex) => {
    const result = Array.from(list);
    const [removed] = result.splice(startIndex, 1);
    result.splice(endIndex, 0, removed);
    return result;
  };

  const handleInsertTile = (tabIndex, tempSubSections) => {
    const tempSections = structuredClone(sections);
    if (tempSubSections == null) {
      tempSubSections = [];
    }

    tempSubSections.push(rawTile());

    tempSections[tabIndex].subSections = tempSubSections;

    setSections(() => tempSections);
  };

  const handleInsertNestedSubSection = (
    tabIndex,
    tileIndex,
    tempNestedSubSection,
  ) => {
    const tempSections = structuredClone(sections);

    if (tempNestedSubSection == null) {
      tempNestedSubSection = [];
    }

    tempNestedSubSection.push(rawNestedSubSection());

    tempSections[tabIndex].subSections[tileIndex].subSections =
      tempNestedSubSection;

    setSections(() => tempSections);
  };

  const handleAlertYes = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.actionParams();
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };

  const handleSubmitAlert = ({isDraft, submitupdateFormPage}) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'submit';
    tempAlertProps.title = 'Are you sure you want to submit ?';
    tempAlertProps.message = (
      <span>
        {isDraft
          ? `form will save as draft.`
          : `Once you submit form for current cycle can't do any changes until PMS cycle ends !`}
      </span>
    );
    tempAlertProps.actionParams = submitupdateFormPage;
    setAlertProps(tempAlertProps);
  };

  const handleUpdateAlert = ({isDraft, submitupdateFormPage}) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'update';
    tempAlertProps.title = 'Update';
    tempAlertProps.message = (
      <span>
        {isDraft
          ? `form will save as draft.`
          : `Are you sure you want to update ?`}
      </span>
    );
    tempAlertProps.actionParams = submitupdateFormPage;
    setAlertProps(tempAlertProps);
  };

  const handleAlertForDeleteRow = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'delete-row';
    tempAlertProps.title = 'Delete';
    tempAlertProps.message = <span>Are you sure you want to delete row ?</span>;
    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };

  const handleDeleteTab = (index) => {
    const tempSections = structuredClone(sections);
    tempSections.splice(index, 1);
    setSections(() => tempSections);
  };

  const handleDeleteTile = (tabIndex, tileIndex, tempTile, tempSections) => {
    tempTile.splice(tileIndex, 1);

    tempSections[tabIndex].subSections = tempTile;

    setSections(() => tempSections);
  };

  const handleDeleteNestedSubSection = (
    tabIndex,
    tileIndex,
    nestedSubSectionIndex,
    tempNestedSubSection,
    tempTile,
    tempSections,
  ) => {
    tempNestedSubSection.splice(nestedSubSectionIndex, 1);

    tempSections[tabIndex].subSections[tileIndex].subSections =
      tempNestedSubSection;

    setSections(() => tempSections);
  };

  const toggleDrawer = (isOpen) => {
    setDrowerFormIsOpen(isOpen);
  };

  const handlerDrawerFormOpen = (index, tileIndex, nestedSubSectionIndex) => {
    if (tileIndex == undefined && nestedSubSectionIndex == undefined) {
      setSelectedSectionForEdit({
        tab: index,
        tile: null,
        nestedSubSection: null,
      });
    } else if (nestedSubSectionIndex == undefined) {
      setSelectedSectionForEdit({
        tab: index,
        tile: tileIndex,
        nestedSubSection: null,
      });
    } else {
      setSelectedSectionForEdit({
        tab: index,
        tile: tileIndex,
        nestedSubSection: nestedSubSectionIndex,
      });
    }
    toggleDrawer(true);
  };

  const handlerDrawerFormClose = (
    configObj,
    referenceEmployeeSections,
    referencePeerSections,
  ) => {
    toggleDrawer(() => false);
    setSelectedSectionForEdit({
      tab: null,
      tile: null,
      nestedSubSection: null,
    });
    if (
      !isEmptyNullUndefined(configObj) ||
      !isEmptyNullUndefined(referenceEmployeeSections) ||
      !isEmptyNullUndefined(referencePeerSections)
    ) {
      handleSetFormDataToSection(
        configObj,
        referenceEmployeeSections,
        referencePeerSections,
      );
    }
  };

  const checkIsThisValidRow = (row) => {
    let isValid = true;
    if (isEmptyNullUndefined(row.configObj.label)) {
      isValid = false;
    } else {
      if (row?.subSections) {
        if (!row.subSections.length) {
          if (
            row.configObj.doesThisQuestionHaveSelection == true ||
            row.configObj.doesThisQuestionHaveSelection == 'true'
          ) {
            if (
              isEmptyNullUndefined(row.configObj.selectionType) ||
              isEmptyNullUndefined(row.configObj.selectableValues)
            ) {
              isValid = false;
            }
          }
          if (
            row.configObj.doesThisQuestionHaveResponse == true ||
            row.configObj.doesThisQuestionHaveResponse == 'true'
          ) {
            if (isEmptyNullUndefined(row.configObj.responseType)) {
              isValid = false;
            }
          }
          if (
            row.configObj.isRatingRequired == true ||
            row.configObj.isRatingRequired == 'true'
          ) {
            if (isEmptyNullUndefined(row.configObj.selectableRatings)) {
              isValid = false;
            }
          }
          if (formFor === 'ManagerFeedBack') {
            if (
              row.configObj.showPeerFeedback == true ||
              row.configObj.showPeerFeedback == 'true'
            ) {
              if (isEmptyNullUndefined(row.referencePeerSections)) {
                isValid = false;
              }
            }
          }

          if (formFor === 'ManagerFeedBack') {
            if (
              row.configObj.showEmployeeSelfAppraisal == true ||
              row.configObj.showEmployeeSelfAppraisal == 'true'
            ) {
              if (isEmptyNullUndefined(row.referenceEmployeeSections)) {
                isValid = false;
              }
            }
          }
        }
      } else {
        if (
          row.configObj.doesThisQuestionHaveSelection == true ||
          row.configObj.doesThisQuestionHaveSelection == 'true'
        ) {
          if (
            isEmptyNullUndefined(row.configObj.selectionType) ||
            isEmptyNullUndefined(row.configObj.selectableValues)
          ) {
            isValid = false;
          }
        }
        if (
          row.configObj.doesThisQuestionHaveResponse == true ||
          row.configObj.doesThisQuestionHaveResponse == 'true'
        ) {
          if (isEmptyNullUndefined(row.configObj.responseType)) {
            isValid = false;
          }
        }
        if (
          row.configObj.isRatingRequired == true ||
          row.configObj.isRatingRequired == 'true'
        ) {
          if (isEmptyNullUndefined(row.configObj.selectableRatings)) {
            isValid = false;
          }
        }
        if (formFor === 'ManagerFeedBack') {
          if (
            row.configObj.showPeerFeedback == true ||
            row.configObj.showPeerFeedback == 'true'
          ) {
            if (isEmptyNullUndefined(row.referencePeerSections)) {
              isValid = false;
            }
          }
        }
        if (formFor === 'ManagerFeedBack') {
          if (
            row.configObj.showEmployeeSelfAppraisal == true ||
            row.configObj.showEmployeeSelfAppraisal == 'true'
          ) {
            if (isEmptyNullUndefined(row.referenceEmployeeSections)) {
              isValid = false;
            }
          }
        }
      }
    }
    return isValid;
  };

  const rowBorder = (expanded, panelIndex, row) => {
    let rowBorder = '';
    let rowBoxShadow = '';

    if (!checkIsThisValidRow(row)) {
      rowBorder = '1px solid rgba(237, 37, 37, 1)';
      rowBoxShadow = 'rgb(95 48 18) 2px 2px 5px';
    } else {
      let isAllSubSectionConfigObjIsValid = true;
      if (row?.subSections) {
        if (row.subSections.length) {
          row.subSections.some((letTileE) => {
            if (!checkIsThisValidRow(letTileE)) {
              isAllSubSectionConfigObjIsValid = false;
            } else if (letTileE?.subSections) {
              if (letTileE.subSections.length) {
                letTileE.subSections.some((letNestedSubSectionE) => {
                  if (!checkIsThisValidRow(letNestedSubSectionE)) {
                    isAllSubSectionConfigObjIsValid = false;
                  }
                });
              }
            }
          });
        }
      }
      if (!isAllSubSectionConfigObjIsValid) {
        rowBorder = '1px solid rgba(237, 37, 37, 1)';
        rowBoxShadow = 'rgb(95 48 18) 2px 2px 5px';
      } else {
        if (expanded === panelIndex) {
          rowBorder = '5px solid rgba(0, 0, 0, 0.12)';
          rowBoxShadow = 'rgba(0, 0, 0, 0.35) 0px 5px 15px';
        } else {
          rowBorder = '1px solid rgba(0, 0, 0, 0.12)';
          rowBoxShadow = '';
        }
      }
    }
    return {
      boxShadow: rowBoxShadow,
      border: rowBorder,
    };
  };

  const handleSetFormDataToSection = (
    configObj,
    referenceEmployeeSections,
    referencePeerSections,
  ) => {
    const tempSections = {...sections};
    if (
      selectedSectionForEdit.nestedSubSection == null &&
      selectedSectionForEdit.tile == null
    ) {
      tempSections[selectedSectionForEdit.tab].configObj = configObj;
      if (
        configObj.showEmployeeSelfAppraisal == false ||
        configObj.showEmployeeSelfAppraisal == 'false'
      ) {
        tempSections[selectedSectionForEdit.tab].referenceEmployeeSections =
          null;
      }
      if (!isEmptyNullUndefined(referenceEmployeeSections)) {
        tempSections[selectedSectionForEdit.tab].referenceEmployeeSections =
          referenceEmployeeSections;
      }
      if (
        configObj.showPeerFeedback == false ||
        configObj.showPeerFeedback == 'false'
      ) {
        tempSections[selectedSectionForEdit.tab].referencePeerSections = null;
      }
      if (!isEmptyNullUndefined(referencePeerSections)) {
        tempSections[selectedSectionForEdit.tab].referencePeerSections =
          referencePeerSections;
      }
    } else if (selectedSectionForEdit.nestedSubSection == null) {
      tempSections[selectedSectionForEdit.tab].subSections[
        selectedSectionForEdit.tile
      ].configObj = configObj;
      if (
        configObj.showEmployeeSelfAppraisal == false ||
        configObj.showEmployeeSelfAppraisal == 'false'
      ) {
        tempSections[selectedSectionForEdit.tab].subSections[
          selectedSectionForEdit.tile
        ].referenceEmployeeSections = null;
      }
      if (!isEmptyNullUndefined(referenceEmployeeSections)) {
        tempSections[selectedSectionForEdit.tab].subSections[
          selectedSectionForEdit.tile
        ].referenceEmployeeSections = referenceEmployeeSections;
      }
      if (
        configObj.showPeerFeedback == false ||
        configObj.showPeerFeedback == 'false'
      ) {
        tempSections[selectedSectionForEdit.tab].subSections[
          selectedSectionForEdit.tile
        ].referencePeerSections = null;
      }
      if (!isEmptyNullUndefined(referencePeerSections)) {
        tempSections[selectedSectionForEdit.tab].subSections[
          selectedSectionForEdit.tile
        ].referencePeerSections = referencePeerSections;
      }
    } else {
      tempSections[selectedSectionForEdit.tab].subSections[
        selectedSectionForEdit.tile
      ].subSections[selectedSectionForEdit.nestedSubSection].configObj =
        configObj;
      // tempSections[selectedSectionForEdit.tab].configObj = configObj;

      if (
        configObj.showEmployeeSelfAppraisal == false ||
        configObj.showEmployeeSelfAppraisal == 'false'
      ) {
        tempSections[selectedSectionForEdit.tab].subSections[
          selectedSectionForEdit.tile
        ].subSections[
          selectedSectionForEdit.nestedSubSection
        ].referenceEmployeeSections = null;
      }

      if (!isEmptyNullUndefined(referenceEmployeeSections)) {
        tempSections[selectedSectionForEdit.tab].subSections[
          selectedSectionForEdit.tile
        ].subSections[
          selectedSectionForEdit.nestedSubSection
        ].referenceEmployeeSections = referenceEmployeeSections;
      }

      if (
        configObj.showPeerFeedback == false ||
        configObj.showPeerFeedback == 'false'
      ) {
        tempSections[selectedSectionForEdit.tab].subSections[
          selectedSectionForEdit.tile
        ].subSections[
          selectedSectionForEdit.nestedSubSection
        ].referencePeerSections = null;
      }

      if (!isEmptyNullUndefined(referencePeerSections)) {
        tempSections[selectedSectionForEdit.tab].subSections[
          selectedSectionForEdit.tile
        ].subSections[
          selectedSectionForEdit.nestedSubSection
        ].referencePeerSections = referencePeerSections;
      }
    }
    setSections(() => sections);
  };

  const handleClosePreviewPage = () => {
    setIsPreviewPageOpen(false);
  };
  const handleOpenPreviewPage = () => {
    setIsPreviewPageOpen(true);
  };

  const handleValidateBeforeSubmit = (isDraft) => {
    let isValid = true;

    ////////// here validate condition ///////
    if (sections.length) {
      sections.some((tabElement) => {
        if (!checkIsThisValidRow(tabElement)) {
          isValid = false;
        }
        if (tabElement?.subSections) {
          if (tabElement.subSections.length) {
            tabElement.subSections.some((tileElement) => {
              if (!checkIsThisValidRow(tileElement)) {
                isValid = false;
              }
              if (tileElement?.subSections) {
                if (tileElement.subSections.length) {
                  tileElement.subSections.some((nestedSubSection) => {
                    if (!checkIsThisValidRow(nestedSubSection)) {
                      isValid = false;
                    }
                  });
                }
              }
            });
          }
        }
      });
    }

    const handleFormAction = (isEdit, isDraft) => {
      if (isEdit) {
        handleUpdateAlert({
          isDraft,
          submitupdateFormPage: () => updateFormPage(isDraft),
        });
      } else {
        handleSubmitAlert({
          isDraft,
          submitupdateFormPage: () => submitFormPage(isDraft),
        });
      }
    };

    if (isDraft) {
      handleFormAction(isEdit, isDraft);
    } else if (isValid) {
      handleFormAction(isEdit, isDraft);
    } else {
      dispatch(fetchError('Please fill all mandatory field.'));
    }
  };

  const removeId = (section) => {
    section.forEach((item) => {
      delete item?.id;
      delete item?.assessmentResponseObjectDTO?.id;
      delete item?.configObj?.id;
      if (item?.subSections) {
        item?.subSections.forEach((subSectionsItem) => {
          delete subSectionsItem?.id;
          delete subSectionsItem?.assessmentResponseObjectDTO?.id;
          delete subSectionsItem?.configObj?.id;
          if (subSectionsItem?.subSections) {
            subSectionsItem.subSections.forEach((nestedSubSectionItem) => {
              delete nestedSubSectionItem?.id;
              delete nestedSubSectionItem?.assessmentResponseObjectDTO?.id;
              delete nestedSubSectionItem?.configObj?.id;
            });
          }
        });
      }
    });
    return section;
  };

  const RemovereferredAppraisalPeerFeedback = (sections) => {
    sections.forEach((item) => {
      item.referenceEmployeeSections = null;
      item.referencePeerSections = null;
      item.configObj.showEmployeeSelfAppraisal = null;
      item.configObj.showPeerFeedback = null;
      if (item?.subSections) {
        item?.subSections.forEach((subSectionsItem) => {
          subSectionsItem.referenceEmployeeSections = null;
          subSectionsItem.referencePeerSections = null;
          subSectionsItem.configObj.showEmployeeSelfAppraisal = null;
          subSectionsItem.configObj.showPeerFeedback = null;
          if (subSectionsItem?.subSections) {
            subSectionsItem.subSections.forEach((nestedSubSectionItem) => {
              nestedSubSectionItem.referenceEmployeeSections = null;
              nestedSubSectionItem.referencePeerSections = null;
              nestedSubSectionItem.configObj.showEmployeeSelfAppraisal = null;
              nestedSubSectionItem.configObj.showPeerFeedback = null;
            });
          }
        });
      }
    });
    return sections;
  };

  const submitFormPage = async (isDraft) => {
    setIsLoading(true);
    let tempSections = structuredClone(sections);
    const payload = {
      isPaginationRequired: isPaginationRequired,
      status: isDraft ? 'INACTIVE' : 'ACTIVE',
      isDraft: isDraft ? true : false,
      formFor: formFor,
      company: {id: selectedCompany.id},
      sections: replica ? removeId(tempSections) : tempSections,
      pmsCycle: pmsCycle,
      displayName: displayName,

      refferedSelfAppraisalForm: refferedSelfAppraisalForm,
      refferedPeerFeedbackForm: refferedPeerFeedbackForm,
      showSelfAppraisal: showSelfAppraisal,
      showPeerFeedback: showPeerFeedback,
      referenceEmployeeSections:
        showSelfAppraisal == true || showSelfAppraisal == 'true'
          ? selfAppraisalUpdatedSection
          : null,
      referencePeerSections:
        showPeerFeedback == true || showPeerFeedback == 'true'
          ? peerFeedbackUpdatedSection
          : null,
    };
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.assessmentNew}`,
        payload,
      );
      if (response.status == 201) {
        dispatch(
          showMessage(
            `${response?.data?.displayName} ${response?.data?.formFor} ${
              isDraft
                ? 'Feedback form saved as draft successfully'
                : 'Form Page added successfully..!'
            }`,
          ),
        );
        history.push('/form-builder-new');
      }
    } catch (error) {
      console.log('error from 1387')
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
    setIsLoading(false);
  };

  const updateFormPage = async (isDraft) => {
    setIsLoading(true);
    let tempSections = structuredClone(sections);
    const payload = {
      isPaginationRequired: isPaginationRequired,
      status: isDraft ? 'INACTIVE' : 'ACTIVE',
      isDraft: isDraft ? true : false,
      formFor: formFor,
      company: {id: selectedCompany.id},
      sections: tempSections,
      id: formPageId,
      pmsCycle: pmsCycle,
      displayName: displayName,

      refferedSelfAppraisalForm: refferedSelfAppraisalForm,
      refferedPeerFeedbackForm: refferedPeerFeedbackForm,
      showSelfAppraisal: showSelfAppraisal,
      showPeerFeedback: showPeerFeedback,
      referenceEmployeeSections:
        showSelfAppraisal == true || showSelfAppraisal == 'true'
          ? selfAppraisalUpdatedSection
          : null,
      referencePeerSections:
        showPeerFeedback == true || showPeerFeedback == 'true'
          ? peerFeedbackUpdatedSection
          : null,
    };
    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.assessmentNew}/${formPageId}`,
        payload,
      );
      if (response.status == 201) {
        dispatch(
          showMessage(
            `${response?.data?.displayName} ${response?.data?.formFor} ${
              isDraft
                ? 'Feedback form saved as draft successfully'
                : 'Form Page updated successfully..!'
            }`,
          ),
        );
        history.push('/form-builder-new');
      }
    } catch (error) {
      console.log('error from 1438')
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
    setIsLoading(false);
  };

  const createDomTabNotExpended = () => {
    return (
      <DragDropContext onDragEnd={onDragEndTab}>
        <Droppable style={{transform: 'none'}} droppableId='droppable'>
          {(provided, snapshot) => (
            <Stack
              spacing={4}
              // marginLeft={7}
              {...provided.droppableProps}
              ref={provided.innerRef}
            >
              {sections?.map((row, index) => (
                <Draggable
                  id={`sections-index-${index}`}
                  key={'sections-key' + index}
                  draggableId={'r-' + index}
                  index={index}
                >
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      {...provided.dragHandleProps}
                      style={getItemStyle(
                        snapshot.isDragging,
                        provided.draggableProps.style,
                      )}
                    >
                      <AppCard key={'sections-' + index}>
                        <Box>
                          <Accordion
                            id={`sections-Accordion-row-${index}`}
                            expanded={expanded === `panel${index}`}
                            onChange={handleChange(`panel${index}`)}
                            sx={rowBorder(expanded, `panel${index}`, row)}
                          >
                            <AccordionSummary
                              expandIcon={<ExpandMoreIcon />}
                              aria-controls='panel1bh-content'
                              id={`learn-page-accordionSummary-tabIndex-${index}}`}
                              sx={{
                                '& .MuiAccordionSummary-content': {
                                  justifyContent: 'space-between',
                                },
                              }}
                            >
                              <div style={{width: '90%', overflow: 'hidden'}}>
                                {/* <Typography sx={{flexShrink: 0}}>
                                    {`${
                                      sections[index]?.configObj?.label?.slice(
                                        0,
                                        100,
                                      ) || 'Section ' + (index + 1)
                                    }`}
                                  </Typography> */}
                                <div
                                  dangerouslySetInnerHTML={{
                                    __html:
                                      sections[index]?.configObj?.label?.slice(
                                        0,
                                        100,
                                      ) || 'Section ' + (index + 1),
                                  }}
                                ></div>
                              </div>
                              <div>
                                <DeleteIcon
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleAlertForDeleteRow(() =>
                                      handleDeleteTab(index),
                                    );
                                  }}
                                />
                                <EditIcon
                                  sx={{
                                    color: !checkIsThisValidRow(row)
                                      ? 'rgb(255, 64, 0)'
                                      : 'rgb(17, 24, 39)',
                                  }}
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handlerDrawerFormOpen(index);
                                  }}
                                />
                              </div>
                            </AccordionSummary>
                            <AccordionDetails
                              id={`learn-page-AccordionDetails-tabIndex-${index}}`}
                            ></AccordionDetails>
                          </Accordion>
                        </Box>
                      </AppCard>
                    </div>
                  )}
                </Draggable>
              ))}

              {provided.placeholder}
            </Stack>
          )}
        </Droppable>
      </DragDropContext>
    );
  };

  const createDomTabExpended = () => {
    return (
      <>
        {sections?.map((row, index) => (
          <AppCard key={'sections-' + index}>
            <Box>
              <Accordion
                id={`sections-Accordion-row-${index}`}
                expanded={expanded === `panel${index}`}
                onChange={handleChange(`panel${index}`)}
                sx={rowBorder(expanded, `panel${index}`, row)}
              >
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls='panel1bh-content'
                  id={`learn-page-accordionSummary-tabIndex-${index}}`}
                  sx={{
                    '& .MuiAccordionSummary-content': {
                      justifyContent: 'space-between',
                    },
                  }}
                >
                  <div style={{width: '90%', overflow: 'hidden'}}>
                    {/* <Typography sx={{width: '90%', flexShrink: 0}}>
                      {`${
                        sections[index]?.configObj?.label?.slice(0, 100) ||
                        'Section ' + (index + 1)
                      }`}
                    </Typography> */}
                    <div
                      dangerouslySetInnerHTML={{
                        __html:
                          sections[index]?.configObj?.label?.slice(0, 100) ||
                          'Section ' + (index + 1),
                      }}
                    ></div>
                  </div>
                  <div>
                    {expanded === `panel${index}` && (
                      <AddCircleOutlineIcon
                        onClick={(e) => {
                          e.stopPropagation();
                          handleInsertTile(
                            index,
                            structuredClone(sections[index].subSections),
                          );
                        }}
                      />
                    )}

                    <DeleteIcon
                      onClick={(e) => {
                        e.stopPropagation();
                        handleAlertForDeleteRow(() => handleDeleteTab(index));
                      }}
                    />
                    <EditIcon
                      sx={{
                        color: !checkIsThisValidRow(row)
                          ? 'rgb(255, 64, 0)'
                          : 'rgb(17, 24, 39)',
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        handlerDrawerFormOpen(index);
                      }}
                    />
                  </div>
                </AccordionSummary>
                <AccordionDetails
                  id={`learn-page-AccordionDetails-tabIndex-${index}}`}
                >
                  <Stack
                    direction='row'
                    sx={{m: 2}}
                    justifyContent={'space-between'}
                    spacing={2}
                  ></Stack>
                  <DragDropContext onDragEnd={onDragEnd}>
                    <Droppable
                      style={{transform: 'none'}}
                      droppableId='droppable'
                    >
                      {(provided, snapshot) => (
                        <Stack
                          spacing={4}
                          marginLeft={7}
                          {...provided.droppableProps}
                          ref={provided.innerRef}
                        >
                          {row?.subSections?.map((tileRow, tileIndex) => (
                            <Draggable
                              id={`tile-draggable-tile-index-${tileIndex}`}
                              key={'key' + tileIndex}
                              draggableId={
                                'r-' + tileIndex + '-sections-' + index
                              }
                              index={tileIndex}
                            >
                              {(provided, snapshot) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.draggableProps}
                                  {...provided.dragHandleProps}
                                  style={getItemStyle(
                                    snapshot.isDragging,
                                    provided.draggableProps.style,
                                  )}
                                >
                                  <Accordion
                                    id={
                                      'Accordion-tile-' +
                                      '-tileIndex-' +
                                      tileIndex
                                    }
                                    key={
                                      'sections-' + index + '-tile-' + tileIndex
                                    }
                                    expanded={
                                      expandedTile === `panel1${tileIndex}`
                                    }
                                    onChange={handleChangeTile(
                                      `panel1${tileIndex}`,
                                    )}
                                    sx={rowBorder(
                                      expandedTile,
                                      `panel1${tileIndex}`,
                                      tileRow,
                                    )}
                                  >
                                    <AccordionSummary
                                      expandIcon={<ExpandMoreIcon />}
                                      aria-controls='panel1bh-content'
                                      id={`learn-page-accordion-summary-tile-index-${tileIndex}`}
                                      sx={{
                                        '& .MuiAccordionSummary-content': {
                                          justifyContent: 'space-between',
                                        },
                                      }}
                                    >
                                      <div
                                        style={{
                                          width: '90%',
                                          overflow: 'hidden',
                                        }}
                                      >
                                        {/* <Typography
                                          sx={{width: '33%', flexShrink: 0}}
                                        >
                                          {`${
                                            sections[index]?.subSections[
                                              tileIndex
                                            ]?.configObj?.label?.slice(
                                              0,
                                              100,
                                            ) ||
                                            'Sub-Section ' + (tileIndex + 1)
                                          }`}
                                        </Typography> */}
                                        <div
                                          dangerouslySetInnerHTML={{
                                            __html:
                                              sections[index]?.subSections[
                                                tileIndex
                                              ]?.configObj?.label?.slice(
                                                0,
                                                100,
                                              ) ||
                                              'Sub-Section ' + (tileIndex + 1),
                                          }}
                                        ></div>
                                      </div>
                                      <div>
                                        {expandedTile ===
                                          `panel1${tileIndex}` && (
                                          <AddCircleOutlineIcon
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              handleInsertNestedSubSection(
                                                index,
                                                tileIndex,
                                                structuredClone(
                                                  sections[index].subSections[
                                                    tileIndex
                                                  ].subSections,
                                                ),
                                              );
                                            }}
                                          />
                                        )}

                                        <DeleteIcon
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            handleAlertForDeleteRow(() =>
                                              handleDeleteTile(
                                                index,
                                                tileIndex,
                                                structuredClone(
                                                  sections[index].subSections,
                                                ),
                                                structuredClone(sections),
                                              ),
                                            );
                                          }}
                                        />
                                        <EditIcon
                                          sx={{
                                            color: !checkIsThisValidRow(tileRow)
                                              ? 'rgb(255, 64, 0)'
                                              : 'rgb(17, 24, 39)',
                                          }}
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            handlerDrawerFormOpen(
                                              index,
                                              tileIndex,
                                            );
                                          }}
                                        />
                                      </div>
                                    </AccordionSummary>
                                    <AccordionDetails
                                      sx={{marginLeft: 7}}
                                      id={`learn-page-AccordionDetails-tile-tileIndex-${tileIndex}`}
                                    >
                                      {tileRow?.subSections?.map(
                                        (
                                          nestedSubSectionRow,
                                          nestedSubSectionIndex,
                                        ) => (
                                          <Accordion
                                            id={
                                              'Accordion-tile-' +
                                              '-nestedSubSectionIndex-' +
                                              nestedSubSectionIndex
                                            }
                                            key={
                                              'sections-' +
                                              index +
                                              '-tile-' +
                                              nestedSubSectionIndex
                                            }
                                            // expanded={
                                            //   expandedNestedSubSection === `panel1${nestedSubSectionIndex}`
                                            // }
                                            expanded={false}
                                            // onChange={handleChangeNestedSubSection(
                                            //   `panel1${nestedSubSectionIndex}`,
                                            // )}
                                            sx={rowBorder(
                                              expandedNestedSubSection,
                                              `panel1${nestedSubSectionIndex}`,
                                              nestedSubSectionRow,
                                            )}
                                          >
                                            <AccordionSummary
                                              expandIcon={<ExpandMoreIcon />}
                                              aria-controls='panel1bh-content'
                                              id={`learn-page-accordion-summary-tile-index-${nestedSubSectionIndex}`}
                                              sx={{
                                                '& .MuiAccordionSummary-content':
                                                  {
                                                    justifyContent:
                                                      'space-between',
                                                  },
                                              }}
                                            >
                                              <div
                                                style={{
                                                  width: '90%',
                                                  overflow: 'hidden',
                                                }}
                                              >
                                                {/* <Typography
                                                  sx={{
                                                    width: '33%',
                                                    flexShrink: 0,
                                                  }}
                                                >
                                                  {`${
                                                    sections[
                                                      index
                                                    ]?.subSections[
                                                      nestedSubSectionIndex
                                                    ]?.configObj?.label?.slice(
                                                      0,
                                                      100,
                                                    ) ||
                                                    'Sub-Section ' +
                                                      (nestedSubSectionIndex +
                                                        1)
                                                  }`}
                                                </Typography> */}
                                                <div
                                                  dangerouslySetInnerHTML={{
                                                    __html:
                                                      sections[
                                                        index
                                                      ]?.subSections[
                                                        nestedSubSectionIndex
                                                      ]?.configObj?.label?.slice(
                                                        0,
                                                        100,
                                                      ) ||
                                                      'Sub-Section ' +
                                                        (nestedSubSectionIndex +
                                                          1),
                                                  }}
                                                ></div>
                                              </div>
                                              <div>
                                                <DeleteIcon
                                                  onClick={(e) => {
                                                    e.stopPropagation();
                                                    handleAlertForDeleteRow(
                                                      () =>
                                                        handleDeleteNestedSubSection(
                                                          index,
                                                          tileIndex,
                                                          nestedSubSectionIndex,
                                                          structuredClone(
                                                            sections[index]
                                                              .subSections[
                                                              tileIndex
                                                            ].subSections,
                                                          ),
                                                          structuredClone(
                                                            sections[index]
                                                              .subSections,
                                                          ),
                                                          structuredClone(
                                                            sections,
                                                          ),
                                                        ),
                                                    );
                                                  }}
                                                />
                                                <EditIcon
                                                  sx={{
                                                    color: !checkIsThisValidRow(
                                                      nestedSubSectionRow,
                                                    )
                                                      ? 'rgb(255, 64, 0)'
                                                      : 'rgb(17, 24, 39)',
                                                  }}
                                                  onClick={(e) => {
                                                    e.stopPropagation();
                                                    handlerDrawerFormOpen(
                                                      index,
                                                      tileIndex,
                                                      nestedSubSectionIndex,
                                                    );
                                                  }}
                                                />
                                              </div>
                                            </AccordionSummary>
                                            <AccordionDetails
                                              id={`learn-page-AccordionDetails-tile-nestedSubSectionIndex-${nestedSubSectionIndex}`}
                                            ></AccordionDetails>
                                          </Accordion>
                                        ),
                                      )}
                                    </AccordionDetails>
                                  </Accordion>
                                </div>
                              )}
                            </Draggable>
                          ))}

                          {provided.placeholder}
                        </Stack>
                      )}
                    </Droppable>
                  </DragDropContext>
                </AccordionDetails>
              </Accordion>
            </Box>
          </AppCard>
        ))}
      </>
    );
  };

  const createDomTileExpended = () => {
    return (
      <>
        {sections?.map((row, index) => (
          <AppCard key={'sections-' + index}>
            <Box>
              <Accordion
                id={`sections-Accordion-row-${index}`}
                expanded={expanded === `panel${index}`}
                onChange={handleChange(`panel${index}`)}
                sx={rowBorder(expanded, `panel${index}`, row)}
              >
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls='panel1bh-content'
                  id={`learn-page-accordionSummary-tabIndex-${index}}`}
                  sx={{
                    '& .MuiAccordionSummary-content': {
                      justifyContent: 'space-between',
                    },
                  }}
                >
                  <div style={{width: '90%', overflow: 'hidden'}}>
                    <div
                      dangerouslySetInnerHTML={{
                        __html:
                          sections[index]?.configObj?.label?.slice(0, 100) ||
                          'Section ' + (index + 1),
                      }}
                    ></div>
                  </div>
                  <div>
                    {expanded === `panel${index}` && (
                      <AddCircleOutlineIcon
                        onClick={(e) => {
                          e.stopPropagation();
                          handleInsertTile(
                            index,
                            structuredClone(sections[index].subSections),
                          );
                        }}
                      />
                    )}

                    <DeleteIcon
                      onClick={(e) => {
                        e.stopPropagation();
                        handleAlertForDeleteRow(() => handleDeleteTab(index));
                      }}
                    />
                    <EditIcon
                      sx={{
                        color: !checkIsThisValidRow(row)
                          ? 'rgb(255, 64, 0)'
                          : 'rgb(17, 24, 39)',
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        handlerDrawerFormOpen(index);
                      }}
                    />
                  </div>
                </AccordionSummary>
                <AccordionDetails
                  id={`learn-page-AccordionDetails-tabIndex-${index}}`}
                >
                  <Stack
                    direction='row'
                    sx={{m: 2}}
                    justifyContent={'space-between'}
                    spacing={2}
                  ></Stack>
                  <Stack spacing={4} marginLeft={7}>
                    {row?.subSections?.map((tileRow, tileIndex) => (
                      <Accordion
                        id={'Accordion-tile-' + '-tileIndex-' + tileIndex}
                        key={'sections-' + index + '-tile-' + tileIndex}
                        expanded={expandedTile === `panel1${tileIndex}`}
                        onChange={handleChangeTile(`panel1${tileIndex}`)}
                        sx={rowBorder(
                          expandedTile,
                          `panel1${tileIndex}`,
                          tileRow,
                        )}
                      >
                        <AccordionSummary
                          expandIcon={<ExpandMoreIcon />}
                          aria-controls='panel1bh-content'
                          id={`learn-page-accordion-summary-tile-index-${tileIndex}`}
                          sx={{
                            '& .MuiAccordionSummary-content': {
                              justifyContent: 'space-between',
                            },
                          }}
                        >
                          <div
                            dangerouslySetInnerHTML={{
                              __html:
                                sections[index]?.subSections[
                                  tileIndex
                                ]?.configObj?.label?.slice(0, 100) ||
                                'Sub-Section ' + (tileIndex + 1),
                            }}
                          ></div>
                          <div>
                            {expandedTile === `panel1${tileIndex}` && (
                              <AddCircleOutlineIcon
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleInsertNestedSubSection(
                                    index,
                                    tileIndex,
                                    structuredClone(
                                      sections[index].subSections[tileIndex]
                                        .subSections,
                                    ),
                                  );
                                }}
                              />
                            )}

                            <DeleteIcon
                              onClick={(e) => {
                                e.stopPropagation();
                                handleAlertForDeleteRow(() =>
                                  handleDeleteTile(
                                    index,
                                    tileIndex,
                                    structuredClone(
                                      sections[index].subSections,
                                    ),
                                    structuredClone(sections),
                                  ),
                                );
                              }}
                            />
                            <EditIcon
                              sx={{
                                color: !checkIsThisValidRow(tileRow)
                                  ? 'rgb(255, 64, 0)'
                                  : 'rgb(17, 24, 39)',
                              }}
                              onClick={(e) => {
                                e.stopPropagation();
                                handlerDrawerFormOpen(index, tileIndex);
                              }}
                            />
                          </div>
                        </AccordionSummary>
                        <AccordionDetails
                          sx={{marginLeft: 7}}
                          id={`learn-page-AccordionDetails-tile-tileIndex-${tileIndex}`}
                        >
                          <DragDropContext
                            onDragEnd={onDragEndNestedSubSection}
                          >
                            <Droppable
                              style={{transform: 'none'}}
                              droppableId='droppable'
                            >
                              {(provided, snapshot) => (
                                <Stack
                                  spacing={2}
                                  {...provided.droppableProps}
                                  ref={provided.innerRef}
                                >
                                  {tileRow?.subSections?.map(
                                    (
                                      nestedSubSectionRow,
                                      nestedSubSectionIndex,
                                    ) => (
                                      <Draggable
                                        id={`Draggable-tabIndex-${index}-tileIndex-${tileIndex}-nestedSubSectionIndex-${nestedSubSectionIndex}`}
                                        key={'key' + nestedSubSectionIndex}
                                        draggableId={`tabIndex-${index}-tileIndex-${tileIndex}-nestedSubSectionIndex-${nestedSubSectionIndex}`}
                                        index={nestedSubSectionIndex}
                                      >
                                        {(provided, snapshot) => (
                                          <div
                                            ref={provided.innerRef}
                                            {...provided.draggableProps}
                                            {...provided.dragHandleProps}
                                            style={getItemStyle(
                                              snapshot.isDragging,
                                              provided.draggableProps.style,
                                            )}
                                          >
                                            {/* <AppCard key={'sections-' + index}>
                                                    <Box> */}
                                            <Accordion
                                              id={
                                                'Accordion-nestedSubSection-' +
                                                '-nestedSubSectionIndex-' +
                                                nestedSubSectionIndex
                                              }
                                              key={
                                                'sections-' +
                                                index +
                                                '-tile-' +
                                                tileIndex +
                                                '-nestedSubSection-' +
                                                nestedSubSectionIndex
                                              }
                                              // expanded={
                                              //   expandedNestedSubSection === `panel1${nestedSubSectionIndex}`
                                              // }
                                              expanded={false}
                                              // onChange={handleChangeNestedSubSection(
                                              //   `panel1${nestedSubSectionIndex}`,
                                              // )}
                                              sx={rowBorder(
                                                expandedNestedSubSection,
                                                `panel1${nestedSubSectionIndex}`,
                                                nestedSubSectionRow,
                                              )}
                                            >
                                              <AccordionSummary
                                                expandIcon={<ExpandMoreIcon />}
                                                aria-controls='panel1bh-content'
                                                id={`learn-page-accordion-summary-tile-index-${nestedSubSectionIndex}`}
                                                sx={{
                                                  '& .MuiAccordionSummary-content':
                                                    {
                                                      justifyContent:
                                                        'space-between',
                                                    },
                                                }}
                                              >
                                                <div
                                                  style={{
                                                    width: '90%',
                                                    overflow: 'hidden',
                                                  }}
                                                >
                                                  {/* <Typography
                                                      sx={{
                                                        width: '33%',
                                                        flexShrink: 0,
                                                      }}
                                                    >
                                                      {`${
                                                        sections[
                                                          index
                                                        ]?.subSections[
                                                          tileIndex
                                                        ]?.subSections[
                                                          nestedSubSectionIndex
                                                        ]?.configObj?.label?.slice(
                                                          0,
                                                          100,
                                                        ) ||
                                                        'Sub-Section ' +
                                                          (nestedSubSectionIndex +
                                                            1)
                                                      }`}
                                                    </Typography> */}
                                                  <div
                                                    dangerouslySetInnerHTML={{
                                                      __html:
                                                        sections[
                                                          index
                                                        ]?.subSections[
                                                          tileIndex
                                                        ]?.subSections[
                                                          nestedSubSectionIndex
                                                        ]?.configObj?.label?.slice(
                                                          0,
                                                          100,
                                                        ) ||
                                                        'Sub-Section ' +
                                                          (nestedSubSectionIndex +
                                                            1),
                                                    }}
                                                  ></div>
                                                </div>
                                                <div>
                                                  <DeleteIcon
                                                    onClick={(e) => {
                                                      e.stopPropagation();
                                                      handleAlertForDeleteRow(
                                                        () =>
                                                          handleDeleteNestedSubSection(
                                                            index,
                                                            tileIndex,
                                                            nestedSubSectionIndex,
                                                            structuredClone(
                                                              sections[index]
                                                                .subSections[
                                                                tileIndex
                                                              ].subSections,
                                                            ),
                                                            structuredClone(
                                                              sections[index]
                                                                .subSections,
                                                            ),
                                                            structuredClone(
                                                              sections,
                                                            ),
                                                          ),
                                                      );
                                                    }}
                                                  />
                                                  <EditIcon
                                                    sx={{
                                                      color:
                                                        !checkIsThisValidRow(
                                                          nestedSubSectionRow,
                                                        )
                                                          ? 'rgb(255, 64, 0)'
                                                          : 'rgb(17, 24, 39)',
                                                    }}
                                                    onClick={(e) => {
                                                      e.stopPropagation();
                                                      handlerDrawerFormOpen(
                                                        index,
                                                        tileIndex,
                                                        nestedSubSectionIndex,
                                                      );
                                                    }}
                                                  />
                                                </div>
                                              </AccordionSummary>
                                              <AccordionDetails
                                                id={`learn-page-AccordionDetails-tile-nestedSubSectionIndex-${nestedSubSectionIndex}`}
                                              ></AccordionDetails>
                                            </Accordion>
                                            {/* </Box>
                                                    </AppCard> */}
                                          </div>
                                        )}
                                      </Draggable>
                                    ),
                                  )}
                                  {provided.placeholder}
                                </Stack>
                              )}
                            </Droppable>
                          </DragDropContext>
                        </AccordionDetails>
                      </Accordion>
                    ))}
                  </Stack>
                </AccordionDetails>
              </Accordion>
            </Box>
          </AppCard>
        ))}
      </>
    );
  };

  const choseWhichAccordianToShow = () => {
    if (!accordianTabExpended) {
      return createDomTabNotExpended();
    } else {
      if (accordianTileExpended) {
        return createDomTileExpended();
      } else {
        return createDomTabExpended();
      }
    }
  };

  const previewPayload = {
    employeeId: null,
    assessmentFormDTO: {
      id: null,
      isPaginationRequired: isPaginationRequired,
      status: 'ACTIVE',
      formFor: formFor,
      company: selectedCompany.id,
      sections: sections,
    },
    appraisalCycle: '2023-2024',
    referenceEmployeeSections:selfAppraisalUpdatedSection,
    referencePeerSections:peerFeedbackUpdatedSection,
    formFor: formFor,
  };

  const handleRefferedSelfAppraisalForm = (updatedData) => {
    setSelfAppraisalUpdatedSection(updatedData);
  };
  const handlePeerFeedbackForm = (updatedData) => {
    setPeerFeedbackUpdatedSection(updatedData);
  };

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <Stack className={view ? 'disabled-button-for-view-only' : ''}>
        <h2 style={{margin: 2}}>Form Builder</h2>
        <AppCard>
          <Stack
            id='learn-page-stack-main'
            // direction='row'
            sx={{mt: 2, ml: 3}}
            // justifyContent='space-between'
            // alignItems='flex-start'
            // spacing={2}
          >
            <Stack sx={{width: '100%'}}>
              <TextField
                onChange={(event) => {
                  setDisplayName(event.target.value);
                }}
                value={displayName || ''}
                size='small'
                name='label'
                label={'Display Name'}
                variant='outlined'
                sx={{...textFieldStyled, ...fieldRequired}}
                fullWidth
              />
            </Stack>
          </Stack>

          <Stack
            id='learn-page-stack-main'
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <FormControl>
                <InputLabel size='small' id='label_form_for'>
                  Form For
                </InputLabel>
                <Select
                  disabled={id}
                  name='formFor'
                  labelId='label_form_For'
                  onChange={(event) => {
                    setFormFor(event.target.value);
                    setPmsCycle(null);
                  }}
                  value={formFor || ''}
                  label='Form For'
                  variant='outlined'
                  size='small'
                  sx={{
                    ...textFieldStyled,
                    ...fieldRequired,
                  }}
                >
                  {formForList.map((element) => {
                    return (
                      <MenuItem key={element.key} value={element.value}>
                        {element.name}
                      </MenuItem>
                    );
                  })}
                </Select>
              </FormControl>
            </Stack>
            <Stack sx={{width: '60%'}}>
              <Stack
                direction='row'
                sx={{ml: 3}}
                justifyContent='space-between'
                alignItems='center'
                spacing={2}
              >
                <Stack sx={{width: '60%'}}>
                  <FormLabel id='demo-row-radio-buttons-group-label'>
                    <Stack direction='row'>
                      <Stack fontWeight={500}>Is Pagination Required</Stack>
                    </Stack>
                  </FormLabel>
                </Stack>
                <Stack sx={{width: '40%'}}>
                  <RadioGroup
                    value={isPaginationRequired}
                    onChange={(event) =>
                      setIsPaginationRequired(event.target.value)
                    }
                    row
                    aria-labelledby='demo-row-radio-buttons-group-label'
                    name='isPaginationRequired'
                  >
                    <FormControlLabel
                      value={true}
                      control={<Radio />}
                      label={<IntlMessages id='common.button.Yes' />}
                    />
                    <FormControlLabel
                      value={false}
                      control={<Radio />}
                      label={<IntlMessages id='common.button.No' />}
                    />
                  </RadioGroup>
                </Stack>
              </Stack>
            </Stack>
          </Stack>

          {formFor == 'ManagerFeedBack' && (
            <>
              {/* Self appraisal form */}
              <Stack
                id='learn-page-stack-main'
                direction='row'
                sx={{mt: 2, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{mt: 2, width: '40%'}}>
                  <FormControl>
                    <InputLabel size='small' id='label_form_for'>
                      Referred Self Appraisal Form
                    </InputLabel>
                    <Select
                      name='refferedSelfAppraisalForm'
                      labelId='label_form_For'
                      onChange={(event) => {
                        setRefferedSelfAppraisalForm(() => event.target.value);
                        if (formFor == 'ManagerFeedBack') {
                          getAllSelfAppraisalReferredSections(
                            event.target.value.id,
                          );
                          setShowSelfAppraisal(false);
                        }
                      }}
                      value={refferedSelfAppraisalForm || ''}
                      renderValue={(selected) => selected.displayName}
                      label='Reffered Self Appraisal Form'
                      variant='outlined'
                      size='small'
                      sx={{
                        ...textFieldStyled,
                        // ...fieldRequired,
                      }}
                    >
                      {refferedSelfAppraisalFormData?.map((element) => {
                        return (
                          <MenuItem key={element.id} value={element}>
                            {element.displayName}
                          </MenuItem>
                        );
                      })}
                    </Select>
                  </FormControl>
                </Stack>
                {!isEmptyNullUndefined(refferedSelfAppraisalForm) && (
                  <Stack sx={{width: '60%'}}>
                    <Stack
                      direction='row'
                      sx={{mt: 2, ml: 3}}
                      justifyContent='space-between'
                      alignItems='center'
                      spacing={2}
                    >
                      <Stack sx={{width: '60%'}}>
                        <FormLabel id='demo-row-radio-buttons-group-label'>
                          <Stack direction='row'>
                            <Stack fontWeight={500}>
                              Is employee self appraisal form to be shown at
                              form level ?
                            </Stack>
                          </Stack>
                        </FormLabel>
                      </Stack>
                      <Stack sx={{width: '40%'}}>
                        <RadioGroup
                          row
                          aria-labelledby='demo-row-radio-buttons-group-label'
                          value={showSelfAppraisal}
                          name='showSelfAppraisal'
                          onChange={(e) => setShowSelfAppraisal(e.target.value)}
                        >
                          <FormControlLabel
                            value={true}
                            control={<Radio />}
                            label={<IntlMessages id='common.button.Yes' />}
                          />
                          <FormControlLabel
                            value={false}
                            control={<Radio />}
                            label={<IntlMessages id='common.button.No' />}
                          />
                        </RadioGroup>
                      </Stack>
                    </Stack>
                  </Stack>
                )}
              </Stack>
              {(showSelfAppraisal == 'true' || showSelfAppraisal == true) &&
                SelfAppraisalReferredSectionsData && (
                  <Stack sx={{mt: 2, ml: 3, mr: 3, mb: 5}}>
                    <ReferenceFormConfig
                      name={
                        refferedSelfAppraisalForm?.displayName ||
                        'Referred Self Appraisal Form'
                      }
                      // configData={SelfAppraisalReferredSectionsData}
                      // configData={JSON.parse(JSON.stringify(SelfAppraisalReferredSectionsData))}
                      configData={
                        SelfAppraisalReferredSectionsData
                          ? JSON.parse(
                              JSON.stringify(SelfAppraisalReferredSectionsData),
                            )
                          : {}
                      }
                      onDataChange={handleRefferedSelfAppraisalForm}
                    />
                  </Stack>
                )}
              {/* Peer appraisal form */}
              <Stack
                id='learn-page-stack-main'
                direction='row'
                sx={{mt: 2, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{mt: 2, width: '40%'}}>
                  <FormControl>
                    <InputLabel size='small' id='label_form_for'>
                      Referred PeerFeedback Form
                    </InputLabel>
                    <Select
                      name='refferedPeerFeedbackForm'
                      labelId='label_form_For'
                      onChange={(event) => {
                        setRefferedPeerFeedbackForm(() => event.target.value);
                        if (formFor == 'ManagerFeedBack') {
                          getAllPeerReferredSections(event.target.value.id);
                          setShowPeerFeedback(false);
                        }
                      }}
                      value={refferedPeerFeedbackForm || ''}
                      renderValue={(selected) => selected.displayName}
                      label='Reffered PeerFeedback Form'
                      variant='outlined'
                      size='small'
                      sx={{
                        ...textFieldStyled,
                        // ...fieldRequired,
                      }}
                    >
                      {refferedPeerFeedbackFormData?.map((element) => {
                        return (
                          <MenuItem key={element.id} value={element}>
                            {element.displayName}
                          </MenuItem>
                        );
                      })}
                    </Select>
                  </FormControl>
                </Stack>
                {!isEmptyNullUndefined(refferedPeerFeedbackForm) && (
                  <Stack sx={{width: '60%'}}>
                    <Stack
                      direction='row'
                      sx={{mt: 2, ml: 3}}
                      justifyContent='space-between'
                      alignItems='center'
                      spacing={2}
                    >
                      <Stack sx={{width: '60%'}}>
                        <FormLabel id='demo-row-radio-buttons-group-label'>
                          <Stack direction='row'>
                            <Stack fontWeight={500}>
                              Is peer feedback form to be shown at form level ?
                            </Stack>
                          </Stack>
                        </FormLabel>
                      </Stack>
                      <Stack sx={{width: '40%'}}>
                        <RadioGroup
                          row
                          aria-labelledby='demo-row-radio-buttons-group-label'
                          value={showPeerFeedback}
                          name='showPeerFeedback'
                          onChange={(e) => setShowPeerFeedback(e.target.value)}
                        >
                          <FormControlLabel
                            value={true}
                            control={<Radio />}
                            label={<IntlMessages id='common.button.Yes' />}
                          />
                          <FormControlLabel
                            value={false}
                            control={<Radio />}
                            label={<IntlMessages id='common.button.No' />}
                          />
                        </RadioGroup>
                      </Stack>
                    </Stack>
                  </Stack>
                )}
              </Stack>

              {(showPeerFeedback == 'true' || showPeerFeedback == true) &&
                PeerReferredSectionsData && (
                  <Stack sx={{mt: 2, ml: 3, mr: 3, mb: 5}}>
                    <ReferenceFormConfig
                      name={
                        refferedPeerFeedbackForm?.displayName ||
                        'Referred Peer Feedback Form'
                      }
                      configData={
                        PeerReferredSectionsData
                          ? JSON.parse(JSON.stringify(PeerReferredSectionsData))
                          : {}
                      }
                      onDataChange={handlePeerFeedbackForm}
                    />
                  </Stack>
                )}
            </>
          )}
        </AppCard>
        {/* /////////  add select form level section /////////// */}

        {/* //////////////////// */}
        <Stack
          direction='row'
          sx={{m: 2, width: '100%'}}
          justifyContent={'space-between'}
          spacing={2}
        >
          <h4 style={{marginBottom: 15}}>Section</h4>
          <Button
            disabled={
              !formFor ||
              ((showSelfAppraisal == true || showSelfAppraisal == 'true') &&
                isEmptyNullUndefined(refferedSelfAppraisalForm)) ||
              ((showPeerFeedback == true || showPeerFeedback == 'true') &&
                isEmptyNullUndefined(refferedPeerFeedbackForm))
            }
            name='comment'
            variant='contained'
            onClick={() => handleInsertTab(structuredClone(sections))}
          >
            Add Section
          </Button>
        </Stack>
        <Stack spacing={2} sx={{width: '100%', textWrap: 'nowrap'}}>
          {isLoading ? (
            <Stack spacing={3}>
              <Skeleton variant='rounded' width={'100%'} height={60} />
              <Skeleton variant='rounded' width={'100%'} height={60} />
              <Skeleton variant='rounded' width={'100%'} height={60} />
              <Skeleton variant='rounded' width={'100%'} height={60} />
            </Stack>
          ) : (
            choseWhichAccordianToShow()
          )}
        </Stack>
        <FormPage
          drowerFormIsOpen={drowerFormIsOpen}
          handleNo={(
            configObj,
            referenceEmployeeSections,
            referencePeerSections,
          ) =>
            handlerDrawerFormClose(
              configObj,
              referenceEmployeeSections,
              referencePeerSections,
            )
          }
          sections={sections}
          selectedSectionForEdit={selectedSectionForEdit}
          valuesData={valuesData}
          ratingsData={ratingsData}
          SelfAppraisalReferredSectionsData={SelfAppraisalReferredSectionsData}
          PeerReferredSectionsData={PeerReferredSectionsData}
          refferedSelfAppraisalForm={refferedSelfAppraisalForm}
          refferedPeerFeedbackForm={refferedPeerFeedbackForm}
          formFor={formFor}
          pmsCycle={pmsCycle}
        />
      </Stack>
      <div style={{height: '80px'}} />
      <Stack
        sx={{
          bottom: 0,
          zIndex: 10,
          position: 'fixed',
          backdropFilter: 'blur(5px)',
          width: '100%',
          right: 0,
        }}
      >
        <Stack
          direction='row'
          justifyContent='end'
          alignItems='center'
          spacing={2}
          sx={{
            pt: 5,
            ml: 3,
            margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
          }}
        >
          <Button
            id='health-hnsurance-close-button'
            color={footerButton.close.color}
            variant={footerButton.close.variant}
            sx={footerButton.close.sx}
            size={footerButton.close.size}
            onClick={() => history.push('/form-builder-new')}
          >
            <IntlMessages id='common.button.Close' />
          </Button>

          <Button
            disabled={
              !sections.length ||
              isLoading ||
              isEmptyNullUndefined(displayName) ||
              isEmptyNullUndefined(sections)
            }
            color={footerButton.back.color}
            variant={footerButton.back.variant}
            sx={footerButton.back.sx}
            size={footerButton.back.size}
            onClick={() => handleOpenPreviewPage()}
          >
            <IntlMessages id='common.button.Preview' />
          </Button>
          {((!view && isDraft == null) ||
            isDraft == true ||
            isDraft == 'true') && (
            <Button
              disabled={
                !formFor ||
                isLoading ||
                isEmptyNullUndefined(displayName) ||
                isEmptyNullUndefined(sections)
              }
              color={footerButton.saveDraft.color}
              variant={footerButton.saveDraft.variant}
              sx={footerButton.saveDraft.sx}
              size={footerButton.saveDraft.size}
              onClick={() => handleValidateBeforeSubmit(true)}
            >
              <IntlMessages id='common.button.SaveDraft' />
            </Button>
          )}
          {!view && (
            <Button
              id='health-hnsurance-submit-button'
              disabled={
                !formFor ||
                isLoading ||
                isEmptyNullUndefined(displayName) ||
                isEmptyNullUndefined(sections)
              }
              color={footerButton.submit.color}
              variant={footerButton.submit.variant}
              sx={footerButton.submit.sx}
              size={footerButton.submit.size}
              onClick={() => handleValidateBeforeSubmit(false)}
            >
              {id ? (
                <IntlMessages id='common.button.Update' />
              ) : (
                <IntlMessages id='common.button.Submit' />
              )}
            </Button>
          )}
        </Stack>
      </Stack>
      {isPreviewPageOpen && (
        <PreviewPage
          handleClose={() => handleClosePreviewPage()}
          dynamicFormData={previewPayload}
          valuesData={valuesData}
          ratingsData={ratingsData}
        ></PreviewPage>
      )}
      {alertProps.isHideShow && (
        <AlertDialog
          alertProps={alertProps}
          handleYes={() => handleAlertYes()}
          handleNo={() => handleAlertNo(alertProps, setAlertProps)}
        />
      )}
      <AppInfoView />
    </AppAnimate>
  );
};

export default FormBuilderNew;
