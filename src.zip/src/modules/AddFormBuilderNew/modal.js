import Checked from './checked.svg';
import PropTypes from 'prop-types';
import InfoIcon from '@mui/icons-material/Info';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Checkbox,
  CircularProgress,
  FormControl,
  FormControlLabel,
  FormGroup,
  FormHelperText,
  FormLabel,
  InputLabel,
  ListItemText,
  MenuItem,
  RadioGroup,
  Select,
  Skeleton,
  Stack,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import {BsChevronDown} from 'react-icons/bs';
import React, {useEffect, useState} from 'react';
import Radio from '@mui/material/Radio';
import {useDispatch, useSelector} from 'react-redux';
import Info from './info.js';
import SideDrawer from './sideDrawer';
import {
  isEmptyNullUndefined,
  onlyAcceptWholeNumbers,
} from 'shared/utils/CommonUtils';
import {fetchError, fetchStart} from 'redux/actions';
import { getALLDropdownData } from 'redux/actions/DropdownData';
import { dropdownData } from './data';

const AccSkeleton = () => {
  return (
    <div
      style={{
        backgroundColor: '#ffffff',
        padding: '1rem',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        borderRadius: '1rem',
      }}
    >
      <Skeleton
        animation='wave'
        variant='rectangular'
        width={'90%'}
        height={60}
        sx={{marginTop: '1rem'}}
      />
      <Skeleton
        animation='wave'
        variant='rectangular'
        width={'90%'}
        height={60}
        sx={{marginTop: '1rem'}}
      />
      <Skeleton
        animation='wave'
        variant='rectangular'
        width={'90%'}
        height={60}
        sx={{marginTop: '1rem'}}
      />
    </div>
  );
};

const textAreaStyle = {
  width: '100%',
  // my: 4,
  mt: 2,
  backgroundColor: '#F9F9F9',
  borderRadius: '1rem',
  '& fieldset': {
    border: '1px solid #F9F9F9',
    borderRadius: '1rem',
  },
};

const accordianSVGstyle = {
  borderRadius: '1rem',
  backgroundColor: '#606060',
  color: '#ffffff',
  fontSize: '1.5rem',
  padding: '0.1rem',
  margin: 'auto 0px',
  transitionDuration: '700ms',
};

const SelfAssesmentAllinone = ({dynamicFormData, valuesData}) => {
  const dispatch = useDispatch();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  // const {dropdownData} = useSelector(
  //   ({dropdownData}) => dropdownData,
  // );
  let adminDetails = JSON.parse(localStorage.getItem('adminDetails'));

  const [expanded, setExpanded] = useState(null);
  const [expandedTile, setExpandedTile] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isOpenDrawer, setIsOpenDrawer] = useState(false);
  const [drawerData, setDrawerData] = useState(null);
  const [formData, setFormData] = useState([]);
  const [vertualFormPayload, setVertualFormPayload] = useState([]);
  const [submitLoader] = useState(false);
  const [vertualError, setVertualError] = useState([]);

  useEffect(() => {
    getFormData();
  }, []);
  
  useEffect(() => {
    dispatch(fetchStart);
    if (!isEmptyNullUndefined(selectedCompany) && !isEmptyNullUndefined(adminDetails) ) {
      dispatch(getALLDropdownData({companyId: selectedCompany.id, managerId:adminDetails?.id}));
    }
  }, [selectedCompany]);

  const handleChangeVertualPayload = (
    event,
    inputType,
    tabIndex,
    tileIndex,
    nestedSubsectionI
  ) => {
    const tempvertualFormPayload = structuredClone(vertualFormPayload);
    const tempvertualFormError = structuredClone(vertualError);
    if (nestedSubsectionI == null && tileIndex == null) {
      if (inputType === "textField") {
        tempvertualFormPayload[tabIndex].assessmentResponseObjectDTO[
          event.target.name
        ] = event.target.value;
        tempvertualFormError[tabIndex].assessmentResponseObjectDTO[
          event.target.name
        ].isError = false;
        tempvertualFormError[tabIndex].assessmentResponseObjectDTO[
          event.target.name
        ].errorMessage = "";
      }
      if (inputType === "numberField") {
        tempvertualFormPayload[tabIndex].assessmentResponseObjectDTO[
          event.target.name
        ] = onlyAcceptWholeNumbers(event.target.value);
        tempvertualFormError[tabIndex].assessmentResponseObjectDTO[
          event.target.name
        ].isError = false;
        tempvertualFormError[tabIndex].assessmentResponseObjectDTO[
          event.target.name
        ].errorMessage = "";
      }
      if (inputType === 'dropDownSelect') {
        if(isEmptyNullUndefined(tempvertualFormPayload[tabIndex].assessmentResponseObjectDTO[event.target.name]) ) {
          tempvertualFormPayload[tabIndex].assessmentResponseObjectDTO[event.target.name] = (event.target.value);
        } else if(
            tempvertualFormPayload[tabIndex].assessmentResponseObjectDTO[event.target.name].id == event.target.value.id
          ) {
            tempvertualFormPayload[tabIndex].assessmentResponseObjectDTO[event.target.name] = null
          } else {
            tempvertualFormPayload[tabIndex].assessmentResponseObjectDTO[event.target.name] = (event.target.value);
          }


        tempvertualFormError[tabIndex].assessmentResponseObjectDTO[
          event.target.name
        ].isError = false;
        tempvertualFormError[tabIndex].assessmentResponseObjectDTO[
          event.target.name
        ].errorMessage = '';
      }
      if (inputType === "ratio") {
        tempvertualFormPayload[tabIndex].assessmentResponseObjectDTO[
          event.target.name
        ] = event.target.value;
        tempvertualFormError[tabIndex].assessmentResponseObjectDTO[
          event.target.name
        ].isError = false;
        tempvertualFormError[tabIndex].assessmentResponseObjectDTO[
          event.target.name
        ].errorMessage = "";
      }
      if (inputType === "selection") {
        if (
          tempvertualFormPayload[tabIndex].configObj.selectionType === "Single"
        ) {


          
          
          if (
            tempvertualFormPayload[tabIndex].assessmentResponseObjectDTO.selection.length
          ) {
            tempvertualFormPayload[tabIndex].assessmentResponseObjectDTO.selection.some((e) => {
              if (e.id == event.id) {
                let indexOfEvent = tempvertualFormPayload[
                  tabIndex
                ].assessmentResponseObjectDTO.selection.findIndex(
                  (e) => e.id == event.id
                );
                tempvertualFormPayload[
                  tabIndex
                ].assessmentResponseObjectDTO.selection.splice(indexOfEvent, 1);
              } else {
                tempvertualFormPayload[
                  tabIndex
                ].assessmentResponseObjectDTO.selection = [event];
              }
            })
          } else {
            tempvertualFormPayload[
              tabIndex
            ].assessmentResponseObjectDTO.selection = [event];
          }
            
          



        } else if (
          tempvertualFormPayload[tabIndex].configObj.selectionType === "Multiple"
        ) {
          if (
            tempvertualFormPayload[tabIndex].assessmentResponseObjectDTO
              .selection.length
          ) {
            let isPresent = false;
            tempvertualFormPayload[
              tabIndex
            ].assessmentResponseObjectDTO.selection.some((e) => {
              if (e.id == event.id) {
                let indexOfEvent = tempvertualFormPayload[
                  tabIndex
                ].assessmentResponseObjectDTO.selection.findIndex(
                  (e) => e.id == event.id
                );
                tempvertualFormPayload[
                  tabIndex
                ].assessmentResponseObjectDTO.selection.splice(indexOfEvent, 1);
                isPresent = true;
              }
            });
            if (!isPresent) {
                if(!isEmptyNullUndefined(tempvertualFormPayload[tabIndex].configObj.maxSelectionLimit)) {
                  if(tempvertualFormPayload[tabIndex].configObj.maxSelectionLimit != 0) {
                    if(tempvertualFormPayload[tabIndex].configObj.maxSelectionLimit <=  tempvertualFormPayload[tabIndex].assessmentResponseObjectDTO.selection.length) {
                      dispatch(fetchError('You have reached the maximum selection limit.'))
                    } else {
                      tempvertualFormPayload[
                        tabIndex
                      ].assessmentResponseObjectDTO.selection.push(event);
                    }
                  } else {
                    tempvertualFormPayload[
                      tabIndex
                    ].assessmentResponseObjectDTO.selection.push(event);
                  }
                } else {
                  tempvertualFormPayload[
                    tabIndex
                  ].assessmentResponseObjectDTO.selection.push(event);
                }
            }
          } else {
            tempvertualFormPayload[
              tabIndex
            ].assessmentResponseObjectDTO.selection.push(event);
          }
        }
        tempvertualFormError[
          tabIndex
        ].assessmentResponseObjectDTO.selection.isError = false;
        tempvertualFormError[
          tabIndex
        ].assessmentResponseObjectDTO.selection.errorMessage = "";
      }
    } else if (nestedSubsectionI == null) {
      if (inputType === "textField") {
        tempvertualFormPayload[tabIndex].subSections[
          tileIndex
        ].assessmentResponseObjectDTO[event.target.name] = event.target.value;
        tempvertualFormError[tabIndex].subSections[
          tileIndex
        ].assessmentResponseObjectDTO[event.target.name].isError = false;
        tempvertualFormError[tabIndex].subSections[
          tileIndex
        ].assessmentResponseObjectDTO[event.target.name].errorMessage = "";
      }
      if (inputType === "numberField") {
        tempvertualFormPayload[tabIndex].subSections[
          tileIndex
        ].assessmentResponseObjectDTO[event.target.name] =
          onlyAcceptWholeNumbers(event.target.value);
        tempvertualFormError[tabIndex].subSections[
          tileIndex
        ].assessmentResponseObjectDTO[event.target.name].isError = false;
        tempvertualFormError[tabIndex].subSections[
          tileIndex
        ].assessmentResponseObjectDTO[event.target.name].errorMessage = "";
      }
      if (inputType === 'dropDownSelect') {

        if(isEmptyNullUndefined(tempvertualFormPayload[tabIndex].subSections[tileIndex].assessmentResponseObjectDTO[event.target.name]) ) {
          tempvertualFormPayload[tabIndex].subSections[tileIndex].assessmentResponseObjectDTO[event.target.name] = (event.target.value);
        } else {
          if(
            tempvertualFormPayload[tabIndex].subSections[tileIndex].assessmentResponseObjectDTO[event.target.name].id == event.target.value.id
          ) {
            tempvertualFormPayload[tabIndex].subSections[tileIndex].assessmentResponseObjectDTO[event.target.name] = null
          } else {
            tempvertualFormPayload[tabIndex].subSections[tileIndex].assessmentResponseObjectDTO[event.target.name] = (event.target.value);
          }
          
        }
        tempvertualFormError[tabIndex].subSections[tileIndex].assessmentResponseObjectDTO[
          event.target.name
        ].isError = false;
        tempvertualFormError[tabIndex].subSections[tileIndex].assessmentResponseObjectDTO[
          event.target.name
        ].errorMessage = '';
      }
      if (inputType === "ratio") {
        tempvertualFormPayload[tabIndex].subSections[
          tileIndex
        ].assessmentResponseObjectDTO[event.target.name] = event.target.value;
        tempvertualFormError[tabIndex].subSections[
          tileIndex
        ].assessmentResponseObjectDTO[event.target.name].isError = false;
        tempvertualFormError[tabIndex].subSections[
          tileIndex
        ].assessmentResponseObjectDTO[event.target.name].errorMessage = "";
      }
      if (inputType === "selection") {
        if (
          tempvertualFormPayload[tabIndex].subSections[tileIndex].configObj
            .selectionType === "Single"
        ) {
          if (
            tempvertualFormPayload[tabIndex].subSections[tileIndex].assessmentResponseObjectDTO.selection.length
          ) {
            tempvertualFormPayload[tabIndex].subSections[tileIndex].assessmentResponseObjectDTO.selection.some((e) => {
              if (e.id == event.id) {
                let indexOfEvent = tempvertualFormPayload[tabIndex].subSections[tileIndex].assessmentResponseObjectDTO.selection.findIndex(
                  (e) => e.id == event.id
                );
                tempvertualFormPayload[tabIndex].subSections[tileIndex].assessmentResponseObjectDTO.selection.splice(indexOfEvent, 1);
              } else {
                tempvertualFormPayload[tabIndex].subSections[tileIndex].assessmentResponseObjectDTO.selection = [event];
              }
            })
          } else {
            tempvertualFormPayload[tabIndex].subSections[tileIndex].assessmentResponseObjectDTO.selection = [event];
          }



        } else if (
          tempvertualFormPayload[tabIndex].subSections[tileIndex].configObj
            .selectionType === "Multiple"
        ) {
          if (
            tempvertualFormPayload[tabIndex].subSections[tileIndex]
              .assessmentResponseObjectDTO.selection.length
          ) {
            let isPresent = false;
            tempvertualFormPayload[tabIndex].subSections[
              tileIndex
            ].assessmentResponseObjectDTO.selection.some((e) => {
              if (e.id == event.id) {
                let indexOfEvent = tempvertualFormPayload[tabIndex].subSections[
                  tileIndex
                ].assessmentResponseObjectDTO.selection.findIndex(
                  (e) => e.id == event.id
                );
                tempvertualFormPayload[tabIndex].subSections[
                  tileIndex
                ].assessmentResponseObjectDTO.selection.splice(indexOfEvent, 1);
                isPresent = true;
              }
            });
            if (!isPresent) {
              if(!isEmptyNullUndefined(tempvertualFormPayload[tabIndex].subSections[tileIndex].configObj.maxSelectionLimit)) {
                if(tempvertualFormPayload[tabIndex].subSections[tileIndex].configObj.maxSelectionLimit != 0) {
                  if(tempvertualFormPayload[tabIndex].subSections[tileIndex].configObj.maxSelectionLimit <=  tempvertualFormPayload[tabIndex].subSections[tileIndex].assessmentResponseObjectDTO.selection.length) {
                    dispatch(fetchError('You have reached the maximum selection limit.'))
                  } else {
                    tempvertualFormPayload[tabIndex].subSections[tileIndex].assessmentResponseObjectDTO.selection.push(event);
                  }
                } else {
                  tempvertualFormPayload[tabIndex].subSections[tileIndex].assessmentResponseObjectDTO.selection.push(event);
                }
              } else {
                tempvertualFormPayload[tabIndex].subSections[tileIndex].assessmentResponseObjectDTO.selection.push(event);
              }
            }
          } else {
            tempvertualFormPayload[tabIndex].subSections[tileIndex].assessmentResponseObjectDTO.selection.push(event);
          }
        }
        tempvertualFormError[tabIndex].subSections[
          tileIndex
        ].assessmentResponseObjectDTO.selection.isError = false;
        tempvertualFormError[tabIndex].subSections[
          tileIndex
        ].assessmentResponseObjectDTO.selection.errorMessage = "";
      }
    } else {
      if (inputType === "textField") {
        tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[
          nestedSubsectionI
        ].assessmentResponseObjectDTO[event.target.name] = event.target.value;
        tempvertualFormError[tabIndex].subSections[tileIndex].subSections[
          nestedSubsectionI
        ].assessmentResponseObjectDTO[event.target.name].isError = false;
        tempvertualFormError[tabIndex].subSections[tileIndex].subSections[
          nestedSubsectionI
        ].assessmentResponseObjectDTO[event.target.name].errorMessage = "";
      }
      if (inputType === "numberField") {
        tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[
          nestedSubsectionI
        ].assessmentResponseObjectDTO[event.target.name] =
          onlyAcceptWholeNumbers(event.target.value);
        tempvertualFormError[tabIndex].subSections[tileIndex].subSections[
          nestedSubsectionI
        ].assessmentResponseObjectDTO[event.target.name].isError = false;
        tempvertualFormError[tabIndex].subSections[tileIndex].subSections[
          nestedSubsectionI
        ].assessmentResponseObjectDTO[event.target.name].errorMessage = "";
      }
      if (inputType === 'dropDownSelect') {
        if(isEmptyNullUndefined(tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].assessmentResponseObjectDTO[event.target.name]) ) {
          tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].assessmentResponseObjectDTO[event.target.name] = (event.target.value);
        } else {
          if(
            tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].assessmentResponseObjectDTO[event.target.name].id == event.target.value.id
          ) {
            tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].assessmentResponseObjectDTO[event.target.name] = null
          } else {
            tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].assessmentResponseObjectDTO[event.target.name] = (event.target.value);
          }
          
        }
        tempvertualFormError[tabIndex].subSections[tileIndex].subSections[
          nestedSubsectionI
        ].assessmentResponseObjectDTO[
          event.target.name
        ].isError = false;
        tempvertualFormError[tabIndex].subSections[tileIndex].subSections[
          nestedSubsectionI
        ].assessmentResponseObjectDTO[
          event.target.name
        ].errorMessage = '';
      }
      if (inputType === "ratio") {
        tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[
          nestedSubsectionI
        ].assessmentResponseObjectDTO[event.target.name] = event.target.value;
        tempvertualFormError[tabIndex].subSections[tileIndex].subSections[
          nestedSubsectionI
        ].assessmentResponseObjectDTO[event.target.name].isError = false;
        tempvertualFormError[tabIndex].subSections[tileIndex].subSections[
          nestedSubsectionI
        ].assessmentResponseObjectDTO[event.target.name].errorMessage = "";
      }
      if (inputType === "selection") {
        if (
          tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[
            nestedSubsectionI
          ].configObj.selectionType === "Single"
        ) {
          if (
            tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].assessmentResponseObjectDTO.selection.length
          ) {
            tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].assessmentResponseObjectDTO.selection.some((e) => {
              if (e.id == event.id) {
                let indexOfEvent = tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].assessmentResponseObjectDTO.selection.findIndex(
                  (e) => e.id == event.id
                );
                tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].assessmentResponseObjectDTO.selection.splice(indexOfEvent, 1);
              } else {
                tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].assessmentResponseObjectDTO.selection = [event];
              }
            })
          } else {
            tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].assessmentResponseObjectDTO.selection = [event];
          }
        } else if (
          tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[
            nestedSubsectionI
          ].configObj.selectionType === "Multiple"
        ) {
          if (
            tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[
              nestedSubsectionI
            ].assessmentResponseObjectDTO.selection.length
          ) {
            let isPresent = false;
            tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[
              nestedSubsectionI
            ].assessmentResponseObjectDTO.selection.some((e) => {
              if (e.id == event.id) {
                let indexOfEvent = tempvertualFormPayload[tabIndex].subSections[
                  tileIndex
                ].subSections[
                  nestedSubsectionI
                ].assessmentResponseObjectDTO.selection.findIndex(
                  (e) => e.id == event.id
                );
                tempvertualFormPayload[tabIndex].subSections[
                  tileIndex
                ].subSections[
                  nestedSubsectionI
                ].assessmentResponseObjectDTO.selection.splice(indexOfEvent, 1);
                isPresent = true;
              }
            });
            if (!isPresent) {
              if(!isEmptyNullUndefined(tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].configObj.maxSelectionLimit)) {
                if(tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].configObj.maxSelectionLimit != 0) {
                  if(tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].configObj.maxSelectionLimit <=  tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].assessmentResponseObjectDTO.selection.length) {
                    dispatch(fetchError('You have reached the maximum selection limit.'))
                  } else {
                    tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].assessmentResponseObjectDTO.selection.push(event);
                  }
                } else {
                  tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].assessmentResponseObjectDTO.selection.push(event);
                }
              } else {
                tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].assessmentResponseObjectDTO.selection.push(event);
              }
            }
          } else {
            tempvertualFormPayload[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].assessmentResponseObjectDTO.selection.push(event);
          }
        }
        tempvertualFormError[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].assessmentResponseObjectDTO.selection.isError = false;
        tempvertualFormError[tabIndex].subSections[tileIndex].subSections[nestedSubsectionI].assessmentResponseObjectDTO.selection.errorMessage = "";
      }
    }
    setVertualFormPayload(tempvertualFormPayload);
    setVertualError(tempvertualFormError);
  };



  const getFormData = async () => {
    setIsLoading(true);
    if (dynamicFormData) {
      let tempvertualFormError = structuredClone(
        dynamicFormData.assessmentFormDTO.sections,
      ).map((tab, tabIndex) => {
        tab.subSections.length &&
          tab.subSections.map((tile, tileIndex) => {
            tile.subSections.length &&
              tile.subSections.map((nestedSubsection, nestedIndex) => {
                nestedSubsection.assessmentResponseObjectDTO.responseString = {
                  isError: false,
                  errorMessage: '',
                };
                nestedSubsection.assessmentResponseObjectDTO.responseBoolean = {
                  isError: false,
                  errorMessage: '',
                };
                nestedSubsection.assessmentResponseObjectDTO.responseInteger = {
                  isError: false,
                  errorMessage: '',
                };
                nestedSubsection.assessmentResponseObjectDTO.selection = {
                  isError: false,
                  errorMessage: '',
                }; // array
                nestedSubsection.assessmentResponseObjectDTO.rating = {
                  isError: false,
                  errorMessage: '',
                };
                return nestedSubsection;
              });

            tile.assessmentResponseObjectDTO.responseString = {
              isError: false,
              errorMessage: '',
            };
            tile.assessmentResponseObjectDTO.responseBoolean = {
              isError: false,
              errorMessage: '',
            };
            tile.assessmentResponseObjectDTO.responseInteger = {
              isError: false,
              errorMessage: '',
            };
            tile.assessmentResponseObjectDTO.selection = {
              isError: false,
              errorMessage: '',
            };
            tile.assessmentResponseObjectDTO.rating = {
              isError: false,
              errorMessage: '',
            };
            return tile;
          });

        tab.assessmentResponseObjectDTO.responseString = {
          isError: false,
          errorMessage: '',
        };
        tab.assessmentResponseObjectDTO.responseBoolean = {
          isError: false,
          errorMessage: '',
        };
        tab.assessmentResponseObjectDTO.responseInteger = {
          isError: false,
          errorMessage: '',
        };
        tab.assessmentResponseObjectDTO.selection = {
          isError: false,
          errorMessage: '',
        };
        tab.assessmentResponseObjectDTO.rating = {
          isError: false,
          errorMessage: '',
        };
        return tab;
      });
      setVertualError(tempvertualFormError);
      setVertualFormPayload(dynamicFormData.assessmentFormDTO.sections);
      setFormData(dynamicFormData);
    }

    setIsLoading(false);
  };

  const handleValidate = () => {
    let isValid = true;
    let tempvertualFormError = structuredClone(vertualError);
    let tempvertualFormPayload = structuredClone(vertualFormPayload);

    tempvertualFormPayload.forEach((tab, tabIndes) => {
      if (!tab.subSections.length) {
        if (
          tab.configObj.doesThisQuestionHaveResponse === true ||
          tab.configObj.doesThisQuestionHaveResponse === 'true'
        ) {
          if (tab.configObj.responseType === 'String') {
            if (
              isEmptyNullUndefined(
                tab.assessmentResponseObjectDTO.responseString,
              )
            ) {
              if (
                tab.configObj.isResponseMandatory === true ||
                tab.configObj.isResponseMandatory === 'true'
              ) {
                tempvertualFormError[
                  tabIndes
                ].assessmentResponseObjectDTO.responseString.isError = true;
                tempvertualFormError[
                  tabIndes
                ].assessmentResponseObjectDTO.responseString.errorMessage =
                  'Required field';
                isValid = false;
              }
            } else if (
              tab.configObj.minCharacterLimit ||
              tab.configObj.maxCharacterLimit
            ) {
              if (
                tab.configObj.minCharacterLimit &&
                !tab.configObj.maxCharacterLimit
              ) {
                if (
                  tab.configObj.minCharacterLimit >
                  tab.assessmentResponseObjectDTO.responseString.length
                ) {
                  tempvertualFormError[
                    tabIndes
                  ].assessmentResponseObjectDTO.responseString.isError = true;
                  tempvertualFormError[
                    tabIndes
                  ].assessmentResponseObjectDTO.responseString.errorMessage = `Your feedback must be at least ${tab.configObj.minCharacterLimit} characters long. Please provide a more detailed response.`;
                  isValid = false;
                }
              } else if (
                !tab.configObj.minCharacterLimit &&
                tab.configObj.maxCharacterLimit
              ) {
                if (
                  tab.configObj.maxCharacterLimit <
                  tab.assessmentResponseObjectDTO.responseString.length
                ) {
                  tempvertualFormError[
                    tabIndes
                  ].assessmentResponseObjectDTO.responseString.isError = true;
                  tempvertualFormError[
                    tabIndes
                  ].assessmentResponseObjectDTO.responseString.errorMessage = `Your feedback exceeds the maximum allowed length of ${tab.configObj.maxCharacterLimit} characters. Please shorten your response.`;
                  isValid = false;
                }
              } else if (
                tab.configObj.minCharacterLimit &&
                tab.configObj.maxCharacterLimit
              ) {
                if (
                  tab.configObj.minCharacterLimit >
                    tab.assessmentResponseObjectDTO.responseString.length ||
                  tab.configObj.maxCharacterLimit <
                    tab.assessmentResponseObjectDTO.responseString.length
                ) {
                  tempvertualFormError[
                    tabIndes
                  ].assessmentResponseObjectDTO.responseString.isError = true;
                  tempvertualFormError[
                    tabIndes
                  ].assessmentResponseObjectDTO.responseString.errorMessage = `Feedback must be between ${tab.configObj.minCharacterLimit} and ${tab.configObj.maxCharacterLimit} characters. Please enter a valid feedback within this range.`;
                  isValid = false;
                }
              }
            }
          } else if (
            tab.configObj.responseType === 'Integer' &&
            (tab.configObj.isResponseMandatory === true ||
              tab.configObj.isResponseMandatory === 'true') &&
            isEmptyNullUndefined(
              tab.assessmentResponseObjectDTO.responseInteger,
            )
          ) {
            tempvertualFormError[
              tabIndes
            ].assessmentResponseObjectDTO.responseInteger.isError = true;
            tempvertualFormError[
              tabIndes
            ].assessmentResponseObjectDTO.responseInteger.errorMessage =
              'Required field';
            isValid = false;
          } else if (
            tab.configObj.responseType === 'Boolean' &&
            (tab.configObj.isResponseMandatory === true ||
              tab.configObj.isResponseMandatory === 'true') &&
            (tab.assessmentResponseObjectDTO.responseBoolean == null ||
              tab.assessmentResponseObjectDTO.responseBoolean == undefined)
          ) {
            tempvertualFormError[
              tabIndes
            ].assessmentResponseObjectDTO.responseBoolean.isError = true;
            tempvertualFormError[
              tabIndes
            ].assessmentResponseObjectDTO.responseBoolean.errorMessage =
              'Please select yes / no';
            isValid = false;
          }
        }
        if (
          (tab.configObj.doesThisQuestionHaveSelection === true ||
            tab.configObj.doesThisQuestionHaveSelection === 'true') &&
          (tab.configObj.isSelectionMandatory === true ||
            tab.configObj.isSelectionMandatory === 'true')
        ) {
          if (tab.configObj.selectionType === 'Single') {
            if (tab.assessmentResponseObjectDTO.selection.length == 0) {
              tempvertualFormError[
                tabIndes
              ].assessmentResponseObjectDTO.selection.isError = true;
              tempvertualFormError[
                tabIndes
              ].assessmentResponseObjectDTO.selection.errorMessage =
                'Please select any one';
              isValid = false;
            }
          } else if (tab.configObj.selectionType === 'Multiple') {
            if (tab.assessmentResponseObjectDTO.selection.length == 0) {
              tempvertualFormError[
                tabIndes
              ].assessmentResponseObjectDTO.selection.isError = true;
              tempvertualFormError[
                tabIndes
              ].assessmentResponseObjectDTO.selection.errorMessage =
                'Please select at least one. ';
              isValid = false;
            }
          }
        }
        if((tab.configObj.isRatingRequired === true ||
          tab.configObj.isRatingRequired === 'true') &&
        (tab.configObj.isRatingMandatory === true ||
          tab.configObj.isRatingMandatory === 'true')) {
            if(isEmptyNullUndefined(tab.assessmentResponseObjectDTO.rating)) {
              tempvertualFormError[
                tabIndes
              ].assessmentResponseObjectDTO.rating.isError = true;
              tempvertualFormError[
                tabIndes
              ].assessmentResponseObjectDTO.rating.errorMessage =
                'Please select rating. ';
              isValid = false;
            }
          }
      } else {
        tab.subSections.forEach((tile, tileIndex) => {
          if (!tile.subSections.length) {
            if (
              tile.configObj.doesThisQuestionHaveResponse === true ||
              tile.configObj.doesThisQuestionHaveResponse === 'true'
            ) {
              if (tile.configObj.responseType === 'String') {
                if (
                  isEmptyNullUndefined(
                    tile.assessmentResponseObjectDTO.responseString,
                  )
                ) {
                  if (
                    tile.configObj.isResponseMandatory === true ||
                    tile.configObj.isResponseMandatory === 'true'
                  ) {
                    tempvertualFormError[tabIndes].subSections[
                      tileIndex
                    ].assessmentResponseObjectDTO.responseString.isError = true;
                    tempvertualFormError[tabIndes].subSections[
                      tileIndex
                    ].assessmentResponseObjectDTO.responseString.errorMessage =
                      'Required field';
                    isValid = false;
                  }
                } else if (
                  tile.configObj.minCharacterLimit ||
                  tile.configObj.maxCharacterLimit
                ) {
                  if (
                    tile.configObj.minCharacterLimit &&
                    !tile.configObj.maxCharacterLimit
                  ) {
                    if (
                      tile.configObj.minCharacterLimit >
                      tile.assessmentResponseObjectDTO.responseString.length
                    ) {
                      tempvertualFormError[tabIndes].subSections[
                        tileIndex
                      ].assessmentResponseObjectDTO.responseString.isError = true;
                      tempvertualFormError[tabIndes].subSections[
                        tileIndex
                      ].assessmentResponseObjectDTO.responseString.errorMessage = `Your feedback must be at least ${tile.configObj.minCharacterLimit} characters long. Please provide a more detailed response.`;
                      isValid = false;
                    }
                  } else if (
                    !tile.configObj.minCharacterLimit &&
                    tile.configObj.maxCharacterLimit
                  ) {
                    if (
                      tile.configObj.maxCharacterLimit <
                      tile.assessmentResponseObjectDTO.responseString.length
                    ) {
                      tempvertualFormError[tabIndes].subSections[
                        tileIndex
                      ].assessmentResponseObjectDTO.responseString.isError = true;
                      tempvertualFormError[tabIndes].subSections[
                        tileIndex
                      ].assessmentResponseObjectDTO.responseString.errorMessage = `Your feedback exceeds the maximum allowed length of ${tile.configObj.maxCharacterLimit} characters. Please shorten your response.`;
                      isValid = false;
                    }
                  } else if (
                    tile.configObj.minCharacterLimit &&
                    tile.configObj.maxCharacterLimit
                  ) {
                    if (
                      tile.configObj.minCharacterLimit >
                        tile.assessmentResponseObjectDTO.responseString
                          .length ||
                      tile.configObj.maxCharacterLimit <
                        tile.assessmentResponseObjectDTO.responseString.length
                    ) {
                      tempvertualFormError[tabIndes].subSections[
                        tileIndex
                      ].assessmentResponseObjectDTO.responseString.isError = true;
                      tempvertualFormError[tabIndes].subSections[
                        tileIndex
                      ].assessmentResponseObjectDTO.responseString.errorMessage = `Feedback must be between ${tile.configObj.minCharacterLimit} and ${tile.configObj.maxCharacterLimit} characters. Please enter a valid feedback within this range.`;
                      isValid = false;
                    }
                  }
                }
              } else if (
                tile.configObj.responseType === 'Integer' &&
                (tile.configObj.isResponseMandatory === true ||
                  tile.configObj.isResponseMandatory === 'true') &&
                isEmptyNullUndefined(
                  tile.assessmentResponseObjectDTO.responseInteger,
                )
              ) {
                tempvertualFormError[tabIndes].subSections[
                  tileIndex
                ].assessmentResponseObjectDTO.responseInteger.isError = true;
                tempvertualFormError[tabIndes].subSections[
                  tileIndex
                ].assessmentResponseObjectDTO.responseInteger.errorMessage =
                  'Required field';
                isValid = false;
              } else if (
                tile.configObj.responseType === 'Boolean' &&
                (tile.configObj.isResponseMandatory === true ||
                  tile.configObj.isResponseMandatory === 'true') &&
                (tile.assessmentResponseObjectDTO.responseBoolean == null ||
                  tile.assessmentResponseObjectDTO.responseBoolean == undefined)
              ) {
                tempvertualFormError[tabIndes].subSections[
                  tileIndex
                ].assessmentResponseObjectDTO.responseBoolean.isError = true;
                tempvertualFormError[tabIndes].subSections[
                  tileIndex
                ].assessmentResponseObjectDTO.responseBoolean.errorMessage =
                  'Please select yes / no';
                isValid = false;
              }
            }
            if (
              (tile.configObj.doesThisQuestionHaveSelection === true ||
                tile.configObj.doesThisQuestionHaveSelection === 'true') &&
              (tile.configObj.isSelectionMandatory === true ||
                tile.configObj.isSelectionMandatory === 'true')
            ) {
              if (tile.configObj.selectionType === 'Single') {
                if (tile.assessmentResponseObjectDTO.selection.length == 0) {
                  tempvertualFormError[tabIndes].subSections[
                    tileIndex
                  ].assessmentResponseObjectDTO.selection.isError = true;
                  tempvertualFormError[tabIndes].subSections[
                    tileIndex
                  ].assessmentResponseObjectDTO.selection.errorMessage =
                    'Please select any one';
                  isValid = false;
                }
              } else if (tile.configObj.selectionType === 'Multiple') {
                if (tile.assessmentResponseObjectDTO.selection.length == 0) {
                  tempvertualFormError[tabIndes].subSections[
                    tileIndex
                  ].assessmentResponseObjectDTO.selection.isError = true;
                  tempvertualFormError[tabIndes].subSections[
                    tileIndex
                  ].assessmentResponseObjectDTO.selection.errorMessage =
                    'Please select at least one. ';
                  isValid = false;
                }
              }
            }
            if((tile.configObj.isRatingRequired === true ||
              tile.configObj.isRatingRequired === 'true') &&
            (tile.configObj.isRatingMandatory === true ||
              tile.configObj.isRatingMandatory === 'true')) {
                if(isEmptyNullUndefined(tile.assessmentResponseObjectDTO.rating)) {
                  tempvertualFormError[tabIndes].subSections[
                    tileIndex
                  ].assessmentResponseObjectDTO.rating.isError = true;
                  tempvertualFormError[tabIndes].subSections[
                    tileIndex
                  ].assessmentResponseObjectDTO.rating.errorMessage =
                    'Please select rating. ';
                  isValid = false;
                }
              }
          } else {
            tile.subSections.forEach(
              (nestedSubSection, nestedSubSectionIndex) => {
                if (
                  nestedSubSection.configObj.doesThisQuestionHaveResponse ===
                    true ||
                  nestedSubSection.configObj.doesThisQuestionHaveResponse ===
                    'true'
                ) {
                  if (nestedSubSection.configObj.responseType === 'String') {
                    if (
                      isEmptyNullUndefined(
                        nestedSubSection.assessmentResponseObjectDTO
                          .responseString,
                      )
                    ) {
                      if (
                        nestedSubSection.configObj.isResponseMandatory ===
                          true ||
                        nestedSubSection.configObj.isResponseMandatory ===
                          'true'
                      ) {
                        tempvertualFormError[tabIndes].subSections[
                          tileIndex
                        ].subSections[
                          nestedSubSectionIndex
                        ].assessmentResponseObjectDTO.responseString.isError = true;
                        tempvertualFormError[tabIndes].subSections[
                          tileIndex
                        ].subSections[
                          nestedSubSectionIndex
                        ].assessmentResponseObjectDTO.responseString.errorMessage =
                          'Required field';
                        isValid = false;
                      }
                    } else if (
                      nestedSubSection.configObj.minCharacterLimit ||
                      nestedSubSection.configObj.maxCharacterLimit
                    ) {
                      if (
                        nestedSubSection.configObj.minCharacterLimit &&
                        !nestedSubSection.configObj.maxCharacterLimit
                      ) {
                        if (
                          nestedSubSection.configObj.minCharacterLimit >
                          nestedSubSection.assessmentResponseObjectDTO
                            .responseString.length
                        ) {
                          tempvertualFormError[tabIndes].subSections[
                            tileIndex
                          ].subSections[
                            nestedSubSectionIndex
                          ].assessmentResponseObjectDTO.responseString.isError = true;
                          tempvertualFormError[tabIndes].subSections[
                            tileIndex
                          ].subSections[
                            nestedSubSectionIndex
                          ].assessmentResponseObjectDTO.responseString.errorMessage = `Your feedback must be at least ${nestedSubSection.configObj.minCharacterLimit} characters long. Please provide a more detailed response.`;
                          isValid = false;
                        }
                      } else if (
                        !nestedSubSection.configObj.minCharacterLimit &&
                        nestedSubSection.configObj.maxCharacterLimit
                      ) {
                        if (
                          nestedSubSection.configObj.maxCharacterLimit <
                          nestedSubSection.assessmentResponseObjectDTO
                            .responseString.length
                        ) {
                          tempvertualFormError[tabIndes].subSections[
                            tileIndex
                          ].subSections[
                            nestedSubSectionIndex
                          ].assessmentResponseObjectDTO.responseString.isError = true;
                          tempvertualFormError[tabIndes].subSections[
                            tileIndex
                          ].subSections[
                            nestedSubSectionIndex
                          ].assessmentResponseObjectDTO.responseString.errorMessage = `Your feedback exceeds the maximum allowed length of ${nestedSubSection.configObj.maxCharacterLimit} characters. Please shorten your response.`;
                          isValid = false;
                        }
                      } else if (
                        nestedSubSection.configObj.minCharacterLimit &&
                        nestedSubSection.configObj.maxCharacterLimit
                      ) {
                        if (
                          nestedSubSection.configObj.minCharacterLimit >
                            nestedSubSection.assessmentResponseObjectDTO
                              .responseString.length ||
                          nestedSubSection.configObj.maxCharacterLimit <
                            nestedSubSection.assessmentResponseObjectDTO
                              .responseString.length
                        ) {
                          tempvertualFormError[tabIndes].subSections[
                            tileIndex
                          ].subSections[
                            nestedSubSectionIndex
                          ].assessmentResponseObjectDTO.responseString.isError = true;
                          tempvertualFormError[tabIndes].subSections[
                            tileIndex
                          ].subSections[
                            nestedSubSectionIndex
                          ].assessmentResponseObjectDTO.responseString.errorMessage = `Feedback must be between ${nestedSubSection.configObj.minCharacterLimit} and ${nestedSubSection.configObj.maxCharacterLimit} characters. Please enter a valid feedback within this range.`;
                          isValid = false;
                        }
                      }
                    }
                  } else if (
                    nestedSubSection.configObj.responseType === 'Integer' &&
                    (nestedSubSection.configObj.isResponseMandatory === true ||
                      nestedSubSection.configObj.isResponseMandatory ===
                        'true') &&
                    isEmptyNullUndefined(
                      nestedSubSection.assessmentResponseObjectDTO
                        .responseInteger,
                    )
                  ) {
                    tempvertualFormError[tabIndes].subSections[
                      tileIndex
                    ].subSections[
                      nestedSubSectionIndex
                    ].assessmentResponseObjectDTO.responseInteger.isError = true;
                    tempvertualFormError[tabIndes].subSections[
                      tileIndex
                    ].subSections[
                      nestedSubSectionIndex
                    ].assessmentResponseObjectDTO.responseInteger.errorMessage =
                      'Required field';
                    isValid = false;
                  } else if (
                    nestedSubSection.configObj.responseType === 'Boolean' &&
                    (nestedSubSection.configObj.isResponseMandatory === true ||
                      nestedSubSection.configObj.isResponseMandatory ===
                        'true') &&
                    (nestedSubSection.assessmentResponseObjectDTO
                      .responseBoolean == null ||
                      nestedSubSection.assessmentResponseObjectDTO
                        .responseBoolean == undefined)
                  ) {
                    tempvertualFormError[tabIndes].subSections[
                      tileIndex
                    ].subSections[
                      nestedSubSectionIndex
                    ].assessmentResponseObjectDTO.responseBoolean.isError = true;
                    tempvertualFormError[tabIndes].subSections[
                      tileIndex
                    ].subSections[
                      nestedSubSectionIndex
                    ].assessmentResponseObjectDTO.responseBoolean.errorMessage =
                      'Please select yes / no';
                    isValid = false;
                  }
                }
                if (
                  (nestedSubSection.configObj.doesThisQuestionHaveSelection ===
                    true ||
                    nestedSubSection.configObj.doesThisQuestionHaveSelection ===
                      'true') &&
                  (nestedSubSection.configObj.isSelectionMandatory === true ||
                    nestedSubSection.configObj.isSelectionMandatory === 'true')
                ) {
                  if (nestedSubSection.configObj.selectionType === 'Single') {
                    if (
                      nestedSubSection.assessmentResponseObjectDTO.selection
                        .length == 0
                    ) {
                      tempvertualFormError[tabIndes].subSections[
                        tileIndex
                      ].subSections[
                        nestedSubSectionIndex
                      ].assessmentResponseObjectDTO.selection.isError = true;
                      tempvertualFormError[tabIndes].subSections[
                        tileIndex
                      ].subSections[
                        nestedSubSectionIndex
                      ].assessmentResponseObjectDTO.selection.errorMessage =
                        'Please select any one';
                      isValid = false;
                    }
                  } else if (
                    nestedSubSection.configObj.selectionType === 'Multiple'
                  ) {
                    if (
                      nestedSubSection.assessmentResponseObjectDTO.selection
                        .length == 0
                    ) {
                      tempvertualFormError[tabIndes].subSections[
                        tileIndex
                      ].subSections[
                        nestedSubSectionIndex
                      ].assessmentResponseObjectDTO.selection.isError = true;
                      tempvertualFormError[tabIndes].subSections[
                        tileIndex
                      ].subSections[
                        nestedSubSectionIndex
                      ].assessmentResponseObjectDTO.selection.errorMessage =
                        'Please select at least one. ';
                      isValid = false;
                    }
                  }
                }
                if((nestedSubSection.configObj.isRatingRequired === true ||
                  nestedSubSection.configObj.isRatingRequired === 'true') &&
                (nestedSubSection.configObj.isRatingMandatory === true ||
                  nestedSubSection.configObj.isRatingMandatory === 'true')) {
                    if(isEmptyNullUndefined(nestedSubSection.assessmentResponseObjectDTO.rating)) {
                      tempvertualFormError[tabIndes].subSections[
                        tileIndex
                      ].subSections[
                        nestedSubSectionIndex
                      ].assessmentResponseObjectDTO.rating.isError = true;
                      tempvertualFormError[tabIndes].subSections[
                        tileIndex
                      ].subSections[
                        nestedSubSectionIndex
                      ].assessmentResponseObjectDTO.rating.errorMessage =
                        'Please select rating. ';
                      isValid = false;
                    }
                  }
              },
            );
          }
        });
      }
    });

    if (isValid) {
      //handle submit
    } else {
      // set form error
      setVertualError(tempvertualFormError);
      dispatch(fetchError('Please enter all mandatory field'));
    }
  };

  const handleChange = (index) => {
    if (expanded === index) {
      setExpanded(null);
    } else {
      setExpanded(index);
    }
  };

  const handleChangeTile = (index) => {
    if (expandedTile === index) {
      setExpandedTile(null);
    } else {
      setExpandedTile(index);
    }
  };

  const handleOpenSideDrawer = (data) => {
    setDrawerData(() => data);
    setIsOpenDrawer(true);
  };

  const selectedValue = (valueId) => {
    let selectedValue = null;
    let index = valuesData.findIndex((e) => e.id === valueId.id);
    selectedValue = valuesData[index];
    return selectedValue;
  };

  const createDynamicForm = (data) => {
    if (!data) {
      return;
    }

    const tempData = structuredClone(data);
    let dom = [];

    if (
      tempData.assessmentFormDTO.sections &&
      tempData.assessmentFormDTO.sections.length > 0
    ) {
      return tempData.assessmentFormDTO.sections.map((TabElement, tabIndex) => (
        <div className='tile-element' key={TabElement.id}>
          {TabElement.subSections.length ? (
            <div className='acc-wrapper'>
                <Stack
                  sx={{
                    margin: '1rem',
                    '& .MuiAccordion-rounded': {
                      border: '1px solid #dad2d2',
                      borderRadius: '10px',
                      boxShadow: 'none',
                    },
                  }}
                >
                  <Accordion
                    expanded={expanded === `Tab-${tabIndex}`}
                    onChange={(e) => {
                      handleChange(`Tab-${tabIndex}`);
                      e.stopPropagation();
                    }}
                    data-value={`Tab-${tabIndex}`}
                  >
                    <AccordionSummary
                      aria-controls='panel1d-content'
                      id='panel1d-header'
                      sx={{
                        width: '100%',
                        fontSize: '1.25rem',
                        fontWeight: '600',
                        '& .MuiAccordionSummary-content': {
                          width: '100%',
                          display: 'flex',
                          justifyContent: 'space-between',
                        },
                      }}
                    >
                      <p className='accordian-heading'>
                        <div
                          dangerouslySetInnerHTML={{
                            __html: TabElement.configObj.label,
                          }}
                        ></div>
                        {/* {TabElement.configObj.label} */}
                      </p>
                      <div className='accordian-right-svg-container'>
                        {(TabElement.configObj.isInfoRequired == true ||
                          TabElement.configObj.isInfoRequired == 'true') &&
                          TabElement.configObj.info && (
                            <div className='accordian-right-svg-container info-drower'>
                              <Tooltip title='Info' placement='top-end'>
                                <InfoIcon
                                  onClick={(e) => {
                                    handleOpenSideDrawer(
                                      TabElement.configObj.info,
                                    );
                                    e.stopPropagation();
                                  }}
                                  style={{marginRight: '10px'}}
                                  alt='Info Icon' // Add alt text for accessibility
                                />
                              </Tooltip>
                            </div>
                          )}
                        <BsChevronDown
                          style={{
                            ...accordianSVGstyle,
                            transform:
                              expanded !== `Tab-${tabIndex}`
                                ? 'rotate(0deg)'
                                : 'rotate(180deg)',
                          }}
                        />
                      </div>
                    </AccordionSummary>
                    <AccordionDetails
                      sx={{
                        fontSize: '1rem',
                      }}
                    >
                      {TabElement.subSections.map((tile, tileIndex) => (
                        <div className='tab-element' key={tile.id}>
                          {tile.subSections.length ? (
                            <Stack
                                sx={{
                                  margin: '1rem',
                                  '& .MuiAccordion-rounded': {
                                    border: '1px solid #dad2d2',
                                    borderRadius: '10px',
                                    boxShadow: 'none',
                                  },
                                }}
                              >
                                <Accordion
                                  expanded={
                                    expandedTile === `Tile-${tileIndex}`
                                  }
                                  onChange={(e) => {
                                    handleChangeTile(`Tile-${tileIndex}`);
                                    e.stopPropagation();
                                  }}
                                  data-value={`Tile-${tileIndex}`}
                                >
                                  <AccordionSummary
                                    aria-controls='panel1d-content'
                                    id='panel1d-header'
                                    sx={{
                                      width: '100%',
                                      fontSize: '1.25rem',
                                      fontWeight: '600',
                                      '& .MuiAccordionSummary-content': {
                                        width: '100%',
                                        display: 'flex',
                                        justifyContent: 'space-between',
                                      },
                                    }}
                                  >
                                    <p className='accordian-heading'>
                                      <div
                                        dangerouslySetInnerHTML={{
                                          __html: tile.configObj.label,
                                        }}
                                      ></div>
                                      {/* {tile.configObj.label} */}
                                    </p>
                                    <div className='accordian-right-svg-container'>
                                      {(tile.configObj.isInfoRequired == true ||
                                        tile.configObj.isInfoRequired ==
                                          'true') &&
                                        tile.configObj.info && (
                                          <div className='accordian-right-svg-container info-drower'>
                                            <Tooltip
                                              title='Info'
                                              placement='top-end'
                                            >
                                              <img
                                                onClick={(e) => {
                                                  handleOpenSideDrawer(
                                                    tile.configObj.info,
                                                  );
                                                  e.stopPropagation();
                                                }}
                                                style={{marginRight: '10px'}}
                                                src={Info}
                                              ></img>
                                            </Tooltip>
                                          </div>
                                        )}
                                      <BsChevronDown
                                        style={{
                                          ...accordianSVGstyle,
                                          transform:
                                            expandedTile !== `Tile-${tileIndex}`
                                              ? 'rotate(0deg)'
                                              : 'rotate(180deg)',
                                        }}
                                      />
                                    </div>
                                  </AccordionSummary>
                                  <AccordionDetails
                                    sx={{
                                      fontSize: '1rem',
                                    }}
                                  >
                                    {tile.subSections.map(
                                      (
                                        nestedSubsectionE,
                                        nestedSubsectionI,
                                      ) => (
                                        <div
                                          className='tab-element'
                                          key={nestedSubsectionE.id}
                                        >
                                          {(((nestedSubsectionE.configObj
                                            .doesThisQuestionHaveSelection ===
                                            true ||
                                            nestedSubsectionE.configObj
                                              .doesThisQuestionHaveSelection ===
                                              'true') &&
                                            nestedSubsectionE.configObj
                                              .selectionType) ||
                                            ((nestedSubsectionE.configObj
                                              .doesThisQuestionHaveResponse ===
                                              true ||
                                              nestedSubsectionE.configObj
                                                .doesThisQuestionHaveResponse ===
                                                'true') &&
                                              (nestedSubsectionE.configObj
                                                .responseType === 'String' ||
                                                nestedSubsectionE.configObj
                                                  .responseType === 'Boolean' ||
                                                nestedSubsectionE.configObj
                                                  .responseType ===
                                                  'Integer')) || (
                                                    ((nestedSubsectionE.configObj.isRatingRequired == true) || (nestedSubsectionE.configObj.isRatingRequired === 'true'))
                                                  )) && (
                                            <div className='accDetail-questions'>
                                              <div style={{display: 'flex'}}>
                                                <p>
                                                    <div
                                                      dangerouslySetInnerHTML={{
                                                        __html: nestedSubsectionE.configObj.label,
                                                      }}
                                                    ></div>
                                                </p>
                                                {(nestedSubsectionE.configObj
                                                  .isResponseMandatory ===
                                                  true ||
                                                  nestedSubsectionE.configObj
                                                    .isResponseMandatory ===
                                                    'true' ||
                                                  nestedSubsectionE.configObj
                                                    .isSelectionMandatory ===
                                                    true ||
                                                  nestedSubsectionE.configObj
                                                    .isSelectionMandatory ===
                                                    'true' || 
                                                  nestedSubsectionE.configObj.isRatingMandatory === true ||
                                                  nestedSubsectionE.configObj.isRatingMandatory === 'true'
                                                    ) && (
                                                  <div style={{color: 'red'}}>
                                                    *
                                                  </div>
                                                )}
                                              </div>
                                              <div className='accordian-right-svg-container'>
                                                {(nestedSubsectionE.configObj
                                                  .isInfoRequired == true ||
                                                  nestedSubsectionE.configObj
                                                    .isInfoRequired ==
                                                    'true') &&
                                                  nestedSubsectionE.configObj
                                                    .info && (
                                                    <div className='accordian-right-svg-container info-drower'>
                                                      <Tooltip
                                                        title='Info'
                                                        placement='top-end'
                                                      >
                                                        <InfoIcon
                                                          onClick={(e) => {
                                                            handleOpenSideDrawer(
                                                              nestedSubsectionE
                                                                .configObj.info,
                                                            );
                                                            e.stopPropagation();
                                                          }}
                                                          style={{
                                                            marginRight: '10px',
                                                          }}
                                                          // src={Info} // Pass your image as the `src` prop
                                                          alt='Info Icon' // Add alt text for accessibility
                                                          // width={5}
                                                          // height={5}
                                                        />
                                                      </Tooltip>
                                                    </div>
                                                    // <></>
                                                  )}
                                              </div>
                                            </div>
                                          )}
                                          {(nestedSubsectionE.configObj
                                            .doesThisQuestionHaveSelection ===
                                            true ||
                                            nestedSubsectionE.configObj
                                              .doesThisQuestionHaveSelection ===
                                              'true') &&
                                            nestedSubsectionE.configObj
                                              .selectionType && (
                                              <>
                                                <div className='rateOuter'>
                                                  {nestedSubsectionE.configObj.selectableValues?.map(
                                                    (item, index) => {
                                                      return (
                                                        <div
                                                          className={`rate ${
                                                            vertualFormPayload[
                                                              tabIndex
                                                            ].subSections[
                                                              tileIndex
                                                            ].subSections[
                                                              nestedSubsectionI
                                                            ].assessmentResponseObjectDTO.selection.some(
                                                              (e) =>
                                                                e.id == item.id,
                                                            )
                                                              ? 'active'
                                                              : ''
                                                          } `}
                                                          onClick={(event) =>
                                                            handleChangeVertualPayload(
                                                              item,
                                                              'selection',
                                                              tabIndex,
                                                              tileIndex,
                                                              nestedSubsectionI,
                                                            )
                                                          }
                                                        >
                                                          <p className='rateTitle'>
                                                            {
                                                              selectedValue(
                                                                item,
                                                              )?.name
                                                            }
                                                          </p>
                                                          {vertualFormPayload[
                                                            tabIndex
                                                          ].subSections[
                                                            tileIndex
                                                          ].subSections[
                                                            nestedSubsectionI
                                                          ].assessmentResponseObjectDTO.selection.some(
                                                            (e) =>
                                                              e.id == item.id,
                                                          ) && (
                                                            <img
                                                              src={Checked}
                                                              className='checked'
                                                            ></img>
                                                          )}
                                                        </div>
                                                      );
                                                    },
                                                  )}
                                                </div>
                                                {vertualError[tabIndex]
                                                  .subSections[tileIndex]
                                                  .subSections[
                                                  nestedSubsectionI
                                                ].assessmentResponseObjectDTO
                                                  .selection.isError && (
                                                  <FormHelperText className='Mui-error'>
                                                    {
                                                      vertualError[tabIndex]
                                                        .subSections[tileIndex]
                                                        .subSections[
                                                        nestedSubsectionI
                                                      ]
                                                        .assessmentResponseObjectDTO
                                                        .selection.errorMessage
                                                    }
                                                  </FormHelperText>
                                                )}

                                              <div style={{margin:'15px'}}>
                                                <FormGroup>
                                                  <FormLabel>{nestedSubsectionE.configObj.selectMenuDynamicType}</FormLabel>
                                                  {dropdownData[nestedSubsectionE.configObj.selectMenuDynamicType]?.map((item) => (
                                                    <FormControlLabel
                                                      key={item.id}
                                                      control={
                                                        <Checkbox
                                                          checked={checkedQuestions[item.id] || false}
                                                          // onChange={() => handleCheckboxChange(item.id)}
                                                        />
                                                      }
                                                      labelPlacement='end'
                                                      label={
                                                        <Typography variant="body1" style={{ fontWeight: 500, color: '#333', marginRight:'5px'}}>
                                                          {item.name}
                                                        </Typography>
                                                      }
                                                    />
                                                  ))}
                                                </FormGroup>
                                                </div>
                                              </>
                                            )}
                                          {nestedSubsectionE.configObj
                                            .doesThisQuestionHaveResponse &&
                                          nestedSubsectionE.configObj
                                            .responseType === 'String' ? (
                                            <TextField
                                                name='responseString'
                                                value={
                                                  vertualFormPayload[tabIndex]
                                                    .subSections[tileIndex]
                                                    .subSections[
                                                    nestedSubsectionI
                                                  ].assessmentResponseObjectDTO
                                                    .responseString
                                                }
                                                onChange={(event) =>
                                                  handleChangeVertualPayload(
                                                    event,
                                                    'textField',
                                                    tabIndex,
                                                    tileIndex,
                                                    nestedSubsectionI,
                                                  )
                                                }
                                                id='outlined-multiline-static'
                                                label=''
                                                variant='outlined'
                                                placeholder={`Provide your feedback here ${
                                                  nestedSubsectionE.configObj
                                                    .minCharacterLimit ||
                                                  nestedSubsectionE.configObj
                                                    .maxCharacterLimit
                                                    ? `(limit: ${
                                                        nestedSubsectionE
                                                          .configObj
                                                          .minCharacterLimit
                                                          ? ` min: ${nestedSubsectionE.configObj.minCharacterLimit}`
                                                          : ''
                                                      }  ${
                                                        nestedSubsectionE
                                                          .configObj
                                                          .maxCharacterLimit
                                                          ? `max: ${nestedSubsectionE.configObj.maxCharacterLimit} `
                                                          : ''
                                                      }char)`
                                                    : ''
                                                }`}
                                                multiline
                                                rows={3}
                                                sx={textAreaStyle}
                                                error={
                                                  vertualError[tabIndex]
                                                    .subSections[tileIndex]
                                                    .subSections[
                                                    nestedSubsectionI
                                                  ].assessmentResponseObjectDTO
                                                    .responseString.isError
                                                }
                                                helperText={
                                                  vertualError[tabIndex]
                                                    .subSections[tileIndex]
                                                    .subSections[
                                                    nestedSubsectionI
                                                  ].assessmentResponseObjectDTO
                                                    .responseString.isError &&
                                                  vertualError[tabIndex]
                                                    .subSections[tileIndex]
                                                    .subSections[
                                                    nestedSubsectionI
                                                  ].assessmentResponseObjectDTO
                                                    .responseString.errorMessage
                                                }
                                              />
                                          ) : nestedSubsectionE.configObj
                                              .doesThisQuestionHaveResponse &&
                                            nestedSubsectionE.configObj
                                              .responseType === 'Boolean' ? (
                                            <>
                                              <Stack sx={{width: '50%'}}>
                                                <RadioGroup
                                                  name='responseBoolean'
                                                  value={
                                                    vertualFormPayload[tabIndex]
                                                      .subSections[tileIndex]
                                                      .subSections[
                                                      nestedSubsectionI
                                                    ]
                                                      .assessmentResponseObjectDTO
                                                      .responseBoolean
                                                  }
                                                  onChange={(event) =>
                                                    handleChangeVertualPayload(
                                                      event,
                                                      'ratio',
                                                      tabIndex,
                                                      tileIndex,
                                                      nestedSubsectionI,
                                                    )
                                                  }
                                                  row
                                                  aria-labelledby='demo-row-radio-buttons-group-label'
                                                >
                                                  <FormControlLabel
                                                    value={true}
                                                    control={<Radio />}
                                                    label={'Yes'}
                                                  />
                                                  <FormControlLabel
                                                    value={false}
                                                    control={<Radio />}
                                                    label={'NO'}
                                                  />
                                                </RadioGroup>
                                              </Stack>
                                              {vertualError[tabIndex]
                                                .subSections[tileIndex]
                                                .subSections[nestedSubsectionI]
                                                .assessmentResponseObjectDTO
                                                .responseBoolean.isError && (
                                                <FormHelperText className='Mui-error'>
                                                  {
                                                    vertualError[tabIndex]
                                                      .subSections[tileIndex]
                                                      .subSections[
                                                      nestedSubsectionI
                                                    ]
                                                      .assessmentResponseObjectDTO
                                                      .responseBoolean
                                                      .errorMessage
                                                  }
                                                </FormHelperText>
                                              )}
                                            </>
                                          ) : (
                                            nestedSubsectionE.configObj
                                              .doesThisQuestionHaveResponse &&
                                            nestedSubsectionE.configObj
                                              .responseType === 'Integer' && (
                                              <>
                                                <TextField
                                                  name='responseInteger'
                                                  value={
                                                    vertualFormPayload[tabIndex]
                                                      .subSections[tileIndex]
                                                      .subSections[
                                                      nestedSubsectionI
                                                    ]
                                                      .assessmentResponseObjectDTO
                                                      .responseInteger
                                                  }
                                                  onChange={(event) =>
                                                    handleChangeVertualPayload(
                                                      event,
                                                      'numberField',
                                                      tabIndex,
                                                      tileIndex,
                                                      nestedSubsectionI,
                                                    )
                                                  }
                                                  id='outlined-multiline-static'
                                                  label=''
                                                  variant='outlined'
                                                  multiline
                                                  rows={1}
                                                  placeholder='Provide your feedback here '
                                                  sx={textAreaStyle}
                                                  error={
                                                    vertualError[tabIndex]
                                                      .subSections[tileIndex]
                                                      .subSections[
                                                      nestedSubsectionI
                                                    ]
                                                      .assessmentResponseObjectDTO
                                                      .responseInteger.isError
                                                  }
                                                  helperText={
                                                    vertualError[tabIndex]
                                                      .subSections[tileIndex]
                                                      .subSections[
                                                      nestedSubsectionI
                                                    ]
                                                      .assessmentResponseObjectDTO
                                                      .responseInteger
                                                      .isError &&
                                                    vertualError[tabIndex]
                                                      .subSections[tileIndex]
                                                      .subSections[
                                                      nestedSubsectionI
                                                    ]
                                                      .assessmentResponseObjectDTO
                                                      .responseInteger
                                                      .errorMessage
                                                  }
                                                />
                                              </>
                                            )
                                          )}
                                          
                                            {(nestedSubsectionE.configObj.isRatingRequired === true ||
                                            nestedSubsectionE.configObj.isRatingRequired === 'true') && (
                                            <>
                                              <FormControl
                                                sx={{width: {md: '50%', sm: '100%'}, marginTop: '1rem'}}
                                              >
                                                <InputLabel id='demo-simple-select-label'>
                                                  Trending Rating
                                                </InputLabel>
                                                <Select
                                                  name='rating'
                                                  labelId='demo-simple-select-label'
                                                  id='demo-simple-select'
                                                  value={
                                                    vertualFormPayload[tabIndex]
                                                    .subSections[tileIndex]
                                                    .subSections[
                                                    nestedSubsectionI
                                                  ].assessmentResponseObjectDTO
                                                      .rating
                                                  }
                                                  renderValue={(selected) =>
                                                    selected.name
                                                  }
                                                  onChange={(event) =>
                                                    handleChangeVertualPayload(
                                                      event,
                                                      'dropDownSelect',
                                                      tabIndex,
                                                      tileIndex,
                                                      nestedSubsectionI,
                                                    )
                                                  }
                                                  label='Trending Rating'
                                                >
                                                  {nestedSubsectionE.configObj?.selectableRatings?.tableData?.map(
                                                    (e) => {
                                                      return <MenuItem style={{background: (vertualFormPayload[tabIndex]
                                                        .subSections[tileIndex]
                                                        .subSections[
                                                        nestedSubsectionI
                                                      ].assessmentResponseObjectDTO
                                                        .rating?.id == e?.id) ? '#f6f6f6' : ''}} key={e.id} value={e}><ListItemText primary={e.name} /></MenuItem>;
                                                    },
                                                  )}
                                                </Select>
                                                {vertualError[tabIndex]
                                                  .subSections[tileIndex]
                                                  .subSections[
                                                  nestedSubsectionI
                                                ].assessmentResponseObjectDTO
                                                  .rating.isError && (
                                                  <FormHelperText className='Mui-error'>
                                                    {
                                                      vertualError[tabIndex]
                                                      .subSections[tileIndex]
                                                      .subSections[
                                                      nestedSubsectionI
                                                    ].assessmentResponseObjectDTO
                                                        .rating.errorMessage
                                                    }
                                                  </FormHelperText>
                                                )}
                                              </FormControl>
                                            </>
                                          )}
                                        </div>
                                      ),
                                    )}
                                  </AccordionDetails>
                                </Accordion>
                              </Stack>
                          ) : (
                            <>
                            {/* Commented for getting subsection if there is only label availble */}
                              {/* {(((tile.configObj
                                .doesThisQuestionHaveSelection === true || tile.configObj.doesThisQuestionHaveSelection === 'true') && tile.configObj.selectionType) ||
                                ((tile.configObj.doesThisQuestionHaveResponse === true || tile.configObj.doesThisQuestionHaveResponse === 'true') &&
                                  (tile.configObj.responseType === 'String' ||
                                    tile.configObj.responseType === 'Boolean' ||
                                    tile.configObj.responseType === 'Integer')) ||
                                    ((tile.configObj.isRatingRequired == true) || (tile.configObj.isRatingRequired === 'true')))
                                    && ( */}
                                <div className='accDetail-questions'>
                                  <div style={{display: 'flex'}}>
                                    <p>
                                      {/* {tile.configObj.label} */}
                                      <div
                                        dangerouslySetInnerHTML={{
                                          __html: tile.configObj.label,
                                        }}
                                      ></div>
                                    </p>
                                    {(tile.configObj.isResponseMandatory ===
                                      true ||
                                      tile.configObj.isResponseMandatory ===
                                        'true' ||
                                      tile.configObj.isSelectionMandatory ===
                                        true ||
                                      tile.configObj.isSelectionMandatory ===
                                        'true' ||
                                      tile.configObj.isRatingMandatory === true ||
                                      tile.configObj.isRatingMandatory === 'true'
                                        ) && (
                                      <div style={{color: 'red'}}>*</div>
                                    )}
                                  </div>
                                  <div className='accordian-right-svg-container'>
                                    {(tile.configObj.isInfoRequired == true ||
                                      tile.configObj.isInfoRequired ==
                                        'true') &&
                                      tile.configObj.info && (
                                        <div className='accordian-right-svg-container info-drower'>
                                          <Tooltip
                                            title='Info'
                                            placement='top-end'
                                          >
                                            <InfoIcon
                                              onClick={(e) => {
                                                handleOpenSideDrawer(
                                                  tile.configObj.info,
                                                );
                                                e.stopPropagation();
                                              }}
                                              style={{marginRight: '10px'}}
                                              // src={Info} // Pass your image as the `src` prop
                                              alt='Info Icon' // Add alt text for accessibility
                                              // width={5}
                                              // height={5}
                                            />
                                          </Tooltip>
                                        </div>
                                        // <></>
                                      )}
                                  </div>
                                </div>
                              {/* )} */}
                              {(tile.configObj.doesThisQuestionHaveSelection ===
                                true ||
                                tile.configObj.doesThisQuestionHaveSelection ===
                                  'true') &&
                                tile.configObj.selectionType && (
                                  <>
                                    <div className='rateOuter'>
                                      {tile.configObj.selectableValues?.map(
                                        (item, index) => {
                                          return (
                                            <div
                                              className={`rate ${
                                                vertualFormPayload[
                                                  tabIndex
                                                ].subSections[
                                                  tileIndex
                                                ].assessmentResponseObjectDTO.selection.some(
                                                  (e) => e.id == item.id,
                                                )
                                                  ? 'active'
                                                  : ''
                                              } `}
                                              onClick={(event) =>
                                                handleChangeVertualPayload(
                                                  item,
                                                  'selection',
                                                  tabIndex,
                                                  tileIndex,
                                                  null,
                                                )
                                              }
                                            >
                                              <p className='rateTitle'>
                                                {selectedValue(item)?.name}
                                              </p>
                                              {vertualFormPayload[
                                                tabIndex
                                              ].subSections[
                                                tileIndex
                                              ].assessmentResponseObjectDTO.selection.some(
                                                (e) => e.id == item.id,
                                              ) && (
                                                <img
                                                  src={Checked}
                                                  className='checked'
                                                ></img>
                                              )}
                                            </div>
                                          );
                                        },
                                      )}
                                    </div>
                                    {vertualError[tabIndex].subSections[
                                      tileIndex
                                    ].assessmentResponseObjectDTO.selection
                                      .isError && (
                                      <FormHelperText className='Mui-error'>
                                        {
                                          vertualError[tabIndex].subSections[
                                            tileIndex
                                          ].assessmentResponseObjectDTO
                                            .selection.errorMessage
                                        }
                                      </FormHelperText>
                                    )}
                                      <div style={{margin:'15px'}}>
                                      <FormGroup>
                                      <FormLabel>{tile.configObj.selectMenuDynamicType}</FormLabel>
                                        {dropdownData[tile.configObj.selectMenuDynamicType]?.map((item) => (
                                          <FormControlLabel
                                            key={item.id}
                                            control={
                                              <Checkbox
                                                checked={false}
                                                // onChange={() => handleCheckboxChange(item.id)}
                                              />
                                            }
                                            labelPlacement='end'
                                            label={
                                              <Typography variant="body1" style={{ fontWeight: 500, color: '#333',  marginRight:'5px'  }}>
                                                {item.name}
                                              </Typography>
                                            }
                                          />
                                        ))}
                                      </FormGroup>
                                      </div>
                                  </>
                                )}
                              {(tile.configObj.doesThisQuestionHaveResponse ===
                                true ||
                                tile.configObj.doesThisQuestionHaveResponse ===
                                  'true') &&
                              tile.configObj.responseType === 'String' ? (
                                <TextField
                                    name='responseString'
                                    value={
                                      vertualFormPayload[tabIndex].subSections[
                                        tileIndex
                                      ].assessmentResponseObjectDTO
                                        .responseString
                                    }
                                    onChange={(event) =>
                                      handleChangeVertualPayload(
                                        event,
                                        'textField',
                                        tabIndex,
                                        tileIndex,
                                        null,
                                      )
                                    }
                                    id='outlined-multiline-static'
                                    label=''
                                    variant='outlined'
                                    placeholder={`Provide your feedback here ${
                                      tile.configObj.minCharacterLimit ||
                                      tile.configObj.maxCharacterLimit
                                        ? `(limit: ${
                                            tile.configObj.minCharacterLimit
                                              ? ` min: ${tile.configObj.minCharacterLimit}`
                                              : ''
                                          }  ${
                                            tile.configObj.maxCharacterLimit
                                              ? `max: ${tile.configObj.maxCharacterLimit} `
                                              : ''
                                          }char)`
                                        : ''
                                    }`}
                                    multiline
                                    rows={3}
                                    sx={textAreaStyle}
                                    error={
                                      vertualError[tabIndex].subSections[
                                        tileIndex
                                      ].assessmentResponseObjectDTO
                                        .responseString.isError
                                    }
                                    helperText={
                                      vertualError[tabIndex].subSections[
                                        tileIndex
                                      ].assessmentResponseObjectDTO
                                        .responseString.isError &&
                                      vertualError[tabIndex].subSections[
                                        tileIndex
                                      ].assessmentResponseObjectDTO
                                        .responseString.errorMessage
                                    }
                                  />
                              ) : (tile.configObj
                                  .doesThisQuestionHaveResponse === true ||
                                  tile.configObj
                                    .doesThisQuestionHaveResponse === 'true') &&
                                tile.configObj.responseType === 'Boolean' ? (
                                <>
                                  <Stack sx={{width: '50%'}}>
                                    <RadioGroup
                                      name='responseBoolean'
                                      value={
                                        vertualFormPayload[tabIndex]
                                          .subSections[tileIndex]
                                          .assessmentResponseObjectDTO
                                          .responseBoolean
                                      }
                                      onChange={(event) =>
                                        handleChangeVertualPayload(
                                          event,
                                          'ratio',
                                          tabIndex,
                                          tileIndex,
                                          null,
                                        )
                                      }
                                      row
                                      aria-labelledby='demo-row-radio-buttons-group-label'
                                    >
                                      <FormControlLabel
                                        value={true}
                                        control={<Radio />}
                                        label={'Yes'}
                                      />
                                      <FormControlLabel
                                        value={false}
                                        control={<Radio />}
                                        label={'NO'}
                                      />
                                    </RadioGroup>
                                  </Stack>
                                  {vertualError[tabIndex].subSections[tileIndex]
                                    .assessmentResponseObjectDTO.responseBoolean
                                    .isError && (
                                    <FormHelperText className='Mui-error'>
                                      {
                                        vertualError[tabIndex].subSections[
                                          tileIndex
                                        ].assessmentResponseObjectDTO
                                          .responseBoolean.errorMessage
                                      }
                                    </FormHelperText>
                                  )}
                                </>
                              ) : (
                                (tile.configObj.doesThisQuestionHaveResponse ===
                                  true ||
                                  tile.configObj
                                    .doesThisQuestionHaveResponse === 'true') &&
                                tile.configObj.responseType === 'Integer' && (
                                  <>
                                    <TextField
                                      name='responseInteger'
                                      value={
                                        vertualFormPayload[tabIndex]
                                          .subSections[tileIndex]
                                          .assessmentResponseObjectDTO
                                          .responseInteger
                                      }
                                      onChange={(event) =>
                                        handleChangeVertualPayload(
                                          event,
                                          'numberField',
                                          tabIndex,
                                          tileIndex,
                                          null,
                                        )
                                      }
                                      id='outlined-multiline-static'
                                      label=''
                                      variant='outlined'
                                      multiline
                                      placeholder='Provide your feedback here '
                                      rows={1}
                                      sx={textAreaStyle}
                                      error={
                                        vertualError[tabIndex].subSections[
                                          tileIndex
                                        ].assessmentResponseObjectDTO
                                          .responseInteger.isError
                                      }
                                      helperText={
                                        vertualError[tabIndex].subSections[
                                          tileIndex
                                        ].assessmentResponseObjectDTO
                                          .responseInteger.isError &&
                                        vertualError[tabIndex].subSections[
                                          tileIndex
                                        ].assessmentResponseObjectDTO
                                          .responseInteger.errorMessage
                                      }
                                    />
                                  </>
                                )
                              )}
                              
                                {(tile.configObj.isRatingRequired === true ||
                                tile.configObj.isRatingRequired === 'true') && (
                                <FormControl
                                    sx={{width: {md: '50%', sm: '100%'}, marginTop: '1rem'}}
                                  >
                                    <InputLabel id='demo-simple-select-label'>
                                      Trending Rating
                                    </InputLabel>
                                    <Select
                                      name='rating'
                                      labelId='demo-simple-select-label'
                                      id='demo-simple-select'
                                      onChange={(event) =>
                                        handleChangeVertualPayload(
                                          event,
                                          'dropDownSelect',
                                          tabIndex,
                                          tileIndex,
                                          null,
                                        )
                                      }
                                      value={
                                        vertualFormPayload[tabIndex]
                                          .subSections[tileIndex]
                                          .assessmentResponseObjectDTO
                                          .rating
                                      }
                                      renderValue={(selected) =>
                                        selected.name
                                      }
                                      label='Trending Rating'
                                    >
                                      {tile.configObj?.selectableRatings?.tableData?.map(
                                        (e) => {
                                          return <MenuItem style={{background: (vertualFormPayload[tabIndex]
                                            .subSections[tileIndex]
                                            .assessmentResponseObjectDTO
                                            .rating?.id == e?.id) ? '#f6f6f6' : ''}} key={e.id} value={e}><ListItemText primary={e.name} /></MenuItem>;
                                        },
                                      )}
                                    </Select>
                                    { vertualError[tabIndex]
                                          .subSections[tileIndex]
                                          .assessmentResponseObjectDTO
                                      .rating.isError && (
                                      <FormHelperText className='Mui-error'>
                                        {
                                           vertualError[tabIndex]
                                          .subSections[tileIndex]
                                          .assessmentResponseObjectDTO
                                            .rating.errorMessage
                                        }
                                      </FormHelperText>
                                    )}
                                  </FormControl>
                              )}
                            </>
                          )}
                        </div>
                      ))}
                    </AccordionDetails>
                  </Accordion>
                </Stack>
              </div>
          ) : (
            <>
            {/* Commented for getting section if there is only label availble */}
              {/* {(((TabElement.configObj.doesThisQuestionHaveSelection === true || TabElement.configObj.doesThisQuestionHaveSelection ==='true') && TabElement.configObj.selectionType) || ((TabElement.configObj.doesThisQuestionHaveResponse === true || TabElement.configObj.doesThisQuestionHaveResponse === 'true') &&
                  (TabElement.configObj.responseType === 'String' ||
                    TabElement.configObj.responseType === 'Boolean' ||
                    TabElement.configObj.responseType === 'Integer')) || (
                      ((TabElement.configObj.isRatingRequired == true) || (TabElement.configObj.isRatingRequired === 'true'))
                    )) && ( */}
                <div className='accDetail-questions'>
                  <div style={{display: 'flex'}}>
                    <p>
                      {/* {TabElement.configObj.label} */}
                      <div
                        dangerouslySetInnerHTML={{
                          __html: TabElement.configObj.label,
                        }}
                      ></div>
                    </p>
                    {(TabElement.configObj.isResponseMandatory === true ||
                      TabElement.configObj.isResponseMandatory === 'true' ||
                      TabElement.configObj.isSelectionMandatory === true ||
                      TabElement.configObj.isSelectionMandatory === 'true' ||
                      TabElement.configObj.isRatingMandatory === true ||
                      TabElement.configObj.isRatingMandatory === 'true'
                      ) && (
                      <div style={{color: 'red'}}>*</div>
                    )}
                  </div>
                  <div className='accordian-right-svg-container'>
                    {(TabElement.configObj.isInfoRequired === true ||
                      TabElement.configObj.isInfoRequired === 'true') &&
                      TabElement.configObj.info && (
                        <div className='accordian-right-svg-container info-drower'>
                          <Tooltip title='Info' placement='top-end'>
                            <InfoIcon
                              onClick={(e) => {
                                handleOpenSideDrawer(TabElement.configObj.info);
                                e.stopPropagation();
                              }}
                              style={{marginRight: '10px'}}
                              alt='Info Icon' // Add alt text for accessibility
                            />
                          </Tooltip>
                        </div>
                      )}
                  </div>
                </div>
               {/* )} */}
              {(TabElement.configObj.doesThisQuestionHaveSelection === true ||
                TabElement.configObj.doesThisQuestionHaveSelection ===
                  'true') &&
                TabElement.configObj.selectionType && (
                  <>
                    <div className='rateOuter'>
                      {TabElement.configObj.selectableValues?.map(
                        (item, index) => {
                          return (
                            <div
                              className={`rate ${
                                vertualFormPayload[
                                  tabIndex
                                ].assessmentResponseObjectDTO.selection.some(
                                  (e) => e.id == item.id,
                                )
                                  ? 'active'
                                  : ''
                              } `}
                              onClick={(event) =>
                                handleChangeVertualPayload(
                                  item,
                                  'selection',
                                  tabIndex,
                                  null,
                                  null,
                                )
                              }
                            >
                              <p className='rateTitle'>
                                {selectedValue(item)?.name}
                              </p>
                              {vertualFormPayload[
                                tabIndex
                              ].assessmentResponseObjectDTO.selection.some(
                                (e) => e.id == item.id,
                              ) && (
                                <img src={Checked} className='checked'></img>
                              )}
                            </div>
                          );
                        },
                      )}
                    </div>
                    {vertualError[tabIndex].assessmentResponseObjectDTO
                      .selection.isError && (
                      <FormHelperText className='Mui-error'>
                        {
                          vertualError[tabIndex].assessmentResponseObjectDTO
                            .selection.errorMessage
                        }
                      </FormHelperText>
                    )}
                    <div style={{margin:'15px'}}>
                      <FormGroup>
                      <FormLabel>{TabElement.configObj.selectMenuDynamicType}</FormLabel>
                        {dropdownData[TabElement.configObj.selectMenuDynamicType]?.map((item) => (
                          <FormControlLabel
                            // key={item.id}
                            control={
                              <Checkbox
                                checked={false}
                                // onChange={() => handleCheckboxChange(item.id)}
                              />
                            }
                            labelPlacement='end'
                            label={
                              <Typography variant="body1" style={{ fontWeight: 500, color: '#333' , marginRight:'5px' }}>
                                {item.name}
                              </Typography>
                            }
                          />
                        ))}
                      </FormGroup>
                      </div>
                  </>
                )}
              {(TabElement.configObj.doesThisQuestionHaveResponse === true ||
                TabElement.configObj.doesThisQuestionHaveResponse === 'true') &&
              TabElement.configObj.responseType === 'String' ? (
                <>
                  <TextField
                    name='responseString'
                    value={
                      vertualFormPayload[tabIndex].assessmentResponseObjectDTO
                        .responseString
                    }
                    onChange={(event) =>
                      handleChangeVertualPayload(
                        event,
                        'textField',
                        tabIndex,
                        null,
                        null,
                      )
                    }
                    id='outlined-multiline-static'
                    label=''
                    variant='outlined'
                    placeholder={`Provide your feedback here ${
                      TabElement.configObj.minCharacterLimit ||
                      TabElement.configObj.maxCharacterLimit
                        ? `(limit: ${
                            TabElement.configObj.minCharacterLimit
                              ? ` min: ${TabElement.configObj.minCharacterLimit}`
                              : ''
                          }  ${
                            TabElement.configObj.maxCharacterLimit
                              ? `max: ${TabElement.configObj.maxCharacterLimit} `
                              : ''
                          }char)`
                        : ''
                    }`}
                    multiline
                    rows={3}
                    sx={textAreaStyle}
                    error={
                      vertualError[tabIndex].assessmentResponseObjectDTO
                        .responseString.isError
                    }
                    helperText={
                      vertualError[tabIndex].assessmentResponseObjectDTO
                        .responseString.isError &&
                      vertualError[tabIndex].assessmentResponseObjectDTO
                        .responseString.errorMessage
                    }
                  />
                </>
              ) : (TabElement.configObj.doesThisQuestionHaveResponse === true ||
                  TabElement.configObj.doesThisQuestionHaveResponse ===
                    'true') &&
                TabElement.configObj.responseType === 'Boolean' ? (
                <>
                  <Stack sx={{width: '50%'}}>
                    <RadioGroup
                      name='responseBoolean'
                      value={
                        vertualFormPayload[tabIndex].assessmentResponseObjectDTO
                          .responseBoolean
                      }
                      onChange={(event) =>
                        handleChangeVertualPayload(
                          event,
                          'ratio',
                          tabIndex,
                          null,
                          null,
                        )
                      }
                      row
                      aria-labelledby='demo-row-radio-buttons-group-label'
                    >
                      <FormControlLabel
                        value={true}
                        control={<Radio />}
                        label={'Yes'}
                      />
                      <FormControlLabel
                        value={false}
                        control={<Radio />}
                        label={'NO'}
                      />
                    </RadioGroup>
                    {vertualError[tabIndex].assessmentResponseObjectDTO
                      .responseBoolean.isError && (
                      <FormHelperText className='Mui-error'>
                        {
                          vertualError[tabIndex].assessmentResponseObjectDTO
                            .responseBoolean.errorMessage
                        }
                      </FormHelperText>
                    )}
                  </Stack>
                </>
              ) : (
                (TabElement.configObj.doesThisQuestionHaveResponse === true ||
                  TabElement.configObj.doesThisQuestionHaveResponse ===
                    'true') &&
                TabElement.configObj.responseType === 'Integer' && (
                  <>
                    <TextField
                      name='responseInteger'
                      value={
                        vertualFormPayload[tabIndex].assessmentResponseObjectDTO
                          .responseInteger
                      }
                      onChange={(event) =>
                        handleChangeVertualPayload(
                          event,
                          'numberField',
                          tabIndex,
                          null,
                          null,
                        )
                      }
                      id='outlined-multiline-static'
                      label=''
                      variant='outlined'
                      multiline
                      rows={1}
                      placeholder='Provide your feedback here '
                      sx={textAreaStyle}
                      error={
                        vertualError[tabIndex].assessmentResponseObjectDTO
                          .responseInteger.isError
                      }
                      helperText={
                        vertualError[tabIndex].assessmentResponseObjectDTO
                          .responseInteger.isError &&
                        vertualError[tabIndex].assessmentResponseObjectDTO
                          .responseInteger.errorMessage
                      }
                    />
                  </>
                )
              )}
              
              {(TabElement.configObj.isRatingRequired === true ||
                TabElement.configObj.isRatingRequired === 'true') && (
                <>
                  <FormControl
                    sx={{width: {md: '50%', sm: '100%'}, marginTop: '1rem'}}
                  >
                    <InputLabel id='demo-simple-select-label'>
                      Trending Rating
                    </InputLabel>
                    <Select
                      name='rating'
                      labelId='demo-simple-select-label'
                      id='demo-simple-select'
                      value={
                        vertualFormPayload[tabIndex].assessmentResponseObjectDTO
                          .rating
                      }
                      renderValue={(selected) =>
                        selected.name
                      }
                      onChange={(event) =>
                        handleChangeVertualPayload(
                          event,
                          'dropDownSelect',
                          tabIndex,
                          null,
                          null,
                        )
                      }
                      // value={feedbackPayload?.rating || ""}
                      label='Trending Rating'
                      // onChange={(e) => handleChangeFeedback(e, "dropdown")}
                    >
                      {/* <MenuItem disabled value="">
                                        <em>Placeholder</em>
                                    </MenuItem> */}
                      {/* <MenuItem value={"OutStanding"}>Outstanding</MenuItem> */}
                      {TabElement.configObj?.selectableRatings?.tableData?.map(
                        (e) => {
                          return <MenuItem style={{background: (vertualFormPayload[tabIndex].assessmentResponseObjectDTO.rating?.id == e?.id) ? '#f6f6f6' : ''}} key={e.id} value={e}><ListItemText primary={e.name} /></MenuItem>;
                        },
                      )}
                      {/* <MenuItem value={"Strong"}>Strong</MenuItem>
                                    <MenuItem value={"Adequate"}>Adequate</MenuItem>
                                    <MenuItem value={"Insufficient"}>Insufficient</MenuItem> */}
                    </Select>
                    {vertualError[tabIndex].assessmentResponseObjectDTO
                      .rating.isError && (
                      <FormHelperText className='Mui-error'>
                        {
                          vertualError[tabIndex].assessmentResponseObjectDTO
                            .rating.errorMessage
                        }
                      </FormHelperText>
                    )}
                  </FormControl>
                </>
              )}
            </>
          )}
        </div>
      ));
    }
  };

  return (
    <div className='selfAssesmentAllinone'>
      <div className='feedback-main'>
        {isLoading ? (
          <AccSkeleton />
        ) : (
          <div className='feedbackAssessment m-3'>
            {/* <>{(formData.assessmentFormDTO || formData) && createDynamicForm(formData.assessmentFormDTO ? formData.assessmentFormDTO : formData)}</> */}
            {formData.assessmentFormDTO?.sections?.length > 0 &&
                createDynamicForm(formData)}
            <div
              style={{
                display: 'flex',
                justifyContent: 'end',
                gap: '1rem !important',
              }}
              className='d-flex justify-content-end gap-3 pt-5 main-btn'
            >
              <div className='valuesBtn draft'>Auto Save 2 sec</div>
              <button
                // style={styleSaveAsDraft()}
                style={{marginRight: '15px'}}
                className="valuesBtn save-draft"
                // onClick={() => handleSaveAsDraft('submitAsDraft')}
              >
                {submitLoader ? (
                  <CircularProgress size={29} sx={{ color: "#ffffff" }} />
                ) : (
                  "Save as draft"
                )}
              </button>
              <button
                className='valuesBtn next'
                // onClick={() => handleValidate()}
              >
                {submitLoader ? (
                  <CircularProgress size={29} sx={{color: '#ffffff'}} />
                ) : (
                  'Submit'
                )}
              </button>
            </div>
          </div>
        )}
      </div>

      {isOpenDrawer && (
        <SideDrawer isOpen={isOpenDrawer} setIsOpen={setIsOpenDrawer}>
          <div className='info'>
            {drawerData && (
              <div dangerouslySetInnerHTML={{__html: drawerData}} />
            )}
          </div>
        </SideDrawer>
      )}
    </div>
  );
};

export default SelfAssesmentAllinone;
SelfAssesmentAllinone.propTypes = {
  dynamicFormData: PropTypes.any,
  valuesData: PropTypes.array,
};
