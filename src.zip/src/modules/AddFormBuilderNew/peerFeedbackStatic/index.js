import React from 'react';
import PropTypes from 'prop-types';
import { isEmptyNullUndefined } from 'shared/utils/CommonUtils';
import { Divider } from '@mui/material';
const parse = require('html-react-parser');

// Helper function to render feedback items
const renderFeedback = (feedback) => (
  <div key={feedback?.employeeId} className="feedback-item">
    <div className="feedback-header">
      <div className="employee-info">
        <span className="employee-name">{feedback?.employeeName}</span>
      </div>
      <div className="employee-department">
        <span className="employee-designation">{feedback?.employeeDesignation}</span>
      </div>
    </div>
    <div className="feedback-content">
      <div className="feedback-text">
        <div key={feedback?.employeeName} className="emp-response">
          <div className="text-responses">
            {!isEmptyNullUndefined(feedback?.responseObject?.responseString) &&
              parse(feedback?.responseObject?.responseString)}
            {!isEmptyNullUndefined(feedback?.responseObject?.responseBoolean) &&
              (feedback?.responseObject?.responseBoolean ? 'Yes' : 'No')}
            {!isEmptyNullUndefined(feedback?.responseObject?.responseInteger) &&
              feedback?.responseObject?.responseInteger}
          </div>
          {!isEmptyNullUndefined(feedback?.responseObject?.rating?.name) && (
            <div className="ratings">
              Rating: {feedback?.responseObject?.rating?.name}
            </div>
          )}
          {!isEmptyNullUndefined(feedback?.responseObject?.selection) && (
            <div className="selections">
              {feedback?.responseObject?.selection?.map((selected) => (
                <div key={selected?.name} className="selected-value">
                  {selected?.name}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  </div>
);

// Helper function to render subsections
const renderSubSections = (subSections) =>
  subSections
    ?.filter((subSection) => subSection?.visible)
    .sort((a, b) => a.sequenceNo - b.sequenceNo)
    .map((subSection) => (
      <div key={subSection?.id} className="sub-section-main">
        <div
          className="question-label"
          dangerouslySetInnerHTML={{ __html: subSection?.label }}
        />
        {subSection?.feedbacks?.map(renderFeedback)}
        {!isEmptyNullUndefined(subSection?.subSectionReferences) && (
          <div className="nested-sub-sections">
            {renderSubSections(subSection?.subSectionReferences)}
          </div>
        )}
        <Divider />
      </div>
    ));

// Main component rendering the sections and subsections
const PeerFeedbackStatic = ({ data }) => {
  console.log('Data:', data);

  return (
    <div className="peer-feedback-container-in-sidebar">
      {data
        ?.filter((section) => section?.visible)
        .sort((a, b) => a.sequenceNo - b.sequenceNo)
        .map((section) => (
          <div key={section?.id} className="section-main">
            <div
              className="section-label"
              dangerouslySetInnerHTML={{ __html: section?.label }}
            />
            {section?.subSectionReferences
              ? renderSubSections(section?.subSectionReferences)
              : section?.feedbacks?.map(renderFeedback)}
          </div>
        ))}
    </div>
  );
};

PeerFeedbackStatic.propTypes = {
  data: PropTypes.array.isRequired,
};

export default PeerFeedbackStatic;


// import React from 'react';
// import PropTypes from 'prop-types';
// import {isEmptyNullUndefined} from 'shared/utils/CommonUtils';
// import {Divider} from '@mui/material';

// const parse = require('html-react-parser');

// const PeerFeedbackStatic = ({data}) => {
//   console.log('dataasasasasasa', data);

//   return (
//     <div className='peer-feedback-container-in-sidebar'>
//       {data
//         ?.filter((section) => section?.visible)
//         .map((section) => (
//           <div key={section?.id} className='section-main'>
//             <div
//               className='section-label'
//               dangerouslySetInnerHTML={{__html: section?.label}}
//             />
//             {
//               !isEmptyNullUndefined(section?.subSectionReferences) ? (
//                 section?.subSectionReferences
//                   ?.filter((subSection) => subSection?.visible)
//                   .map((subSection) => (
//                     <div key={subSection?.id} className='sub-section-main'>
//                       <div
//                         className='question-label'
//                         dangerouslySetInnerHTML={{__html: subSection?.label}}
//                       />
//                       {/* ******************************************************************************** */}
//                       {
//                         !isEmptyNullUndefined(
//                           subSection?.subSectionReferences,
//                         ) ? (
//                           subSection?.subSectionReferences
//                             ?.filter((nsubSection) => nsubSection?.visible)
//                             .map((nsubSection) => (
//                               <div
//                                 key={nsubSection?.id}
//                                 className='sub-section-main'
//                               >
//                                 <div
//                                   className='question-label'
//                                   dangerouslySetInnerHTML={{
//                                     __html: nsubSection?.label,
//                                   }}
//                                 />
//                                 {nsubSection?.feedbacks?.map((feedback) => (
//                                   <div
//                                     key={feedback?.employeeId}
//                                     className='feedback-item'
//                                   >
//                                     <div className='feedback-header'>
//                                       <div className='employee-info'>
//                                         <span className='employee-name'>
//                                           {feedback?.employeeName}
//                                         </span>
//                                       </div>
//                                       <div className='employee-department'>
//                                         <span className='employee-designation'>
//                                           {feedback?.employeeDesignation}
//                                         </span>
//                                       </div>
//                                     </div>
//                                     <div className='feedback-content'>
//                                       {nsubSection?.feedbacks && (
//                                         <div className='feedback-text'>
//                                           <div
//                                             key={feedback?.employeeName}
//                                             className='emp-response'
//                                           >
//                                             <div className='text-responses'>
//                                               {!isEmptyNullUndefined(
//                                                 feedback?.responseObject
//                                                   ?.responseString,
//                                               ) &&
//                                                 parse(
//                                                   feedback?.responseObject
//                                                     ?.responseString,
//                                                 )}
//                                               {!isEmptyNullUndefined(
//                                                 feedback?.responseObject
//                                                   ?.responseBoolean,
//                                               )
//                                                 ? feedback?.responseObject
//                                                     ?.responseBoolean
//                                                   ? 'Yes'
//                                                   : 'No'
//                                                 : ''}
//                                               {!isEmptyNullUndefined(
//                                                 feedback?.responseObject
//                                                   ?.responseInteger,
//                                               ) &&
//                                                 feedback?.responseObject
//                                                   ?.responseInteger}
//                                             </div>
//                                             {!isEmptyNullUndefined(
//                                               feedback?.responseObject?.rating
//                                                 ?.name,
//                                             ) && (
//                                               <div className='ratings'>
//                                                 Rating :{' '}
//                                                 {
//                                                   feedback?.responseObject
//                                                     ?.rating?.name
//                                                 }
//                                               </div>
//                                             )}
//                                             {!isEmptyNullUndefined(
//                                               feedback?.responseObject
//                                                 ?.selection,
//                                             ) && (
//                                               <div className='selections'>
//                                                 {feedback?.responseObject?.selection?.map(
//                                                   (selected, sIndex) => {
//                                                     return (
//                                                       <div className='selected-value'>
//                                                         {selected?.name}
//                                                       </div>
//                                                     );
//                                                   },
//                                                 )}
//                                               </div>
//                                             )}
//                                           </div>
//                                         </div>
//                                       )}
//                                     </div>
//                                   </div>
//                                 ))}
//                               </div>
//                             ))
//                         ) : (
//                           // data?.filter(subSection => subSection?.visible).map((subSection) => (
//                           <div
//                             key={subSection?.id}
//                             className='sub-section-main'
//                           >
//                             <div
//                               className='question-label'
//                               dangerouslySetInnerHTML={{
//                                 __html: subSection?.label,
//                               }}
//                             />
//                             {subSection?.feedbacks?.map((feedback) => (
//                               <div
//                                 key={feedback?.employeeId}
//                                 className='feedback-item'
//                               >
//                                 <div className='feedback-header'>
//                                   <div className='employee-info'>
//                                     <span className='employee-name'>
//                                       {feedback?.employeeName}
//                                     </span>
//                                   </div>
//                                   <div className='employee-department'>
//                                     <span className='employee-designation'>
//                                       {feedback?.employeeDesignation}
//                                     </span>
//                                   </div>
//                                 </div>
//                                 <div className='feedback-content'>
//                                   <div className='feedback-text'>
//                                     <div
//                                       key={feedback?.employeeName}
//                                       className='emp-response'
//                                     >
//                                       <div className='text-responses'>
//                                         {!isEmptyNullUndefined(
//                                           feedback?.responseObject
//                                             ?.responseString,
//                                         ) &&
//                                           parse(
//                                             feedback?.responseObject
//                                               ?.responseString,
//                                           )}
//                                         {!isEmptyNullUndefined(
//                                           feedback?.responseObject
//                                             ?.responseBoolean,
//                                         )
//                                           ? feedback?.responseObject
//                                               ?.responseBoolean
//                                             ? 'Yes'
//                                             : 'No'
//                                           : ''}
//                                         {!isEmptyNullUndefined(
//                                           feedback?.responseObject
//                                             ?.responseInteger,
//                                         ) &&
//                                           feedback?.responseObject
//                                             ?.responseInteger}
//                                       </div>
//                                       {!isEmptyNullUndefined(
//                                         feedback?.responseObject?.rating?.name,
//                                       ) && (
//                                         <div className='ratings'>
//                                           Rating :{' '}
//                                           {
//                                             feedback?.responseObject?.rating
//                                               ?.name
//                                           }
//                                         </div>
//                                       )}
//                                       {!isEmptyNullUndefined(
//                                         feedback?.responseObject?.selection,
//                                       ) && (
//                                         <div className='selections'>
//                                           {feedback?.responseObject?.selection?.map(
//                                             (selected, sIndex) => {
//                                               return (
//                                                 <div className='selected-value'>
//                                                   {selected?.name}
//                                                 </div>
//                                               );
//                                             },
//                                           )}
//                                         </div>
//                                       )}
//                                     </div>
//                                   </div>
//                                 </div>
//                               </div>
//                             ))}
//                           </div>
//                         )
//                         // ))
//                       }

//                       {/* ******************************************************************************** */}
//                       <Divider />

//                       {subSection?.feedbacks?.map((feedback) => (
//                         <div
//                           key={feedback?.employeeId}
//                           className='feedback-item'
//                         >
//                           <div className='feedback-header'>
//                             <div className='employee-info'>
//                               <span className='employee-name'>
//                                 {feedback?.employeeName}
//                               </span>
//                             </div>
//                             <div className='employee-department'>
//                               <span className='employee-designation'>
//                                 {feedback?.employeeDesignation}
//                               </span>
//                             </div>
//                           </div>
//                           <div className='feedback-content'>
//                             {subSection?.feedbacks && (
//                               <div className='feedback-text'>
//                                 <div
//                                   key={feedback?.employeeName}
//                                   className='emp-response'
//                                 >
//                                   <div className='text-responses'>
//                                     {!isEmptyNullUndefined(
//                                       feedback?.responseObject?.responseString,
//                                     ) &&
//                                       parse(
//                                         feedback?.responseObject
//                                           ?.responseString,
//                                       )}
//                                     {!isEmptyNullUndefined(
//                                       feedback?.responseObject?.responseBoolean,
//                                     )
//                                       ? feedback?.responseObject
//                                           ?.responseBoolean
//                                         ? 'Yes'
//                                         : 'No'
//                                       : ''}
//                                     {!isEmptyNullUndefined(
//                                       feedback?.responseObject?.responseInteger,
//                                     ) &&
//                                       feedback?.responseObject?.responseInteger}
//                                   </div>
//                                   {!isEmptyNullUndefined(
//                                     feedback?.responseObject?.rating?.name,
//                                   ) && (
//                                     <div className='ratings'>
//                                       Rating :{' '}
//                                       {feedback?.responseObject?.rating?.name}
//                                     </div>
//                                   )}
//                                   {!isEmptyNullUndefined(
//                                     feedback?.responseObject?.selection,
//                                   ) && (
//                                     <div className='selections'>
//                                       {feedback?.responseObject?.selection?.map(
//                                         (selected, sIndex) => {
//                                           return (
//                                             <div className='selected-value'>
//                                               {selected?.name}
//                                             </div>
//                                           );
//                                         },
//                                       )}
//                                     </div>
//                                   )}
//                                 </div>
//                               </div>
//                             )}
//                           </div>
//                         </div>
//                       ))}
//                     </div>
//                   ))
//               ) : (
//                 // data?.filter(subSection => subSection?.visible).map((subSection) => (
//                 <div key={section?.id} className='sub-section-main'>
//                   <div
//                     className='question-label'
//                     dangerouslySetInnerHTML={{__html: section?.label}}
//                   />
//                   {section?.feedbacks?.map((feedback) => (
//                     <div key={feedback?.employeeId} className='feedback-item'>
//                       {/* <div className="icon-size">
//                                         {feedback?.profilePhotoPath ? 
//                                             <img src={feedback?.profilePhotoPath} className="user" alt="User" />
//                                             :
//                                             <Avatar 
//                                                 name={feedback?.employeeName} 
//                                                 size="45" 
//                                                 className="user"
//                                                 color={"#00425A"}  
//                                             />
//                                         }
//                                     </div> */}
//                       <div className='feedback-header'>
//                         <div className='employee-info'>
//                           <span className='employee-name'>
//                             {feedback?.employeeName}
//                           </span>
//                         </div>
//                         <div className='employee-department'>
//                           <span className='employee-designation'>
//                             {feedback?.employeeDesignation}
//                           </span>
//                         </div>
//                       </div>
//                       <div className='feedback-content'>
//                         {/* {subSection?.feedbacks && ( */}
//                         <div className='feedback-text'>
//                           {/* { */}
//                           {/* subSection?.feedbacks?.map((feedback, index) => { */}
//                           {/* return( */}
//                           <div
//                             key={feedback?.employeeName}
//                             className='emp-response'
//                           >
//                             <div className='text-responses'>
//                               {!isEmptyNullUndefined(
//                                 feedback?.responseObject?.responseString,
//                               ) &&
//                                 parse(feedback?.responseObject?.responseString)}
//                               {!isEmptyNullUndefined(
//                                 feedback?.responseObject?.responseBoolean,
//                               )
//                                 ? feedback?.responseObject?.responseBoolean
//                                   ? 'Yes'
//                                   : 'No'
//                                 : ''}
//                               {!isEmptyNullUndefined(
//                                 feedback?.responseObject?.responseInteger,
//                               ) && feedback?.responseObject?.responseInteger}
//                             </div>
//                             {!isEmptyNullUndefined(
//                               feedback?.responseObject?.rating?.name,
//                             ) && (
//                               <div className='ratings'>
//                                 Rating :{' '}
//                                 {feedback?.responseObject?.rating?.name}
//                               </div>
//                             )}
//                             {!isEmptyNullUndefined(
//                               feedback?.responseObject?.selection,
//                             ) && (
//                               <div className='selections'>
//                                 {feedback?.responseObject?.selection?.map(
//                                   (selected, sIndex) => {
//                                     return (
//                                       <div className='selected-value'>
//                                         {selected?.name}
//                                       </div>
//                                     );
//                                   },
//                                 )}
//                               </div>
//                             )}
//                           </div>
//                           {/* ) */}
//                           {/* }) */}
//                           {/* } */}
//                         </div>
//                         {/* )} */}
//                       </div>
//                     </div>
//                   ))}
//                 </div>
//               )
//               // ))
//             }
//           </div>
//         ))}
//     </div>
//   );
// };

// export default PeerFeedbackStatic;
