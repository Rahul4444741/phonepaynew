import * as React from 'react';
import { useRef, useEffect, useState } from 'react';
import { BsXLg } from 'react-icons/bs';
import PropTypes from 'prop-types';


export default function SideDrawer({setIsOpen, children}) { 

  const [disappear, setDisappear] = useState(false);

  function HandleOutsideClick(ref) {
    useEffect(() => {
      /**
       * Alert if clicked on outside of element
       */
      function handleClickOutside(event) {
        if (ref.current && !ref.current.contains(event.target)) {
            setDisappear(true);
            setTimeout(() => {
              setIsOpen(false);
            }, 400);            
        }
      }

      // Bind the event listener
      document.addEventListener("mousedown", handleClickOutside);
      return () => {
        // Unbind the event listener on clean up
        document.removeEventListener("mousedown", handleClickOutside);
      };
    }, [ref]);
  }
  const wrapperRef = useRef(null);
  HandleOutsideClick(wrapperRef);

  const handleCloase = () => {
    setDisappear(true);
    setTimeout(() => {
      setIsOpen(false);
    }, 400);
  }
 

  return (
          <div className={`${disappear ? "d-sidedrawer":"sidedrawer"}`} ref={wrapperRef}>

            <div className='close-drawer-icon'>
              <BsXLg onClick={() => handleCloase()} />  
            </div>

            <div className='drawer-children-main'>
              {children}
            </div>  

          </div>
  );
}

SideDrawer.propTypes = {
  setIsOpen: PropTypes.bool,
  children: PropTypes.any,
};