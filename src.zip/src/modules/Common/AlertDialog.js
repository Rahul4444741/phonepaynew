import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import PropTypes from 'prop-types';
import Stack from '@mui/material/Stack';
import IconButton from '@mui/material/IconButton';
import WarningIcon from '@mui/icons-material/Warning';
import IntlMessages from '@crema/utility/IntlMessages';

const AlertDialog = ({alertProps, handleNo, handleYes}) => {
  const iconButtonStyled = {padding: '2px 10px'};
  return (
    <div>
      <Dialog
        open={true}
        onClose={() => handleNo()}
        aria-labelledby='alert-dialog-title'
        aria-describedby='alert-dialog-description'
      >
        <DialogTitle id='alert-dialog-title'>
          <Stack direction='row'>
            <IconButton sx={{...iconButtonStyled}} aria-label='save'>
              <WarningIcon color='warning' />
            </IconButton>
            <Stack sx={{fontSize: 20}}>{alertProps.title}</Stack>
          </Stack>
        </DialogTitle>
        <DialogContent>
          <DialogContentText id='alert-dialog-description'>
            <Stack sx={{fontSize: 16}}>{alertProps.message}</Stack>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            id='alert-dialog-accept-submit-button'
            onClick={() => handleYes()}
            data-test='alert-dialog-accept-submit-button'
          >
            <IntlMessages id='common.button.Yes' />
          </Button>
          <Button
            id='alert-dialog-reject-submit-button'
            onClick={() => handleNo()}
          >
            <IntlMessages id='common.button.No' />
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

AlertDialog.propTypes = {
  alertProps: PropTypes.object.isRequired,
  handleNo: PropTypes.func.isRequired,
  handleYes: PropTypes.func.isRequired,
};
export default AlertDialog;
