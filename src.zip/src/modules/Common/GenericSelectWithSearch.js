import React from 'react';
import PropTypes from 'prop-types';
import {FormControl, Autocomplete, TextField} from '@mui/material';

const GenericSelectWithSearch = ({
  label,
  name,
  value,
  error,
  helperText,
  handleChange,
  optionList,
  customStyles,
  labelName,
  disabled = false,
}) => {
  // Filter out duplicates from the optionList
  const uniqueQueryList = optionList?.filter(
    (item, index, self) => index === self.findIndex((t) => t.id === item.id),
  );

  return (
    <FormControl
      size='small'
      sx={customStyles}
    >
      <Autocomplete
        id='customQueryId'
        options={uniqueQueryList || []}
        getOptionLabel={(option) => option[labelName] || ''}
        onChange={(event, newValue) =>
          handleChange(
            {
              target: {
                name: name,
                value: newValue ? newValue.id : '',
              },
            },
            'dropdown',
          )
        }
        // value={value}
        value={uniqueQueryList?.find((item) => item.id === value) || null}
        renderInput={(params) => (
          <TextField
            {...params}
            variant='outlined'
            error={error}
            helperText={helperText}
            size='small'
            label={label}
          />
        )}
        disabled={disabled}
      />
    </FormControl>
  );
};

GenericSelectWithSearch.propTypes = {
  label: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
  error: PropTypes.bool,
  helperText: PropTypes.string,  // Add helperText prop type validation
  handleChange: PropTypes.func.isRequired,
  optionList: PropTypes.arrayOf(PropTypes.object).isRequired,
  customStyles: PropTypes.object,
  labelName: PropTypes.string.isRequired,
  disabled: PropTypes.bool,
};

export default GenericSelectWithSearch;
