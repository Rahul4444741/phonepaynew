import React, {useEffect, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {
  Autocomplete,
  TextField,
  CircularProgress,
  Avatar,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Typography,
  styled,
  Popper,
} from '@mui/material';
import axios from 'axios';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {fetchError, showInfo} from 'redux/actions';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {apiCatchErrorMessage} from 'shared/utils/CommonUtils';

const CustomPopper = styled(Popper)(({theme}) => ({
  zIndex: -1, // Adjust the zIndex as needed
}));

const SelectEmployee = ({onEmployeeSelect,customSx}) => {
  const dispatch = useDispatch();
  const selectedCompany = useSelector(({company}) => company.selectedCompany);

  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();

  useEffect(() => {
    if (searchTerm.length > 2) {
      setLoading(true);
      getEmployeesData(selectedCompany?.id, searchTerm);
    } else {
      setEmployees([]);
    }
  }, [searchTerm]);

  const getEmployeesData = async (companyId, searchValue) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.employeeSimulator}employees/dropdown/${companyId}?searchValue=${searchValue}`,
        {cancelToken: source.token},
      );

      if (res.status === 200) {
        setLoading(false);
        if (res.data.length === 0) {
          dispatch(showInfo(`Employees not found with keyword '${searchTerm}'`));
          setEmployees([]);
        } else {
          setEmployees(res.data);
        }
      } else {
        setLoading(false);
        setEmployees([]);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setLoading(false);
      setEmployees([]);
    }
  };

  const getInitials = (name) => {
    const nameArray = name.split(' ');
    const initials = nameArray.map((n) => n[0]).join('');
    return initials;
  };

  const stringToColor = (string) => {
    let hash = 0;
    for (let i = 0; i < string.length; i++) {
      hash = string.charCodeAt(i) + ((hash << 5) - hash);
    }
    let color = '#';
    for (let i = 0; i < 3; i++) {
      const value = (hash >> (i * 8)) & 0xff;
      color += ('00' + value.toString(16)).slice(-2);
    }
    return color;
  };

  return (
    <Autocomplete
      freeSolo
      size='small'
      options={employees}
      getOptionLabel={(option) => option.name || ''}
      onInputChange={(event, value) => setSearchTerm(value)}
      clearOnBlur={true}
      PopperComponent={CustomPopper}
      loading={loading}
      onChange={(event, value) => {
        onEmployeeSelect(value);
      }}
      renderOption={(props, option) => (
        <ListItem {...props} alignItems='flex-start'>
          <ListItemAvatar>
            <Avatar sx={{bgcolor: stringToColor(option.name)}}>
              {getInitials(option.name)}
            </Avatar>
          </ListItemAvatar>
          <ListItemText
            primary={option.name}
            secondary={
              <React.Fragment>
                <Typography
                  component='span'
                  variant='body2'
                  color='textPrimary'
                >
                  {option.emailId}
                </Typography>
              </React.Fragment>
            }
          />
        </ListItem>
      )}
      renderInput={(params) => (
        <TextField
          {...params}
          label='Search Employee'
          placeholder='Enter at least 3 char...'
          variant='outlined'
          InputProps={{
            ...params.InputProps,
            endAdornment: (
              <>
                {loading ? (
                  <CircularProgress color='inherit' size={20} />
                ) : null}
                {params.InputProps.endAdornment}
              </>
            ),
          }}
        />
      )}
      sx={customSx}
    />
  );
};

export default SelectEmployee;
