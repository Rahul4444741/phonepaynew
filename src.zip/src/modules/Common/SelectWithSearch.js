import React from 'react';
import {FormControl, Autocomplete, TextField, Stack} from '@mui/material';

const SelectWithSearch = ({
  label,
  formData,
  formError,
  handleChange,
  optionList,
  customStyles,
  disabled
}) => {
  // Filter out duplicates from the optionList
  const uniqueQueryList = optionList?.filter(
    (item, index, self) => index === self.findIndex((t) => t.id === item.id),
  );

  return (
    <FormControl
      size='small'
      sx={{
        ...customStyles,
        '& .MuiOutlinedInput-root': {
          '& fieldset': {
            borderLeftColor: 'red',
            borderLeftWidth: 3,
          },
        },
      }}
    >
      <Autocomplete
        id='customQueryId'
        options={uniqueQueryList || []}
        getOptionLabel={(option) => option.variableName || ''}
        onChange={(event, newValue) =>
          handleChange(
            {
              target: {
                name: 'customQueryId',
                value: newValue ? newValue.id : '',
              },
            },
            'dropdown',
          )
        }
        value={
          uniqueQueryList?.find(
            (item) => item.id === formData?.customQueryId,
          ) || null
        }
        renderInput={(params) => (
          <TextField
            {...params}
            variant='outlined'
            error={formError.customQueryId.isError}
            helperText={
              formError.customQueryId.isError
                ? formError.customQueryId.errorMessage
                : ''
            }
            size='small'
            label={label}
          />
        )}
      disabled={disabled}
      />
    </FormControl>
  );
};

export default SelectWithSearch;
