import * as React from 'react';
import {
  Autocomplete,
  Box,
  CircularProgress,
  FormControlLabel,
  FormLabel,
  IconButton,
  Radio,
  RadioGroup,
} from '@mui/material';
import TextField from '@mui/material/TextField';
import Select from '@mui/material/Select';
import Stack from '@mui/material/Stack';
import MenuItem from '@mui/material/MenuItem';
import {AiOutlineClose} from 'react-icons/ai';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Button from '@mui/material/Button';
import {useDispatch, useSelector} from 'react-redux';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard} from '../../../@crema';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import {
  showMessage,
  fetchError,
  fetchStart,
  showInfo,
} from '../../../redux/actions';
import Router, {useRouter} from 'next/router';
import {styled} from '@mui/material/styles';
import {DesktopDatePicker, LocalizationProvider} from '@mui/x-date-pickers';
import {AdapterDateFns} from '@mui/x-date-pickers/AdapterDateFns';
import AppInfoView from '../../../@crema/core/AppInfoView';
import FormHelperText from '@mui/material/FormHelperText';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {
  apiCatchErrorMessage,
  getCompanyDateFormatForInputs,
  isEmptyNullUndefined,
  isStrExceeds,
} from 'shared/utils/CommonUtils';
import {footerButton} from 'shared/constants/AppConst';
import axios from 'axios';
import IntlMessages from '@crema/utility/IntlMessages';

const initialEmptyEmployeeList = {
  name: null,
  dateOfBirth: null,
  emailId: null,
  employeeId: null,
  dateOfJoining: null,
  employeeDesignation: null,
  company: {
    // id: null,
  },
  employeeType: {
    id: null,
  },
  employeeLevel: {
    id: null,
  },
  employeeFunction: {
    id: null,
  },
  employeeSubFunction: {
    id: null,
  },
  empstatus: {
    id: null,
  },
  employmentStatus: {
    id: null,
  },
  employeeGrade: {
    id: null,
  },
  jobCode: {
    id: null,
  },
  manager: null,
  isManager: false,
  isFunctionalLeader: false,
  // roles: null,
  string1: null,
  string2: null,
  string3: null,
  string4: null,
  string5: null,

  date1: null,
  date2: null,
  date3: null,
  date4: null,
  date5: null,

  boolean1: false,
  boolean2: false,
  boolean3: false,
  boolean4: false,
  boolean5: false,

  double1: null,
  double2: null,
  double3: null,
  double4: null,
  double5: null,
};

const initialFormErrorList = {
  name: {isError: false, errorMessage: ''},
  emailId: {isError: false, errorMessage: ''},
  dateOfBirth: {isError: false, errorMessage: ''},
  employeeId: {isError: false, errorMessage: ''},
  dateOfJoining: {isError: false, errorMessage: ''},
  employeeDesignation: {isError: false, errorMessage: ''},
  employeeType: {
    id: {isError: false, errorMessage: ''},
  },
  employeeLevel: {
    id: {isError: false, errorMessage: ''},
  },

  manager: {
    id: {isError: false, errorMessage: ''},
  },
  empstatus: {
    id: {isError: false, errorMessage: ''},
  },
  employmentStatus: {
    id: {isError: false, errorMessage: ''},
  },
  employeeGrade: {
    id: {isError: false, errorMessage: ''},
  },
  jobCode: {
    id: {isError: false, errorMessage: ''},
  },
  employeeFunction: {
    id: {isError: false, errorMessage: ''},
  },
  employeeSubFunction: {
    id: {isError: false, errorMessage: ''},
  },
  isManager: {isError: false, errorMessage: ''},
  isFunctionalLeader: {isError: false, errorMessage: ''},
  // roles: {isError: false, errorMessage: ''},
  string1: {isError: false, errorMessage: ''},
  string2: {isError: false, errorMessage: ''},
  string3: {isError: false, errorMessage: ''},
  string4: {isError: false, errorMessage: ''},
  string5: {isError: false, errorMessage: ''},
  date1: {isError: false, errorMessage: ''},
  date2: {isError: false, errorMessage: ''},
  date3: {isError: false, errorMessage: ''},
  date4: {isError: false, errorMessage: ''},
  date5: {isError: false, errorMessage: ''},
  boolean1: {isError: false, errorMessage: ''},
  boolean2: {isError: false, errorMessage: ''},
  boolean3: {isError: false, errorMessage: ''},
  boolean4: {isError: false, errorMessage: ''},
  boolean5: {isError: false, errorMessage: ''},
  double1: {isError: false, errorMessage: ''},
  double2: {isError: false, errorMessage: ''},
  double3: {isError: false, errorMessage: ''},
  double4: {isError: false, errorMessage: ''},
  double5: {isError: false, errorMessage: ''},
};

const AddEmployee = () => {
  const router = useRouter();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const {id, page} = router.query;
  const dispatch = useDispatch();
  const [isEdit, setIsEdit] = React.useState(false);
  const [employee, setEmployee] = React.useState(initialEmptyEmployeeList);
  const [employeeResetDetails, setEmployeeResetDetails] = React.useState(
    initialEmptyEmployeeList,
  );

  const [formError, setFormError] = React.useState(initialFormErrorList);
  const [loading, setLoading] = React.useState(false);
  const [planData, setPlanData] = React.useState(null);
  const [filteredSubFunction, setFilteredSubFunction] = React.useState([]);

  const [customVariables, setCustomVariables] = React.useState([]);
  const [customVariablesError, setCustomVariablesError] = React.useState({});

  const [employeeDisplay, setEmployeeDisplay] = React.useState([]);

  const initialCustomData = customVariables.map((field) => ({
    options: field.dataType === 'Array' ? [] : field.options || [],
    data:
      field.dataType === 'Array'
        ? ''
        : field.dataType === 'Boolean'
        ? false
        : field.data || '',
    isMultiselect: field.isMultiselect,
    customVariables: {
      id: field.id,
    },
  }));

  const [customData, setCustomData] = React.useState(initialCustomData);
  const [customDataResetDetails, setCustomDataResetDetails] =
    React.useState(initialCustomData);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();
  const source3 = CancelToken.source();

  if (router.isFallback) {
    <h1>Data is loading</h1>;
  }

  React.useEffect(() => {
    dispatch(fetchStart);
    if (id != undefined) {
      handleResetForm();
      setIsEdit(true);
      getEmployeeDetails(id);
    } else {
      handleResetForm();
      setIsEdit(false);
    }
    getPlanData(selectedCompany.id);
    getAllCustomVariables(selectedCompany.id);
    getAllVariableNameMapping();
    // return () => {
    //   source.cancel('Aborting all previous operations.');
    //   source2.cancel('Aborting all previous operations.');
    //   source3.cancel('Aborting all previous operations.');
    // };
  }, [router]);

  React.useEffect(() => {
    if (planData) {
      filterDataByEmployeeFunction(employee.employeeFunction?.id);
    }
  }, [planData, employee.employeeFunction?.id]);

  const getAllCustomVariables = async (companyId) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.customvariables_company}${companyId}?status=ACTIVE`,
        {cancelToken: source3.token},
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(
            showInfo(
              `You have no ${status.toLowerCase()} Custom Variables for selected company`,
            ),
          );
          setCustomVariables([]);
        } else {
          setCustomVariables(res.data);
        }
      } else {
        setCustomVariables([]);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
        // TODO document why this block is empty
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setCustomVariables([]);
    }
  };

  const getPlanData = async (companyId) => {
    try {
      const response = await jwtAxios.get(
        `${API_ROUTS.configuration_data}${companyId}`,
        {cancelToken: source.token},
      );
      if (response.status == 200) {
        setPlanData(response.data);
      } else {
        // TODO document why this block is empty
      }
    } catch (e) {
      if (axios.isCancel(e)) {
        // TODO document why this block is empty
      } else if (e?.response?.data?.detail) {
        dispatch(fetchError(e?.response?.data?.detail));
      } else {
        dispatch(fetchError(e?.message));
      }
    }
  };

  const getAllVariableNameMapping = async () => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.variable_name_mapping}/find-by-entity/Employee/${selectedCompany.id}`,
        {headers: {}},
        {
          cancelToken: source.token,
        },
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(
            showInfo('You have no Variable Name Mapping for selected company'),
          );
          setEmployeeDisplay([]);
        } else {
          setEmployeeDisplay(res.data);
        }
      }
    } catch (error) {
      setEmployeeDisplay([]);
    }
  };

  const getLable = (name) => {
    const field = employeeDisplay.find((item) => item.variableName == name);
    return field?.displayName;
  };

  const getIsVisible = (name) => {
    const field = employeeDisplay?.find((item) => item.variableName == name);
    if (!isEmptyNullUndefined(field)) {
      return field.isVisible;
    }
    return false;
  };

  const getIsRequired = (name) => {
    const field = employeeDisplay?.find((item) => item.variableName == name);
    if (!isEmptyNullUndefined(field)) {
      return field.isVisible && field.isRequired;
    }
    return false;
  };

  const handleResetForm = () => {
    setEmployee(() => employeeResetDetails);
    setFormError(() => initialFormErrorList);
    setCustomData(() => customDataResetDetails);
  };

  const getEmployeeDetails = async (empId) => {
    try {
      const response = await jwtAxios.get(`${API_ROUTS.employee}${empId}`, {
        cancelToken: source2.token,
      });
      if (response.status == 200) {
        setEmployee({
          ...response.data,
          employeeLevel: isEmptyNullUndefined(response.data.employeeLevel)
            ? {id: ''}
            : response.data.employeeLevel,
          employmentStatus: isEmptyNullUndefined(response.data.employmentStatus)
            ? {id: ''}
            : response.data.employmentStatus,
          employeeType: isEmptyNullUndefined(response.data.employeeType)
            ? {id: ''}
            : response.data.employeeType,
          employeeFunction: isEmptyNullUndefined(response.data.employeeFunction)
            ? {id: ''}
            : response.data.employeeFunction,
          empstatus: isEmptyNullUndefined(response.data.empstatus)
            ? {id: ''}
            : response.data.empstatus,
          employeeGrade: isEmptyNullUndefined(response.data.employeeGrade)
            ? {id: ''}
            : response.data.employeeGrade,
        });
        setEmployeeResetDetails(response.data);
        setFormError(() => initialFormErrorList);
        setCustomData(response.data.customData);
        setCustomDataResetDetails(response.data.customData);
      } else {
      }
      // TODO document why this block is empty
    } catch (e) {
      if (axios.isCancel(e)) {
        // TODO document why this block is empty
      } else if (e?.response?.data?.detail) {
        dispatch(fetchError(e.response.data.detail));
      } else {
        dispatch(fetchError(e.message));
      }
    }
  };

  const filterDataByEmployeeFunction = (id) => {
    const filteredData = planData?.employeeSubfunction?.filter(
      (item) => item.employeeFunction.id === id,
    );

    setFilteredSubFunction(filteredData);
  };

  const handleChangeEmployeeData = async (event, fieldType, newValue) => {
    const tempEmployee = structuredClone(employee);
    const tempError = {...formError};
    if (fieldType == 'textfield' || fieldType == 'dropdown') {
      tempEmployee[event.target.name] = event.target.value;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
    } else if (fieldType == 'joindate') {
      tempEmployee.dateOfJoining = event;
      tempError.dateOfJoining.isError = false;
      tempError.dateOfJoining.errorMessage = '';
    } else if (fieldType == 'dob') {
      tempEmployee.dateOfBirth = event;
      tempError.dateOfBirth.isError = false;
      tempError.dateOfBirth.errorMessage = '';
    } else if (fieldType == 'date1') {
      tempEmployee.date1 = event;
      tempError.date1.isError = false;
      tempError.date1.errorMessage = '';
    } else if (fieldType == 'date2') {
      tempEmployee.date2 = event;
      tempError.date2.isError = false;
      tempError.date2.errorMessage = '';
    } else if (fieldType == 'date3') {
      tempEmployee.date3 = event;
      tempError.date3.isError = false;
      tempError.date3.errorMessage = '';
    } else if (fieldType == 'date4') {
      tempEmployee.date4 = event;
      tempError.date4.isError = false;
      tempError.date4.errorMessage = '';
    } else if (fieldType == 'date5') {
      tempEmployee.date5 = event;
      tempError.date5.isError = false;
      tempError.date5.errorMessage = '';
    } else if (fieldType == 'radio') {
      tempEmployee[event.target.name] = event.target.value;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
    } else if (fieldType == 'dropdownID') {
      tempEmployee[event.target.name] = {id: event.target.value};
      tempError[event.target.name].id.isError = false;
      tempError[event.target.name].id.errorMessage = '';
    } else if (fieldType == 'Autocomplete') {
      tempEmployee.manager = newValue;
      tempError.manager.id.isError = false;
      tempError.manager.id.errorMessage = '';
    }

    setEmployee(() => tempEmployee);
    setFormError(() => tempError);
  };

  const handleChangeCustomVariable = (field, value, fieldType) => {
    setCustomData((prevCustomData) => {
      const existingFieldIndex = prevCustomData.findIndex(
        (data) => data.customVariables.id === field.id,
      );

      if (existingFieldIndex !== -1) {
        // If the field already exists in customData, update its value
        return [
          ...prevCustomData.slice(0, existingFieldIndex),
          {
            ...prevCustomData[existingFieldIndex],
            [fieldType === 'dropdown' ? 'options' : 'data']:
              field.isMultiselect === null && field.dataType === 'Array'
                ? field.isMultiselect === true
                  ? value
                  : [value]
                : value,
          },
          ...prevCustomData.slice(existingFieldIndex + 1),
        ];
      } else {
        // If the field doesn't exist in customData, add it
        return [
          ...prevCustomData,
          {
            // options: fieldType === 'dropdown' ? value : [],
            options:
              fieldType === 'dropdown'
                ? field.isMultiselect === true
                  ? value
                  : [value]
                : [],
            data: fieldType === 'dropdown' ? '' : value,
            customVariables: {
              id: field.id,
            },
          },
        ];
      }
    });

    // Reset the error for the field
    setCustomVariablesError((prevCustomVariablesErrors) => {
      const updatedErrors = {...prevCustomVariablesErrors};
      updatedErrors[field.variableName] = {
        isError: false,
        errorMessage: '',
      };
      return updatedErrors;
    });
  };

  const handleValidateEmployee = async () => {
    let isValid = true;
    const tempError = {...formError};
    const tempEmployee = structuredClone(employee);

    // ------------------Name validation---------------------------------
    if (getIsRequired('name') && isEmptyNullUndefined(tempEmployee.name)) {
      tempError.name.isError = true;
      tempError.name.errorMessage = 'Please enter name';
      isValid = false;
    }
    if (tempEmployee?.name) {
      if (isStrExceeds(tempEmployee?.name?.toString(), 50)) {
        tempError.name.isError = true;
        tempError.name.errorMessage = 'should not exceed 50 characters';
        isValid = false;
      }
    }

    // ------------------Date Of Birth validation-----------------------------------------------
    if (
      getIsRequired('dateOfBirth') &&
      isEmptyNullUndefined(tempEmployee.dateOfBirth)
    ) {
      tempError.dateOfBirth.isError = true;
      tempError.dateOfBirth.errorMessage = 'Please enter Date of Birth';
      isValid = false;
    }

    if (
      !isEmptyNullUndefined(tempEmployee.dateOfBirth) &&
      Date.parse(tempEmployee.dateOfBirth) > Date.parse(new Date())
    ) {
      tempError.dateOfBirth.isError = true;
      tempError.dateOfBirth.errorMessage = 'Please enter correct Date Of Birth';
      isValid = false;
    }

    if (
      getIsRequired('emailId') &&
      isEmptyNullUndefined(tempEmployee.emailId)
      // tempEmployee.emailId == null) ||
      // tempEmployee.emailId?.trim() == ''
    ) {
      tempError.emailId.isError = true;
      tempError.emailId.errorMessage = 'Please enter Email';
      isValid = false;
    } else if (
      !tempEmployee.emailId.match(
        /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
      )
    ) {
      tempError.emailId.isError = true;
      tempError.emailId.errorMessage = 'The Email you entered is incorrect.';
      isValid = false;
    }

    // ------------------EmployeeId validation-----------------------------------------------
    if (
      getIsRequired('employeeId') &&
      isEmptyNullUndefined(tempEmployee.employeeId)
    ) {
      tempError.employeeId.isError = true;
      tempError.employeeId.errorMessage = (
        <IntlMessages id='errorMessage.Please_enter_employee_Id' />
      );
      isValid = false;
    }
    // ------------------Employee Designation Validation-----------------------------------------------
    if (
      getIsRequired('employeeDesignation') &&
      isEmptyNullUndefined(tempEmployee.employeeDesignation)
    ) {
      tempError.employeeDesignation.isError = true;
      tempError.employeeDesignation.errorMessage =
        'Please enter employee designation';
      isValid = false;
    }

    // ------------------Date Of Joining validation-----------------------------------------------
    if (
      getIsRequired('dateOfJoining') &&
      isEmptyNullUndefined(tempEmployee.dateOfJoining)
    ) {
      tempError.dateOfJoining.isError = true;
      tempError.dateOfJoining.errorMessage = 'Please enter Date of Joining';
      isValid = false;
    }

    if (
      !isEmptyNullUndefined(tempEmployee.dateOfJoining) &&
      Date.parse(tempEmployee.dateOfJoining) > Date.parse(new Date())
    ) {
      tempError.dateOfJoining.isError = true;
      tempError.dateOfJoining.errorMessage =
        'Please enter correct Date Of Joining';
      isValid = false;
    }

    // ------------------Employee Level validation-----------------------------------------------
    if (
      getIsRequired('employeeLevel') &&
      isEmptyNullUndefined(tempEmployee.employeeLevel.id)
      // tempEmployee.employeeLevel.id == null) ||
      // tempEmployee.employeeLevel.id?.trim() == ''
    ) {
      tempError.employeeLevel.id.isError = true;
      tempError.employeeLevel.id.errorMessage = (
        <IntlMessages id='errorMessage.Please_select_Grades/Levels' />
      );
      isValid = false;
    }

    // ------------------Employee Type validation-----------------------------------------------
    if (
      getIsRequired('employeeType') &&
      isEmptyNullUndefined(tempEmployee.employeeType.id)
      // tempEmployee.employeeType.id == null) ||
      // tempEmployee.employeeType.id?.trim() == ''
    ) {
      tempError.employeeType.id.isError = true;
      tempError.employeeType.id.errorMessage = 'Please select employee type';
      isValid = false;
    }

    // ------------------Function validation-----------------------------------------------
    if (
      getIsRequired('employeeFunction') &&
      isEmptyNullUndefined(tempEmployee.employeeFunction.id)
      //   tempEmployee.employeeFunction.id == null) ||
      // tempEmployee.employeeFunction.id?.trim() == ''
    ) {
      tempError.employeeFunction.id.isError = true;
      tempError.employeeFunction.id.errorMessage = 'Please select function';
      isValid = false;
    }
    // ------------------Employee Status validation-----------------------------------------------
    if (
      getIsRequired('empstatus') &&
      isEmptyNullUndefined(tempEmployee.empstatus.id)
      // tempEmployee.empstatus.id == null) ||
      // tempEmployee.empstatus.id?.trim() == ''
    ) {
      tempError.empstatus.id.isError = true;
      tempError.empstatus.id.errorMessage = 'Please select employee status';
      isValid = false;
    }
    // ------------------Employment Status validation-----------------------------------------------
    if (
      getIsRequired('employmentStatus') &&
      isEmptyNullUndefined(tempEmployee.employmentStatus.id)
    ) {
      tempError.employmentStatus.id.isError = true;
      tempError.employmentStatus.id.errorMessage =
        'Please select employment status';
      isValid = false;
    }
    // ------------------Grade validation-----------------------------------------------
    if (
      getIsRequired('employeeGrade') &&
      isEmptyNullUndefined(tempEmployee.employeeGrade.id)
    ) {
      tempError.employeeGrade.id.isError = true;
      tempError.employeeGrade.id.errorMessage = 'Please select grade';
      isValid = false;
    }

    // ------------------Is Manager validation-----------------------------------------------
    if (
      getIsRequired('isManager') &&
      isEmptyNullUndefined(tempEmployee.isManager)
    ) {
      tempError.isManager.isError = true;
      tempError.isManager.errorMessage = 'Please choose isManager';
      isValid = false;
    }

    // ------------------Is Functional Leader validation-----------------------------------------------
    if (
      getIsRequired('isFunctionalLeader') &&
      isEmptyNullUndefined(tempEmployee.isFunctionalLeader)
    ) {
      tempError.isFunctionalLeader.isError = true;
      tempError.isFunctionalLeader.errorMessage =
        'Please choose functional leader';
      isValid = false;
    }

    // OTHER VARIABLES VALIDATION

    //string variables *****************************************************
    if (
      getIsRequired('string1') &&
      isEmptyNullUndefined(tempEmployee.string1)
    ) {
      tempError.string1.isError = true;
      tempError.string1.errorMessage = 'Required field';
      isValid = false;
    }
    if (
      getIsRequired('string2') &&
      isEmptyNullUndefined(tempEmployee.string2)
    ) {
      tempError.string2.isError = true;
      tempError.string2.errorMessage = 'Required field';
      isValid = false;
    }
    if (
      getIsRequired('string3') &&
      isEmptyNullUndefined(tempEmployee.string3)
    ) {
      tempError.string3.isError = true;
      tempError.string3.errorMessage = 'Required field';
      isValid = false;
    }
    if (
      getIsRequired('string4') &&
      isEmptyNullUndefined(tempEmployee.string4)
    ) {
      tempError.string4.isError = true;
      tempError.string4.errorMessage = 'Required field';
      isValid = false;
    }
    if (
      getIsRequired('string5') &&
      isEmptyNullUndefined(tempEmployee.string5)
    ) {
      tempError.string5.isError = true;
      tempError.string5.errorMessage = 'Required field';
      isValid = false;
    }
    //Date variables *****************************************************8
    if (getIsRequired('date1') && isEmptyNullUndefined(tempEmployee.date1)) {
      tempError.date1.isError = true;
      tempError.date1.errorMessage = 'Required field';
      isValid = false;
    }
    if (getIsRequired('date2') && isEmptyNullUndefined(tempEmployee.date2)) {
      tempError.date2.isError = true;
      tempError.date2.errorMessage = 'Required field';
      isValid = false;
    }
    if (getIsRequired('date3') && isEmptyNullUndefined(tempEmployee.date3)) {
      tempError.date3.isError = true;
      tempError.date3.errorMessage = 'Required field';
      isValid = false;
    }
    if (getIsRequired('date4') && isEmptyNullUndefined(tempEmployee.date4)) {
      tempError.date4.isError = true;
      tempError.date4.errorMessage = 'Required field';
      isValid = false;
    }
    if (getIsRequired('date5') && isEmptyNullUndefined(tempEmployee.date5)) {
      tempError.date5.isError = true;
      tempError.date5.errorMessage = 'Required field';
      isValid = false;
    }
    //Double variables *****************************************************
    if (
      getIsRequired('double1') &&
      isEmptyNullUndefined(tempEmployee.double1)
    ) {
      tempError.double1.isError = true;
      tempError.double1.errorMessage = 'Required field';
      isValid = false;
    }
    if (
      getIsRequired('double2') &&
      isEmptyNullUndefined(tempEmployee.double2)
    ) {
      tempError.double2.isError = true;
      tempError.double2.errorMessage = 'Required field';
      isValid = false;
    }
    if (
      getIsRequired('double3') &&
      isEmptyNullUndefined(tempEmployee.double3)
    ) {
      tempError.double3.isError = true;
      tempError.double3.errorMessage = 'Required field';
      isValid = false;
    }
    if (
      getIsRequired('double4') &&
      isEmptyNullUndefined(tempEmployee.double4)
    ) {
      tempError.double4.isError = true;
      tempError.double4.errorMessage = 'Required field';
      isValid = false;
    }
    if (
      getIsRequired('double5') &&
      isEmptyNullUndefined(tempEmployee.double5)
    ) {
      tempError.double5.isError = true;
      tempError.double5.errorMessage = 'Required field';
      isValid = false;
    }
    //Boolean variables *****************************************************

    if (!validateCustomVariable()) {
      isValid = false;
    }

    //do Submit
    if (isValid) {
      if (isEdit) {
        updateEmployee();
      } else {
        submitEmployee();
      }
    } else {
      setFormError(tempError);
    }
  };

  const validateCustomVariable = () => {
    const errors = {};

    customVariables.forEach((field) => {
      if (field.isRequired) {
        const fieldValue = customData.find(
          (data) => data.customVariables.id === field.id,
        )?.data;

        const isDropdownWithSelection =
          field.dataType === 'Array' &&
          customData.find((data) => data.customVariables.id === field.id)
            ?.options.length > 0;

        if (field.dataType === 'Boolean' && fieldValue === undefined) {
          // For boolean, explicitly check for undefined
          errors[field.variableName] = {
            isError: true,
            errorMessage: (
              <span>{<IntlMessages id='error.This_field_is_required' />}</span>
            ),
          };
        } else if (!fieldValue && !isDropdownWithSelection) {
          // For other data types
          errors[field.variableName] = {
            isError: true,
            errorMessage: (
              <span>{<IntlMessages id='error.This_field_is_required' />}</span>
            ),
          };
        }
      }
    });

    setCustomVariablesError(errors);
    return Object.keys(errors).length === 0; // Return true if there are no errors
  };

  const submitEmployee = async () => {
    let tempEmployee = structuredClone(employee);
    tempEmployee = {
      ...tempEmployee,
      emailId: employee.emailId.toLowerCase(),
      company: {
        id: selectedCompany.id,
      },
      customData: [...customData],
    };
    // tempEmployee.company.id = selectedCompany.id;
    const submit = async () => {
      setLoading(true);
      try {
        const response = await jwtAxios.post(
          `${API_ROUTS.employee}`,
          tempEmployee,
        );
        if (response.status == 201) {
          // setLoading(false);
          dispatch(
            showMessage(response.data.name + ' Employee added successfully..!'),
          );
          handleResetForm();
          Router.push('/company-builder/employee');
        } else {
          setLoading(false);
        }
      } catch (error) {
        apiCatchErrorMessage(error, dispatch, fetchError);
        setLoading(false);
      }
    };
    await submit();
    setEmployee(() => tempEmployee);
  };

  const updateEmployee = async () => {
    setLoading(true);

    // let tempemp = {...employee, id: id};

    let tempEmployee = structuredClone(employee);
    tempEmployee = {
      ...tempEmployee,
      id: id,
      customData: [...customData],
    };

    try {
      const response = await jwtAxios.put(
        // `${API_ROUTS.employee}/${employeeEditId}`,
        `${API_ROUTS.employee}`,
        tempEmployee,
      );
      if (response.status == 200) {
        // setLoading(false);
        dispatch(
          showMessage(response.data.name + ' Employee updated successfully..!'),
        );
        handleResetForm();
        setIsEdit(false);
        Router.push(
          !page
            ? `/company-builder/employee`
            : `/company-builder/view-employee?id=${id}`,
        );
      } else {
        setLoading(false);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
      setLoading(false);
    }
  };

  const ValidationTextField = styled(TextField)({
    '& input:valid + fieldset': {
      borderColor: 'green',
      borderWidth: 2,
    },
    '& input:invalid + fieldset': {
      borderColor: 'red',
      borderWidth: 2,
    },
    '& input:valid:focus + fieldset': {
      borderLeftWidth: 6,
      padding: '4px !important', // override inline-style
    },
  });

  const textFieldStyled = {
    backgroundColor: 'white',
    mb: 4,
    width: {xs: '100%', xl: '50%', md: '75%'},
  };

  const handleClearClick = (field) => {
    const tempError = JSON.parse(JSON.stringify(formError));
    const tempEmployee = structuredClone(employee);

    if (field == 'maritalStatus' || field == 'terminationReason') {
      tempEmployee[field] = null;
      tempError[field].isError = false;
      tempError[field].errorMessage = '';
    } else if (field == 'idType') {
      tempEmployee[field] = null;
      tempError[field].isError = false;
      tempError.nationalId.isError = false;
      tempError.nationalId.errorMessage = '';
      tempError[field].errorMessage = '';
    } else if (field == 'country') {
      tempEmployee.address[field] = null;
      tempError.address[field].isError = false;
      tempError.address[field].errorMessage = '';
    } else {
      tempEmployee[field].id = null;
      tempError[field].id.isError = false;
      tempError[field].id.errorMessage = '';
    }

    setEmployee(tempEmployee);
    setFormError(tempError);
  };

  const domCreaction = () => {
    return (
      employee && (
        <div className='addEmployee-main-container-main'>
          <Stack sx={{mx: {xs: 0, xl: 10, md: 5}}}>
            <Box sx={{my: 2}}>
              {/* Personal Details */}
              <h3 style={{marginBottom: 12}}>
                <IntlMessages id='employee.addEmployee.personalInformation' />
              </h3>
              <Stack
                direction={{xs: 'column', sm: 'row'}}
                sx={{my: 2}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack width={{xs: '100%', sm: '50%'}}>
               
                  <TextField
                    size='small'
                    name='name'
                    label={getLable('name')}
                    onChange={(event) =>
                      handleChangeEmployeeData(event, 'textfield')
                    }
                    variant='outlined'
                    error={formError.name.isError}
                    helperText={formError.name.errorMessage}
                    value={employee.name ? employee.name : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: getIsRequired('name')
                            ? 'red'
                            : 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DesktopDatePicker
                      sx={{
                        ...textFieldStyled,
                        '& .MuiOutlinedInput-root': {
                          '& fieldset': {
                            borderLeftColor: getIsRequired('dateOfBirth')
                              ? 'red'
                              : 'gray',
                            borderLeftWidth: 3,
                          },
                          height: '40px',
                        },
                      }}
                      maxDate={new Date()}
                      format={getCompanyDateFormatForInputs(selectedCompany)}
                      value={
                        !isEmptyNullUndefined(employee.dateOfBirth)
                          ? new Date(employee.dateOfBirth)
                          : null
                      }
                      // label={<IntlMessages id='employee.addEmployee.dob' />}
                      label={getLable('dateOfBirth')}
                      name='dateOfBirth'
                      onChange={(event) =>
                        handleChangeEmployeeData(event, 'dob')
                      }
                    />
                  </LocalizationProvider>
                  {formError.dateOfBirth.isError && (
                    <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                      {formError.dateOfBirth.errorMessage}
                    </FormHelperText>
                  )}
              
                </Stack>

                <Stack width={{xs: '100%', sm: '50%'}}>
                  <TextField //tempHide
                    disabled={isEdit}
                    size='small'
                    name='emailId'
                    label={getLable('emailId')}
                    onChange={(event) =>
                      handleChangeEmployeeData(event, 'textfield')
                    }
                    variant='outlined'
                    error={formError.emailId.isError}
                    helperText={formError.emailId.errorMessage}
                    value={employee.emailId ? employee.emailId : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: getIsRequired('emailId')
                            ? 'red'
                            : 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack>

              {/**EMPLoyee details */}
              <h3 style={{marginBottom: 12}}>
                <IntlMessages id='employee.addEmployee.employeeInformation' />
              </h3>
              <Stack
                // display={{xs: 'flex', sm: 'flex'}}
                direction={{xs: 'column', sm: 'row'}}
                sx={{mt: 2}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{mb: 5}} width={{xs: '100%', sm: '50%'}}>
                  <TextField
                    size='small'
                    maxRows={3}
                    name='employeeId'
                    labelId='employeeId'
                    // label={
                    //   <IntlMessages id='employee.addEmployee.employeeId' />
                    // }
                    label={getLable('employeeId')}
                    onChange={(event) =>
                      handleChangeEmployeeData(event, 'textfield')
                    }
                    variant='outlined'
                    value={employee?.employeeId || ''}
                    error={formError.employeeId.isError}
                    helperText={formError.employeeId.errorMessage}
                    sx={{
                      ...textFieldStyled,
                      '& fieldset': {
                        borderLeftWidth: 3,
                        borderLeftColor: getIsRequired('employeeId')
                          ? 'red'
                          : 'gray',
                      },
                    }}
                  />
                  <TextField
                    size='small'
                    maxRows={3}
                    name='employeeDesignation'
                    labelId='employeeDesignation'
                    // label={'Designation'}
                    label={getLable('employeeDesignation')}
                    onChange={(event) =>
                      handleChangeEmployeeData(event, 'textfield')
                    }
                    variant='outlined'
                    value={employee?.employeeDesignation || ''}
                    error={formError.employeeDesignation?.isError}
                    helperText={formError.employeeDesignation?.errorMessage}
                    sx={{
                      ...textFieldStyled,
                      '& fieldset': {
                        borderLeftWidth: 3,
                        borderLeftColor: getIsRequired('employeeDesignation')
                          ? 'red'
                          : 'gray',
                      },
                    }}
                  />

                  <FormControl sx={{mb: 0}}>
                    <InputLabel size='small' id='employeeLevel'>
                      {/* level of Employment */}
                      {getLable('employeeLevel')}
                    </InputLabel>
                    <Select
                      value={employee?.employeeLevel?.id || ''}
                      labelId='employeeLevel'
                      name='employeeLevel'
                      onChange={(event) =>
                        handleChangeEmployeeData(event, 'dropdownID')
                      }
                      variant='outlined'
                      error={formError.employeeLevel.id.isError}
                      // label={<IntlMessages id='sidebar.companybuilder.roles' />}
                      label={getLable('employeeLevel')}
                      size='small'
                      sx={{
                        ...textFieldStyled,
                        '& fieldset': {
                          borderLeftWidth: 3,
                          borderLeftColor: getIsRequired('employeeLevel')
                            ? 'red'
                            : 'gray',
                        },
                      }}
                    >
                      {planData &&
                        planData.employeeLevel &&
                        planData.employeeLevel.map((role, index) => (
                          <MenuItem
                            id={`employeeLevel-MenuItem-${index}`}
                            key={role.id}
                            value={role.id}
                          >
                            {role.name}
                          </MenuItem>
                        ))}
                    </Select>
                    {formError.employeeLevel.id.isError && (
                      <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                        {formError.employeeLevel.id.errorMessage}
                      </FormHelperText>
                    )}
                  </FormControl>

                  <FormControl sx={{mb: 0}}>
                    <InputLabel
                      size='small'
                      id='emp-status'
                      // shrink={true}
                    >
                      <IntlMessages id='employee.addEmployee.employeeStatus' />
                    </InputLabel>
                    <Select
                      value={employee?.empstatus?.id || ''}
                      labelId='emp-status'
                      name='empstatus'
                      onChange={(event) =>
                        handleChangeEmployeeData(event, 'dropdownID')
                      }
                      variant='outlined'
                      error={formError.empstatus.id.isError}
                      // label='Employee Status'
                      label={getLable('empstatus')}
                      // notched
                      size='small'
                      sx={{
                        ...textFieldStyled,
                        mb: 2,
                        '& fieldset': {
                          borderLeftWidth: 3,
                          borderLeftColor: getIsRequired('empstatus')
                            ? 'red'
                            : 'gray',
                        },
                      }}
                    >
                      {planData &&
                        planData.employeeStatus &&
                        planData.employeeStatus.map((status, index) => (
                          <MenuItem
                            key={status.id}
                            id={`empstatus-MenuItem-${index}`}
                            value={status.id}
                          >
                            {status.name}
                          </MenuItem>
                        ))}
                    </Select>
                    {formError.empstatus.id.isError && (
                      <FormHelperText sx={{color: '#d32f2f'}}>
                        {formError.empstatus.id.errorMessage}
                      </FormHelperText>
                    )}
                  </FormControl>
                  <FormControl sx={{mt: 2, mb: 0}}>
                    <InputLabel
                      size='small'
                      id='jobCode'
                      // shrink={true}
                    >
                      {/* <IntlMessages id='employee.addEmployee.employeeStatus' /> */}
                      Job code
                    </InputLabel>
                    <Select
                      value={employee?.jobCode?.id || ''}
                      labelId='jobCode'
                      name='jobCode'
                      onChange={(event) =>
                        handleChangeEmployeeData(event, 'dropdownID')
                      }
                      variant='outlined'
                      error={formError.jobCode.id.isError}
                      // label='Employee Status'
                      label={getLable('jobCode')}
                      // notched
                      size='small'
                      sx={{
                        ...textFieldStyled,
                        mb: 2,
                        '& fieldset': {
                          borderLeftWidth: 3,
                          borderLeftColor: 'gray',
                        },
                      }}
                    >
                      {planData &&
                        planData.jobCode &&
                        planData.jobCode.map((item, index) => (
                          <MenuItem
                            key={item.id}
                            id={`jobCode-MenuItem-${index}`}
                            value={item.id}
                          >
                            {item.name}
                          </MenuItem>
                        ))}
                    </Select>
                    {formError.jobCode.id?.isError && (
                      <FormHelperText sx={{color: '#d32f2f'}}>
                        {formError.jobCode.id?.errorMessage}
                      </FormHelperText>
                    )}
                  </FormControl>
                </Stack>

                <Stack width={{xs: '100%', sm: '50%'}}>
                  {getIsVisible('dateOfJoining') && (
                    <Stack>
                    <LocalizationProvider dateAdapter={AdapterDateFns}>
                      <DesktopDatePicker
                        sx={{
                          ...textFieldStyled,
                          '& .MuiOutlinedInput-root': {
                            '& fieldset': {
                              borderLeftColor: getIsRequired('dateOfJoining')
                                ? 'red'
                                : 'gray',
                              borderLeftWidth: 3,
                            },
                            height: '40px',
                          },
                        }}
                        maxDate={new Date()}
                        format={getCompanyDateFormatForInputs(selectedCompany)}
                        value={
                          !isEmptyNullUndefined(employee.dateOfJoining)
                            ? new Date(employee.dateOfJoining)
                            : null
                        }
                        label={getLable('dateOfJoining')}
                        name='dateOfJoining'
                        onChange={(event) =>
                          handleChangeEmployeeData(event, 'joindate')
                        }
                      />
                    </LocalizationProvider>
                     {formError.dateOfJoining?.isError && (
                      <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                        {formError.dateOfJoining?.errorMessage}
                      </FormHelperText>
                    )}

                  </Stack>
                  )}

                  {getIsVisible('employeeType') && (
                    <FormControl sx={{mb: 0}}>
                      <InputLabel size='small' id='employeeType'>
                        {getLable('employeeType')}
                      </InputLabel>
                      <Select
                        value={employee?.employeeType?.id || ''}
                        labelId='employeeType'
                        name='employeeType'
                        onChange={(event) =>
                          handleChangeEmployeeData(event, 'dropdownID')
                        }
                        variant='outlined'
                        label={getLable('employeeType')}
                        size='small'
                        sx={{
                          ...textFieldStyled,
                          '& fieldset': {
                            borderLeftWidth: 3,
                            borderLeftColor: getIsRequired('employeeType')
                              ? 'red'
                              : 'gray',
                          },
                        }}
                      >
                        {planData &&
                          planData.employeeType &&
                          planData.employeeType.map((type, index) => (
                            <MenuItem
                              key={type.id}
                              id={`employeeType-MenuItem-${index}`}
                              value={type.id}
                            >
                              {type.name}
                            </MenuItem>
                          ))}
                      </Select>
                      {formError.employeeType.id.isError && (
                        <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                          {formError.employeeType.id.errorMessage}
                        </FormHelperText>
                      )}
                    </FormControl>
                  )}
                  {getIsVisible('employmentStatus') && (
                    <FormControl sx={{mb: 2}}>
                      <InputLabel size='small' id='emp-status'>
                        {getLable('employmentStatus')}
                      </InputLabel>
                      <Select
                        value={employee?.employmentStatus?.id || ''}
                        labelId='emp-status'
                        name='employmentStatus'
                        onChange={(event) =>
                          handleChangeEmployeeData(event, 'dropdownID')
                        }
                        variant='outlined'
                        error={formError.employmentStatus?.id.isError}
                        label={getLable('employmentStatus')}
                        // notched
                        size='small'
                        sx={{
                          ...textFieldStyled,
                          mb: 2,
                          '& fieldset': {
                            borderLeftWidth: 3,
                            borderLeftColor: getIsRequired('employmentStatus')
                              ? 'red'
                              : 'gray',
                          },
                        }}
                      >
                        {planData &&
                          planData.employementStatus &&
                          planData.employementStatus.map((status, index) => (
                            <MenuItem
                              key={status.id}
                              id={`empstatus-MenuItem-${index}`}
                              value={status.id}
                            >
                              {status.name}
                            </MenuItem>
                          ))}
                      </Select>
                      {formError.employmentStatus?.id.isError && (
                        <FormHelperText sx={{color: '#d32f2f'}}>
                          {formError.employmentStatus?.id.errorMessage}
                        </FormHelperText>
                      )}
                    </FormControl>
                  )}

                  {getIsVisible('employeeGrade') && (
                    <FormControl sx={{mb: 0}}>
                      <InputLabel size='small' id='employeeGrade'>
                        {getLable('employeeGrade')}
                      </InputLabel>
                      <Select
                        value={employee?.employeeGrade?.id || ''}
                        labelId='emp-status'
                        name='employeeGrade'
                        onChange={(event) =>
                          handleChangeEmployeeData(event, 'dropdownID')
                        }
                        variant='outlined'
                        error={formError.employeeGrade?.id.isError}
                        label={getLable('employeeGrade')}
                        size='small'
                        sx={{
                          ...textFieldStyled,
                          mb: 2,
                          '& fieldset': {
                            borderLeftWidth: 3,
                            borderLeftColor: getIsRequired('employeeGrade')
                              ? 'red'
                              : 'gray',
                          },
                        }}
                      >
                        {planData &&
                          planData.employeeGrade &&
                          planData.employeeGrade.map((grade, index) => (
                            <MenuItem
                              key={grade.id}
                              id={`employeeGrade-MenuItem-${index}`}
                              value={grade.id}
                            >
                              {grade.name}
                            </MenuItem>
                          ))}
                      </Select>
                      {formError.employeeGrade?.id.isError && (
                        <FormHelperText sx={{color: '#d32f2f'}}>
                          {formError.employeeGrade?.id.errorMessage}
                        </FormHelperText>
                      )}
                    </FormControl>
                  )}
                </Stack>
              </Stack>

              {/**Other Info */}
              <h3 style={{marginBottom: 12}}>
                {/* <IntlMessages id='employee.addEmployee.employeeInformation' /> */}
                Other Info
              </h3>
              <Stack
                // display={{xs: 'flex', sm: 'flex'}}
                direction={{xs: 'column', sm: 'row'}}
                sx={{mt: 2}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{mb: 5}} width={{xs: '100%', sm: '50%'}}>
                  {getIsVisible('employeeFunction') && (
                    <FormControl sx={{mb: 0}}>
                      <InputLabel size='small' id='employeeLevel'>
                        {getLable('employeeFunction')}
                      </InputLabel>
                      <Select
                        value={employee?.employeeFunction?.id || ''}
                        labelId='employeeFunction'
                        name='employeeFunction'
                        onChange={(event) =>
                          handleChangeEmployeeData(event, 'dropdownID')
                        }
                        variant='outlined'
                        error={formError.employeeFunction.id.isError}
                        label={getLable('employeeFunction')}
                        size='small'
                        sx={{
                          ...textFieldStyled,
                          '& fieldset': {
                            borderLeftWidth: 3,
                            borderLeftColor: getIsRequired('employeeFunction')
                              ? 'red'
                              : 'gray',
                          },
                        }}
                      >
                        {planData &&
                          planData.employeeFunction &&
                          planData.employeeFunction.map((func, index) => (
                            <MenuItem
                              id={`employeeFunction-MenuItem-${index}`}
                              key={func.id}
                              value={func.id}
                            >
                              {func.name}
                            </MenuItem>
                          ))}
                      </Select>
                      {formError.employeeFunction.id.isError && (
                        <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                          {formError.employeeFunction.id.errorMessage}
                        </FormHelperText>
                      )}
                    </FormControl>
                  )}

                  {getIsVisible('manager') && (
                    <FormControl sx={{mb: 0}}>
                      <Autocomplete
                        value={employee?.manager || null}
                        onChange={(event, newValue) =>
                          handleChangeEmployeeData(
                            event,
                            'Autocomplete',
                            newValue,
                          )
                        }
                        options={
                          isEdit
                            ? planData?.manager?.filter(
                                (item) => item.id != id,
                              ) || []
                            : planData?.manager || []
                        }
                        getOptionLabel={(option) => option.name}
                        isOptionEqualToValue={(option, value) =>
                          option.id === value.id
                        }
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            // label='Manager'
                            label={getLable('manager')}
                            variant='outlined'
                            size='small'
                          />
                        )}
                        sx={{
                          ...textFieldStyled,
                          '& fieldset': {
                            borderLeftWidth: 3,
                            borderLeftColor: getIsRequired('manager')
                              ? 'red'
                              : 'gray',
                          },
                        }}
                        renderOption={(props, option) => (
                          <li {...props}>
                            <span>{option.name}</span>
                          </li>
                        )}
                        endAdornment={
                          <IconButton
                            sx={{
                              display: employee?.manager?.id ? '' : 'none',
                              fontSize: '1.25rem',
                              marginRight: '0.4rem',
                            }}
                            onClick={() => handleClearClick('manager')}
                          >
                            <AiOutlineClose />
                          </IconButton>
                        }
                      />
                    </FormControl>
                  )}
                </Stack>
                {/* <Stack sx={{mb: 5}} width={{xs: '100%', sm: '50%'}}> */}
                <Stack width={{xs: '100%', sm: '50%'}}>
                  {getIsVisible('employeeSubFunction') && (
                    <FormControl sx={{mb: 0}}>
                      <InputLabel size='small' id='employeeSubFunction'>
                        {getLable('employeeSubFunction')}
                      </InputLabel>
                      <Select
                        value={employee?.employeeSubFunction?.id || ''}
                        labelId='employeeSubFunction'
                        name='employeeSubFunction'
                        onChange={(event) =>
                          handleChangeEmployeeData(event, 'dropdownID')
                        }
                        variant='outlined'
                        error={formError.employeeSubFunction.id.isError}
                        label={getLable('employeeSubFunction')}
                        size='small'
                        sx={{
                          ...textFieldStyled,
                          '& fieldset': {
                            borderLeftWidth: 3,
                            borderLeftColor: getIsRequired(
                              'employeeSubFunction',
                            )
                              ? 'red'
                              : 'gray',
                          },
                        }}
                      >
                        {filteredSubFunction &&
                          filteredSubFunction.map((sub, index) => (
                            <MenuItem
                              id={`employeeSubFunction-MenuItem-${index}`}
                              key={sub.id}
                              value={sub.id}
                            >
                              {sub.name}
                            </MenuItem>
                          ))}
                      </Select>
                      {formError.employeeSubFunction.id.isError && (
                        <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                          {formError.employeeSubFunction.id.errorMessage}
                        </FormHelperText>
                      )}
                    </FormControl>
                  )}
                </Stack>
              </Stack>

              {/* Extra yes / no questions */}
              <Stack
                direction='row'
                sx={{mt: 0, ml: 3, mb: 3}}
                justifyContent='space-between'
                alignItems='center'
                spacing={2}
              >
                {getIsVisible('isManager') && (
                  <>
                    <Stack sx={{width: '50%'}}>
                      <FormLabel id='demo-row-radio-buttons-group-label'>
                        <Stack direction='row'>
                          <Stack fontWeight={500}>
                            {getLable('isManager')}
                          </Stack>
                        </Stack>
                      </FormLabel>
                    </Stack>
                    <Stack
                      sx={{width: '50%'}}
                      direction='column'
                      alignItems='flex-start'
                    >
                      <RadioGroup
                        value={employee.isManager}
                        row
                        aria-labelledby='demo-row-radio-buttons-group-label'
                        name='isManager'
                        onChange={(event) =>
                          handleChangeEmployeeData(event, 'radio')
                        }
                      >
                        <FormControlLabel
                          value={true}
                          control={<Radio />}
                          label={<IntlMessages id='common.button.Yes' />}
                        />
                        <FormControlLabel
                          value={false}
                          control={<Radio />}
                          label={<IntlMessages id='common.button.No' />}
                        />
                      </RadioGroup>
                      {formError.isManager.isError && (
                        <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                          {formError.isManager.errorMessage}
                        </FormHelperText>
                      )}
                    </Stack>
                  </>
                )}

                {getIsVisible('isFunctionalLeader') && (
                  <>
                    <Stack sx={{width: '50%'}}>
                      <FormLabel id='demo-row-radio-buttons-group-label'>
                        <Stack direction='row'>
                          <Stack fontWeight={500}>
                            {getLable('isFunctionalLeader')}
                          </Stack>
                        </Stack>
                      </FormLabel>
                    </Stack>
                    <Stack
                      sx={{width: '50%'}}
                      direction='column'
                      alignItems='flex-start'
                    >
                      <RadioGroup
                        value={employee.isFunctionalLeader}
                        row
                        aria-labelledby='demo-row-radio-buttons-group-label'
                        name='isFunctionalLeader'
                        onChange={(event) =>
                          handleChangeEmployeeData(event, 'radio')
                        }
                      >
                        <FormControlLabel
                          value={true}
                          control={<Radio />}
                          label={<IntlMessages id='common.button.Yes' />}
                        />
                        <FormControlLabel
                          value={false}
                          control={<Radio />}
                          label={<IntlMessages id='common.button.No' />}
                        />
                      </RadioGroup>
                      {formError.isFunctionalLeader.isError && (
                        <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                          {formError.isFunctionalLeader.errorMessage}
                        </FormHelperText>
                      )}
                    </Stack>
                  </>
                )}
              </Stack>

              {/**Other Variables */}
              <h3 style={{marginBottom: 12}}>
                {/* <IntlMessages id='employee.addEmployee.employeeInformation' /> */}
                Other Variables
              </h3>

              {/* ######################  String Fields  ######################## */}
              <Stack
                direction={{xs: 'column', sm: 'row'}}
                sx={{mt: 2}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{mb: 5}} width={{xs: '100%', sm: '50%'}}>
                  {[1, 2, 3].map((index) => {
                    const stringKey = `string${index}`;
                    return (
                      getIsVisible(stringKey) && (
                        <Stack key={stringKey}>
                          <TextField
                            size='small'
                            maxRows={3}
                            name={stringKey}
                            label={getLable(stringKey)}
                            onChange={(event) =>
                              handleChangeEmployeeData(event, 'textfield')
                            }
                            variant='outlined'
                            value={employee?.[stringKey] || ''}
                            error={formError[stringKey]?.isError}
                            helperText={formError[stringKey]?.errorMessage}
                            sx={{
                              ...textFieldStyled,
                              '& fieldset': {
                                borderLeftWidth: 3,
                                borderLeftColor: getIsRequired(stringKey)
                                  ? 'red'
                                  : 'gray',
                              },
                            }}
                          />
                        </Stack>
                      )
                    );
                  })}
                </Stack>

                <Stack width={{xs: '100%', sm: '50%'}}>
                  {[4, 5].map((index) => {
                    const stringKey = `string${index}`;
                    return (
                      getIsVisible(stringKey) && (
                        <Stack key={stringKey}>
                          <TextField
                            size='small'
                            maxRows={3}
                            name={stringKey}
                            label={getLable(stringKey)}
                            onChange={(event) =>
                              handleChangeEmployeeData(event, 'textfield')
                            }
                            variant='outlined'
                            value={employee?.[stringKey] || ''}
                            error={formError[stringKey]?.isError}
                            helperText={formError[stringKey]?.errorMessage}
                            sx={{
                              ...textFieldStyled,
                              '& fieldset': {
                                borderLeftWidth: 3,
                                borderLeftColor: getIsRequired(stringKey)
                                  ? 'red'
                                  : 'gray',
                              },
                            }}
                          />
                        </Stack>
                      )
                    );
                  })}
                </Stack>
              </Stack>

              {/* ######################  Date Fields  ######################## */}

              <Stack
                direction={{xs: 'column', sm: 'row'}}
                sx={{mt: 2}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{mb: 5}} width={{xs: '100%', sm: '50%'}}>
                  {[1, 2, 3].map((index) => {
                    const dateKey = `date${index}`;
                    return (
                      getIsVisible(dateKey) && (
                        <Stack>
                          <LocalizationProvider
                            key={dateKey}
                            dateAdapter={AdapterDateFns}
                          >
                            <DesktopDatePicker
                              sx={{
                                ...textFieldStyled,
                                '& .MuiOutlinedInput-root': {
                                  '& fieldset': {
                                    borderLeftColor: getIsRequired(dateKey)
                                      ? 'red'
                                      : 'gray',
                                    borderLeftWidth: 3,
                                  },
                                  height: '40px',
                                },
                              }}
                              maxDate={new Date()}
                              format={getCompanyDateFormatForInputs(
                                selectedCompany,
                              )}
                              value={
                                !isEmptyNullUndefined(employee[dateKey])
                                  ? new Date(employee[dateKey])
                                  : null
                              }
                              label={getLable(dateKey)}
                              name={dateKey}
                              onChange={(event) =>
                                handleChangeEmployeeData(event, dateKey)
                              }
                            />
                          </LocalizationProvider>
                          {formError[dateKey]?.isError && (
                            <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                              {formError[dateKey]?.errorMessage}
                            </FormHelperText>
                          )}
                        </Stack>
                      )
                    );
                  })}
                </Stack>

                <Stack width={{xs: '100%', sm: '50%'}}>
                  {[4, 5].map((index) => {
                    const dateKey = `date${index}`;
                    return (
                      getIsVisible(dateKey) && (
                        <Stack>
                          <LocalizationProvider
                            key={dateKey}
                            dateAdapter={AdapterDateFns}
                          >
                            <DesktopDatePicker
                            sx={{
                              ...textFieldStyled,
                              '& .MuiOutlinedInput-root': {
                                '& fieldset': {
                                  borderLeftColor: getIsRequired(dateKey)
                                    ? 'red'
                                    : 'gray',
                                  borderLeftWidth: 3,
                                },
                                height: '40px',
                              },
                            }}
                              maxDate={new Date()}
                              format={getCompanyDateFormatForInputs(
                                selectedCompany,
                              )}
                              value={
                                !isEmptyNullUndefined(employee[dateKey])
                                  ? new Date(employee[dateKey])
                                  : null
                              }
                              label={getLable(dateKey)}
                              name={dateKey}
                              onChange={(event) =>
                                handleChangeEmployeeData(event, dateKey)
                              }
                             
                            />
                          </LocalizationProvider>
                          {formError[dateKey]?.isError && (
                            <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                              {formError[dateKey]?.errorMessage}
                            </FormHelperText>
                          )}
                        </Stack>
                      )
                    );
                  })}
                </Stack>
              </Stack>

              {/* ######################  Boolean Fields  ######################## */}

              <Stack
                direction={{xs: 'column', sm: 'row'}}
                sx={{mt: 2}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{mb: 5}} width={{xs: '100%', sm: '50%'}}>
                  {[1, 2, 3].map((index) => {
                    const booleanKey = `boolean${index}`;
                    return (
                      getIsVisible(booleanKey) && (
                        <Stack
                          key={booleanKey}
                          direction='row'
                          sx={{mt: 0, ml: 3, mb: 3}}
                          justifyContent='space-between'
                          alignItems='center'
                          spacing={2}
                        >
                          <Stack sx={{width: '50%'}}>
                            <FormLabel
                              id={`demo-row-radio-buttons-group-label-${booleanKey}`}
                            >
                              <Stack direction='row'>
                                <Stack fontWeight={500}>
                                  {getLable(booleanKey)}
                                </Stack>
                              </Stack>
                            </FormLabel>
                          </Stack>
                          <Stack
                            sx={{width: '50%'}}
                            direction='column'
                            alignItems='flex-start'
                          >
                            <RadioGroup
                              value={employee[booleanKey]}
                              row
                              aria-labelledby={`demo-row-radio-buttons-group-label-${booleanKey}`}
                              name={booleanKey}
                              onChange={(event) =>
                                handleChangeEmployeeData(event, 'radio')
                              }
                            >
                              <FormControlLabel
                                value={true}
                                control={<Radio />}
                                label={<IntlMessages id='common.button.Yes' />}
                              />
                              <FormControlLabel
                                value={false}
                                control={<Radio />}
                                label={<IntlMessages id='common.button.No' />}
                              />
                            </RadioGroup>
                            {formError[booleanKey]?.isError && (
                              <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                                {formError[booleanKey].errorMessage}
                              </FormHelperText>
                            )}
                          </Stack>
                        </Stack>
                      )
                    );
                  })}
                </Stack>

                <Stack width={{xs: '100%', sm: '50%'}}>
                  {[4, 5].map((index) => {
                    const booleanKey = `boolean${index}`;
                    return (
                      getIsVisible(booleanKey) && (
                        <Stack
                          key={booleanKey}
                          direction='row'
                          sx={{mt: 0, ml: 3, mb: 3}}
                          justifyContent='space-between'
                          alignItems='center'
                          spacing={2}
                        >
                          <Stack sx={{width: '50%'}}>
                            <FormLabel
                              id={`demo-row-radio-buttons-group-label-${booleanKey}`}
                            >
                              <Stack direction='row'>
                                <Stack fontWeight={500}>
                                  {getLable(booleanKey)}
                                </Stack>
                              </Stack>
                            </FormLabel>
                          </Stack>
                          <Stack
                            sx={{width: '50%'}}
                            direction='column'
                            alignItems='flex-start'
                          >
                            <RadioGroup
                              value={employee[booleanKey]}
                              row
                              aria-labelledby={`demo-row-radio-buttons-group-label-${booleanKey}`}
                              name={booleanKey}
                              onChange={(event) =>
                                handleChangeEmployeeData(event, 'radio')
                              }
                            >
                              <FormControlLabel
                                value={true}
                                control={<Radio />}
                                label={<IntlMessages id='common.button.Yes' />}
                              />
                              <FormControlLabel
                                value={false}
                                control={<Radio />}
                                label={<IntlMessages id='common.button.No' />}
                              />
                            </RadioGroup>
                            {formError[booleanKey]?.isError && (
                              <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                                {formError[booleanKey].errorMessage}
                              </FormHelperText>
                            )}
                          </Stack>
                        </Stack>
                      )
                    );
                  })}
                </Stack>
              </Stack>

              {/* ######################  Double Fields  ######################## */}

              <Stack
                direction={{xs: 'column', sm: 'row'}}
                sx={{mt: 2}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{mb: 5}} width={{xs: '100%', sm: '50%'}}>
                  {[1, 2, 3].map((index) => {
                    const doubleKey = `double${index}`;
                    return (
                      getIsVisible(doubleKey) && (
                        <TextField
                          key={doubleKey}
                          size='small'
                          maxRows={3}
                          name={doubleKey}
                          type='number'
                          label={getLable(doubleKey)}
                          onChange={(event) =>
                            handleChangeEmployeeData(event, 'textfield')
                          }
                          variant='outlined'
                          value={employee?.[doubleKey] || ''}
                          error={formError[doubleKey]?.isError}
                          helperText={formError[doubleKey]?.errorMessage}
                          sx={{
                            ...textFieldStyled,
                            '& fieldset': {
                              borderLeftWidth: 3,
                              borderLeftColor: getIsRequired(doubleKey)
                                ? 'red'
                                : 'gray',
                            },
                          }}
                        />
                      )
                    );
                  })}
                </Stack>
                <Stack width={{xs: '100%', sm: '50%'}}>
                  {[4, 5].map((index) => {
                    const doubleKey = `double${index}`;
                    return (
                      getIsVisible(doubleKey) && (
                        <TextField
                          key={doubleKey}
                          size='small'
                          maxRows={3}
                          name={doubleKey}
                          type='number'
                          label={getLable(doubleKey)}
                          onChange={(event) =>
                            handleChangeEmployeeData(event, 'textfield')
                          }
                          variant='outlined'
                          value={employee?.[doubleKey] || ''}
                          error={formError[doubleKey]?.isError}
                          helperText={formError[doubleKey]?.errorMessage}
                          sx={{
                            ...textFieldStyled,
                            '& fieldset': {
                              borderLeftWidth: 3,
                              borderLeftColor: getIsRequired(doubleKey)
                                ? 'red'
                                : 'gray',
                            },
                          }}
                        />
                      )
                    );
                  })}
                </Stack>
              </Stack>

              {/**Custom Variables */}
              {customVariables.length > 0 && (
                <>
                  <h3 style={{marginBottom: 12}}>
                    {/* <IntlMessages id='employee.addEmployee.employeeInformation' /> */}
                    Custom Variables :
                  </h3>
                  <Stack
                    // display={{xs: 'flex', sm: 'flex'}}
                    direction={{xs: 'column', sm: 'row'}}
                    sx={{mt: 2}}
                    justifyContent='center'
                    alignItems='flex-start'
                    spacing={2}
                  >
                    {/* <Stack sx={{mb: 5}} width={{xs: '100%', sm: '50%'}}></Stack> */}

                    <Stack sx={{mb: 5}} width={{xs: '100%', sm: '50%'}}>
                      {customVariables &&
                        customVariables.map((field) => (
                          <div>
                            {(field.dataType === 'String' ||
                              field.dataType === 'Number') && (
                              <TextField
                                value={
                                  customData.find(
                                    (data) =>
                                      data.customVariables.id === field.id,
                                  )?.data || ''
                                }
                                type={
                                  field.dataType === 'Number'
                                    ? 'number'
                                    : 'text'
                                }
                                size='small'
                                name={field.variableName}
                                labelId={field.variableName}
                                label={field.variableName}
                                onChange={(e) =>
                                  handleChangeCustomVariable(
                                    field,
                                    e.target.value,
                                    'string',
                                  )
                                }
                                variant='outlined'
                                error={
                                  customVariablesError[field.variableName]
                                    ?.isError || false
                                }
                                helperText={
                                  customVariablesError[field.variableName]
                                    ?.errorMessage || ''
                                }
                                sx={{
                                  ...textFieldStyled,
                                  '& fieldset': {
                                    borderLeftWidth: 3,
                                    borderLeftColor: field.isRequired
                                      ? 'red'
                                      : 'gray',
                                  },
                                }}
                              />
                            )}

                            {field.dataType === 'Array' && (
                              <FormControl sx={{mb: 0}}>
                                <InputLabel
                                  size='small'
                                  id={field.variableName}
                                >
                                  {field.variableName}
                                </InputLabel>
                                <Select
                                  value={
                                    (
                                      customData.find(
                                        (data) =>
                                          data.customVariables.id === field.id,
                                      ) || {options: []}
                                    ).options || (field.isMultiselect ? [] : [])
                                  }
                                  multiple={field.isMultiselect}
                                  labelId='employeeVariableName'
                                  name={field.variableName}
                                  onChange={(e) =>
                                    handleChangeCustomVariable(
                                      field,
                                      e.target.value,
                                      'dropdown',
                                    )
                                  }
                                  variant='outlined'
                                  label={field.variableName}
                                  size='small'
                                  sx={{
                                    ...textFieldStyled,
                                    '& fieldset': {
                                      borderLeftWidth: 3,
                                      borderLeftColor: field.isRequired
                                        ? 'red'
                                        : 'gray',
                                    },
                                    width: '370px',
                                  }}
                                >
                                  {field.options &&
                                    field.options.map((op, index) => (
                                      <MenuItem
                                        id={`employeeSubFunction-MenuItem-${index}`}
                                        key={index}
                                        value={op}
                                      >
                                        {op}
                                      </MenuItem>
                                    ))}
                                </Select>
                                {customVariablesError[field.variableName]
                                  ?.isError && (
                                  <FormHelperText
                                    sx={{color: '#d32f2f', mt: -2}}
                                  >
                                    {
                                      customVariablesError[field.variableName]
                                        ?.errorMessage
                                    }
                                  </FormHelperText>
                                )}
                              </FormControl>
                            )}

                            {field.dataType === 'Boolean' && (
                              <FormLabel id='demo-row-radio-buttons-group-label'>
                                <Stack
                                  direction={{xs: 'column', sm: 'row'}}
                                  sx={{mt: 2}}
                                  justifyContent='space-between'
                                  alignItems='flex-start'
                                >
                                  <Stack
                                    fontWeight={500}
                                    width={{xs: '100%', sm: '50%'}}
                                  >
                                    {field.variableName}
                                  </Stack>
                                  <Stack width={{xs: '100%', sm: '50%'}}>
                                    <RadioGroup
                                      // value={customData.data}
                                      // value={
                                      //   customData.find(
                                      //     (data) =>
                                      //       data.customVariables.id === field.id,
                                      //   )?.data || ''
                                      // }
                                      value={
                                        (
                                          customData.find(
                                            (data) =>
                                              data.customVariables.id ===
                                              field.id,
                                          )?.data || ''
                                        ).toString() // Ensure that data is converted to a string
                                      }
                                      row
                                      aria-labelledby='demo-row-radio-buttons-group-label'
                                      name={field.variableName}
                                      onChange={(e) =>
                                        handleChangeCustomVariable(
                                          field,
                                          e.target.value,
                                          'radio',
                                        )
                                      }
                                    >
                                      <FormControlLabel
                                        value='true'
                                        control={<Radio />}
                                        label={
                                          <IntlMessages id='common.button.Yes' />
                                        }
                                      />
                                      <FormControlLabel
                                        value='false'
                                        control={<Radio />}
                                        label={
                                          <IntlMessages id='common.button.No' />
                                        }
                                      />
                                    </RadioGroup>
                                  </Stack>
                                </Stack>
                                {customVariablesError[field.variableName]
                                  ?.isError && (
                                  <FormHelperText
                                    sx={{color: '#d32f2f', mt: -2, mb: 2}}
                                  >
                                    {
                                      customVariablesError[field.variableName]
                                        ?.errorMessage
                                    }
                                  </FormHelperText>
                                )}
                              </FormLabel>
                            )}
                          </div>
                        ))}
                    </Stack>
                  </Stack>
                </>
              )}
              {/* ////////add Stack for fixed////// */}
              <Stack
                sx={{
                  bottom: 0,
                  zIndex: 10,
                  position: 'fixed',
                  backdropFilter: 'blur(5px)',
                  width: '100%',
                  right: 0,
                }}
              >
                <Stack
                  direction='row'
                  justifyContent='end'
                  alignItems='center'
                  spacing={2}
                  sx={{
                    pt: 5,
                    ml: 3,
                    //// add marging for fixed stack///
                    margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
                  }}
                >
                  <Button
                    color={footerButton.back.color}
                    variant={footerButton.back.variant}
                    sx={footerButton.back.sx}
                    size={footerButton.back.size}
                    onClick={() => Router.push('/company-builder/employee')}
                  >
                    <IntlMessages id='common.button.Back' />
                  </Button>
                  <Button
                    color={footerButton.reset.color}
                    variant={footerButton.reset.variant}
                    sx={footerButton.reset.sx}
                    size={footerButton.reset.size}
                    onClick={() => handleResetForm()}
                  >
                    <IntlMessages id='common.button.Reset' />
                  </Button>
                  <Button
                    color={footerButton.submit.color}
                    variant={footerButton.submit.variant}
                    sx={footerButton.submit.sx}
                    size={footerButton.submit.size}
                    onClick={() => handleValidateEmployee()}
                    disabled={loading}
                  >
                    {loading ? (
                      <CircularProgress
                        sx={{
                          width: '15px !important',
                          margin: '4px !important',
                          height: '15px !important',
                        }}
                      />
                    ) : isEdit ? (
                      <IntlMessages id='common.button.Update' />
                    ) : (
                      <IntlMessages id='common.button.Submit' />
                    )}
                  </Button>
                </Stack>
              </Stack>
            </Box>
          </Stack>
        </div>
      )
    );
  };

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        {!isEdit ? (
          <IntlMessages id='employee.addEmployee' />
        ) : (
          <IntlMessages id='employee.addEmployee.editEmployee' />
        )}
      </h2>
      <AppCard>{domCreaction()}</AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default AddEmployee;
