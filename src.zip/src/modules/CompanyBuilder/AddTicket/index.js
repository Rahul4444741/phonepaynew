import * as React from 'react';
import {Chip, CircularProgress, IconButton} from '@mui/material';
import TextField from '@mui/material/TextField';
import Stack from '@mui/material/Stack';
import AlertDialog from '../../Common/AlertDialog';
import FormControl from '@mui/material/FormControl';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard} from '../../../@crema';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import {useDispatch} from 'react-redux';
import FormHelperText from '@mui/material/FormHelperText';
import {showMessage, fetchError} from '../../../redux/actions';
import axios from 'axios';
import Router, {useRouter} from 'next/router';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import { footerButton } from 'shared/constants/AppConst';
import { documentAcceptInputString, documentsFileType } from 'shared/utils/CommonUtils';
import { GoCloudUpload } from 'react-icons/go';
import { RiDeleteBin4Fill, RiEdit2Fill } from 'react-icons/ri';
import IntlMessages from '@crema/utility/IntlMessages';

const AddTicket = () => {
  const dispatch = useDispatch();
  const employeeId = JSON.parse(localStorage.getItem('userDetails'));

  const requiredStyled = {
    backgroundColor: 'white',
    mb: 2,
    width: {xs: '100%', xl: '60%', md: '75%'},
    '& .MuiOutlinedInput-root': {
      '& fieldset': {
        borderLeftColor: 'red',
        borderLeftWidth: 3,
      },
    },
  };
  const initialEmptyCaseList = {
    title: null,
    raisedBy: {id: employeeId && employeeId?.id},
    message: null,
    //checked:false,
    fileUrl: {id: null},
    status: null,
  };
  const initialFormErrorList = {
    title: {isError: false, errorMessage: ''},
    raisedBy: {id: {isError: false, errorMessage: ''}},
    message: {isError: false, errorMessage: ''},
    //checked: {isError: false, errorMessage: ''},
    fileUrl: {id: {isError: false, errorMessage: ''}},
    status: {isError: false, errorMessage: ''},
    // comments: {isError: false, errorMessage: ''},
  };
  const [alertProps, setAlertProps] = React.useState({});
  const [cases, setCases] = React.useState(initialEmptyCaseList);
  const [formError, setFormError] = React.useState(initialFormErrorList);
  const [isEdit, setIsEdit] = React.useState(false);
  const [caseEditId, setCaseEditId] = React.useState(null);
  const [isUploadingFile, setIsUploadingFile] = React.useState(false);
  const [filename , setFilename] =React.useState('')
  const router = useRouter();
  const {id} = router.query;
  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  React.useEffect(() => {
    if (id != undefined) {
      //handleResetForm();
      setCaseEditId(id);
      setIsEdit(true);
      getAllCaseDetails(id);
    } else {
      //handleResetForm();
      setCaseEditId(null);
      setIsEdit(false);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
    };
  }, [router]);

  const getAllCaseDetails = async (caseID) => {
    try {
      const res = await jwtAxios.get(`${API_ROUTS.case}/${caseID}`, cases, {
        cancelToken: source.token,
      });
      if (res.status == 200) {
        setCases(res.data);
      }
    } catch (e) {
      if (axios.isCancel(e)) {
        // TODO document why this block is empty
      
      } else {
        dispatch(fetchError(e?.response));
      }
    }
  };

  const handleChangeCaseData = (event, fieldType) => {
    const tempCases = JSON.parse(JSON.stringify(cases));
    const tempError = {...formError};
    if (fieldType == 'textfield' || fieldType == 'dropdown') {
      tempCases[event.target.name] = event.target.value;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
    }
    setCases(tempCases);
    setFormError(tempError);
  };

  const handleCaptureFile = (event , eventType) => {
    const tempCase = JSON.parse(JSON.stringify(cases));
    // const tempError = JSON.parse(JSON.stringify(formError));
    const tempError = {...formError};
    const file =
      event.target.files.length > 0 ? event.target.files[0] : undefined;
      setFilename(file.name);
      if (file) {
        tempCase.fileUploadStatus = 'LOADING';
        if (file.size > 2097152) {
          if (eventType === 'editComment') {
          } else {
            setCases({
              ...cases,
              fileUrl: {fname: file.name},
            });
            setFormError({
              ...formError,
              fileUrl: {
                isError: true,
                // errorMessage: 'Please upload a file smaller than 2 MB',
                errorMessage: <IntlMessages id='error.pleaseUploadFileSmallerThan2MB'/>,
              },
            });
          }
          return;
        }else {
          if (documentsFileType(file.name)) {
            if (eventType === 'editComment') {
              // TODO document why this block is empty
            
            } else {
            }
            setFormError({
              ...formError,
              fileUrl: {isError: false, errorMessage: ''},
            });
            setTimeout(() => {
              UploadFile(file);
            }, 200);
          } else {
            setFormError({
              ...formError,
              fileUrl: {
                isError: true,
                // errorMessage:
                //   'Select valid file . Allowed formats : png , jpeg , jpg , pdf '
                errorMessage:<IntlMessages id='error.selectValidImage'/>,
              },
            });
          }
        }
      }
  };

  const handleDeleteFile = () => {
    const tempCategories = JSON.parse(JSON.stringify(cases));
    tempCategories.fileUrl = {id : null };
    setCases(tempCategories);
  };

  const UploadFile = async (file) => {
    setIsUploadingFile(() => true);
    const formData = new FormData();
    formData.append('file', file);
    const tempCase = JSON.parse(JSON.stringify(cases));
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.file_upload}`,
        formData,

        // {headers: {ContentType: 'multipart/form-data'}},
      );
      if (response.status == 201) {
        tempCase.fileUploadStatus = 'LOADED';
        tempCase.fileUrl = response.data;
      } else {
        tempCase.fileUploadStatus = 'NA';
      }
    } catch (e) {
      tempCase.fileUploadStatus = 'NA';
      dispatch(fetchError(e.message));
    }
    setCases(tempCase);
    // setFormError(tempError);
    setFormError({
      ...formError,
      fileUrl: {isError: false},
    });
    setIsUploadingFile(() => false);
  };

  const handleValidateCase = async () => {
    let isValid = true;
    const tempError = {...formError};
    const tempCases = {...cases};
    if (tempCases.title == null || tempCases.title.trim() == '') {
      tempError.title.isError = true;
      tempError.title.errorMessage = <IntlMessages id='error.pleaseEnterTitle'/>;
      isValid = false;
    }
    if (tempCases.message == null || tempCases.message.trim() == '') {
      tempError.message.isError = true;
      tempError.message.errorMessage = <IntlMessages id='error.pleaseEnterMessage'/>;
      isValid = false;
    }
    if (!tempCases.fileUrl.id) {
      tempError.fileUrl.isError = true;
      tempError.fileUrl.errorMessage = <IntlMessages id='error.pleaseChooseFile'/>;
      isValid = false;
    }
    if (isValid) {
      if (isEdit) {
        delete cases.comments;
       
        updateCases();
      } else {
        setCases({...cases, raisedBy: {id: employeeId?.id}});
        submitCases();

      }
    } else {
      setFormError(tempError);
    }
  };

  const submitCases = async () => {
    try {
      const response = await jwtAxios.post(`${API_ROUTS.case}`, cases);
     
      if (response.status == 201) {
       
        dispatch(
          showMessage(response.data.title + ' Ticket added successfully..!'),
        );
        Router.push('/company-builder/company-tickets');
      }
    } catch (e) {
      dispatch(fetchError(e.response.data.title));
    }
  };

  const updateCases = async () => {
    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.case}/${caseEditId}?action=update`,
        cases,
      );
      
      if (response.status == 200) {
        dispatch(
          showMessage(response.data.title + ' Ticket updated successfully..!'),
        );
        setCaseEditId(null);
        setIsEdit(false);
        Router.replace('/company-builder/company-tickets');
      }
    } catch (e) {
      dispatch(fetchError(e.response.data.title));
    }
  };
  const closeCases = async () => {
    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.case}/${caseEditId}?action=close`,
      );
      if (response.status == 200) {
        dispatch(
          showMessage(response.data.title + ' Ticket closed successfully..!'),
        );
        setCaseEditId(null);
        setIsEdit(false);
        Router.replace('/company-builder/company-tickets');
      }
    } catch (e) {
      dispatch(fetchError(e.response.data.title));
    }
  };

  const handelCloseCase = () => {
    let tempProps = {
      isHideShow: true,
      alertType: 'Confirmation',
      // title: 'close ticket',
      // message: 'Are you sure want to close this ticket?',
      title: <IntlMessages id='ticket.closeTicket'/>,
      message: <IntlMessages id='ticket.areYouSureCloseTicket'/>,
    };

    setAlertProps(tempProps);
  };
  //
  const handelNo = () => {
    let tempProps = {
      isHideShow: false,
      alertType: '',
      title: '',
      message: '',
    };

    setAlertProps(tempProps);
  };
  const chipViewPageHandleClick = () => {
    if (cases?.fileUrl?.path) {
      window.open(`${cases.fileUrl.path}`);
    } else {
      dispatch(fetchError('Something went wrong!'));
    }
  };
  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      {/* <BackNavigation /> */}
      <AppCard>
        <h2 style={{display: 'flex', marginBottom: 15}}>
          {!isEdit ? 
          // 'Add Ticket' 
          <IntlMessages id='ticket.addTicket'/>
          : 
          // 'Update Ticket'
          <IntlMessages id='ticket.updateTicket'/>
          }
        </h2>
        <Stack
          direction='row'
          sx={{mt: 2, ml: 3}}
          justifyContent='space-between'
          alignItems='flex-start'
          spacing={2}
        >
          <Stack sx={{width: '50%'}}>
            <TextField
              size='small'
              name='title'
              // label='Title'
              label={ <IntlMessages id='ticket.title'/>}
              variant='outlined'
              error={formError.title.isError}
              helperText={formError.title.errorMessage}
              sx={{...requiredStyled}}
              onChange={(event) => handleChangeCaseData(event, 'textfield')}
              value={cases?.title || ''}
            />
          </Stack>
          <Stack sx={{width: '50%'}}>
            <TextField
              size='small'
              name='message'
              // label='Message'
              label={ <IntlMessages id='ticket.message'/>}
              multiline
              maxRows={4}
              variant='outlined'
              error={formError.message.isError}
              helperText={formError.message.errorMessage}
              sx={{...requiredStyled}}
              onChange={(event) => handleChangeCaseData(event, 'textfield')}
              value={cases?.message || ''}
            />
          </Stack>
        </Stack>
        <Stack
          direction='row'
          sx={{mt: 2, ml: 3}}
          justifyContent='space-between'
          alignItems='flex-start'
          spacing={2}
        >
          {/* <Stack sx={{width: '50%'}}>
          <TextField
            //size='small'
            name='comments'
            label='Comments'
            multiline
            maxRows={4}
            variant='outlined'
            error={formError.comments.isError}
            helperText={formError.comments.errorMessage}
            sx={{...requiredStyled}}
            onChange={(event) => handleChangeCaseData(event,'textfield')}
            value={cases?.comments || ''}
          />
        </Stack> */}
        </Stack>
        <Stack
          direction='row'
          sx={{mt: 2, ml: 3}}
          justifyContent='space-between'
          alignItems='flex-start'
          spacing={2}
        >
          <FormControl>
                  {/* <h3>Upload Document</h3> */}
                  <h3><IntlMessages id='ticket.uploadDocument'/></h3>

                  <Stack
                    direction='row'
                    sx={{
                      display: 'flex',
                      justifyContent: 'flex-start',
                      alignItems: 'center',
                    }}
                  >
                    {cases.fileUploadStatus != 'LOADING' &&
                      cases.fileUrl.id == null  && (
                        <Stack
                          sx={{
                            width: '100%',
                            height: '100px',
                            border: '1px dashed #ccc2c2',
                            display: 'flex',
                            justifyContent: 'center',
                            alignItems: 'center',
                            backgroundColor: '#f6f6f6',
                          }}
                        >                         
                          <IconButton
                            //disabled={!checked}
                            color='primary'
                            aria-label='upload document'
                            component='label'
                            sx={{
                              width: '100%',
                              height: '100%',
                              borderRadius: '0px',
                            }}
                          >
                            <input
                              id={'inputFile_'}
                              onChange={(event) =>
                                handleCaptureFile(event, 'newAdd')
                              }
                              hidden
                              type='file'
                              label='File upload'
                              // value={cases.fileUrl.name}
                              // error={formError.fileUrl.id.isError}
                              // helperText={formError.fileUrl.id.errorMessage}
                              accept={documentAcceptInputString}
                              disabled={isUploadingFile}
                            />
                            <GoCloudUpload
                              style={{fontSize: '4.5rem', marginRight: '2rem'}}
                            />
                            {/* Upload File */}
                            <IntlMessages id='ticket.uploadFile'/>
                          </IconButton>
                         
                        </Stack>
                         
                      )}

                    {cases.fileUploadStatus == 'LOADING' && (
                        <CircularProgress size={20} />
                      )}
                     <Stack
                      sx={{
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        position: 'relative',
                        border: '1px solid blue',
                      }}
                    >
                     
                      {cases.fileUploadStatus != 'LOADING' &&
                        cases.fileUrl.id != null && (
                          <Stack>
                            {RegExp(/\.(pdf)$/).exec(filename)?
                            <Chip
                            sx={{
                              width:'auto',
                              whiteSpace: 'nowrap',
                              overflow: 'hidden',
                              textOverflow: 'ellipsis',
                              margin:'40px 10px'
                            }}
                            label={filename}
                            color='success'
                            size='small'
                            onClick={() => chipViewPageHandleClick()}
                          />
                            :
                            <img
                              src={cases?.fileUrl?.path}
                              alt='document'
                              style={{width: 'auto', height: '100px'}}
                            />}
                            <IconButton
                              //disabled={!checked}
                              color='primary'
                              aria-label='upload document'
                              component='label'
                              style={{
                                position: 'absolute',
                                right: '-14px',
                                top: '20px',
                                fontSize: '1.25rem',
                                color: 'blue',
                                backgroundColor: '#ffffff',
                                padding: '2px',
                                width: '1.75rem',
                                height: '1.75rem',
                                borderRadius: '1rem',
                                border: '1px solid gray',
                              }}
                            >
                              <input
                                id={'inputFile_'}
                                onChange={(event) => handleCaptureFile(event ,'newAdd')}
                                hidden
                                type='file'
                                label='File upload'
                                // value={cases.fileUrl.name}
                                // error={formError.fileUrl.id.isError}
                                // helperText={formError.fileUrl.id.errorMessage}
                                accept={documentAcceptInputString}
                                disabled={isUploadingFile}
                              />
                              <RiEdit2Fill />
                            </IconButton>

                            <RiDeleteBin4Fill
                              onClick={() => handleDeleteFile()}
                              style={{
                                position: 'absolute',
                                right: '-14px',
                                top: '52px',
                                fontSize: '1.25rem',
                                color: 'blue',
                                backgroundColor: '#ffffff',
                                padding: '2px',
                                width: '1.75rem',
                                height: '1.75rem',
                                borderRadius: '1rem',
                                border: '1px solid gray',
                                cursor: 'pointer',
                              }}
                            />
                          </Stack>
                        )}
                      </Stack>

                  </Stack>
                </FormControl>    
          </Stack>
              {formError.fileUrl?.isError && (
                <FormHelperText className='Mui-error'  style={{marginLeft:'15px'}}>
                      {formError.fileUrl.errorMessage}
                </FormHelperText>
              )}
                {/* --------------- icon end ------------------------ */}
        {/* <Stack
          direction='row'
          sx={{mt: 2, ml: 3}}
          justifyContent='space-between'
          alignItems='flex-start'
          spacing={2}
        >
          <Stack sx={{width: '50%'}}>
            <FormControlLabel
              control={
                <Checkbox
                  checked={checked}
                  onChange={(event) => handleChange(event)}
                />
              }
              label='Template Check'
              name='checked'
            />
            {formError.fileUrl.id.isError && (
              <FormHelperText sx={{color: '#d32f2f', mt: -1}}>
                {formError.fileUrl.id.errorMessage}
              </FormHelperText>
            )}
            {checked && (
              <IconButton
                //disabled={!checked}
                color='primary'
                aria-label='upload document'
                component='label'
              >
                <input
                  id={'inputFile_'}
                  onChange={(event) => handleCaptureFile(event)}
                  hidden
                  type='file'
                  label='File upload'
                  value={cases.fileUrl.name}
                  // error={formError.fileUrl.id.isError}
                  // helperText={formError.fileUrl.id.errorMessage}
                />
                <UploadFileIcon />
              </IconButton>
            )}
            {cases.fileUploadStatus == 'LOADING' && (
              <CircularProgress size={20} />
            )}
            {cases.fileUploadStatus == 'LOADED' && cases.fileUrl != null && (
              <Chip
                sx={{
                  maxWidth: 150,
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                }}
                label={cases.fileUrl.fname}
                color='success'
                size='small'
              />
            )}
            {!isLoad && cases?.fileUrl?.fname && (
              <Chip
                sx={{
                  maxWidth: 150,
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis',
                }}
                label={cases?.fileUrl?.fname}
                color='success'
                size='small'
                onClick={() => chipViewPageHandleClick()}
              />
            )}
          </Stack>
        </Stack> */}

        {/* ////////add Stack for fixed////// */}
        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0
          }}
        >

          <Stack
            direction='row'
            justifyContent='end'
            alignItems='center'
            spacing={2}
            sx={{
              pt: 5, 
              ml: 3,
              //// add marging for fixed stack///
              margin: {xs: '0 5% 1% 0', xl: "0 17% 1% 0"}
            }}
          >
            <Button 
              color={footerButton.back.color}
              variant={footerButton.back.variant}
              sx={footerButton.back.sx}
              size={footerButton.back.size} 
              onClick={() => Router.push('/company-builder/company-tickets')}>
              {/* Back */}
              <IntlMessages id='common.button.Back'/>
            </Button>
            {!isEdit ? (
            <Button
              name='reset'
              color={footerButton.reset.color}
              variant={footerButton.reset.variant}
              sx={footerButton.reset.sx}
              size={footerButton.reset.size}
              onClick={() => handleResetForm()}
            >
              {/* Reset */}
              <IntlMessages id='common.button.Reset'/>
            </Button>
          ) : (
            <Button
              name='close'
              color={footerButton.close.color}
              variant={footerButton.close.variant}
              sx={footerButton.close.sx}
              size={footerButton.close.size}
              onClick={() => handelCloseCase()}
            >
              {/* Close */}
              <IntlMessages id='common.button.Close'/>
            </Button>
          )}
          <Button
            name='submit'
            color={footerButton.submit.color}
            variant={footerButton.submit.variant}
            sx={footerButton.submit.sx}
            size={footerButton.submit.size}
            onClick={() => handleValidateCase()}
          >
            {!isEdit ? 
            // 'Submit' 
            <IntlMessages id='common.button.Submit'/>
            : 
            // 'Update'
            <IntlMessages id='common.button.Update'/>
            }
          </Button>
          </Stack>
        </Stack>

      </AppCard>
      {alertProps?.isHideShow && (
        <AlertDialog
          alertProps={alertProps}
          handleYes={() => closeCases()}
          handleNo={() => handelNo()}
        />
      )}
    </AppAnimate>
  );
};

export default AddTicket;
