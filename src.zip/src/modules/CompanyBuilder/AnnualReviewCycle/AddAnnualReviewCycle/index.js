import React from 'react';
import {useDispatch, useSelector} from 'react-redux';
import AppAnimate from '../../../../@crema/core/AppAnimate';
import AppPageMeta from '../../../../@crema/core/AppPageMeta';
import {AppCard, AppInfoView} from '../../../../@crema';
import Stack from '@mui/material/Stack';
import {
  DatePicker,
  DesktopDatePicker,
  LocalizationProvider,
} from '@mui/x-date-pickers';
import {AdapterDateFns} from '@mui/x-date-pickers/AdapterDateFns';
import TextField from '@mui/material/TextField';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import {
  getCompanyDateFormatForInputs,
  isEmptyNullUndefined,
  apiCatchErrorMessage,
} from '../../../../shared/utils/CommonUtils';
import Button from '@mui/material/Button';
import Router, {useRouter} from 'next/router';
import {
  showMessage,
  fetchError,
  fetchStart,
  showInfo,
} from '../../../../redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import FormHelperText from '@mui/material/FormHelperText';
import {footerButton} from 'shared/constants/AppConst';
import IntlMessages from '@crema/utility/IntlMessages';
import {
  CircularProgress,
  FormControlLabel,
  Radio,
  RadioGroup,
} from '@mui/material';
import axios from 'axios';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';

const textFieldStyled = {
  backgroundColor: 'white',
  mb: 2,
  width: {xs: '100%', xl: '60%', md: '75%'},
};

const AddAnnualReviewCycle = () => {
  const router = useRouter();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const {id, view} = router.query;
  const dispatch = useDispatch();

  const initialAnnualCycle = {
    companyId: selectedCompany?.id,
    cycleName: '',
    status: null,
    startDate: null,
    endDate: null,
    isThreeSixtyCycle: false,
    threeSixtyCycleId: null,
  };

  const initialAnnualCycleError = {
    cycleName: {isError: false, errorMessage: ''},
    status: {isError: false, errorMessage: ''},
    startDate: {isError: false, errorMessage: ''},
    endDate: {isError: false, errorMessage: ''},
    isThreeSixtyCycle: {isError: false, errorMessage: ''},
    threeSixtyCycleId: {isError: false, errorMessage: ''},
  };

  const [annualCycle, setAnnualCycle] = React.useState(initialAnnualCycle);
  const [annualCycleError, setAnnualCycleError] = React.useState(
    initialAnnualCycleError,
  );

  const [isLoading, setIsLoading] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [isEdit, setIsEdit] = React.useState(false);
  const [isView, setIsView] = React.useState(false);

  const [threeSixtyData, setThreeSixtyData] = React.useState(null);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  React.useEffect(() => {
    if (!isEmptyNullUndefined(id)) {
      if (view == true || view == 'true') {
        getAnnualCycleDetails(id);
        setIsView(true);
      } else {
        getAnnualCycleDetails(id);
        setIsEdit(true);
      }
    }
  }, []);

  React.useEffect(() => {
    dispatch(fetchStart);
    if (selectedCompany != null && selectedCompany != undefined) {
      getAllThreeSixtyCycle(selectedCompany.id);
    }
  }, [selectedCompany]);

  const getAllThreeSixtyCycle = async (companyId) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.threeSixtyCycle}/company/${companyId}?status=ACTIVE`,
        // `${API_ROUTS.threeSixtyCycle}/company/${companyId}?status=All`,
        {cancelToken: source.token},
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no pms cycle for selected company'));
          setThreeSixtyData([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setThreeSixtyData(reversed);
        }
      } else {
        setThreeSixtyData([]);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setThreeSixtyData([]);
    }
  };

  const getAnnualCycleDetails = async (id) => {
    setIsLoading(true);
    try {
      const response = await jwtAxios.get(`${API_ROUTS.annualCycle}/${id}`, {
        cancelToken: source2.token,
      });
      if (response.status == 200) {
        setAnnualCycle(response.data);
        setIsLoading(false);
      }
    } catch (e) {
      dispatch(fetchError(e.response?.data?.detail));
      setIsLoading(false);
    }
  };

  const handleChangeAnnualCycleData = (event, fieldType, name) => {
    let tempAnnualCycle = {...annualCycle};
    let tempAnnualCycleError = {...annualCycleError};

    if (fieldType == 'textfield' || fieldType == 'dropdown') {
      tempAnnualCycle[event.target.name] = event.target.value;
      tempAnnualCycleError[event.target.name].isError = false;
      tempAnnualCycleError[event.target.name].errorMessage = '';
    } else if (fieldType == 'dropdownID') {
      tempAnnualCycle[event.target.name] = {id: event.target.value};
      tempAnnualCycleError[event.target.name] = {
        id: {isError: false, errorMessage: ''},
      };
    } else if (fieldType == 'date') {
      tempAnnualCycle[name] = event;
      tempAnnualCycleError[name].isError = false;
      tempAnnualCycleError[name].errorMessage = '';
    } else if (fieldType == 'radio') {
      tempAnnualCycle[event.target.name] = event.target.value;
      tempAnnualCycleError[event.target.name].isError = false;
      tempAnnualCycleError[event.target.name].errorMessage = '';

      if (
        event.target.name == 'isThreeSixtyCycle' &&
        event.target.value == 'false'
      ) {
        tempAnnualCycle.threeSixtyCycleId = null;
        tempAnnualCycleError.threeSixtyCycleId.isError = false;
        tempAnnualCycleError.threeSixtyCycleId.errorMessage = '';
      }
    }

    setAnnualCycle(() => tempAnnualCycle);
    setAnnualCycleError(() => tempAnnualCycleError);
  };

  const validateAnualCycleData = () => {
    const tempError = {...annualCycleError};
    let isValid = true;

    if (isEmptyNullUndefined(annualCycle.cycleName)) {
      tempError.cycleName.isError = true;
      tempError.cycleName.errorMessage = (
        <IntlMessages id='annualCycle.Please_enter_annual_cycle_name' />
      );
      isValid = false;
    }

    if (isEmptyNullUndefined(annualCycle.status)) {
      tempError.status.isError = true;
      tempError.status.errorMessage = (
        <IntlMessages id='annualCycle.Please_select_status' />
      );
      isValid = false;
    }

    if (isEmptyNullUndefined(annualCycle.startDate)) {
      tempError.startDate.isError = true;
      tempError.startDate.errorMessage = (
        <IntlMessages id='annualCycle.Please_enter_start_date' />
      );
      isValid = false;
    }

    if (isEmptyNullUndefined(annualCycle.endDate)) {
      tempError.endDate.isError = true;
      tempError.endDate.errorMessage = (
        <IntlMessages id='annualCycle.Please_enter_end_date' />
      );
      isValid = false;
    }
    if (!dateValidation(annualCycle.startDate, annualCycle.endDate)) {
      tempError.endDate.isError = true;
      tempError.endDate.errorMessage = (
        <IntlMessages id='annualCycle.invalid_date' />
      );
      isValid = false;
    }

    if (
      (annualCycle.isThreeSixtyCycle == true ||
        annualCycle.isThreeSixtyCycle == 'true') &&
      isEmptyNullUndefined(annualCycle.threeSixtyCycleId)
    ) {
      tempError.threeSixtyCycleId.isError = true;
      tempError.threeSixtyCycleId.errorMessage = 'Please select 360 cycle.';
      isValid = false;
    }

    if (isValid) {
      if (!isEdit) {
        SubmitAnnualCycleDate();
      } else {
        UpdateAnnualCycleData();
      }
    } else {
      setAnnualCycleError(tempError);
    }
  };

  const dateValidation = (startDate, endDate) => {
    let isValid = true;
    if (new Date(startDate) > new Date(endDate)) {
      isValid = false;
    }

    return isValid;
  };

  const SubmitAnnualCycleDate = async () => {
    let tempAnnualCycle = {
      ...annualCycle,

      threeSixtyCycleId:
        annualCycle.isThreeSixtyCycle == 'false' ||
        annualCycle.isThreeSixtyCycle == false
          ? null
          : annualCycle.threeSixtyCycleId,
    };

    const submit = async () => {
      setLoading(true);
      try {
        const response = await jwtAxios.post(
          `${API_ROUTS.annualCycle}/save`,
          tempAnnualCycle,
        );
        if (response.status == 200) {
          dispatch(showMessage('Annual review cycle added successfully..!'));
          Router.push('/company-builder/annual-review-cycle');
        } else {
          setLoading(false);
        }
      } catch (error) {
        apiCatchErrorMessage(error, dispatch, fetchError);
        setLoading(false);
      }
    };
    await submit();
  };

  const UpdateAnnualCycleData = async () => {
    let tempAnnualCycle = {
      ...annualCycle,
      id: id,
      threeSixtyCycleId:
        annualCycle.isThreeSixtyCycle == 'false' ||
        annualCycle.isThreeSixtyCycle == false
          ? null
          : annualCycle.threeSixtyCycleId,
    };

    const update = async () => {
      setLoading(true);
      try {
        const response = await jwtAxios.post(
          `${API_ROUTS.annualCycle}/save`,
          tempAnnualCycle,
        );
        if (response.status == 200) {
          dispatch(showMessage('Annual review cycle updated successfully..!'));
          Router.push('/company-builder/annual-review-cycle');
        } else {
          setLoading(false);
        }
      } catch (error) {
        apiCatchErrorMessage(error, dispatch, fetchError);
        setLoading(false);
      }
    };
    await update();
  };

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />

      <h2 style={{marginBottom: 20}}>
        {isView ? (
          <h3>View review cycle</h3>
        ) : !isEdit ? (
          <h3>
            <IntlMessages id='annualCycle.Add_Annual_Review_Cycle' />
          </h3>
        ) : (
          <h3>
            <IntlMessages id='annualCycle.Edit_Annual_Review_Cycle' />
          </h3>
        )}
      </h2>

      <AppCard>
        <Stack sx={{mb: 10}}>
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>
                <IntlMessages id='annualCycle.Cycle_Name' /> :
              </Stack>
            </Stack>
            {isLoading ? (
              domCreactionGridSkeletonLoader('70px')
            ) : (
              <Stack direction={'row'} sx={{width: '50%'}}>
                <TextField
                  size='small'
                  disabled={isView}
                  name='cycleName'
                  label={<IntlMessages id='annualCycle.Cycle_Name' />}
                  onChange={(event) =>
                    handleChangeAnnualCycleData(event, 'textfield')
                  }
                  variant='outlined'
                  error={annualCycleError.cycleName.isError}
                  helperText={annualCycleError.cycleName.errorMessage}
                  value={annualCycle.cycleName ? annualCycle.cycleName : ''}
                  sx={{
                    ...textFieldStyled,
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                    },
                  }}
                />
              </Stack>
            )}
          </Stack>

          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>
                <IntlMessages id='configuration.dialogbox.Status' /> :{' '}
              </Stack>
            </Stack>
            {isLoading ? (
              domCreactionGridSkeletonLoader('70px')
            ) : (
              <Stack direction={'row'} sx={{width: '50%'}}>
                <FormControl
                  sx={{
                    ...textFieldStyled,
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                    },
                  }}
                >
                  <InputLabel size='small' id='status'>
                    <IntlMessages id='configuration.dialogbox.Status' />
                  </InputLabel>
                  <Select
                    size='small'
                    name='status'
                    disabled={isView}
                    label={<IntlMessages id='configuration.dialogbox.Status' />}
                    labelId='status'
                    value={annualCycle?.status || ''}
                    error={annualCycleError.status?.isError}
                    helperText={annualCycleError.status?.errorMessage}
                    onChange={(event) =>
                      handleChangeAnnualCycleData(event, 'dropdown')
                    }
                    variant='outlined'
                    sx={{...textFieldStyled, width: '100%'}}
                  >
                    <MenuItem key='Active' value='ACTIVE'>
                      <IntlMessages id='configuration.dialogbox.Status.Active' />
                    </MenuItem>
                    <MenuItem key='Inactive' value='INACTIVE'>
                      <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                    </MenuItem>
                  </Select>
                  <FormHelperText style={{color: '#d32f2f'}}>
                    {annualCycleError.status.errorMessage}
                  </FormHelperText>
                </FormControl>
              </Stack>
            )}
          </Stack>

          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>
                <IntlMessages id='annualCycle.Annual_Review_Cycle_Period' />:{' '}
              </Stack>
            </Stack>
            {isLoading ? (
              domCreactionGridSkeletonLoader('70px')
            ) : (
              <Stack direction={'row'} sx={{width: '50%'}}>
                <Stack
                  direction={'column'}
                  sx={{width: '42%'}}
                  justifyContent='flex-start'
                >
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DesktopDatePicker
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          '& fieldset': {
                            borderLeftColor: 'red',
                            borderLeftWidth: 3,
                          },
                          height: '40px',
                          width: '180px',
                        },
                      }}
                      minDate={new Date()}
                      disabled={isView}
                      format={getCompanyDateFormatForInputs(selectedCompany)}
                      size='small'
                      value={
                        !isEmptyNullUndefined(annualCycle.startDate)
                          ? new Date(annualCycle.startDate)
                          : null
                      }
                      label={<IntlMessages id='annualCycle.Start_date' />}
                      name='startDate'
                      onChange={(event) =>
                        handleChangeAnnualCycleData(event, 'date', 'startDate')
                      }
                    />
                  </LocalizationProvider>
                  {annualCycleError.startDate?.isError && (
                    <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                      {annualCycleError.startDate?.errorMessage}
                    </FormHelperText>
                  )}
                </Stack>
                <Stack direction={'column'} sx={{width: '42%'}}>
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DesktopDatePicker
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          '& fieldset': {
                            borderLeftColor: 'red',
                            borderLeftWidth: 3,
                          },
                          height: '40px',
                          width: '180px',
                        },
                      }}
                      minDate={new Date()}
                      disabled={isView}
                      format={getCompanyDateFormatForInputs(selectedCompany)}
                      size='small'
                      // value={annualCycle.endDate}
                      value={
                        !isEmptyNullUndefined(annualCycle.endDate)
                          ? new Date(annualCycle.endDate)
                          : null
                      }
                      label={<IntlMessages id='annualCycle.End_date' />}
                      name='endDate'
                      onChange={(event) =>
                        handleChangeAnnualCycleData(event, 'date', 'endDate')
                      }
                    />
                  </LocalizationProvider>
                  {annualCycleError.endDate?.isError && (
                    <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                      {annualCycleError.endDate?.errorMessage}
                    </FormHelperText>
                  )}
                </Stack>
              </Stack>
            )}
          </Stack>

          {/* -------------------------------------------------------------------------------------- */}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>Is 360 cycle required ?</Stack>
            </Stack>
            {isLoading ? (
              domCreactionGridSkeletonLoader('70px')
            ) : (
              <Stack direction={'row'} sx={{width: '50%'}}>
                <RadioGroup
                  value={annualCycle.isThreeSixtyCycle}
                  row
                  aria-labelledby='demo-row-radio-buttons-group-label'
                  name='isThreeSixtyCycle'
                  onChange={(event) =>
                    handleChangeAnnualCycleData(event, 'radio')
                  }
                >
                  <FormControlLabel
                    value={true}
                    control={<Radio />}
                    disabled={isView}
                    label={<IntlMessages id='common.button.Yes' />}
                  />
                  <FormControlLabel
                    value={false}
                    control={<Radio />}
                    disabled={isView}
                    label={<IntlMessages id='common.button.No' />}
                  />
                </RadioGroup>
              </Stack>
            )}
          </Stack>

          {(annualCycle.isThreeSixtyCycle == 'true' ||
            annualCycle.isThreeSixtyCycle == true) && (
            <Stack
              id='addEnrollmentStack'
              direction='row'
              sx={{mt: 5, ml: 3}}
              justifyContent='space-between'
              alignItems='flex-start'
              spacing={2}
            >
              <Stack sx={{width: '50%'}}>
                <Stack fontWeight={500}>Select 360 cycle</Stack>
              </Stack>
              {isLoading ? (
                domCreactionGridSkeletonLoader('70px')
              ) : (
                <Stack direction={'row'} sx={{width: '50%'}}>
                  <FormControl
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'red',
                          borderLeftWidth: 3,
                        },
                      },
                      // width: '195px',
                    }}
                  >
                    <InputLabel
                      sx={{backgroundColor: '#ffffff', padding: '0px 0.5rem'}}
                      size='small'
                      id='Type-threeSixtyCycle'
                    >
                      Select 360 cycle
                    </InputLabel>
                    <Select
                      value={annualCycle.threeSixtyCycleId || ''}
                      id={'threeSixtyCycleId'}
                      name='threeSixtyCycleId'
                      disabled={isView}
                      error={annualCycleError.threeSixtyCycleId?.isError}
                      onChange={(event) =>
                        handleChangeAnnualCycleData(event, 'dropdown')
                      }
                      variant='outlined'
                      size='small'
                    >
                      {threeSixtyData?.map((t, i) => {
                        return (
                          <MenuItem
                            value={t.id}
                            id={t.id}
                            name={t.cycleName}
                            size='small'
                            key={t.id}
                          >
                            {t.cycleName}
                          </MenuItem>
                        );
                      })}
                    </Select>
                    {annualCycleError.threeSixtyCycleId?.isError && (
                      <FormHelperText className='Mui-error'>
                        <>{annualCycleError.threeSixtyCycleId?.errorMessage}</>
                      </FormHelperText>
                    )}
                  </FormControl>
                </Stack>
              )}
            </Stack>
          )}
          {/* -------------------------------------------------------------------------------------- */}
        </Stack>
        {/* ////////add Stack for fixed////// */}
        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0,
          }}
        >
          <Stack
            direction='row'
            justifyContent='end'
            alignItems='center'
            spacing={2}
            sx={{
              pt: 5,
              ml: 3,
              //// add marging for fixed stack///
              margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
            }}
          >
            <Button
              color={footerButton.back.color}
              variant={footerButton.back.variant}
              sx={footerButton.back.sx}
              size={footerButton.back.size}
              onClick={() =>
                Router.push('/company-builder/annual-review-cycle')
              }
            >
              <IntlMessages id='common.button.Back' />
            </Button>

            {!isView && (
              <Button
                color={footerButton.submit.color}
                variant={footerButton.submit.variant}
                sx={footerButton.submit.sx}
                size={footerButton.submit.size}
                disabled={loading || isLoading}
                onClick={() => {
                  validateAnualCycleData();
                }}
              >
                {loading ? (
                  <CircularProgress
                    sx={{
                      margin: '0px 1rem',
                      color: '#000000',
                      width: '25px !important',
                      height: '25px !important',
                    }}
                  />
                ) : (
                  <Stack>
                    {isEdit ? (
                      <IntlMessages id='common.button.Update' />
                    ) : (
                      <IntlMessages id='common.button.Submit' />
                    )}
                  </Stack>
                )}
              </Button>
            )}
          </Stack>
        </Stack>
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default AddAnnualReviewCycle;
