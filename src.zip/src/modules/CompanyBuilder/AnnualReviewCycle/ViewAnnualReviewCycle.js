import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard, AppInfoView} from '../../../@crema';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import Router, {useRouter} from 'next/router';
import {useDispatch} from 'react-redux';
import {
  fetchError,
} from '../../../redux/actions';
import axios from 'axios';
import {
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';
import IntlMessages from '@crema/utility/IntlMessages';
import {footerButton} from 'shared/constants/AppConst';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';

const ViewAnnualReviewCycle = () => {
  const router = useRouter();
  const {id} = router.query;
  const dispatch = useDispatch();

  const [annualCycle, setAnnualCycle] = React.useState({});

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  React.useEffect(() => {
    if (!isEmptyNullUndefined(id)) {
      getAnnualCycleDetails(id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, []);

  const getAnnualCycleDetails = async (id) => {
    try {
      const response = await jwtAxios.get(`${API_ROUTS.annualCycle}/${id}`, {
        cancelToken: source2.token,
      });
      if (response.status == 200) {
        setAnnualCycle(response.data);
      }
    } catch (e) {
      dispatch(fetchError(e.response?.data?.detail));
    }
  };


  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h1 style={{marginBottom: 5}}><IntlMessages id='annualCycle.Annual_Review_Cycle'/></h1>

      <Stack spacing={2} sx={{mb: 10}}>
        <AppCard>
          <h3
            style={{
              marginBottom: 10,
              backgroundColor: '#D3D3D3',
              borderRadius: 10,
              padding: 5,
            }}
          >
           <IntlMessages id='annualCycle.Annual_Review_Cycle_Information'/> :
          </h3>
          <Stack
            direction='row'
            sx={{mt: 5, ml: 10}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <div>
                <b>
                  <IntlMessages id='annualCycle.Annual_Review_Cycle_Name' />
                </b>
              </div>
            </Stack>
            <Stack sx={{width: '50%'}}>
              <div>
                <span style={{marginLeft: 75}}>{annualCycle?.cycleName}</span>
              </div>
            </Stack>
          </Stack>
          <Stack
            direction='row'
            sx={{mt: 5, ml: 10}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <div>
                <b>
                  <IntlMessages id='annualCycle.Status' />
                </b>
              </div>
            </Stack>
            <Stack sx={{width: '50%'}}>
              <div>
                <span style={{marginLeft: 75}}>{annualCycle?.status}</span>
              </div>
            </Stack>
          </Stack>
          <Stack
            direction='row'
            sx={{mt: 5, ml: 10}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <div>
                <b>
                  <IntlMessages id='annualCycle.Start_date' />
                </b>
              </div>
            </Stack>
            <Stack sx={{width: '50%'}}>
              <div>
                <span style={{marginLeft: 75}}>{annualCycle?.startDate}</span>
              </div>
            </Stack>
          </Stack>
          <Stack
            direction='row'
            sx={{mt: 5, ml: 10}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <div>
                <b>
                  <IntlMessages id='annualCycle.End_date' />
                </b>
              </div>
            </Stack>
            <Stack sx={{width: '50%'}}>
              <div>
                <span style={{marginLeft: 75}}>{annualCycle?.endDate}</span>
              </div>
            </Stack>
          </Stack>
          <Stack
            direction='row'
            sx={{mt: 5, ml: 10}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <div>
                <b>
                  <IntlMessages id='annualCycle.Is_PMS_Cycle_Required' />
                </b>
              </div>
            </Stack>
            <Stack sx={{width: '50%'}}>
              <div>
                <span style={{marginLeft: 75}}>{annualCycle?.isPmsCycle ? 'Yes' : 'No'}</span>
              </div>
            </Stack>
          </Stack>
          <Stack
            direction='row'
            sx={{mt: 5, ml: 10}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <div>
                <b>
                  <IntlMessages id='annualCycle.PMS_Cycle_Name' />
                </b>
              </div>
            </Stack>
            <Stack sx={{width: '50%'}}>
              <div>
                <span style={{marginLeft: 75}}>{annualCycle?.pmsCycle?.cycleName}</span>
              </div>
            </Stack>
          </Stack>
          <Stack
            direction='row'
            sx={{mt: 5, ml: 10}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <div>
                <b>
                  <IntlMessages id='annualCycle.Is_Calibration_Cycle_Required' />
                </b>
              </div>
            </Stack>
            <Stack sx={{width: '50%'}}>
              <div>
                <span style={{marginLeft: 75}}>{annualCycle?.isCalibrationCycle ? 'Yes' : 'No'}</span>
              </div>
            </Stack>
          </Stack>
          <Stack
            direction='row'
            sx={{mt: 5, ml: 10}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <div>
                <b>
                  <IntlMessages id='annualCycle.Calibration_Cycle_Name' />
                </b>
              </div>
            </Stack>
            <Stack sx={{width: '50%'}}>
              <div>
                <span style={{marginLeft: 75}}>{annualCycle?.calibrationCycle?.cycleName}</span>
              </div>
            </Stack>
          </Stack>
        </AppCard>

        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0,
          }}
        >
          <Stack
            direction='row'
            justifyContent='end'
            alignItems='center'
            spacing={2}
            sx={{
              pt: 5,
              ml: 3,
              margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
            }}
          ></Stack>
        </Stack>
      </Stack>
      <AppInfoView />

      {/* ////////add Stack for fixed////// */}
      <Stack
        sx={{
          bottom: 0,
          zIndex: 10,
          position: 'fixed',
          backdropFilter: 'blur(5px)',
          width: '100%',
          right: 0,
        }}
      >
        <Stack
          direction='row'
          justifyContent='end'
          alignItems='center'
          spacing={2}
          sx={{
            pt: 5,
            ml: 3,
            //// add marging for fixed stack///
            margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
          }}
        >
          <Button
            color={footerButton.back.color}
            variant={footerButton.back.variant}
            sx={footerButton.back.sx}
            size={footerButton.back.size}
            onClick={() => Router.push('/company-builder/annual-review-cycle')}
          >
            <IntlMessages id='common.button.Back' />
          </Button>
        </Stack>
      </Stack>
    </AppAnimate>
  );
};

export default ViewAnnualReviewCycle;
