import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard} from '../../../@crema';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import {AgGridReact} from 'ag-grid-react';
import {useDispatch, useSelector} from 'react-redux';
import AppInfoView from '../../../@crema/core/AppInfoView';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import {
  fetchStart,
  showMessage,
  fetchError,
  showInfo,
} from '../../../redux/actions';
import axios from 'axios';
import AlertDialog from '../../Common/AlertDialog';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {TextField} from '@mui/material';
import {
  isEmptyNullUndefined,
  buttonStyle,
  apiCatchErrorMessage,
  isAllowedUser,
} from 'shared/utils/CommonUtils';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import IntlMessages from '@crema/utility/IntlMessages';
import Router from 'next/router';
import {permissionName} from 'shared/utils/PermissionName';
import Error403 from 'modules/errorPages/Error403';
import { useCallback } from 'react';

const AnnualReviewCycle = () => {
  const dispatch = useDispatch();
  const [annualCycle, setAnnualCycle] = React.useState(null);
  const [overlayMessage, setOverlayMessage] = React.useState('No Rows To Show');
  const [isLoading, setIsLoading] = React.useState(true);
  const [alertProps, setAlertProps] = React.useState({
    isHideShow: false,
    message: '',
    title: '',
    alertType: '',
    actionParams: null,
  });

  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);

  React.useEffect(() => {
    if (isAllowedUser(permissionName.ANNUAL_REVIEW_CYCLE)) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  const CustomHeaderName = () => (
    <IntlMessages id='aggrid.tableHeader.Name' />
  );
  const CustomHeaderStatus = () => (
    <IntlMessages id='aggrid.tableHeader.Status' />
  );
  const CustomHeaderAction = () => (
    <IntlMessages id='aggrid.tableHeader.Action' />
  );

  const [columnDefs] = React.useState([
    {
      field: 'cycleName',
      filter: true,
      headerName: 'Name',
      minWidth: 350,
      headerComponentFramework: CustomHeaderName,
    },
    {
      field: 'status',
      filter: true,
      headerName: 'Status',
      headerComponentFramework: CustomHeaderStatus,
      minWidth: 350,
      cellRenderer: function (params) {
        return (
          <Stack direction='row'>
            {params.data.status == 'ACTIVE' ? (
              <div style={{color: '#11C15B'}}>{params.data.status}</div>
            ) : params.data.isDraft == true ? (
              <div style={{color: '#ebe134'}}>{'DRAFT'}</div>
            ) : (
              <div style={{color: '#D32F2F'}}>{params.data.status}</div>
            )}
          </Stack>
        );
      },
    },
    {
      headerName: 'Action',
      headerComponentFramework: CustomHeaderAction,
      minWidth: 300,
      cellRenderer: function (params) {
        return (
          <Stack direction='row'>
            {isAllowedUser(permissionName.UPDATE) && (
              <Button
                onClick={() => handleRedirectEditAnnualCycle(params)}
                style={buttonStyle}
              >
                <IntlMessages id='common.button.Edit' />
              </Button>
            )}
            {isAllowedUser(permissionName.READ) && (
              <Button
                onClick={() => handleRedirectViewAnnualCycle(params)}
                style={buttonStyle}
              >
                <IntlMessages id='common.button.View' />
              </Button>
            )}

            {isAllowedUser(permissionName.DEACTIVATE) &&
              params.data.status == 'ACTIVE' && (
                <Button
                  onClick={() => handleDeactivateConfirmation(params)}
                  style={buttonStyle}
                >
                  <IntlMessages id='common.button.Deactivate' />
                </Button>
              )}
            {isAllowedUser(permissionName.ACTIVATE) &&
              params.data.status == 'INACTIVE' &&
              params.data.isDraft != true && (
                <Button
                  onClick={() => handleActivateConfirmation(params)}
                  style={buttonStyle}
                >
                  <IntlMessages id='common.button.Activate' />
                </Button>
              )}
          </Stack>
        );
      },
    },
  ]);

  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();
  React.useEffect(() => {
    dispatch(fetchStart);
    if (
      isAuthorized &&
      selectedCompany != null &&
      selectedCompany != undefined
    ) {
      getAllActiveAnnualCycle(selectedCompany.id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, [isAuthorized, selectedCompany]);

  const gridRef = React.useRef();
  const defaultColDef = React.useMemo(() => ({
    sortable: true,
  }));

  const getAllActiveAnnualCycle = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.annualCycle}/${companyId}/ACTIVE`,
        {cancelToken: source.token},
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no annual cycle for selected company'));
          setAnnualCycle([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setAnnualCycle(reversed);
        }
        setIsLoading(() => false);
      } else {
        setAnnualCycle([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setAnnualCycle([]);
    }
    setIsLoading(() => false);
  };
  const getAllInactiveAnnualCycle = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.annualCycle}/${companyId}/INACTIVE`,
        {cancelToken: source.token},
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no annual cycle for selected company'));
          setAnnualCycle([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setAnnualCycle(reversed);
        }
        setIsLoading(() => false);
      } else {
        setAnnualCycle([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setAnnualCycle([]);
    }
    setIsLoading(() => false);
  };

  const handleRedirectAddAnnualCycle = () => {
    Router.push('/company-builder/add-annual-cycle');
  };

  const handleRedirectEditAnnualCycle = (params) => {
    Router.push(`/company-builder/add-annual-cycle?id=${params.data?.id}`);
  };
  const handleRedirectViewAnnualCycle = (params) => {
    Router.push(
      `/company-builder/add-annual-cycle?id=${params.data?.id}&view=true`,
    );
  };

  const handleDeactivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = <IntlMessages id='warning.deactivateAnnualCycle' />;

    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureDeactivate' /> {params.data.name} ?
      </span>
    );

    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleAlertYes = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.actionParams.data.status == 'ACTIVE' &&
      handleDeactivateAnnualCycle(tempAlertProps.actionParams);
    tempAlertProps.actionParams.data.status == 'INACTIVE' &&
      handleActivateAnnualCycle(tempAlertProps.actionParams);
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };

  const handleAlertNo = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };
  const handleDeactivateAnnualCycle = async (params) => {
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));
      const response = await jwtAxios.put(
        `${API_ROUTS.annualCycle}/${params.data.id}/INACTIVE`,
      );
      if (response.status == 200) {
        dispatch(showMessage('Annual review cycle deactivate successfully..!'));

        const roleIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );

        if (roleIndex != -1) {
          rowData[roleIndex].status = 'INACTIVE';
        }
        getAllInactiveAnnualCycle(selectedCompany.id);
        setAlignment('INACTIVE');
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleActivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = <IntlMessages id='warning.activateAnnualCycle' />;
    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureActivate' /> {params.data.name} ?
      </span>
    );
    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleActivateAnnualCycle = async (params) => {
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));
      const response = await jwtAxios.put(
        `${API_ROUTS.annualCycle}/${params.data.id}/ACTIVE`,
      );
      if (response.status == 200) {
        dispatch(showMessage('Annual review cycle activate successfully..!'));
        const roleIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );
        if (roleIndex != -1) {
          rowData[roleIndex].status = 'ACTIVE';
        }
        getAllActiveAnnualCycle(selectedCompany.id);
        setAlignment('ACTIVE');
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const [alignment, setAlignment] = React.useState('ACTIVE');

  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
  };

  const onFilterTextBoxChanged = useCallback(() => {
    const filterText = document.getElementById("filter-text-box").value;
    gridRef.current.api.setGridOption("quickFilterText", filterText);
    const totalResults = gridRef.current.api.getDisplayedRowCount();
    if (!isEmptyNullUndefined(annualCycle) && annualCycle.length > 0) {
      if (totalResults === 0 && !isEmptyNullUndefined(filterText)) {
        setOverlayMessage('No Record Found');
        gridRef.current.api.showNoRowsOverlay();
      } else if (totalResults !== 0) {
        setOverlayMessage('No Rows To Show');
        gridRef.current.api.hideOverlay();
      }
    }
  }, []);

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (!isAuthorized) {
    return <Error403 />;
  }

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
        <AppPageMeta />
        <h2 style={{marginBottom: 20}}>
          <IntlMessages id='annualCycle.Annual_Review_Cycle' />
        </h2>
        <AppCard>
          <Stack style={{width: '100%'}}>
            <Stack direction='row' sx={{mb: 2}} justifyContent={'end'}>
              <TextField
                //size='small'
                sx={{width: 200, mr: 2}}
                id='filter-text-box'
                onInput={onFilterTextBoxChanged}
                type={'search'}
                name='search'
                label={<IntlMessages id='common.button.Search' />}
                variant='outlined'
              />
              {isAllowedUser(permissionName.CREATE) && (
                <Button
                  sx={{mr: 2}}
                  variant='outlined'
                  onClick={() => handleRedirectAddAnnualCycle()}
                >
                  <IntlMessages id='annualCycle.Add_Annual_Review_Cycle' />
                </Button>
              )}
              <ToggleButtonGroup
                color='primary'
                value={alignment}
                exclusive
                onChange={handleChange}
              >
                <ToggleButton
                  value='ACTIVE'
                  onClick={() => getAllActiveAnnualCycle(selectedCompany.id)}
                >
                  <IntlMessages id='common.button.Active' />
                </ToggleButton>
                <ToggleButton
                  value='INACTIVE'
                  onClick={() => getAllInactiveAnnualCycle(selectedCompany.id)}
                >
                  <IntlMessages id='common.button.Inactive' />
                </ToggleButton>
              </ToggleButtonGroup>
            </Stack>
            {isLoading ? (
              domCreactionGridSkeletonLoader()
            ) : (
              <Stack
                className='ag-theme-alpine'
                style={{height: 525, width: '100%'}}
              >
                <AgGridReact
                  ref={gridRef}
                  rowData={annualCycle}
                  columnDefs={columnDefs}
                  defaultColDef={defaultColDef}
                  animateRows={true}
                  pagination={true}
                  paginationPageSize={10}
                  overlayLoadingTemplate={
                    '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'
                  }
                  overlayNoRowsTemplate={`<span class="ag-overlay-loading-center">${overlayMessage}</span>`}
                />
              </Stack>
            )}
          </Stack>

          {alertProps.isHideShow && (
            <AlertDialog
              alertProps={alertProps}
              handleYes={() => handleAlertYes()}
              handleNo={() => handleAlertNo()}
            />
          )}
        </AppCard>
        <AppInfoView />
      </AppAnimate>
  );
};

export default AnnualReviewCycle;
