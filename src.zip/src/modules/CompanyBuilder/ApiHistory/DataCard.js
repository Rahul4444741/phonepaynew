import { green, red } from '@mui/material/colors';
import PropTypes from 'prop-types';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import {
  Avatar,
  Box,
  Typography,
  Accordion,
  AccordionSummary,
  AccordionDetails
} from '@mui/material';

const DataCard = ({icon, title, data, length}) => {
  
  return (
    <div>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls='panel-content'
          id='panel-header'
        >
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
            }}
          >
            <Avatar
              sx={{
                p: 3,
                fontSize: {xs: 30, md: 48},
                height: {xs: 46, md: 50, xl: 60},
                width: {xs: 46, md: 50, xl: 60},
              }}
            >
              {icon}
            </Avatar>

            <Box
              sx={{
                position: 'relative',
                ml: 4,
              }}
            >
              <Box
                component='h3'
                sx={{
                  fontSize: 14,
                  color: 'text.secondary',
                  mb: 2,
                  whiteSpace: 'nowrap',
                }}
              >
                {/* {heading} */}
                {title}
                {`(${length})`}
              </Box>
            </Box>
          </Box>
        </AccordionSummary>
        <AccordionDetails>
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              ml: 20,
            }}
          >
            <Box
              component='div'
              sx={{
                display: 'flex',
                flexWrap: 'wrap', // Ensures items wrap to the next row
                gap: 2, // Adds gap between items
                fontSize: 17,
                mr: 3,
                color:
                  title === 'Mapping Not Found'
                    ? '#5c6bc0'
                    : title === 'Duplicate Records'
                    ? red[500]
                    : green[500],
              }}
            >
              {data?.map((item, index) => (
                <Box
                  key={index}
                  sx={{
                    width: '45%',
                    mb: 2,
                  }}
                >
                  <Typography component='div' variant='h4'>
                    <span style={{marginRight: '5px'}}>{`${index + 1})`}</span>
                    <span>{item}</span>
                  </Typography>
                </Box>
              ))}
            </Box>
          </Box>
        </AccordionDetails>
      </Accordion>
    </div>
  );
};

export default DataCard;
DataCard.propTypes = {
  icon: PropTypes.any,
  title: PropTypes.any,
  data: PropTypes.any,
};