import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import AllInboxIcon from '@mui/icons-material/AllInbox';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import DoneAllIcon from '@mui/icons-material/DoneAll';
import InboxIcon from '@mui/icons-material/Inbox';
import SpeakerNotesOffIcon from '@mui/icons-material/SpeakerNotesOff';
import {grey} from '@mui/material/colors';
import {AppInfoView} from '../../../@crema';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import Router, {useRouter} from 'next/router';
import {styled} from '@mui/material/styles';
import {useDispatch, useSelector} from 'react-redux';
import {fetchError} from '../../../redux/actions';
import axios from 'axios';
import {isEmptyNullUndefined} from 'shared/utils/CommonUtils';
import IntlMessages from '@crema/utility/IntlMessages';
import {footerButton} from 'shared/constants/AppConst';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {Card} from '@mui/material';
import DataCard from './DataCard';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';

const MyCardContainer = styled('div')({
  display: 'flex',
  flexDirection: 'row',
  flexWrap: 'wrap',
  justifyContent: 'center',
});

const MyCardItem = styled(Card)({
  minWidth: 275,
  margin: '10px',
});

const ViewCalibrationCycle = () => {
  const router = useRouter();
  const {id} = router.query;
  const dispatch = useDispatch();

  const [valueOfResponseRecord, setValueOfResponseRecord] = React.useState({
    blankRecords: null,
    duplicateRecords: null,
    successfullyUploaded: null,
    alreadyExistinDbRecords: null,
    mappingNotFound: null,
  });

  const [loading, setLoading] = React.useState(true);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();

  React.useEffect(() => {
    if (!isEmptyNullUndefined(id)) {
      getApiHistoryDetails(id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
    };
  }, []);

  const getApiHistoryDetails = async (id) => {
    setLoading(true);
    try {
      const response = await jwtAxios.get(
        `${API_ROUTS.apiHistory}/api-history/${id}`,
        {
          cancelToken: source.token,
        },
      );
      if (response.status == 200) {
        let tempValueOfResponseRecord = {...valueOfResponseRecord};

        tempValueOfResponseRecord.alreadyExistinDbRecords = response.data
          .filter(
            (item) =>
              !isEmptyNullUndefined(item.existingRecords) &&
              item.existingRecords,
          )
          .map((item) => item.existingRecords);

        tempValueOfResponseRecord.blankRecords = response.data
          ?.filter(
            (item) =>
              !isEmptyNullUndefined(item.blankRecords) && item.blankRecords,
          )
          .map((item) => item.blankRecords);

        tempValueOfResponseRecord.successfullyUploaded = response.data
          ?.filter(
            (item) => !isEmptyNullUndefined(item.newRecords) && item.newRecords,
          )
          .map((item) => item.newRecords);

        tempValueOfResponseRecord.mappingNotFound = response.data
          ?.filter(
            (item) =>
              !isEmptyNullUndefined(item.mappingNotFoundRecords) &&
              item.mappingNotFoundRecords,
          )
          .map((item) => item.mappingNotFoundRecords);

        setValueOfResponseRecord(() => tempValueOfResponseRecord);
        setLoading(false);
      }
    } catch (e) {
      dispatch(fetchError(e.response?.data?.detail));
      setLoading(false);
    }
  };

  console.log('valueOfResponseRecord', valueOfResponseRecord);

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: '10px'}}>API History Info</h2>

      {loading ? (
        <Stack spacing={2} sx={{mb:1}}>
          {domCreactionGridSkeletonLoader()}
        </Stack>
      ) : (
        <Stack spacing={2} sx={{mb: 10}}>
          <DataCard
            icon={<DoneAllIcon sx={{color: grey[900]}} />}
            title='Successfully Uploaded'
            data={valueOfResponseRecord.successfullyUploaded}
            length={valueOfResponseRecord.successfullyUploaded?.length || 0}
          />
          <DataCard
            icon={<SpeakerNotesOffIcon sx={{color: grey[900]}} />}
            title='Mapping Not Found'
            data={valueOfResponseRecord.mappingNotFound}
            length={valueOfResponseRecord.mappingNotFound?.length || 0}
          />
          <DataCard
            icon={<InboxIcon sx={{color: grey[900]}} />}
            title='Blank Records'
            data={valueOfResponseRecord.blankRecords}
            length={valueOfResponseRecord.blankRecords?.length || 0}
          />
          <DataCard
            icon={<AllInboxIcon sx={{color: grey[900]}} />}
            title='Already Exist in Db Records'
            data={valueOfResponseRecord.alreadyExistinDbRecords}
            length={valueOfResponseRecord.alreadyExistinDbRecords?.length || 0}
          />
          <DataCard
            icon={<ContentCopyIcon sx={{color: grey[900]}} />}
            title='Duplicate Records'
            data={valueOfResponseRecord.duplicateRecords}
            length={valueOfResponseRecord.duplicateRecords?.length || 0}
          />
        </Stack>
      )}
      <AppInfoView />

      {/* ////////add Stack for fixed////// */}
      <Stack
        sx={{
          bottom: 0,
          zIndex: 10,
          position: 'fixed',
          backdropFilter: 'blur(5px)',
          width: '100%',
          right: 0,
        }}
      >
        <Stack
          direction='row'
          justifyContent='end'
          alignItems='flex-start'
          spacing={2}
          sx={{
            pt: 5,
            ml: 3,
            //// add marging for fixed stack///
            margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
          }}
        >
          <Button
            color={footerButton.back.color}
            variant={footerButton.back.variant}
            sx={footerButton.back.sx}
            size={footerButton.back.size}
            onClick={() => Router.push('/company-builder/api-history')}
          >
            <IntlMessages id='common.button.Back' />
          </Button>
        </Stack>
      </Stack>
    </AppAnimate>
  );
};

export default ViewCalibrationCycle;
