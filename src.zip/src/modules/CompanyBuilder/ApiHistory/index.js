import * as React from 'react';
import Stack from '@mui/material/Stack';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard} from '../../../@crema';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import {AgGridReact} from 'ag-grid-react';
import {useDispatch, useSelector} from 'react-redux';
import AppInfoView from '../../../@crema/core/AppInfoView';
import {fetchStart, fetchError, showInfo} from '../../../redux/actions';
import axios from 'axios';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {Button, CircularProgress, TextField} from '@mui/material';
import {
  isEmptyNullUndefined,
  buttonStyle,
  apiCatchErrorMessage,
  isAllowedUser,
} from 'shared/utils/CommonUtils';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import IntlMessages from '@crema/utility/IntlMessages';
import Router, {useRouter} from 'next/router';
import {permissionName} from 'shared/utils/PermissionName';
import Error403 from 'modules/errorPages/Error403';
import {useCallback} from 'react';
import {footerButton} from 'shared/constants/AppConst';
import {saveAs} from 'file-saver';

const CustomHeaderEndpoint = () => 'End Point';
const CustomHeaderType = () => 'API Type';
const CustomHeaderCreatedDate = () => 'Created Date';
const CustomHeaderStatus = () => (
  <IntlMessages id='aggrid.tableHeader.Status' />
);
const CustomHeaderAction = () => (
  <IntlMessages id='aggrid.tableHeader.Action' />
);

const ApiHistory = () => {
  const dispatch = useDispatch();
  const token = localStorage.getItem('token');
  const [apiHistory, setApiHistory] = React.useState(null);
  const [overlayMessage, setOverlayMessage] = React.useState('No Rows To Show');
  const [isLoading, setIsLoading] = React.useState(true);
  const [downloadLoading, setDownloadLoading] = React.useState(false);

  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);

  React.useEffect(() => {
    if (isAllowedUser(permissionName.EMPLOYEE_RELATED_API_HISTORY)) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  const [columnDefs] = React.useState([
    {
      field: 'apiType',
      filter: true,
      headerName: 'ApiType',
      resizable: true,
      flex: 1,
      headerComponentFramework: CustomHeaderType,
      cellRenderer: function (params) {
        return (
          <Stack direction='row'>
            {params.data.apiType.charAt(0).toUpperCase() +
              params.data.apiType.slice(1)}
          </Stack>
        );
      },
    },
    {
      field: 'endpoint',
      filter: true,
      headerName: 'Endpoint',
      resizable: true,
      flex: 2,
      headerComponentFramework: CustomHeaderEndpoint,
    },
    {
      field: 'createdDate',
      filter: true,
      headerName: 'Created Date',
      resizable: true,
      flex: 2,
      headerComponentFramework: CustomHeaderCreatedDate,
      valueFormatter: (params) => {
        // Convert the date to a readable format
        const date = new Date(params.value);
        if (isNaN(date.getTime())) return ''; // Handle invalid dates
        return date.toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'long', // Use 'short' for abbreviated month names
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true, // Set to false for 24-hour format
        });
      },
    },
    {
      field: 'status',
      filter: true,
      headerName: 'Status',
      headerComponentFramework: CustomHeaderStatus,
      resizable: true,
      flex: 1,
      cellRenderer: function (params) {
        return <Stack direction='row'>{params.data.status}</Stack>;
      },
    },
    {
      headerName: 'Action',
      headerComponentFramework: CustomHeaderAction,
      resizable: true,
      flex: 1,
      cellRenderer: function (params) {
        return (
          <Stack direction='row'>
            {isAllowedUser(permissionName.READ) && (
              <Button
                onClick={() => handleRedirectViewApi(params)}
                style={buttonStyle}
              >
                <IntlMessages id='common.button.View' />
              </Button>
            )}
            {isAllowedUser(permissionName.DOWNLOAD) && (
              <Button
                disabled={downloadLoading}
                onClick={() => downloadReport(params.data.id,params.data.apiType)}
                style={buttonStyle}
              >
                {downloadLoading ? (
                  <CircularProgress
                    color='success'
                    size={25}
                    sx={{marginRight: '20px', marginBottom: '10px'}}
                  />
                ) : (
                  <IntlMessages id='common.button.Download' />
                )}
              </Button>
            )}
          </Stack>
        );
      },
    },
  ]);

  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();
  React.useEffect(() => {
    dispatch(fetchStart);
    if (
      isAuthorized &&
      selectedCompany != null &&
      selectedCompany != undefined
    ) {
      getAPIHistory(selectedCompany.id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, [isAuthorized, selectedCompany]);

  const gridRef = React.useRef();
  const defaultColDef = React.useMemo(() => ({
    sortable: true,
  }));

  const onFilterTextBoxChanged = useCallback(() => {
    const filterText = document.getElementById('filter-text-box').value;
    gridRef.current.api.setGridOption('quickFilterText', filterText);
    const totalResults = gridRef.current.api.getDisplayedRowCount();
    if (!isEmptyNullUndefined(apiHistory) && apiHistory.length > 0) {
      if (totalResults === 0 && !isEmptyNullUndefined(filterText)) {
        setOverlayMessage('No Record Found');
        gridRef.current.api.showNoRowsOverlay();
      } else if (totalResults !== 0) {
        setOverlayMessage('No Rows To Show');
        gridRef.current.api.hideOverlay();
      }
    }
  }, []);

  const handleRedirectViewApi = (params) => {
    Router.push(`/company-builder/view-api?id=${params.data?.id}`);
  };

  const getAPIHistory = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(`${API_ROUTS.apiHistory}/${companyId}`, {
        cancelToken: source.token,
      });

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no api history for selected company'));
          setApiHistory([]);
        } else {
          const reversed = res?.data?.sort(
            (a, b) => new Date(b.createdDate) - new Date(a.createdDate),
          );
          setApiHistory(reversed);
        }
        setIsLoading(() => false);
      } else {
        setApiHistory([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setApiHistory([]);
    }
    setIsLoading(() => false);
  };

  const downloadReport = async (apiHistoryId,apiType) => {
    setDownloadLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.apiHistory}/report?apiHistoryId=${apiHistoryId}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          responseType: 'arraybuffer',
        },
      );
      if (res.status == 200) {
        console.log('res?.data', res?.data);
        const blob = new Blob([res?.data], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        saveAs(blob, `${apiType}.xlsx`);
        dispatch(showMessage(`Report downloaded successfully..!`));
        setDownloadLoading(() => false);
      }
    } catch (e) {
      if (e?.response?.data?.detail) {
        dispatch(fetchError(e?.response?.data?.detail));
      } else if (e?.response?.data?.title) {
        dispatch(fetchError(e?.response?.data?.title));
      }
      setDownloadLoading(() => false);
    }
  };

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (!isAuthorized) {
    return <Error403 />;
  }

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        {/* <IntlMessages id='roles.pageHeaderName' /> */}
        API History
      </h2>
      <AppCard>
        <Stack style={{width: '100%', marginBottom: '25px'}}>
          <Stack direction='row' sx={{mb: 2}} justifyContent={'end'}>
            <TextField
              //size='small'
              sx={{width: 200, mr: 2}}
              id='filter-text-box'
              onInput={onFilterTextBoxChanged}
              type={'search'}
              name='search'
              label={<IntlMessages id='common.button.Search' />}
              variant='outlined'
            />
          </Stack>
          {isLoading ? (
            domCreactionGridSkeletonLoader()
          ) : (
            <Stack
              className='ag-theme-alpine'
              style={{height: 525, width: '100%'}}
            >
              <AgGridReact
                ref={gridRef}
                rowData={apiHistory}
                columnDefs={columnDefs}
                defaultColDef={defaultColDef}
                animateRows={true}
                pagination={true}
                paginationPageSize={10}
                overlayLoadingTemplate={
                  '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'
                }
                overlayNoRowsTemplate={`<span class="ag-overlay-loading-center">${overlayMessage}</span>`}
              />
            </Stack>
          )}
        </Stack>

        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0,
          }}
        >
          <Stack
            direction='row'
            justifyContent='end'
            alignItems='flex-start'
            spacing={2}
            sx={{
              pt: 5,
              ml: 3,
              margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
            }}
          >
            <Button
              color={footerButton.back.color}
              variant={footerButton.back.variant}
              sx={footerButton.back.sx}
              size={footerButton.back.size}
              onClick={() => Router.push('/company-builder/schedular-history')}
            >
              <IntlMessages id='common.button.Back' />
            </Button>
          </Stack>
        </Stack>
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default ApiHistory;
