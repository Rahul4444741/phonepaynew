import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import {CircularProgress, IconButton, Typography} from '@mui/material';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import Stack from '@mui/material/Stack';
import {AppCard} from '../../../@crema';
import TextField from '@mui/material/TextField';
import PropTypes from 'prop-types';
import AppInfoView from '../../../@crema/core/AppInfoView';
import {showMessage, fetchError} from '../../../redux/actions';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import {useDispatch} from 'react-redux';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {useState} from 'react';
import {RiDeleteBin4Fill, RiEdit2Fill} from 'react-icons/ri';
import IntlMessages from '@crema/utility/IntlMessages';
import {GoCloudUpload} from 'react-icons/go';
import {
  apiCatchErrorMessage,
  imageIconAcceptInputString,
  isEmptyNullUndefined,
  isDuplicate,
} from 'shared/utils/CommonUtils';

const AddnewBanner = ({
  company,
  closeBox,
  handleAddCostCenter,
  getActiveBanners,
  handleClose,
  editCostCenter,
  isEdit,
  handleUpdateCostCenter,
  costCentersData,
}) => {
  const dispatch = useDispatch();
  const [costCenter, setCostCenter] = React.useState({
    id: null,
    sequenceId: '',
    status: '',
    company: {
      id: company.id,
    },
    fileDetails: null,
    fileUploadStatus: 'NA',
  });
  const [isUploadingFile, setIsUploadingFile] = React.useState(false);
  const [selectedFile] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  React.useEffect(() => {
    if (isEdit) {
      setCostCenter(editCostCenter);
    }
  }, []);

  const [formError, setFormError] = React.useState({
    sequenceId: {isError: false, errorMessage: ''},
    file: {isError: false, errorMessage: ''},
    status: {isError: false, errorMessage: ''},
  });

  const textFieldStyled = {
    backgroundColor: 'white',
    mb: 4,
    width: {xs: '100%'},
  };
  const mandatoryFieldStyled = {
    '& .MuiOutlinedInput-root': {
      '& fieldset': {
        borderLeftColor: 'red',
        borderLeftWidth: 3,
      },
    },
  };
  const formHelperTextStyle = {
    color: '#d32f2f',
    fontSize: '0.75rem',
    margin: '-4px 14px 4px',
    textAlign: 'center',
  };
  const handleValidateCostCenter = async () => {
    let isValid = true;
    const tempError = {...formError};
    const {sequenceId, fileDetails, status, company, id} = costCenter;

    if (sequenceId == null || sequenceId == '') {
      tempError.sequenceId.isError = true;
      tempError.sequenceId.errorMessage = (
        <IntlMessages id='error.pleaseEnterSequenceID' />
      );
      isValid = false;
    }
    if (
      !isEmptyNullUndefined(sequenceId) &&
      (!isEdit
        ? isDuplicate(sequenceId, costCentersData)
        : isDuplicate(sequenceId, costCentersData, id))
    ) {
      tempError.sequenceId.isError = true;
      tempError.sequenceId.errorMessage = (
        <IntlMessages id='error.sequenceIdAlreadyExists' />
      );
      isValid = false;
    }
    if (status == null || status.trim() == '') {
      tempError.status.isError = true;
      tempError.status.errorMessage = (
        <IntlMessages id='error.pleaseSelectStatus' />
      );
      isValid = false;
    }
    if (fileDetails == null) {
      tempError.file.isError = true;
      tempError.file.errorMessage = (
        <IntlMessages id='error.pleaseSelectBannerImage' />
      );
      isValid = false;
    }
    if (isValid) {
      if (isEdit) {
        setIsLoading(true);
        const body = {
          id,
          sequenceId: sequenceId,
          status: status,
          company,
          fileDetails: {
            id: fileDetails?.id,
          },
        };

        try {
          const {data} = await jwtAxios.put(
            `${API_ROUTS.post_company_banner}${id}`,
            body,
          );

          if (data) {
            setIsLoading(false);
            dispatch(showMessage(`${selectedFile}  updated banner`));

            getActiveBanners(company.id);

            closeBox(false);
          }
        } catch (error) {
          setIsLoading(false);
          apiCatchErrorMessage(error, dispatch, fetchError);
        }
      } else {
        setIsLoading(true);
        const body = {
          sequenceId: sequenceId,
          status: status,
          company,
          fileDetails: {
            id: fileDetails?.id,
          },
        };

        try {
          const {data} = await jwtAxios.post(
            `${API_ROUTS.post_company_banner}`,
            body,
          );

          if (data) {
            setIsLoading(false);
            dispatch(showMessage(`${selectedFile}  added to banners`));

            getActiveBanners(company.id);

            closeBox(false);
          }
        } catch (error) {
          setIsLoading(false);
          apiCatchErrorMessage(error, dispatch, fetchError);
        }
      }
    } else {
      setFormError(tempError);
    }
  };

  const handleChangeCostCenterData = (event) => {
    const tempCostCenter = {...costCenter};
    const tempError = {...formError};
    tempCostCenter[event.target.name] = event.target.value;
    tempError[event.target.name].isError = false;
    tempError[event.target.name].errorMessage = '';
    setCostCenter(tempCostCenter);
    setFormError(tempError);
  };

  const handleDeleteFile = () => {
    const tempCostCenter = JSON.parse(JSON.stringify(costCenter));
    tempCostCenter.fileDetails = null;
    setCostCenter(tempCostCenter);
  };
  const handleCaptureFile = (event) => {
    const tempCostCenter = JSON.parse(JSON.stringify(costCenter));
    const file =
      event.target.files.length > 0 ? event.target.files[0] : undefined;

    if (file != undefined) {
      tempCostCenter.fileUploadStatus = 'LOADING';
      setCostCenter(tempCostCenter);
      if (!file.name.match(/\.(jpg|jpeg|png)$/)) {
        setFormError({
          ...formError,
          file: {
            isError: true,
            errorMessage: <IntlMessages id='error.selectValidImage' />,
          },
        });

        setCostCenter({...costCenter, fileDetails: {fname: file.name}});
        return;
      }

      if (file?.size > 2097152) {
        setCostCenter({...costCenter, fileDetails: {fname: file.name}});
        setFormError({
          ...formError,
          file: {
            isError: true,
            errorMessage: (
              <IntlMessages id='error.pleaseUploadFileSmallerThan2MB' />
            ),
          },
        });
        return;
      } else {
        setFormError({
          ...formError,
          file: {isError: false, errorMessage: ''},
        });
        setTimeout(() => {
          UploadFile(file);
        }, 200);
      }
    }
  };

  const UploadFile = async (file) => {
    setIsUploadingFile(() => true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.file_upload}`,
        formData,

        // {headers: {ContentType: 'multipart/form-data'}},
      );
      if (response.status == 201) {
        setCostCenter({
          ...costCenter,
          fileUploadStatus: 'LOADED',
          fileDetails: response.data,
        });
      } else {
        setCostCenter({
          ...costCenter,
          fileUploadStatus: 'NA',
        });
      }
    } catch (e) {
      setCostCenter({
        ...costCenter,
        fileUploadStatus: 'NA',
      });
      apiCatchErrorMessage(e, dispatch, fetchError);
    }
    setIsUploadingFile(() => false);
  };

  return (
    <Dialog maxWidth={'sm'} open={true}>
      <DialogContent>
        <Stack direction='row' justifyContent='center' sx={{mt: '7%'}}>
          <AppCard style={{width: '350px'}}>
            <h4 style={{display: 'flex'}}>
              {!isEdit ? (
                <IntlMessages id='bannerConfiguration.addBanner' />
              ) : (
                <IntlMessages id='bannerConfiguration.updateBanner' />
              )}
            </h4>
            <Stack sx={{mt: 2}} display='flex' justifyContent='center'>
              <TextField
                size='small'
                name='sequenceId'
                label={<IntlMessages id='aggrid.tableHeader.SequenceId' />}
                onChange={(event) => handleChangeCostCenterData(event)}
                value={costCenter?.sequenceId}
                type='number'
                error={formError.sequenceId.isError}
                helperText={formError.sequenceId.errorMessage}
                variant='outlined'
                sx={{...textFieldStyled, ...mandatoryFieldStyled}}
              />

              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id='event-type'>
                  <IntlMessages id='bannerConfiguration.status' />
                </InputLabel>
                <Select
                  size='small'
                  name='status'
                  label='Status'
                  value={costCenter?.status}
                  error={formError.status.isError}
                  helperText={formError.status.errorMessage}
                  onChange={(event) => handleChangeCostCenterData(event)}
                  variant='outlined'
                  sx={{...textFieldStyled, ...mandatoryFieldStyled}}
                >
                  <MenuItem key='Active' value='ACTIVE'>
                    <IntlMessages id='bannerConfiguration.Active' />
                  </MenuItem>
                  <MenuItem key='Inactive' value='INACTIVE'>
                    <IntlMessages id='bannerConfiguration.Inactive' />
                  </MenuItem>
                </Select>
                <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                  {formError.status.errorMessage}
                </FormHelperText>
              </FormControl>
            </Stack>
            <Stack
              direction='row'
              sx={{
                width: '100%',
                height: '100px',
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              {!costCenter?.fileDetails?.id &&
                costCenter.fileUploadStatus != 'LOADING' && (
                  <Stack
                    sx={{
                      width: '70%',
                      height: '100px',
                      border: '1px dashed #ccc2c2',
                      display: 'flex',
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      backgroundColor: '#f6f6f6',
                    }}
                  >
                    <IconButton
                      color='primary'
                      aria-label='upload banner'
                      component='label'
                      sx={{
                        width: '100%',
                        height: '100%',
                        borderRadius: '0px',
                      }}
                    >
                      <input
                        id={'inputFile_'}
                        onChange={(event) => handleCaptureFile(event)}
                        hidden
                        type='file'
                        label='File upload'
                        accept={imageIconAcceptInputString}
                        disabled={isUploadingFile}
                      />
                      <GoCloudUpload
                        style={{
                          fontSize: '4.5rem',
                          marginRight: '2rem',
                        }}
                      />
                      <IntlMessages id='bannerConfiguration.uploadBanner' />
                    </IconButton>
                  </Stack>
                )}
              <Stack
                sx={{
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  position: 'relative',
                  border: '1px solid blue',
                }}
              >
                {costCenter.fileUploadStatus == 'LOADING' && (
                  <CircularProgress size={20} />
                )}
                {costCenter?.fileDetails?.id != null &&
                  costCenter.fileUploadStatus != 'LOADING' && (
                    <Stack>
                      <img
                        src={costCenter?.fileDetails?.path}
                        alt='icon'
                        style={{width: '100%', height: '100px'}}
                      />
                      <IconButton
                        color='primary'
                        aria-label='upload document'
                        component='label'
                        style={{
                          position: 'absolute',
                          right: '-14px',
                          top: '20px',
                          fontSize: '1.25rem',
                          color: 'blue',
                          backgroundColor: '#ffffff',
                          padding: '2px',
                          width: '1.75rem',
                          height: '1.75rem',
                          borderRadius: '1rem',
                          border: '1px solid gray',
                        }}
                      >
                        <input
                          id={'inputFile_'}
                          onChange={(event) => handleCaptureFile(event)}
                          hidden
                          type='file'
                          label='File upload'
                          accept={imageIconAcceptInputString}
                          disabled={isUploadingFile}
                        />
                        <RiEdit2Fill />
                      </IconButton>

                      <RiDeleteBin4Fill
                        onClick={() => handleDeleteFile()}
                        style={{
                          position: 'absolute',
                          right: '-14px',
                          top: '52px',
                          fontSize: '1.25rem',
                          color: 'blue',
                          backgroundColor: '#ffffff',
                          padding: '2px',
                          width: '1.75rem',
                          height: '1.75rem',
                          borderRadius: '1rem',
                          border: '1px solid gray',
                          cursor: 'pointer',
                        }}
                      />
                    </Stack>
                  )}
              </Stack>
            </Stack>
            <Typography style={formHelperTextStyle}>
              <div style={{marginTop: '1rem'}}>
                {formError?.file?.errorMessage}
              </div>
            </Typography>
            <br />
          </AppCard>
        </Stack>
      </DialogContent>

      <DialogActions>
        <Button
          disabled={isUploadingFile || isLoading}
          onClick={() => handleValidateCostCenter()}
        >
          <IntlMessages id='common.button.Submit' />
        </Button>
        <Button disabled={isLoading} onClick={() => handleClose()}>
          <IntlMessages id='common.button.Close' />
        </Button>
      </DialogActions>
      <AppInfoView />
    </Dialog>
  );
};

export default AddnewBanner;

AddnewBanner.propTypes = {
  company: PropTypes.object,
  handleAddCostCenter: PropTypes.func,
  handleClose: PropTypes.func,
  handleUpdateCostCenter: PropTypes.func,
  isEdit: PropTypes.bool,
  getActiveBanners: PropTypes.func,
  closeBox: PropTypes.func,
  editCostCenter: PropTypes.object,
  costCentersData: PropTypes.array,
};
