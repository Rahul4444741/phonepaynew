import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard} from '../../../@crema';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import {AgGridReact} from 'ag-grid-react';
import {useDispatch, useSelector} from 'react-redux';
import AppInfoView from '../../../@crema/core/AppInfoView';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import AddnewBanner from './Addnewbanner';
import {
  fetchStart,
  showMessage,
  fetchError,
  showInfo,
} from '../../../redux/actions';
import axios from 'axios';
import AlertDialog from '../../Common/AlertDialog';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {TextField} from '@mui/material';
import IntlMessages from '@crema/utility/IntlMessages';
import {apiCatchErrorMessage, buttonStyle, isEmptyNullUndefined} from 'shared/utils/CommonUtils';
import { useCallback } from 'react';

const BannerConfiguration = () => {
  const dispatch = useDispatch();
  const [costCentersData, setCostCentersData] = React.useState([]);
  const [isAddCostCenterOpen, setIsAddCostCenterOpen] = React.useState(false);
  const [isEdit, setIsEdit] = React.useState(false);
  const [editCostCenter, setEditCostCenter] = React.useState(undefined);
  const [alertProps, setAlertProps] = React.useState({
    isHideShow: false,
    message: '',
    title: '',
    alertType: '',
    actionParams: null,
  });

  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();
  React.useEffect(() => {
    dispatch(fetchStart);
    if (selectedCompany != null && selectedCompany != undefined) {
      getActiveBanners(selectedCompany.id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, [selectedCompany]);

  const gridRef = React.useRef();
  const defaultColDef = React.useMemo(() => ({
    sortable: true,
  }));

  const CustomHeaderSequenceId = () => (
    <IntlMessages id='aggrid.tableHeader.SequenceId' />
  );
  const CustomHeaderFileName = () => (
    <IntlMessages id='aggrid.tableHeader.FileName' />
  );
  const CustomHeaderStatus = () => (
    <IntlMessages id='aggrid.tableHeader.Status' />
  );
  const CustomHeaderAction = () => (
    <IntlMessages id='aggrid.tableHeader.Action' />
  );

  const [columnDefs] = React.useState([
    {
      field: 'sequenceId',
      filter: true,
      headerName: 'Sequence Id',
      headerComponentFramework: CustomHeaderSequenceId,
      minWidth: 250,
    },
    {
      field: 'fileDetails.fname',
      filter: true,
      headerName: 'File name',
      headerComponentFramework: CustomHeaderFileName,
      minWidth: 250,
    },
    {
      field: 'status',
      filter: true,
      headerName: 'Status',
      headerComponentFramework: CustomHeaderStatus,
      minWidth: 100,
      cellRenderer: function (params) {
        return (
          <Stack direction='row'>
            {params.data.status == 'ACTIVE' ? (
              <div style={{color: '#11C15B'}}>{params.data.status}</div>
            ) : (
              <div style={{color: '#D32F2F'}}>{params.data.status}</div>
            )}
          </Stack>
        );
      },
    },
    {
      headerName: 'Action',
      headerComponentFramework: CustomHeaderAction,
      minWidth: 250,
      cellRenderer: function (params) {
        return (
          <Stack direction='row'>
            <div
              style={buttonStyle}
              onClick={() => chipViewPageHandleClick(params.data.fileDetails)}
            >
              <IntlMessages id='common.button.View' />
            </div>
            <div
              style={buttonStyle}
              onClick={() => handleOpenEditModel(params)}
            >
              <IntlMessages id='common.button.Edit' />
            </div>

            {params.data.status.toLowerCase() === 'active' && (
              <div
                style={buttonStyle}
                onClick={() => handleDeactivateConfirmation(params)}
              >
                <IntlMessages id='common.button.Deactivate' />
              </div>
            )}
            {params.data.status.toLowerCase() != 'active' && (
              <div
                style={buttonStyle}
                onClick={() => handleActivateConfirmation(params)}
              >
                <IntlMessages id='common.button.Activate' />
              </div>
            )}
          </Stack>
        );
      },
    },
  ]);

  const chipViewPageHandleClick = (row) => {
    if (row?.path) {
      window.open(`${row?.path}`);
    } else {
      dispatch(fetchError('Something went wrong!'));
    }
  };
  const getActiveBanners = async (companyId) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.get_company_banners}${companyId}?status=ACTIVE`,
        {headers: {}},
        {
          cancelToken: source.token,
        },
      );

      if (res.status == 200) {
        setCostCentersData(res.data);

        if (res.data.length == 0) {
          dispatch(
            showInfo('You have no active banners for  selected company'),
          );
          setCostCentersData([]);
        } else {
          setCostCentersData(res.data);
        }
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }

      setCostCentersData([]);
    }
  };

  const getAllInactiveCostCenters = async (companyId) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.get_company_banners}${companyId}?status=INACTIVE`,
        {
          cancelToken: source2.token,
        },
      );

      if (res.status == 200) {
        setCostCentersData(res.data);

        if (res.data.length == 0) {
          dispatch(
            showInfo('You have no Inactive banners for selected company'),
          );
          setCostCentersData([]);
        } else {
          setCostCentersData(res.data);
        }
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setCostCentersData([]);
    }
  };
  const handleOpenEditModel = (params) => {
    let rowData = [];
    params.api.forEachNode((node) => rowData.push(node.data));
    const costCenterIndex = rowData.findIndex(
      (item) => item.id == params.data.id,
    );
    if (costCenterIndex != -1) setEditCostCenter(rowData[costCenterIndex]);
    setIsEdit(true);
    setIsAddCostCenterOpen(true);
  };

  const handleDeactivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = (
      <IntlMessages id='bannerConfiguration.deactivateBanner' />
    );
    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureDeactivate' />{' '}
        {params.data.fileDetails.fname}?
      </span>
    );
    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleAlertYes = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.actionParams.data.status == 'ACTIVE' &&
      handelDeactivateBanner(tempAlertProps.actionParams);
    tempAlertProps.actionParams.data.status == 'INACTIVE' &&
      handelActivateBanner(tempAlertProps.actionParams);
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };

  const handleAlertNo = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };
  const handelDeactivateBanner = async (params) => {
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));
      const response = await jwtAxios.put(
        `${API_ROUTS.post_company_banner}inactivate/${params.data.id}`,
      );
      if (response.status == 200) {
        dispatch(
          showMessage(
            params.data.fileDetails.fname + '   deactivated successfully..!',
          ),
        );
        const costCenterIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );
        if (costCenterIndex != -1) {
          rowData[costCenterIndex].status = 'INACTIVE';
        }
        getAllInactiveCostCenters(selectedCompany.id);
        setAlignment('INACTIVE');
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleActivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = (
      <IntlMessages id='bannerConfiguration.activateBanner' />
    );
    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureActivate' />{' '}
        {params.data.fileDetails.fname}?
      </span>
    );
    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };

  const handelActivateBanner = async (params) => {
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));
      const response = await jwtAxios.put(
        `${API_ROUTS.post_company_banner}activate/${params.data.id}`,
      );
      if (response.status == 200) {
        dispatch(
          showMessage(
            params.data.fileDetails.fname + ' Banner activated successfully..!',
          ),
        );
        const costCenterIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );

        if (costCenterIndex != -1) {
          rowData[costCenterIndex].status = 'ACTIVE';
        }
        getActiveBanners(selectedCompany.id);
        setAlignment('ACTIVE');
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };
  const handleUpdateCostCenter = (costCenter) => {
    dispatch(
      showMessage(
        costCenter.costCenterId + ' Cost Center updated successfully..!',
      ),
    );
    const tempCostCenters = [...costCentersData];
    const costCenterIndex = tempCostCenters.findIndex(
      (item) => item.id == costCenter.id,
    );
    if (costCenterIndex != -1 && tempCostCenters.status == 'ACTIVE') {
      tempCostCenters[costCenterIndex] = costCenter;
    }
    getActiveBanners(selectedCompany.id);
    setAlignment('ACTIVE');
    setEditCostCenter(null);
    setIsEdit(false);
    setIsAddCostCenterOpen(false);
  };

  const handleAddCostCenterToList = (costCenter) => {
    dispatch(
      showMessage(
        costCenter.costCenterId + ' Cost Center added successfully..!',
      ),
    );
    const tempCostCenters = [...costCentersData];
    tempCostCenters.push(costCenter);
    setCostCentersData(tempCostCenters);
    setIsAddCostCenterOpen(false);
  };
  const handleCloseAddCostCenter = () => {
    setIsAddCostCenterOpen(false);
  };
  const handleOpenAddCostCenter = () => {
    setIsAddCostCenterOpen(true);
    setIsEdit(false);
  };

  const [alignment, setAlignment] = React.useState('ACTIVE');

  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
  };

  const onFilterTextBoxChanged = useCallback(() => {
    const filterText = document.getElementById("filter-text-box").value;
    gridRef.current.api.setGridOption("quickFilterText", filterText);
    const totalResults = gridRef.current.api.getDisplayedRowCount();
    if (!isEmptyNullUndefined(costCentersData) && costCentersData.length > 0) {
      if (totalResults === 0 && !isEmptyNullUndefined(filterText)) {
        setOverlayMessage('No Record Found');
        gridRef.current.api.showNoRowsOverlay();
      } else if (totalResults !== 0) {
        setOverlayMessage('No Rows To Show');
        gridRef.current.api.hideOverlay();
      }
    }
  }, []);

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
        <AppPageMeta />
        <h2 style={{marginBottom: 20}}>
          {' '}
          <IntlMessages id='bannerConfiguration.pageHeaderName' />
        </h2>
        <AppCard>
          <Stack style={{width: '100%'}}>
            <Stack direction='row' sx={{mb: 2}} justifyContent={'end'}>
              <TextField
                //size='small'
                sx={{width: 200, mr: 2}}
                id="filter-text-box"
                onInput={onFilterTextBoxChanged}
                type={'search'}
                name='search'
                label={<IntlMessages id='common.button.Search' />}
                variant='outlined'
              />
              <Button
                sx={{mr: 2}}
                variant='outlined'
                onClick={() => handleOpenAddCostCenter()}
              >
                <IntlMessages id='bannerConfiguration.addBanner' />
              </Button>
              <ToggleButtonGroup
                color='primary'
                value={alignment}
                exclusive
                onChange={handleChange}
              >
                <ToggleButton
                  value='ACTIVE'
                  onClick={() => getActiveBanners(selectedCompany.id)}
                >
                  <IntlMessages id='common.button.Active' />
                </ToggleButton>
                <ToggleButton
                  value='INACTIVE'
                  onClick={() => getAllInactiveCostCenters(selectedCompany.id)}
                >
                  <IntlMessages id='common.button.Inactive' />
                </ToggleButton>
              </ToggleButtonGroup>
            </Stack>
            <Stack
              className='ag-theme-alpine'
              style={{height: 525, width: '100%'}}
            >
              <AgGridReact
                ref={gridRef}
                rowData={costCentersData}
                columnDefs={columnDefs}
                defaultColDef={defaultColDef}
                animateRows={true}
                pagination={true}
                paginationPageSize={10}
              />
            </Stack>
          </Stack>
          {isAddCostCenterOpen && (
            <AddnewBanner
              company={selectedCompany}
              isEdit={isEdit}
              editCostCenter={editCostCenter}
              closeBox={setIsAddCostCenterOpen}
              getActiveBanners={getActiveBanners}
              handleUpdateCostCenter={(costCenter) =>
                handleUpdateCostCenter(costCenter)
              }
              handleAddCostCenter={(newCostCenter) =>
                handleAddCostCenterToList(newCostCenter)
              }
              costCentersData={costCentersData}
              handleClose={() => handleCloseAddCostCenter()}
            />
          )}
          {alertProps.isHideShow && (
            <AlertDialog
              alertProps={alertProps}
              handleYes={() => handleAlertYes()}
              handleNo={() => handleAlertNo()}
            />
          )}
        </AppCard>
        <AppInfoView />
      </AppAnimate>
  );
};

export default BannerConfiguration;
