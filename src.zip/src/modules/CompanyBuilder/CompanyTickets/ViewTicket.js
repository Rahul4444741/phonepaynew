import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard, AppInfoView} from '../../../@crema';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import TextField from '@mui/material/TextField';
import AccountCircleSharpIcon from '@mui/icons-material/AccountCircleSharp';
import EditSharpIcon from '@mui/icons-material/EditSharp';
import Router, {useRouter} from 'next/router';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import AlertDialog from '../../Common/AlertDialog';
import moment from 'moment';
import {Grid, Paper} from '@mui/material';
import {apiCatchErrorMessage, getCompanyDateFormat} from 'shared/utils/CommonUtils';
import {useDispatch, useSelector} from 'react-redux';
import Box from '@mui/material/Box';
import {
  fetchStart,
  fetchSuccess,
  showInfo,
  showMessage,
  fetchError,
} from '../../../redux/actions';
import axios from 'axios';
import Typography from '@mui/material/Typography';

import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {Chip} from '@mui/material';
import {useState} from 'react';
import {useEffect} from 'react';
import {footerButton} from 'shared/constants/AppConst';
import IntlMessages from '@crema/utility/IntlMessages';

const ViewTicket = () => {
  const [caseData, setCaseData] = React.useState(null);
  const [displayComment, setComment] = useState(false);
  const [validateEditId, setValidateEditId] = useState('');
  const router = useRouter();
  const [alertProps, setAlertProps] = useState({});
  //
  const [selectedFile, setSelectedFile] = useState('Upload file');
  const [preview, setPreview] = useState('');
  const [previewError, setPreviewError] = useState('');
  const [comment, setCommentmsg] = useState('');
  //
  const [editComment, setEditComment] = useState({status: false});
  const [fileDataApi, setFileDataApi] = useState({});
  const dispatch = useDispatch();
  const {id} = router.query;
  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  React.useEffect(() => {
    getAllCaseDetails(id);
    return () => {
      source.cancel('Aborting all previous operations.');
    };
  }, [router]);
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const getAllCaseDetails = async (caseID) => {
    try {
      const res = await jwtAxios.get(`${API_ROUTS.case}/${caseID}`, caseData, {
        cancelToken: source.token,
      });
      if (res.status == 200) {
        setCaseData(res.data);
        if (res.data.fileUrl.fname) {
          setChecked(() => true);
        }
      } else {
        
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
    }
  };

  useEffect(() => {
    let {id} = JSON.parse(localStorage.getItem('userDetails'));

    setValidateEditId(id);
  }, []);
  const chipViewPageHandleClick = (filePath) => {
    if (filePath !== '') {
      window.open(`${filePath}`);
      return;
    }

    dispatch(fetchError('Something went wrong!'));
  };

  const handleRedirectEditCase = (id) => {
    Router.push(`/company-builder/add-ticket?id=${id}`);
  };

  const addComment = () => {
    setComment(!displayComment);
  };

  const submitComment = async (event) => {
    event.preventDefault();
    const employeeDetails = JSON.parse(localStorage.getItem('userDetails'));

    if (comment !== '') {
      const ApiBody = {
        message: comment,
        employee: {
          id: employeeDetails?.id,
        },
        fileUrl: fileDataApi?.id
          ? {
              id: fileDataApi?.id,
            }
          : null,
        caseId: {
          id: id,
        },
        dateTime: new Date().toISOString(),
      };

      try {
        const response = await jwtAxios.post(
          `${API_ROUTS.post_comment}`,
          ApiBody,
        );
        if (response.status == 201) {
          dispatch(showInfo('Comment added succesfully'));
          setCommentmsg('');
          setSelectedFile('Upload file');
          setPreview('');
          setFileDataApi({});

          setTimeout(() => {
            getAllCaseDetails(id);
          }, 2000);
        }
      } catch (error) {
        dispatch(showMessage('comment not added try after sometime'));
      }
    } else {
      dispatch(showInfo('Please add comment'));
    }
  };

  const EditComments = (commentValues) => {
    setEditComment({status: true, values: {...commentValues}});
  };

  const SubmitEditFucntion = async () => {
    const ApiBody = {
      message: editComment?.values?.message,
      employee: {
        id: editComment?.values?.employee?.id,
      },
      fileUrl: editComment?.values?.fileUrl
        ? {
            id: editComment?.values?.fileUrl?.id,
          }
        : null,
      caseId: {
        id: id,
      },
      dateTime: new Date().toISOString(),
    };

    try {
      const res = await jwtAxios.put(
        `${API_ROUTS.post_comment}${editComment?.values?.id}`,
        ApiBody,
      );

      if (res.status == 200 || res.status == 201) {
        dispatch(showInfo('Ticket updated succesfully'));

        setTimeout(() => {
          getAllCaseDetails(id);
        }, 2000);

        setEditComment({status: false});
      }
    } catch (error) {
      dispatch(showInfo(JSON.stringify(error)));
    }
  };
  const handleCaptureFile = (event, eventType) => {
    const file =
      event.target.files.length > 0 ? event.target.files[0] : undefined;

    if (file) {
      if (file.size > 2097152) {
        if (eventType === 'editComment') {
          setEditComment({
            ...editComment,
            values: {
              ...editComment?.values,
              fileUrl: {...editComment?.values.fileUrl, fname: file.name},
            },
            fileError: 'Please upload a file smaller than 2 MB',
          });
        } else {
          setSelectedFile(file.name);
          setPreviewError('Please upload a file smaller than 2 MB');
          setPreview('');
        }
        return;
      } else {
        if (file.name.match(/\.(jpg|jpeg|png)$/)) {
          if (eventType === 'editComment') {
            setEditComment({
              ...editComment,
              values: {
                ...editComment?.values,
                fileUrl: {...editComment?.values.fileUrl, fname: file.name},
              },
              fileError: '',
              preview: URL.createObjectURL(file),
            });
          } else {
            setSelectedFile(file.name);
            setPreview(URL.createObjectURL(file));
            setPreviewError('');
          }

          setTimeout(() => {
            UploadFile(file);
          }, 200);
        } else {
          eventType === 'editComment'
            ? setEditComment({
                ...editComment,
                values: {
                  ...editComment?.values,
                  fileUrl: {
                    ...editComment?.values.fileUrl,
                    fileError: '',
                    fname: file.name,
                  },
                },
              })
            : setSelectedFile(file.name);
          setPreview('');
          setPreviewError('');
          setTimeout(() => {
            UploadFile(file);
          }, 200);
        }

        // setSelectedFile(file.name)
      }
    }
  };

  const UploadFile = async (file) => {
    const formData = new FormData();
    formData.append('file', file);
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.file_upload}`,
        formData,

        // {headers: {ContentType: 'multipart/form-data'}},
      );
      if (response.status == 201) {
        if (editComment?.status == true) {
          setEditComment({
            ...editComment,
            values: {...editComment?.values, fileUrl: response.data},
            fileError: '',
          });
        } else {
          setFileDataApi(response.data);
        }
      } else {
      }
    } catch (e) {
      dispatch(fetchError(e.message));
    }
  };

  //
  const handelCloseCase = () => {
    let tempProps = {
      isHideShow: true,
      alertType: 'Confirmation',
      title: <IntlMessages id='ticket.closeTicket' />,
      message: <IntlMessages id='ticket.areYouSureCloseTicket' />,
    };

    setAlertProps(tempProps);
  };
  const closeCases = async () => {
    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.case}/${id}?action=close`,
      );
      if (response.status == 200) {
        dispatch(
          showMessage(response.data.title + ' Ticket closed successfully..!'),
        );

        Router.replace('/company-builder/company-tickets');
      } else {
        
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  //
  const handelNo = () => {
    let tempProps = {
      isHideShow: false,
      alertType: '',
      title: '',
      message: '',
    };

    setAlertProps(tempProps);
  };

  return (
    <>
      <AppAnimate animation='transition.slideUpIn' delay={500}>
        <AppPageMeta />
        <h2 style={{marginBottom: 2}}>
          <IntlMessages id='ticket.ticketDetails' />
        </h2>
        {caseData?.status.toLowerCase() == 'active' && (
          <Stack
            direction='row'
            sx={{my: 2}}
            justifyContent={'end'}
            spacing={2}
          >
            <Button
              name='close'
              variant='contained'
              color='warning'
              onClick={() => handelCloseCase()}
            >
              <IntlMessages id='common.button.Close' />
            </Button>
            <Button
              name='edit'
              variant='contained'
              onClick={() => handleRedirectEditCase(id)}
            >
              <IntlMessages id='common.button.Edit' />
            </Button>
          </Stack>
        )}

        <AppCard component={Box} style={{borderRadius: '3px'}}>
          <Stack
            direction='row'
            sx={{mt: 2}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <div>
                <b>
                  <IntlMessages id='ticket.title' /> :{' '}
                </b>
                <span>{caseData?.title}</span>
              </div>
            </Stack>
            <Stack sx={{width: '50%'}}>
              <div>
                <b style={{marginRight: '5px'}}>
                  <IntlMessages id='bannerConfiguration.status' /> :
                </b>
                <span
                  style={
                    caseData?.status.toLowerCase() == 'active'
                      ? {color: 'green ', fontWeight: '500'}
                      : {color: 'orange', fontWeight: '500'}
                  }
                >
                  {' '}
                  {caseData?.status}
                </span>
              </div>
            </Stack>
          </Stack>
          <Stack
            direction='row'
            sx={{mt: 2}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <div>
                <b>
                  <IntlMessages id='ticket.message' /> :
                </b>
                <span style={{marginLeft: 9}}>{caseData?.message}</span>
              </div>
            </Stack>
            <Stack sx={{width: '50%'}}>
              <div>
                <b>
                  <IntlMessages id='case.view.comments' /> :
                </b>
                <span style={{marginLeft: 9}}>{caseData?.comments.length}</span>
              </div>
            </Stack>
          </Stack>
          <Stack
            direction='row'
            sx={{my: 2}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <div>
                <b>
                  <IntlMessages id='case.view.closedDate' /> :{' '}
                </b>
                <span style={{marginLeft: 18}}>
                  {caseData?.closedDate == null
                    ? 'Null'
                    : moment(caseData?.closedDate).format(
                        getCompanyDateFormat(selectedCompany),
                      )}
                </span>
              </div>
            </Stack>
          </Stack>

          <Stack direction='row' sx={{width: '50%'}}>
            <h4>
              <IntlMessages id='case.view.uploadedFile' /> :
            </h4>
            <div>
              <span style={{marginLeft: 40}}>
                {caseData?.fileUrl?.fname && (
                  <Chip
                    sx={{
                      maxWidth: 150,
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                    }}
                    label={caseData?.fileUrl?.fname}
                    color='success'
                    size='small'
                    onClick={() =>
                      chipViewPageHandleClick(caseData?.fileUrl?.path)
                    }
                  />
                )}
              </span>
            </div>
          </Stack>
        </AppCard>

        <Stack direction='row' sx={{m: 2}} justifyContent={'end'} spacing={2}>
          <Button name='comment' variant='contained' onClick={addComment}>
            <IntlMessages id='case.view.addComment' />
          </Button>
        </Stack>
        {displayComment && (
          <Box>
            <h2 style={{margin: 2}}>
              <IntlMessages id='case.view.addComment' />
            </h2>
            <AppCard>
              <Box component='form' onSubmit={submitComment}>
                <Stack
                  direction='row'
                  alignItems='flex-start'
                  sx={{m: 2, mr: 4}}
                  spacing={2}
                >
                  <TextField
                    id='outlined-multiline-static'
                    label={
                      <IntlMessages id='case.view.addComment.writeComment' />
                    }
                    multiline
                    value={comment}
                    onChange={(e) => setCommentmsg(e.target.value)}
                    minRows={5}
                    sx={{width: '50%'}}
                    variant='outlined'
                  />
                  <Box>
                    <Stack
                      direction='row'
                      justifyContent='space-between'
                      sx={{
                        border: '1px solid gainsboro',
                        p: 2,
                        borderRadius: 2,
                        width: 300,
                      }}
                      spacing={2}
                    >
                      <Typography>{selectedFile}</Typography>

                      <label htmlFor='file'>
                        <UploadFileIcon />
                      </label>
                      <input
                        onChange={(event) => handleCaptureFile(event, 'new')}
                        id='file'
                        type='file'
                        hidden
                      />
                    </Stack>
                    <Stack direction='row' justifyContent='space-between'>
                      <Typography variant='h4' sx={{color: 'red'}}>
                        {previewError}
                      </Typography>

                      {preview !== '' && (
                        <img
                          src={preview}
                          height='100'
                          width='200px'
                          alt='preview'
                          style={{
                            width: '100px',
                            height: 'auto',
                            margin: '1rem 0',
                          }}
                        />
                      )}
                    </Stack>
                  </Box>
                </Stack>

                <Stack
                  direction='row'
                  justifyContent='end'
                  alignItems='flex-start'
                  sx={{m: 2, mr: 4}}
                  spacing={2}
                >
                  <Button
                    disabled={previewError !== ''}
                    variant='contained'
                    type='submit'
                  >
                    <IntlMessages id='common.button.Submit' />
                  </Button>
                </Stack>
              </Box>
            </AppCard>
          </Box>
        )}

        {caseData?.comments.length > 0 && (
          <div className='App'>
            <h2>
              <IntlMessages id='case.view.comments' />
            </h2>
            {caseData?.comments.map((comments, index) => {
              let {
                employee: {firstName, lastName},
                message,
                id,
                fileUrl,
                createdAt,
              } = comments;
              return (
                <Paper key={id} style={{padding: '40px 20px', marginTop: 10}}>
                  <Grid
                    direction={'column'}
                    component={Box}
                    container
                    wrap='nowrap'
                  >
                    <Grid container direction={'row'}>
                      <AccountCircleSharpIcon sx={{mr: 2}} />
                      <Typography
                        xs={3}
                        variant='subtitle2'
                        width={300}
                        style={{
                          margin: 0,
                          textAlign: 'left',
                          textTransform: 'capitalize',
                        }}
                      >{`${firstName} ${lastName}`}</Typography>
                      <Stack
                        flex={1}
                        direction='row'
                        component={Box}
                        justifyContent='flex-end'
                      >
                        <Box>
                          {editComment.status == false &&
                            validateEditId == comments?.employee?.id && (
                              <Button
                                onClick={() => EditComments(comments)}
                                size='small'
                                endIcon={<EditSharpIcon />}
                              >
                                {/* Edit */}
                                <IntlMessages id='common.button.Edit' />
                              </Button>
                            )}
                        </Box>
                      </Stack>
                    </Grid>
                    <Grid justifyContent='left' item xs={12}>
                      {editComment.status == true &&
                      editComment.values.id == id ? (
                        <TextField
                          id='outlined-multiline-static'
                          multiline
                          value={editComment?.values?.message}
                          onChange={(e) =>
                            setEditComment({
                              ...editComment,
                              values: {
                                ...editComment?.values,
                                message: e.target.value,
                              },
                            })
                          }
                          minRows={5}
                          sx={{width: '100%'}}
                          variant='outlined'
                        />
                      ) : (
                        <Typography gutterBottom style={{textAlign: 'left'}}>
                          {message}
                        </Typography>
                      )}
                    </Grid>
                  </Grid>
                  <Grid my={2} component={Box} xs={12} item>
                    {editComment.status == true &&
                    editComment.values.id == id ? (
                      <Box>
                        <Typography variant='h5'>
                          <IntlMessages id='case.view.uploadedFile' />
                        </Typography>
                        <Stack
                          alignItems={'flex-start'}
                          direction='row'
                          justifyContent='space-between'
                        >
                          <Stack direction='column'>
                            <Box
                              width='100%'
                              border={1}
                              sx={{
                                ml: 0,
                                p: 2,
                                borderRadius: 2,
                                display: 'flex',
                                justifyContent: 'space-between',
                              }}
                              spacing={2}
                            >
                              <Typography>
                                {editComment?.values?.fileUrl?.fname ?? (
                                  <IntlMessages id='case.addCase.uploadFile' />
                                )}
                              </Typography>

                              <label htmlFor='editfile'>
                                <UploadFileIcon />
                              </label>
                              <input
                                onChange={(event) =>
                                  handleCaptureFile(event, 'editComment')
                                }
                                id='editfile'
                                type='file'
                                hidden
                              />
                            </Box>
                            <Typography variant='h4' sx={{color: 'red'}}>
                              {editComment?.fileError}
                            </Typography>
                          </Stack>

                          <Stack
                            width='50%'
                            component={Box}
                            direction='row'
                            justifyContent='space-between'
                          >
                            {editComment?.values?.fileUrl?.path &&
                              editComment?.values?.fileUrl?.path !== '' && (
                                <img
                                  src={editComment?.values?.fileUrl?.path}
                                  alt='preview'
                                  style={{
                                    width: '300px',
                                    height: 'auto',
                                    margin: '1rem 0',
                                  }}
                                />
                              )}
                          </Stack>
                        </Stack>
                      </Box>
                    ) : (
                      fileUrl &&
                      fileUrl?.fname && (
                        <Stack direction='row' alignItems='center' spacing={1}>
                          File uploaded :{' '}
                          <Chip
                            onClick={() =>
                              chipViewPageHandleClick(fileUrl?.path)
                            }
                            color='primary'
                            sx={{mx: 2}}
                            label={fileUrl?.fname}
                          />
                        </Stack>
                      )
                    )}
                  </Grid>
                  {editComment.status == true && editComment.values.id == id && (
                    <Box>
                      <Button onClick={SubmitEditFucntion} size='small'>
                        <IntlMessages id='common.button.Update' />
                      </Button>
                      <Button
                        onClick={() => setEditComment({status: false})}
                        size='small'
                        color='error'
                      >
                        <IntlMessages id='common.button.Cancel' />
                      </Button>
                    </Box>
                  )}
                  <p>
                    <IntlMessages id='case.view.addComment.commentedOn' />:{' '}
                    {moment(createdAt).format(
                      `${getCompanyDateFormat(selectedCompany)} hh:mm a`,
                    )}
                  </p>
                </Paper>
              );
            })}
          </div>
        )}
        {alertProps?.isHideShow && (
          <AlertDialog
            alertProps={alertProps}
            handleYes={() => closeCases()}
            handleNo={() => handelNo()}
          />
        )}
        <Stack sx={{mb: 15}} />
        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0,
          }}
        >
          <Stack
            direction='row'
            justifyContent='end'
            alignItems='center'
            spacing={2}
            sx={{
              pt: 5,
              ml: 3,
              margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
            }}
          >
            <Button
              color={footerButton.back.color}
              variant={footerButton.back.variant}
              sx={footerButton.back.sx}
              size={footerButton.back.size}
              onClick={() => Router.push('/company-builder/company-tickets')}
            >
              <IntlMessages id='common.button.Back' />
            </Button>
          </Stack>
        </Stack>
        <AppInfoView />
      </AppAnimate>
    </>
  );
};

export default ViewTicket;
