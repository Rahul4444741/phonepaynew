import * as React from 'react';
import Stack from '@mui/material/Stack';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard, AppInfoView} from '../../../@crema';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import Router, {useRouter} from 'next/router';
import {useDispatch, useSelector} from 'react-redux';
import {
  fetchStart,
  fetchSuccess,
  showMessage,
  showInfo,
  fetchError,
} from '../../../redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {Button, ToggleButton, ToggleButtonGroup} from '@mui/material';
import {AgGridReact} from 'ag-grid-react';
import axios from 'axios';
import {apiCatchErrorMessage, buttonStyle} from 'shared/utils/CommonUtils';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import IntlMessages from '@crema/utility/IntlMessages';

const CompanyTickets = () => {
  const dispatch = useDispatch();
  const gridRef = React.useRef();
  const [isLoading, setIsLoading] = React.useState(true);
  const defaultColDef = React.useMemo(() => ({
    sortable: true,
    flex: 1,
  }));
  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  function fullNameGetter(params) {
    return params.data.raisedBy.firstName + ' ' + params.data.raisedBy.lastName;
  }
  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();
  React.useEffect(() => {
    dispatch(fetchStart);
    if (selectedCompany != null && selectedCompany != undefined) {
      getAllActiveCase(selectedCompany.id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, [selectedCompany]);

  const CustomHeaderSummary = () => (
    <IntlMessages id='aggrid.tableHeader.Summary' />
  );
  const CustomHeaderStatus = () => (
    <IntlMessages id='aggrid.tableHeader.Status' />
  );
  const CustomHeaderMessage = () => (
    <IntlMessages id='aggrid.tableHeader.Message' />
  );
  const CustomHeaderRaisedby = () => (
    <IntlMessages id='aggrid.tableHeader.Raisedby' />
  );
  const CustomHeaderAction = () => (
    <IntlMessages id='aggrid.tableHeader.Action' />
  );
  const [columnDefs, setColumnDefs] = React.useState([
    {
      field: 'title',
      filter: true,
      headerName: 'Summary',
      headerComponentFramework: CustomHeaderSummary,
      minWidth: 100,
    },
    {
      field: 'status',
      filter: true,
      headerName: 'Status',
      headerComponentFramework: CustomHeaderStatus,
      minWidth: 100,
    },
    {
      field: 'message',
      filter: true,
      headerName: 'Message',
      headerComponentFramework: CustomHeaderMessage,
      minWidth: 100,
    },
    {
      field: 'raisedBy.firstName&raisedBy.lastName',
      filter: true,
      headerName: 'Raised by',
      headerComponentFramework: CustomHeaderRaisedby,
      minWidth: 100,
      valueGetter: function sumField(params) {
        return (
          params.data.raisedBy.firstName + ' ' + params.data.raisedBy.lastName
        );
      },
    },
    {
      headerName: 'Action',
      headerComponentFramework: CustomHeaderAction,
      minWidth: 100,
      cellRenderer: function (params) {
        return (
          <Stack direction='row'>
            <div
              style={buttonStyle}
              name='view'
              onClick={() => handleRedirectViewCase(params)}
            >
              <IntlMessages id='common.button.View' />
            </div>
            {params.data.status.toLowerCase() == 'active' && (
              <div
                style={buttonStyle}
                name='edit'
                onClick={() => handleRedirectEditCase(params)}
              >
                <IntlMessages id='common.button.Edit' />
              </div>
            )}
          </Stack>
        );
      },
    },
  ]);
  const [caseData, setCaseData] = React.useState([]);
  const [alignment, setAlignment] = React.useState('ACTIVE');

  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
  };
  const handleRedirectEditCase = (params) => {
    Router.push('/company-builder/add-ticket?id=' + params.data.id);
  };
  const handleRedirectViewCase = (params) => {
    Router.push('/company-builder/view-ticket?id=' + params.data.id);
  };
  const handleActivateCase = async (params) => {
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));
      const response = await jwtAxios.put(`${API_ROUTS.case}${params.data.id}`);
      if (response.status == 200) {
        dispatch(showMessage('Ticket activated successfully..!'));
        const caseIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );
        if (caseIndex != -1) {
          rowData[caseIndex].status = 'ACTIVE';
        }
        getAllActiveCase(selectedCompany.id);
      }
    } catch (e) {
      dispatch(fetchError(e.response.data.title));
    }
  };

  const getAllActiveCase = async (companyID) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.case}?status=ACTIVE&companyId=${companyID}`,
        {
          headers: {},
        },
        {
          cancelToken: source.token,
        },
      );

      if (res.status == 200) {
        setCaseData(res.data);

        if (res.data.length == 0) {
          dispatch(showInfo('You have no tickets for selected company'));
          setCaseData([]);
        } else {
          setCaseData(res.data);
        }
        setIsLoading(() => false);
      } else {
        setCaseData([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setCaseData([]);
    }
    setIsLoading(() => false);
  };

  const getAllInactiveCase = async (companyID) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.case}?status=INACTIVE&companyId=${companyID}`,
        {
          cancelToken: source2.token,
        },
      );

      if (res.status == 200) {
        setCaseData(res.data);

        if (res.data.length == 0) {
          dispatch(showInfo('You have no tickets for selected company'));
          setCaseData([]);
        } else {
          setCaseData(res.data);
        }
        setIsLoading(() => false);
      } else {
        setCaseData([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setCaseData([]);
      setIsLoading(() => false);
    }
  };

  const handleAddCase = () => {
    Router.push('/company-builder/add-ticket');
  };
  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        <IntlMessages id='tickets.pageHeaderName' />
      </h2>
      <AppCard>
        <Stack direction='row' sx={{mb: 2}} justifyContent={'end'} spacing={2}>
          <Button
            name='addCase'
            variant='outlined'
            onClick={() => handleAddCase()}
            sx={{mr: 1}}
          >
            {/* Add Ticket */}
            <IntlMessages id='eventLog.button.AddTicket' />
          </Button>
          <ToggleButtonGroup
            color='primary'
            value={alignment}
            exclusive
            onChange={handleChange}
          >
            <ToggleButton
              value='ACTIVE'
              onClick={() => getAllActiveCase(selectedCompany.id)}
            >
              <IntlMessages id='common.button.Active' />
            </ToggleButton>
            <ToggleButton
              value='INACTIVE'
              onClick={() => getAllInactiveCase(selectedCompany.id)}
            >
              <IntlMessages id='common.button.Inactive' />
            </ToggleButton>
          </ToggleButtonGroup>
        </Stack>
        {isLoading ? (
          domCreactionGridSkeletonLoader()
        ) : (
          <Stack
            className='ag-theme-alpine'
            style={{height: 525, width: '100%'}}
          >
            <AgGridReact
              ref={gridRef}
              rowData={caseData}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              animateRows={true}
              pagination={true}
              paginationPageSize={10}
            />
          </Stack>
        )}
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default CompanyTickets;
