import React from 'react';
import { Button } from '@mui/material';

const EligibilityActions = ({ isView, footerButton, handleInsertEligibilityData }) => (
  !isView && (
    <Button
      color={footerButton.addMore.color}
      variant={footerButton.addMore.variant}
      sx={footerButton.addMore.sx}
      size={footerButton.addMore.size}
      onClick={handleInsertEligibilityData}
    >
      Add More 
    </Button>
  )
);

export default EligibilityActions;
