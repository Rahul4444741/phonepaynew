import React, { useState } from 'react';
import {
  Stack, TableContainer, Card, Button, Table, TableHead, TableRow, TableBody,
} from '@mui/material';
import EligibilityError from './EligibilityError';
import EligibilityActions from './EligibilityActions';
import EligibilityTable from './EligibilityTable';
import ViewQueryModal from './ViewQueryModal';

const EligibilityContainer = ({
  eligibilityError,
  eligibilityData,
   
  isView,
  footerButton,
  handleInsertEligibilityData,
  handleEditEligibilityData,
  handleDeleteEligibilityData,
  handleAddEligibilityData,
  handleChangeEligibilityData,
   
}) => {
  const [open, setOpen] = useState(false);
  const [firstArray, setFirstArray] = useState([]);

  return (
    <Stack direction='row' sx={{ mt: 3, mb: 10, ml: 3 }} alignItems='flex-start'>
      <TableContainer component={Card}>
        <Stack direction='row' justifyContent='flex-end' sx={{ mb: 2, mr: 5, py: 2 }} spacing={2}>
          <EligibilityError eligibilityError={eligibilityError} />
          <EligibilityActions
            isView={isView}
            footerButton={footerButton}
            handleInsertEligibilityData={handleInsertEligibilityData}
          />
        </Stack>

        <EligibilityTable
          eligibilityData={eligibilityData}
          
          isView={isView}
          handleEditEligibilityData={handleEditEligibilityData}
          handleDeleteEligibilityData={handleDeleteEligibilityData}
          handleAddEligibilityData={handleAddEligibilityData}
          handleChangeEligibilityData={handleChangeEligibilityData}
          setOpen={setOpen}
          setFirstArray={setFirstArray}
          eligibilityDataErrors={eligibilityError}
        
        />
      </TableContainer>

      {open && (
        <ViewQueryModal
          open={open}
          onClose={() => setOpen(false)}
          firstArray={firstArray}
          secondArray={activeQueries}
        />
      )}
    </Stack>
  );
};

export default EligibilityContainer;
