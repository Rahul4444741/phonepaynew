import React from 'react';
import { FormHelperText } from '@mui/material';

const EligibilityError = ({ eligibilityError }) => (
  eligibilityError?.salaryHeadsEligibilityData?.isError && (
    <FormHelperText sx={{ width: 200, fontSize: '12px' }} className='Mui-error'>
      {eligibilityError?.salaryHeadsEligibilityData?.errorMessage}
    </FormHelperText>
  )
);

export default EligibilityError;
