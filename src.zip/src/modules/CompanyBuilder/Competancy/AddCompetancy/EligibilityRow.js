import React from 'react';
import {
  TableRow, Stack,TextField, IconButton, Button, FormControl, InputLabel, Select, MenuItem, FormHelperText,
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
// import StyledTableCell from './StyledTableCell';
import {styled} from '@mui/material/styles';
import TableCell, {tableCellClasses} from '@mui/material/TableCell';

const iconButtonStyled = {padding: '2px 10px'};

const textFieldStyled = {
  backgroundColor: 'white',
  mb: 2,
   
};
const StyledTableCell = styled(TableCell)(({theme}) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: theme.palette.common.primary,
      fontWeight: 'bold',
   
    },
    ['&.MuiTableCell-root']: {
      padding: '5px 10px 5px 10px',
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));

const EligibilityRow = ({
  row,
  index,
  
  isView,
  handleEditEligibilityData,
  handleDeleteEligibilityData,
  handleAddEligibilityData,
  handleChangeEligibilityData,
  setOpen,
  setFirstArray,
  eligibilityDataErrors,
  
}) => {
  
  
  const getNameById = (list, id, fieldType) => {
    if (fieldType == 'salaryHead') {
      let findObject = list?.find((item) => item.id == id);
      if (!isEmptyNullUndefined(findObject)) {
        return findObject?.salaryTypes ? findObject.salaryTypes : '';
      }
      return '';
    } else {
      let findObject = list?.find((item) => item.id == id);
      if (!isEmptyNullUndefined(findObject)) {
        return findObject?.name ? findObject.name : '';
      }
      return '';
    }
  };

  return (
  <TableRow sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
    {!row.isWriteAction ? (
      <>
        <StyledTableCell align='left'  sx={{ flex: 1 }} >
          {/* {getNameById(salaryHeadData, row.salaryHeadId, 'salaryHead')} */}
        {  row.behaviourQuestion}
        </StyledTableCell>
        <StyledTableCell align='left'  sx={{ flex: 1 }} >
          {/* {multipleQueryNameById(row.salaryHeadsEligibilityQuerys, activeQueries)} */}
          {row.pointToRecode}
        </StyledTableCell>
        <StyledTableCell align='left'  sx={{ flex: 1 }} >
          {/* {multipleQueryNameById(row.salaryHeadsEligibilityQuerys, activeQueries)} */}
          {row.pointToCode}
        </StyledTableCell>
        <StyledTableCell align='left'  sx={{ flex: 1 }} >
          {row.salaryHeadsEligibilityQuerys && (
            <Button variant='text' onClick={() => { setOpen(true); setFirstArray(row.salaryHeadsEligibilityQuerys); }}>
              View
            </Button>
          )}
        </StyledTableCell>
        {!isView && (
          <StyledTableCell align='left'  sx={{ flex: 1 }}  >
            <Stack direction='row'>
              <IconButton onClick={() => handleEditEligibilityData(index)}>
                <EditIcon color='primary' />
              </IconButton>
              <IconButton onClick={() => handleDeleteEligibilityData(index)}>
                <HighlightOffIcon color='error' />
              </IconButton>
            </Stack>
          </StyledTableCell>
        )}
      </>
    ) :    (
      <>
          <StyledTableCell align='left'  sx={{ flex: 1 }}  >
          <FormControl
            sx={{
               ...textFieldStyled,
              '& fieldset': {
                borderLeftWidth: 3,
                borderLeftColor: 'red',
              },
              mt: 3,
              minWidth: '400px',
              maxWidth: '400px',
            }}
          >
             
            <TextField
                size='small'
                name='behaviourQuestion'
             placeholder='Behaviour Name'
             label='Behaviour Name'
             multiline
             rows={3}
                onChange={(event) =>
                  handleChangeEligibilityData(event,index)
                }
                variant='outlined'
                disabled={isView}
                error={eligibilityDataErrors[index].behaviourQuestion?.isError}
                helperText={eligibilityDataErrors[index].behaviourQuestion?.errorMessage}
                value={row.behaviourQuestion}
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              />
          </FormControl>
        </StyledTableCell>

        <StyledTableCell align='left'  sx={{ flex: 1 }}>
          <FormControl
            sx={{
              ...textFieldStyled,
              '& fieldset': {
                borderLeftWidth: 3,
                borderLeftColor: 'red',
              },
              mt: 3,
              minWidth: '400px',
              maxWidth: '400px',
            }}
          >
            <InputLabel
              sx={{
                backgroundColor: '#ffffff',
                padding: '0px 0.5rem',
              }}
              size='small'
              id='salaryHeadId'
            >
             
            </InputLabel>
            <TextField
                size='small'
                name='pointToRecode'
                label='Recode Value'
             placeholder='Recode Value'
             onChange={(event) =>
              handleChangeEligibilityData(event,index)
            }
                variant='outlined'
                disabled={isView}
                error={eligibilityDataErrors[index].pointToRecode?.isError}
                helperText={eligibilityDataErrors[index].pointToRecode?.errorMessage}
                value={row.pointToRecode}
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              />
          </FormControl>
        </StyledTableCell>

        <StyledTableCell align='left'  sx={{ flex: 1 }}>
          <FormControl
            sx={{
               ...textFieldStyled,
              '& fieldset': {
                borderLeftWidth: 3,
                borderLeftColor: 'red',
              },
              mt: 3,
              minWidth: '400px',
              maxWidth: '400px',
            }}
          >
            <InputLabel
              sx={{
                backgroundColor: '#ffffff',
                padding: '0px 0.5rem',
              }}
              size='small'
              id='salaryHeadId'
            >
            
            </InputLabel>
            <TextField
            placeholder='Behaviour code'
                size='small'
                name='pointToCode'
                label='Behaviour code'
             fullWidth
             onChange={(event) =>
              handleChangeEligibilityData(event,index)
            }
                variant='outlined'
                error={eligibilityDataErrors[index].pointToCode?.isError}
                helperText={eligibilityDataErrors[index].pointToCode?.errorMessage}
                value={row.pointToCode}
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              />
          </FormControl>
        </StyledTableCell>

        <StyledTableCell align='left'  sx={{ flex: 1 ,minWidth:120}} >
          {row?.salaryHeadsEligibilityQuerys != null && (
            <Button
            style={{...textFieldStyled}}
              variant='text'
              onClick={() => {
                setOpen(() => !open);
                setFirstArray(
                  row?.salaryHeadsEligibilityQuerys,
                );
              }}
            >
              View
            </Button>
          )}
        </StyledTableCell>

        {!isView && (
          <StyledTableCell align='left'  sx={{ flex: 1 }}>
            {
              <Stack direction='row' >
                <IconButton
                  sx={{...iconButtonStyled}}
                  aria-label='save'
                  onClick={() =>
                    handleAddEligibilityData(index)
                  }
                >
                  <CheckBoxIcon color='success' />
                </IconButton>
                <IconButton
                  sx={{...iconButtonStyled}}
                  aria-label='delete'
                  onClick={() =>
                    handleDeleteEligibilityData(index)
                  }
                >
                  <HighlightOffIcon color='error' />
                </IconButton>
              </Stack>
            }
          </StyledTableCell>
        )}
      </>
    )}
  </TableRow>
)};

export default EligibilityRow;
