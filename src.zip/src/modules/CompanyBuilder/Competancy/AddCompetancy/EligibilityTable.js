import React from 'react';
import { Table, TableHead, TableRow, TableBody } from '@mui/material';
import EligibilityRow from './EligibilityRow';
// import StyledTableCell from './StyledTableCell';
import {styled} from '@mui/material/styles';
import TableCell, {tableCellClasses} from '@mui/material/TableCell';

const StyledTableCell = styled(TableCell)(({theme}) => ({
    [`&.${tableCellClasses.head}`]: {
      backgroundColor: theme.palette.common.primary,
      fontWeight: 'bold',
    },
    ['&.MuiTableCell-root']: {
      padding: '5px 10px 5px 10px',
    },
    [`&.${tableCellClasses.body}`]: {
      fontSize: 14,
    },
  }));

const EligibilityTable = ({
  eligibilityData,
  
  isView,
  handleEditEligibilityData,
  handleDeleteEligibilityData,
  handleAddEligibilityData,
  handleChangeEligibilityData,
  setOpen,
  setFirstArray,
  eligibilityDataErrors,
}) => {

  console.log('eligibilityData',eligibilityData)
 return (
 <Table stickyHeader sx={{ minWidth: 650 }} aria-label='simple table'>
    <TableHead>
      <TableRow>
        <StyledTableCell align='left' sx={{ flex: 1 }}>Behaviour Name</StyledTableCell>
        <StyledTableCell align='left' sx={{ flex: 1 }}>Recode Value</StyledTableCell>
        <StyledTableCell align='left' sx={{ flex: 1 }}>Behaviour code</StyledTableCell>
        {!isView && <StyledTableCell align='left' sx={{ minWidth: 200 }}>Action</StyledTableCell>}
      </TableRow>
    </TableHead>
    <TableBody>
      {eligibilityData?.map((row, index) => (
        <EligibilityRow
          key={`${index}-${row.id}`}
          row={row}
          index={index}
      
        
          isView={isView}
          handleEditEligibilityData={handleEditEligibilityData}
          handleDeleteEligibilityData={handleDeleteEligibilityData}
          handleAddEligibilityData={handleAddEligibilityData}
          handleChangeEligibilityData={handleChangeEligibilityData}
          setOpen={setOpen}
          setFirstArray={setFirstArray}
          eligibilityDataErrors={eligibilityDataErrors}
        />
      ))}
    </TableBody>
  </Table>)
};

export default EligibilityTable;
