import PropTypes from 'prop-types';
import {
  Dialog,
  DialogContent,
  DialogActions,
  Button,
  TableRow,
  TableCell,
  TableContainer,
  Paper,
  Table,
  TableBody,
  TableHead,
  Stack,
} from '@mui/material';
import styled from '@emotion/styled';

const CustomTableHeaderCell = styled(TableCell)({
  border: '1px solid #dddddd',
});

const ViewQueryModal = ({open, onClose, firstArray, secondArray}) => {
  // Dictionary to store id to variableName:query mapping
  const idToVariableQuery = {};

  // Create a dictionary mapping IDs to variableName:query
  secondArray?.forEach((entry) => {
    idToVariableQuery[entry.id] = {
      variableName: entry.variableName,
      query: entry.query,
    };
  });

  // Create rows for the table
  const tableRows = firstArray
    ?.filter((id) => idToVariableQuery[id])
    ?.map((id) => {
      const {variableName, query} = idToVariableQuery[id];
      return (
        <TableRow key={id}>
          <CustomTableHeaderCell>{variableName}</CustomTableHeaderCell>
          <CustomTableHeaderCell>{query}</CustomTableHeaderCell>
        </TableRow>
      );
    });

  return (
    <Dialog open={open} onClose={onClose}>
      <DialogContent>
        <Stack sx={{mb:5}}>
            <h2>Selected Queries :</h2>
        </Stack>
        <Stack>
        <TableContainer component={Paper}>
          <Table id='multiplier-table'>
            <TableHead>
              <TableRow>
                <CustomTableHeaderCell
                  style={{
                    backgroundColor: '#f0f0f0',
                    width: '400px',
                  }}
                >
                  Name
                </CustomTableHeaderCell>
                <CustomTableHeaderCell
                  style={{
                    backgroundColor: '#f0f0f0',
                    width: '450px',
                  }}
                >
                  Query
                </CustomTableHeaderCell>
              </TableRow>
            </TableHead>
            <TableBody>{tableRows}</TableBody>
          </Table>
        </TableContainer>
        </Stack>
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose} color='secondary'>
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
};

ViewQueryModal.propTypes = {
  open: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  firstArray: PropTypes.any,
  secondArray: PropTypes.any,
};

export default ViewQueryModal;
