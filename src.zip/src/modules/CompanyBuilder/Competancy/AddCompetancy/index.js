import jwtAxios from '@crema/services/auth/jwt-auth';
import IntlMessages from '@crema/utility/IntlMessages';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import EditIcon from '@mui/icons-material/Edit';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import {
  Card,
  Checkbox,
  CircularProgress,
  FormControlLabel,
  IconButton,
  InputAdornment,
  Box,
  ListItemIcon,
  Paper,
  Radio,
  RadioGroup,
  Autocomplete,
  Chip,
} from '@mui/material';
import {Divider} from '@mui/material';
import Button from '@mui/material/Button';
import FormControl from '@mui/material/FormControl';
import FormHelperText from '@mui/material/FormHelperText';
import InputLabel from '@mui/material/InputLabel';
import ListItemText from '@mui/material/ListItemText';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import Stack from '@mui/material/Stack';
import {styled} from '@mui/material/styles';
import Table from '@mui/material/Table';

import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import { useEffect } from 'react';
import DeleteIcon from '@mui/icons-material/Delete';
import TableBody from '@mui/material/TableBody';
import TableCell, {tableCellClasses} from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TextField from '@mui/material/TextField';
import axios from 'axios';
import ExcelJS from 'exceljs';
import _ from 'lodash';
import Router, {useRouter} from 'next/router';
import React, {useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {getALLRatings} from 'redux/actions/Ratings';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {footerButton} from 'shared/constants/AppConst';
import {AppCard, AppInfoView} from '../../../../@crema';
import AppAnimate from '../../../../@crema/core/AppAnimate';
import AppPageMeta from '../../../../@crema/core/AppPageMeta';
import {fetchError, showInfo, showMessage} from '../../../../redux/actions';
import {
  apiCatchErrorMessage,
  isEmptyNullUndefined,
} from '../../../../shared/utils/CommonUtils';
import {domCreactionHeaderTitle} from 'shared/utils/domCreaction';
import EligibilityContainer from './EligibilityContainer';

const textFieldStyled = {
  backgroundColor: 'white',
  mb: 2,
  width: {xs: '100%', xl: '60%', md: '75%'},
};
const iconButtonStyled = {padding: '2px 10px'};

const CustomTableCell = styled(TableCell)({
  borderBottom: '1px solid #dddddd',
});

// Custom TableHeaderCell component with border
const CustomTableHeaderCell = styled(TableCell)({
  border: '1px solid #dddddd',
});

const StyledTableCell = styled(TableCell)(({theme}) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.primary,
    fontWeight: 'bold',
  },
  ['&.MuiTableCell-root']: {
    padding: '5px 10px 5px 10px',
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const conditionOptions = [
  {name: 'Equal To', value: '='},
  {name: 'Less Than', value: '<'},
  {name: 'Less Than Equal To', value: '<='},
  {name: 'Greater Than', value: '>'},
  {name: 'Greater Than Equal To', value: '>='},
];

const MeritMatrix = () => {
  const router = useRouter();

  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const ratingsData = useSelector(({ratings}) => ratings.ratingsData);

  const {id, view} = router.query;
  const dispatch = useDispatch();
  const [isView, setIsView] = React.useState(false);
  const [eligibilityData, setEligibilityData] = React.useState([]);
  const [eligibilityDataErrors, setEligibilityDataErrors] = React.useState([]);

  
  
  let rawEligibilityData = {
    id: null,
    behaviourQuestion: null,
    pointToRecode:null,
    pointToCode:eligibilityData[0]?.pointToCode ?? null,
    isWriteAction: true,
  };
  
  let rawEligibilityDataError = {
    behaviourQuestion: {isError: false, errorMessage: ''},
    pointToRecode: {isError: false, errorMessage: ''},
    pointToCode: {isError: false, errorMessage: ''},
  };
  
  const initialMeritMatrix = {
    calculateType: null,
    jobCode: null,
    salarySetUpId: null,
    status: null,
    multiplier: false,
    company: {
      id: selectedCompany?.id,
    },
    meritMatrixVariables: [],
    meritMatrixMultiplier: [],
    name: null,
    status: null,
    code: null,
    competencyCategory: null,
    competencyQuestions: [{question: '', score: '', id: Date.now()}],
  };
  const initialFormError = {
    name: {isError: false, errorMessage: ''},
    code: {isError: false, errorMessage: ''},
    competencyCategory: {isError: false, errorMessage: ''},
    jobCode: {isError: false, errorMessage: ''},
    salarySetUpId: {isError: false, errorMessage: ''},
    status: {isError: false, errorMessage: ''},
    multiplier: {isError: false, errorMessage: ''},
    meritMatrixVariables: {isError: false, errorMessage: ''},
    meritMatrixMultiplier: {isError: false, errorMessage: ''},
    selectedRatings: {isError: false, errorMessage: ''},

    score: {isError: false, errorMessage: ''},
  };

  const initialCompetencyError={
    name:{isError: false, errorMessage: ''},
    code:{isError: false, errorMessage: ''},
    competencyCategory: {isError: false, errorMessage: ''},
    status: {isError: false, errorMessage: ''},
  }
  const [meritMatrix, setMeritMatrix] = React.useState(initialMeritMatrix);
  const [compentencyErrors,setCompentencyError] = React.useState(initialCompetencyError)
  const [formError, setFormError] = React.useState(initialFormError);

  const [isEdit, setIsEdit] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [genrateLoading, setGenrateLoading] = React.useState(false);
  const [variablesList, setVariablesList] = useState([]);
  const [selectedRatings, setSelectedRatings] = useState([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const [matrixData, setMatrixData] = useState([]);
  const [variableOne, setVariableOne] = useState([]);
  const [variableTwo, setVariableTwo] = useState([]);
  const [salaryData, setSalaryData] = useState([]);
  const [jobCodeData, setJobCodeData] = React.useState(null);

  const [cellValueErrors, setCellValueErrors] = useState([]);
  console.log('meritMatrix', meritMatrix);
  const initialMultiplierForm = {
    id: null,
    multiplier: false,
    multiplierVariable: null,
    selectedRatings: null,
    calculateType: null,
    meritMatrixMultiplierScales: null,
  };
  const initialMultiplierFormError = {
    multiplier: {isError: false, errorMessage: ''},
    multiplierVariable: {isError: false, errorMessage: ''},
    selectedRatings: {isError: false, errorMessage: ''},
    calculateType: {isError: false, errorMessage: ''},
    meritMatrixMultiplierScales: {isError: false, errorMessage: ''},
  };
  const [multiplierForm, setMultiplierForm] = useState(initialMultiplierForm);
  const [multiplierFormError, setMultiplierFormError] = useState(
    initialMultiplierFormError,
  );

  let rawMultiplierData = {
    id: null,
    scaleName: null,
    lowerCondition: null,
    lowerCircuit: null,
    upperCondition: null,
    upperCircuit: null,
    scaleValue: null,
    isWriteAction: true,
  };

  let rawMultiplierDataError = {
    scaleName: {isError: false, errorMessage: ''},
    lowerCondition: {isError: false, errorMessage: ''},
    lowerCircuit: {isError: false, errorMessage: ''},
    upperCondition: {isError: false, errorMessage: ''},
    upperCircuit: {isError: false, errorMessage: ''},
    scaleValue: {isError: false, errorMessage: ''},
  };

  const [competancyData, setCompetancyData] = React.useState([]);
  const [multiplierDataErrors, setMultiplierDataErrors] = React.useState([]);

  const [multiplierVariablesList, setMultiplierVariablesList] = useState([]);
  const [multiplierName, setMultiplierName] = useState([]);
  const [multiplierValues, setMultiplierValues] = useState([]);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const handleChange = (event, newValue) => {
    setSelectedOptions(newValue);
  };
  console.log('meritMatrix', meritMatrix);
  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();

  React.useEffect(() => {
    if (!isEmptyNullUndefined(selectedCompany.id)) {
      //getVariableList();
      //   getAllActiveSalary(selectedCompany.id);
      //  dispatch(getALLRatings(selectedCompany.id, 'ACTIVE'));
      if (!isEmptyNullUndefined(id)) {
        if (view || view == 'true') {
          getSavedMeritMatrix(id);
          setIsView(true);
        }
        setIsEdit(true);
        getSavedMeritMatrix(id);
      }
    }
  }, []);

  React.useEffect(() => {
    if (multiplierForm.multiplierVariable == 'Compa Ratio') {
      // handleInsertMultiplierData();
    }
  }, []);

  React.useEffect(() => {
    if (multiplierForm.multiplier == true || multiplierForm.multiplier) {
      //getMultipliersVariableList();
    }
  }, [multiplierForm.multiplier]);

  React.useEffect(() => {
    getCompetancyCategory(selectedCompany.id);
    // getAllActiveJobCode(selectedCompany.id);
  }, []);

  React.useEffect(() => {
    // if (
    //   !isEdit &&
    //   !isEmptyNullUndefined(multiplierForm.multiplierVariable) &&
    //   multiplierForm.multiplierVariable != 'Compa Ratio'
    // ) {
    //   if (multiplierForm.multiplierVariable == 'Rating') {
    //     if (!isEmptyNullUndefined(multiplierForm.selectedRatings)) {
    //       getMultiplierNameByVariable(
    //         multiplierForm.multiplierVariable,
    //         multiplierForm.selectedRatings,
    //       );
    //     }
    //   } else {
    //     getMultiplierNameByVariable(multiplierForm.multiplierVariable, null);
    //   }
    // }
  }, [multiplierForm.multiplierVariable, multiplierForm.selectedRatings]);

  const handelAddquestion = () => {
    let initialState = {
      id: Date.now(),
      question: '',
      score: '',
    };

    let allQuestions = [...meritMatrix.competencyQuestions];

    let tempQuestion = allQuestions[0];
    allQuestions[0] = initialState;
    allQuestions.push(tempQuestion);

    setMeritMatrix((prev) => ({
      ...prev,
      competencyQuestions: allQuestions,
    }));
  };

  const deleteQuestion = (deleteID) => {
    let allQuestions = [...meritMatrix.competencyQuestions];

    allQuestions.splice(deleteID, 1);
    setMeritMatrix((prev) => ({
      ...prev,
      competencyQuestions: allQuestions,
    }));
  };
  // Initialize multiplierValues with objects for all scaleName
  React.useEffect(() => {
    //  setMultiplierValues(
    //     multiplierName.map((scaleName) => ({
    //       scaleName: scaleName,
    //       scaleValue: null,
    //       lowerCircuit: null,
    //       upperCircuit: null,
    //       lowerCondition: null,
    //       upperCondition: null,
    //     })),
    //   );
  }, [multiplierName]);

  const getCompetancyCategory = async (companyId) => {
    setIsLoading(() => true);

    console.log('companyId',companyId)
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.competancyCategory}/get-all/${companyId}/ACTIVE`,
         
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no Job Codes for selected company'));
          setCompetancyData([]);
        } else {
          //**Reversed original array****/
          const reversed = res.data.reverse();
          setCompetancyData(reversed);
        }
        setIsLoading(() => false);
      } else {
        setCompetancyData([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      // if (!axios.isCancel(error)) {
      //   apiCatchErrorMessage(error, dispatch, fetchError);
      // }
      console.log('error',error)
      setCompetancyData([]);
    }
    setIsLoading(() => false);
  };

  const getMultipliersVariableList = async () => {
    try {
      const res = await jwtAxios.get(`${API_ROUTS.multiplierDropdown}`, {
        cancelToken: source.token,
      });
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no variables'));
          setMultiplierVariablesList([]);
        } else {
          setMultiplierVariablesList(res.data);
        }
      } else {
        setMultiplierVariablesList([]);
      }
    } catch (e) {
      if (axios.isCancel(e)) {
      } else {
        apiCatchErrorMessage(e, dispatch, fetchError);
      }
      setMultiplierVariablesList([]);
    }
  };

  const getSavedMeritMatrix = async (Id) => {
    try {
      const res = await jwtAxios.get(`${API_ROUTS.competancyEntity}/${Id}`, {
        cancelToken: source.token,
      });
      if (res.status == 200) {
        if (res.data.length == 0) {
          // dispatch(showInfo('You have no matrix data'));
          setMatrixData([]);
        } else {
          //setMatrixData(res.data);

          console.log('res__', res.data);

          let tempState = {
            name: res.data.name,
            code: res.data.code,
            competencyCategory: res.data.competencyCategory.id,
            status: res.data.status,
            competencyQuestions:
              res.data.competencyQuestions.length > 0
                ? res.data.competencyQuestions
                : [{question: '', score: '', id: Date.now()}],
          };

        
         let tempEligibilityQuestion = res.data.competencyQuestions.map((ele,idx) => {
            let obj ={
              id: ele.id,
              behaviourQuestion: ele.question,
              pointToRecode:ele.score,
              pointToCode:ele.code,
              isWriteAction: false,
            }
            return obj
          })
         
          let tempErrorData = res.data.competencyQuestions.map(ele => {
            let obj ={
              behaviourQuestion: {isError: false, errorMessage: ''},
    pointToRecode: {isError: false, errorMessage: ''},
    pointToCode: {isError: false, errorMessage: ''},
            }
            return obj
          })

          setEligibilityDataErrors(tempErrorData)
          setEligibilityData(tempEligibilityQuestion)

          setMeritMatrix(tempState);
        }
      } else {
        setMatrixData([]);
      }
    } catch (e) {
      if (axios.isCancel(e)) {
      } else {
        apiCatchErrorMessage(e, dispatch, fetchError);
      }
      setMatrixData([]);
    }
  };

  // ********************Table handlers*********************************************

  const handleInsertMultiplierData = () => {
    const tempMultiplierDataErrors = _.cloneDeep(multiplierDataErrors);
    const tempMultiplierData = [...multiplierData];

    tempMultiplierDataErrors.push(rawMultiplierDataError);
    tempMultiplierData.push(rawMultiplierData);
    setMultiplierDataErrors(() => tempMultiplierDataErrors);
    setMultiplierData(() => tempMultiplierData);
  };

  const handleEditMultiplierData = (index) => {
    const tempMultiplierData = JSON.parse(JSON.stringify(multiplierData));
    const selectedRow = tempMultiplierData[index];
    selectedRow.isWriteAction = true;
    tempMultiplierData[index] = selectedRow;
    setMultiplierData(() => tempMultiplierData);
  };

  const handleChangeMultiplierData = (event, index, fieldType) => {
    const tempMultiplierDataErrors = _.cloneDeep(multiplierDataErrors);
    const tempMultiplierFormError = _.cloneDeep(multiplierFormError);
    const tempMultiplierData = JSON.parse(JSON.stringify(multiplierData));
    const selectedRow = tempMultiplierData[index];
    const selectedRowError = tempMultiplierDataErrors[index];

    if (fieldType == 'textField' || fieldType == 'dropdown') {
      selectedRow[event.target.name] = event.target.value;
      selectedRowError[event.target.name].isError = false;
      selectedRowError[event.target.name].errorMessage = '';
      tempMultiplierFormError.meritMatrixMultiplierScales.isError = true;
      tempMultiplierFormError.meritMatrixMultiplierScales.errorMessage = '';
    }

    tempMultiplierData[index] = selectedRow;
    tempMultiplierDataErrors[index] = selectedRowError;

    setMultiplierFormError(() => tempMultiplierFormError);
    setMultiplierDataErrors(() => tempMultiplierDataErrors);
    setMultiplierData(() => tempMultiplierData);
  };

  const handleDeleteMultiplierData = async (index) => {
    const tempMultiplierDataErrors = _.cloneDeep(multiplierDataErrors);
    const tempMultiplierData = JSON.parse(JSON.stringify(multiplierData));

    tempMultiplierData.splice(index, 1);
    tempMultiplierDataErrors.splice(index, 1);
    setMultiplierDataErrors(() => tempMultiplierDataErrors);
    setMultiplierData(() => tempMultiplierData);
  };

  const handleAddMultiplierData = (index) => {
    const tempMultiplierData = _.cloneDeep(multiplierData);
    const selectedRow = tempMultiplierData[index];
    const isValid = getMultiplierDataIsValid(tempMultiplierData[index], index);

    if (isValid) {
      selectedRow.isWriteAction = false;
      tempMultiplierData[index] = selectedRow;
      setMultiplierData(tempMultiplierData);
    }
  };

  const getMultiplierDataIsValid = (multiplierRow, index) => {
    let isValid = true;
    const tempMultiplierDataErrors = _.cloneDeep(multiplierDataErrors);
    const tempMultiplierFormError = _.cloneDeep(multiplierFormError);
    const selectedRowError = tempMultiplierDataErrors[index];

    if (isEmptyNullUndefined(multiplierRow.scaleName)) {
      selectedRowError.scaleName.isError = true;
      selectedRowError.scaleName.errorMessage = (
        <IntlMessages id='error.required' />
      );
      isValid = false;
    }

    if (
      !isEmptyNullUndefined(multiplierRow.lowerCondition) &&
      isEmptyNullUndefined(multiplierRow.lowerCircuit)
    ) {
      selectedRowError.lowerCircuit.isError = true;
      selectedRowError.lowerCircuit.errorMessage = (
        <IntlMessages id='error.required' />
      );
      isValid = false;
    }

    if (
      multiplierForm?.calculateType == 'Range' &&
      !isEmptyNullUndefined(multiplierRow.upperCondition) &&
      isEmptyNullUndefined(multiplierRow.upperCircuit)
    ) {
      selectedRowError.upperCircuit.isError = true;
      selectedRowError.upperCircuit.errorMessage = (
        <IntlMessages id='error.required' />
      );
      isValid = false;
    }
    if (isEmptyNullUndefined(multiplierRow.scaleValue)) {
      selectedRowError.scaleValue.isError = true;
      selectedRowError.scaleValue.errorMessage = (
        <IntlMessages id='error.required' />
      );
      isValid = false;
    }

    if (
      multiplierForm?.calculateType == 'Range' &&
      isEmptyNullUndefined(multiplierRow.lowerCondition) &&
      isEmptyNullUndefined(multiplierRow.upperCondition)
    ) {
      tempMultiplierFormError.meritMatrixMultiplierScales.isError = true;
      tempMultiplierFormError.meritMatrixMultiplierScales.errorMessage =
        'Please select atleast one condition';
      isValid = false;
    }

    tempMultiplierDataErrors[index] = selectedRowError;
    setMultiplierDataErrors(tempMultiplierDataErrors);
    setMultiplierFormError(tempMultiplierFormError);
    return isValid;
  };

  // *************************************************************************
  const handleChangeMultiplier = (event, fieldType, name) => {
    const tempMultiplierForm = {...multiplierForm};
    const tempMultiplierFormError = {...multiplierFormError};

    if (
      fieldType === 'textfield' ||
      fieldType === 'dropdown' ||
      fieldType === 'radio'
    ) {
      tempMultiplierForm[event.target.name] = event.target.value;
      tempMultiplierFormError[event.target.name].isError = false;
      tempMultiplierFormError[event.target.name].errorMessage = '';
    }
    setMultiplierData(() => []);
    setMultiplierDataErrors(() => []);
    setMultiplierForm(() => tempMultiplierForm);
    setMultiplierFormError(() => tempMultiplierFormError);
  };

  const getTableName = (list, name) => {
    if (!isEmptyNullUndefined(list) && !isEmptyNullUndefined(name)) {
      const findObject = list?.find((item) => item.name == name);
      return findObject?.tableName ? findObject.tableName : '';
    }
  };

  const getMultiplierNameByVariable = async (variableName, ratingId) => {
    let payload = {
      id: selectedCompany && selectedCompany?.id,
      tableName: getTableName(multiplierVariablesList, variableName),
      ratingIds: ratingId ? [ratingId] : null,
    };

    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.multiplierDropdown}/values`,
        payload,
      );
      if (response.status == 201 || response.status == 200) {
        setMultiplierName(response.data);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleChangeMultiplierInput = (event, scaleName) => {
    const {value} = event.target;
    const scaleValue = value.trim() === '' ? null : value;

    // Update the scaleValue for the specific scaleName
    setMultiplierValues((prevState) => {
      const updatedValues = prevState.map((item) => {
        if (item.scaleName === scaleName) {
          return {...item, scaleValue};
        }
        return item;
      });
      return updatedValues;
    });
  };

  // *************************************************************************

  console.log('compeError',compentencyErrors)
  const handleChangeMeritMatrix = (event, fieldType, name) => {
  
    const tempMeritMatrix = {...meritMatrix};
    const tempError = {...compentencyErrors};

    if (fieldType === 'textfield' || fieldType === 'dropdown') {
      tempMeritMatrix[event.target.name] = event.target.value;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
      if (event.target.value == 'Amount') {
        tempMeritMatrix.salarySetUpId = null;
        tempError.salarySetUpId.isError = false;
        tempError.salarySetUpId.errorMessage = '';
      }
    } else if (fieldType == 'radio') {
      tempMeritMatrix[event.target.name] = event.target.value;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
    } else if (fieldType === 'multiDropdown') {
      if (event.target.name === 'meritMatrixVariables') {
        const value = event.target.value;
        const selectedVariables = variablesList
          .filter((variable) => value.includes(variable.name))
          .map(({name, tableName}) => ({name, tableName}));

        tempMeritMatrix.meritMatrixVariables = selectedVariables;
        tempError.meritMatrixVariables.isError =
          selectedVariables.length === 0 || selectedVariables.length > 2;
        tempError.meritMatrixVariables.errorMessage =
          selectedVariables.length === 0 ? (
            <IntlMessages id='error.pleaseSelectTwoValues' />
          ) : selectedVariables.length > 2 ? (
            <IntlMessages id='error.pleaseSelectTwoValues' />
          ) : (
            ''
          );
      }
    } else if (fieldType == 'selectedRatings') {
      setSelectedRatings(() => event.target.value);
      tempError.selectedRatings.isError = false;
      tempError.selectedRatings.errorMessage = '';
    }

    setMeritMatrix(tempMeritMatrix);
    setFormError(tempError);
  };

 

  const generateTableHandler = () => {
    let isValid = true;
    let tempMeritMatrix = {...meritMatrix};
    let tempFormError = {...formError};
    console.log('isValid', isValid);

    if (isValid) {
      generate();
    } else {
      setFormError(tempFormError);
    }
  };


  const getQuestionPayload = (list) => {
        
     let result =[];

     list.forEach((ele) => {
      let obj ={
        question:ele.behaviourQuestion,
        score:ele.pointToRecode,
        code:ele.pointToCode
      }
      result.push(obj)
     })

     return result
  }
  const generate = async () => {
    setGenrateLoading(true);
    let tempMeritMatrix = {...meritMatrix};

    let questions = [...meritMatrix.competencyQuestions];

    let payloadQuestions = questions
      .filter((_, idx) => idx !== 0)
      .map((ele) => ({
        question: ele.question,
        score: ele.score,
      }));

    let competencyJObentityCode = selectedOptions.map((ele, idx) => {
      return {
        jobCodeId: ele.id,
      };
    });

    console.log('payloadQuestions', payloadQuestions);

    let payload = {
      name: meritMatrix.name,
      status: meritMatrix.status,
      code: meritMatrix.code,
      competencyCategory: {id: meritMatrix.competencyCategory},
      competencyQuestions: getQuestionPayload(eligibilityData),
    };

    if (isEdit) {
      payload.id = id;
    }
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.competancyEntity}/save/${selectedCompany?.id}`,
        payload,
      );
      if (response.status == 201 || response.status == 200) {
        dispatch(showMessage('Competency  generated successfully...!'));
        Router.push(`/company-builder/competancy`);
        setGenrateLoading(false);
      } else {
        setGenrateLoading(false);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
      setGenrateLoading(false);
    } finally {
      setGenrateLoading(false);
    }
  };

  const renderMenuItem = (variable, index) => {
    const isSelected = meritMatrix.meritMatrixVariables?.some(
      (item) => item.name === variable.name,
    );

    return (
      <MenuItem
        key={'role_' + index}
        value={variable.name}
        disabled={!isSelected && meritMatrix.meritMatrixVariables?.length === 2}
      >
        <ListItemIcon>
          <Checkbox checked={isSelected} />
        </ListItemIcon>
        <ListItemText primary={variable.name} />
      </MenuItem>
    );
  };
  //******************* */ Matrix Table Data onChangeHandler*****************************
  const handleCellChange = (event, variable1, variable2, type) => {
    const value = event.target.value;
    // Update the matrixData state with the new value for the corresponding cell
    let tempMatrixData = {...matrixData};
    let tempCellValueError = {...cellValueErrors};
    const updatedMatrixData = [...matrixData['matrix ']];
    let isValid = true;

    const cellIndex = updatedMatrixData.findIndex(
      (item) =>
        item['variable 1'] == variable1 && item['variable 2'] == variable2,
    );

    if (cellIndex !== -1) {
      if (type == 'minRange') {
        if (value < 0) {
          tempCellValueError[cellIndex] = {
            isError: true,
            errorMessage: <IntlMessages id='error.pleaseEnterPositiveValue' />,
          };
          isValid = false;
        }
        if (isValid) {
          updatedMatrixData[cellIndex].meritMatrixValue.minRange = value;
          updatedMatrixData[cellIndex].meritMatrixValue.matrixValue = null;
          tempMatrixData['matrix '] = updatedMatrixData;
          tempCellValueError[cellIndex] = {
            isError: false,
            errorMessage: '',
          };
        }
      }
      if (type == 'maxRange') {
        if (value < 0) {
          tempCellValueError[cellIndex] = {
            isError: true,
            // errorMessage: 'Please enter positive value',
            errorMessage: <IntlMessages id='error.pleaseEnterPositiveValue' />,
          };
          isValid = false;
        }
        if (isValid) {
          updatedMatrixData[cellIndex].meritMatrixValue.maxRange = value;
          updatedMatrixData[cellIndex].meritMatrixValue.matrixValue = null;
          tempMatrixData['matrix '] = updatedMatrixData;
          tempCellValueError[cellIndex] = {
            isError: false,
            errorMessage: '',
          };
        }
      }
      if (type == 'matrixValue') {
        if (value < 0) {
          tempCellValueError[cellIndex] = {
            isError: true,
            errorMessage: 'Enter positive value',
          };
          isValid = false;
        }
        if (
          meritMatrix.calculateType == 'Percentage' &&
          (value < 0 || value > 100)
        ) {
          tempCellValueError[cellIndex] = {
            isError: true,
            errorMessage: <IntlMessages id='error.percentageValidation' />,
          };
          isValid = false;
        }
        if (isValid) {
          updatedMatrixData[cellIndex].meritMatrixValue.matrixValue = value;
          updatedMatrixData[cellIndex].meritMatrixValue.minRange = null;
          updatedMatrixData[cellIndex].meritMatrixValue.maxRange = null;
          tempMatrixData['matrix '] = updatedMatrixData;
          tempCellValueError[cellIndex] = {
            isError: false,
            errorMessage: '',
          };
        }
      }
      setCellValueErrors(tempCellValueError);
      setMatrixData(tempMatrixData);
    }
  };

  // ******************************************************************
  const validateSubmitHandler = () => {
    let isValid = true;
    let tempMultiplierFormError = _.cloneDeep(compentencyErrors);



    if (isEmptyNullUndefined(meritMatrix.name)) {
      
      tempMultiplierFormError.name.isError=true;
      tempMultiplierFormError.name.errorMessage = (
        <IntlMessages id='error.required' />
      );
      isValid = false;
    }
    if (isEmptyNullUndefined(meritMatrix.code)) {
      
      tempMultiplierFormError.code.isError=true;
      tempMultiplierFormError.code.errorMessage = (
        <IntlMessages id='error.required' />
      );
      isValid = false;
    }
    if (isEmptyNullUndefined(meritMatrix.competencyCategory)) {
      
      tempMultiplierFormError.competencyCategory.isError=true;
      tempMultiplierFormError.competencyCategory.errorMessage = (
        <IntlMessages id='error.required' />
      );
      isValid = false;
    }
    if (isEmptyNullUndefined(meritMatrix.status)) {
      
      tempMultiplierFormError.status.isError=true;
      tempMultiplierFormError.status.errorMessage = (
        <IntlMessages id='error.required' />
      );
      isValid = false;
    }
    if (isValid) {
      generate();
    } else {
      //setMultiplierFormError(() => tempMultiplierFormError);
      setCompentencyError(tempMultiplierFormError)
    }
  };

  const submitHandler = async () => {
    // setLoading(true);
    const meritMatrixId = matrixData.meritMatrixEntity.id;
    let transformedData = [];
    if (meritMatrix.calculateType != 'Range') {
      transformedData = matrixData['matrix '].map((item) => ({
        meritMatrixId: meritMatrixId,
        matrixValue: item.meritMatrixValue.matrixValue,
        meritMatrixValueId: item.meritMatrixValue.id,
      }));
    } else {
      transformedData = matrixData['matrix '].map((item) => ({
        meritMatrixId: meritMatrixId,
        minRange: item.meritMatrixValue.minRange,
        maxRange: item.meritMatrixValue.maxRange,
        meritMatrixValueId: item.meritMatrixValue.id,
      }));
    }

    let compaRatioData = multiplierData?.map((item) => {
      const {isWriteAction, ...rest} = item;
      return rest;
    });

    let tempMeritMatrixMultiplier = [];
    tempMeritMatrixMultiplier.push({
      id: multiplierForm?.id || null,
      name: multiplierForm.multiplierVariable,
      tableName: getTableName(
        multiplierVariablesList,
        multiplierForm.multiplierVariable,
      ),
      ratingIds: multiplierForm.selectedRatings
        ? [multiplierForm?.selectedRatings]
        : null,
      calculateType: multiplierForm.calculateType,
      meritMatrixMultiplierScales:
        multiplierForm.multiplierVariable == 'Compa Ratio'
          ? compaRatioData
          : multiplierValues,
    });

    let payload = {
      matrixData: transformedData,
      matrixMultiplierData: {
        id: meritMatrixId,
        multiplier: multiplierForm.multiplier == 'true' ? true : false,
        meritMatrixMultiplier: tempMeritMatrixMultiplier,
      },
    };

    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.saveMeritMatrixTable}`,
        payload,
      );
      if (response.status == 200) {
        dispatch(showMessage('Merit matrix saved successfully...!'));
        Router.push('/company-builder/competancy');
      } else {
        setLoading(false);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
      setLoading(false);
    }
  };

 
  // const router = useRouter();
  // const dispatch = useDispatch();
  // const selectedCompany = useSelector(({ company }) => company.selectedCompany);
  const activeQueries = useSelector(({ CustomQueries }) => CustomQueries.CustomQueries);
  // const { id, view } = router.query;

  const [eligibility, setEligibility] = useState({
    name: '',
    status: null,
    companyId: selectedCompany?.id,
    salaryHeadsEligibilityData: null,
  });
  const [eligibilityError, setEligibilityError] = useState({
    name: { isError: false, errorMessage: '' },
    status: { isError: false, errorMessage: '' },
    salaryHeadsEligibilityData: { isError: false, errorMessage: '' },
  });
   // const [loading, setLoading] = useState(false);
  // const [isEdit, setIsEdit] = useState(false);
 // const [isView, setIsView] = useState(false);
  const [salaryHeadData, setSalaryHeadData] = useState([]);
 
  
 
  const handleInsertEligibilityData = () => {
    const tempEligibilityDataErrors = _.cloneDeep(eligibilityDataErrors);
    const tempEligibilityData = [...eligibilityData];
  

    tempEligibilityDataErrors.push(rawEligibilityDataError);
    tempEligibilityData.push(rawEligibilityData);
    setEligibilityDataErrors(() => tempEligibilityDataErrors);
    setEligibilityData(() => tempEligibilityData);
  };

  const handleEditEligibilityData = (index) => {
    const tempEligibilityData = JSON.parse(JSON.stringify(eligibilityData));
    const selectedRow = tempEligibilityData[index];
    selectedRow.isWriteAction = true;
    tempEligibilityData[index] = selectedRow;
    setEligibilityData(() => tempEligibilityData);
  };

   const getEligibilityDataIsValid = (eligibilityRow, index) => {
    let isValid = true;
    const tempEligibilityDataErrors = _.cloneDeep(eligibilityDataErrors);
    const selectedRowError = tempEligibilityDataErrors[index];
 
    if (isEmptyNullUndefined(eligibilityRow.behaviourQuestion)) {
      selectedRowError.behaviourQuestion.isError = true;
      selectedRowError.behaviourQuestion.errorMessage = (
        <IntlMessages id='error.required' />
      );
      isValid = false;
    }

    if (isEmptyNullUndefined(eligibilityRow.pointToRecode)) {
      selectedRowError.pointToRecode.isError = true;
      selectedRowError.pointToRecode.errorMessage = (
        <IntlMessages id='error.required' />
      );
      isValid = false;
    }

    if (isEmptyNullUndefined(eligibilityRow.pointToCode)) {
      selectedRowError.pointToCode.isError = true;
      selectedRowError.pointToCode.errorMessage = (
        <IntlMessages id='error.required' />
      );
      isValid = false;
    }

    tempEligibilityDataErrors[index] = selectedRowError;
    setEligibilityDataErrors(tempEligibilityDataErrors);
    return isValid;
  };
 
  const handleChangeQuestions = (event , index) =>{
    const tempEligibilityData = _.cloneDeep(eligibilityData);
    const tempEligibilityDataErrors = [...eligibilityDataErrors];
    const selectedRow = tempEligibilityData[index];
    const selectedRowError = tempEligibilityDataErrors[index];
    console.log('selectedRow' , {selectedRow,event})

    selectedRow[event.target.name] = event.target.value;
    selectedRowError[event.target.name].isError = false;
    selectedRowError[event.target.name].errorMessage = '';

    tempEligibilityData[index] = selectedRow;
    tempEligibilityDataErrors[index] = selectedRowError;
    setEligibilityData(tempEligibilityData);
    setEligibilityDataErrors(tempEligibilityDataErrors);
  }

  const handleAddEligibilityDataAction = (index) => {
    const tempEligibilityData = _.cloneDeep(eligibilityData);
    const selectedRow = tempEligibilityData[index];
    const tempError = _.cloneDeep(eligibilityError);
    const isValid = getEligibilityDataIsValid(
      tempEligibilityData[index],
      index,
    );
    console.log('isValid',isValid)
    if (isValid) {
      selectedRow.isWriteAction = false;
      tempEligibilityData[index] = selectedRow;

      // tempError.salaryHeadsEligibilityData.isError = false;
      // tempError.salaryHeadsEligibilityData.errorMessage = '';
      // setEligibilityError(() => tempError);

      // // Check for duplicate entry before adding
      // const isDuplicate = tempEligibilityData.some(
      //   (item, i) =>
      //     i !== index && item.salaryHeadId === selectedRow.salaryHeadId,
      // );

      // if (isDuplicate) {
      //   dispatch(fetchError('Duplicate salary head entered'));
      //   return;
      // }
      setEligibilityData(tempEligibilityData);
    }
  };

  const handleDeleteEligibilityData = (index) => {
    const tempEligibilityData = eligibilityData.filter((_, i) => i !== index);
    const tempEligibilityDataErrors = eligibilityDataErrors.filter((_, i) => i !== index);
    setEligibilityData(tempEligibilityData);
    setEligibilityDataErrors(tempEligibilityDataErrors);
  };

  const handleChangeEligibilityData = (event, index, fieldType) => {
    const tempEligibilityData = [...eligibilityData];
    const tempEligibilityDataErrors = [...eligibilityDataErrors];
    const selectedRow = tempEligibilityData[index];
    const selectedRowError = tempEligibilityDataErrors[index];

    selectedRow[event.target.name] = event.target.value;
    selectedRowError[event.target.name].isError = false;
    selectedRowError[event.target.name].errorMessage = '';
    
    tempEligibilityData[index] = selectedRow;
    tempEligibilityDataErrors[index] = selectedRowError;
    setEligibilityData(tempEligibilityData);
    setEligibilityDataErrors(tempEligibilityDataErrors);
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      await axios.post('/api/salary-eligibility', eligibilityData);
      dispatch(showInfo('Eligibility data saved successfully.'));
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      {isView ? (
        <h2 style={{marginBottom: 20}}>
          <IntlMessages id='matrix.viewMeritMatrix' />
        </h2>
      ) : isEdit ? (
        <h2 style={{marginBottom: 20}}>
          {' '}
          <IntlMessages id='matrix.updateMeritMatrix' />
        </h2>
      ) : (
        <h2 style={{marginBottom: 20}}>
          <IntlMessages id='matrix.addMeritMatrix' />
        </h2>
      )}

      <AppCard>
        <Stack>
          {domCreactionHeaderTitle('Basic Info')}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>
              Name of Competency :
              </Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <TextField
                size='small'
                name='name'
                label={<IntlMessages id='calibration.Name' />}
                onChange={(event) =>
                  handleChangeMeritMatrix(event, 'textfield', 'name')
                }
                variant='outlined'
                disabled={isView}
                error={compentencyErrors.name.isError}
                helperText={compentencyErrors.name.errorMessage}
                value={meritMatrix.name ? meritMatrix.name : ''}
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              />
            </Stack>
          </Stack>

          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>Code :</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <TextField
                size='small'
                name='code'
                label='Code'
                onChange={(event) =>
                  handleChangeMeritMatrix(event, 'textfield', 'code')
                }
                variant='outlined'
                disabled={isView}
                error={compentencyErrors.code.isError}
                helperText={compentencyErrors.code.errorMessage}
                value={meritMatrix.code ? meritMatrix.code : ''}
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              />
            </Stack>
          </Stack>

          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>Competency Category :</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                {!isView && <InputLabel size='small' id='status'>
                  Competency Category
                </InputLabel>}
                <Select
                  labelId='competency-category-label'
                  size='small'
                  id='competency-category'
                  label='Competency Category'
                  disabled={isView}
                  name='competencyCategory'
                  value={meritMatrix.competencyCategory || null}
                  onChange={(event) =>
                    handleChangeMeritMatrix(
                      event,
                      'dropdown',
                      'competencyCategory',
                    )
                  }
                >
                  {competancyData.map((category) => (
                    <MenuItem key={category.id} value={category.id}>
                      {category.name}
                    </MenuItem>
                  ))}
                </Select>

                {compentencyErrors.competencyCategory?.isError && (
                  <FormHelperText style={{color: '#d32f2f'}}>
                    {compentencyErrors.competencyCategory.errorMessage}
                  </FormHelperText>
                )}
              </FormControl>
            </Stack>
          </Stack>

          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>Competency status :</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id='status'>
                  <IntlMessages id='configuration.dialogbox.Status' />
                </InputLabel>
                <Select
                  size='small'
                  name='status'
                  disabled={isView}
                  label='Status'
                  labelId='status'
                  value={meritMatrix?.status || ''}
                  error={compentencyErrors.status?.isError}
                  helperText={compentencyErrors.status?.errorMessage}
                  onChange={(event) =>
                    handleChangeMeritMatrix(event, 'dropdown', 'status')
                  }
                  variant='outlined'
                  sx={{...textFieldStyled, width: '100%'}}
                >
                  <MenuItem key='Active' value='ACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Active' />
                  </MenuItem>
                  <MenuItem key='Inactive' value='INACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                  </MenuItem>
                </Select>

                {compentencyErrors.status?.isError && (
                  <FormHelperText style={{color: '#d32f2f'}}>
                    {compentencyErrors.status.errorMessage}
                  </FormHelperText>
                )}
              </FormControl>
            </Stack>
          </Stack>

         
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3, mb: 5}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}></Stack>

            <Stack
              direction={'row'}
              sx={{width: '60%', alignItems: 'flex-end'}}
              justifyContent='flex-end'
            ></Stack>
          </Stack>

          <Divider sx={{mt: 5, mb: 5}} />

          {domCreactionHeaderTitle('Behaviour')}
          <EligibilityContainer
            eligibilityError={eligibilityDataErrors}
            eligibilityData ={eligibilityData}
            
            isView={isView}
            footerButton={footerButton}
            handleInsertEligibilityData={handleInsertEligibilityData}
            handleEditEligibilityData={handleEditEligibilityData}
            handleDeleteEligibilityData={handleDeleteEligibilityData}
            handleAddEligibilityData={handleAddEligibilityDataAction}
            // handleChangeEligibilityData={handleChangeEligibilityData}
            handleChangeEligibilityData={handleChangeQuestions}
            
          />
        </Stack>

        {/* ////////add Stack for fixed////// */}
        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0,
          }}
        >
          <Stack
            direction='row'
            justifyContent='end'
            alignItems='center'
            spacing={2}
            sx={{
              pt: 5,
              ml: 3,
              margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
            }}
          >
            <Button
              color={footerButton.back.color}
              variant={footerButton.back.variant}
              sx={footerButton.back.sx}
              size={footerButton.back.size}
              onClick={() => Router.push('/company-builder/competancy')}
            >
              <IntlMessages id='common.button.Back' />
            </Button>

            <Button
              color={footerButton.submit.color}
              variant={footerButton.submit.variant}
              sx={footerButton.submit.sx}
              size={footerButton.submit.size}
              disabled={loading || isEmptyNullUndefined(meritMatrix)}
              onClick={() => {
                validateSubmitHandler();
              }}
            >
              {isEdit ? (
                <IntlMessages id='common.button.Update' />
              ) : (
                <IntlMessages id='common.button.Submit' />
              )}
            </Button>
          </Stack>
        </Stack>
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default MeritMatrix;
