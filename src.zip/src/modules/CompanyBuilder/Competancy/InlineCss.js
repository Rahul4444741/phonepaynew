
export const tableContainerStyle = {
    position: 'relative',
    maxHeight: '500px', // Adjust based on your requirement
    width: '95%',
    overflow: 'auto',
  };
  
  export const stickyHeaderStyle = {
    position: 'sticky',
    top: 0,
    zIndex: 3,
    backgroundColor: '#f0f0f0',
  };
  
  export const stickyColumnStyle = {
    position: 'sticky',
    left: 0,
    zIndex: 4,
    backgroundColor: '#f0f0f0',
  };
  
  export const stickyColumnHeaderStyle = {
    ...stickyColumnStyle,
    top:0,
    zIndex: 5,
  };
  
  export const tableCellStyle = {
    border: '1px solid #dddddd',
  };