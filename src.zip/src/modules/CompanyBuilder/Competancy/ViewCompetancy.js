import jwtAxios from '@crema/services/auth/jwt-auth';
import IntlMessages from '@crema/utility/IntlMessages';
import {
  Box,
  CardContent,
  Checkbox,
  FormControlLabel,
  ListItemIcon,
  Paper,
  Radio,
  RadioGroup,
  Skeleton
} from '@mui/material';
import Button from '@mui/material/Button';
import FormControl from '@mui/material/FormControl';
import FormHelperText from '@mui/material/FormHelperText';
import InputLabel from '@mui/material/InputLabel';
import ListItemText from '@mui/material/ListItemText';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import Stack from '@mui/material/Stack';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TextField from '@mui/material/TextField';
import axios from 'axios';
import ExcelJS from 'exceljs';
import Router, { useRouter } from 'next/router';
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getALLRatings } from 'redux/actions/Ratings';
import { API_ROUTS } from 'shared/constants/ApiRouts';
import { footerButton } from 'shared/constants/AppConst';
import { AppCard, AppInfoView } from '../../../@crema';
import AppAnimate from '../../../@crema/core/AppAnimate';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import { fetchError, showInfo } from '../../../redux/actions';
import {
  apiCatchErrorMessage,
  isEmptyNullUndefined,
} from '../../../shared/utils/CommonUtils';
import {
  stickyColumnHeaderStyle,
  stickyColumnStyle,
  stickyHeaderStyle,
  tableCellStyle,
  tableContainerStyle,
} from './InlineCss';

const textFieldStyled = {
  backgroundColor: 'white',
  mb: 2,
  width: {xs: '100%', xl: '60%', md: '75%'},
};

const CustomTableCell = styled(TableCell)({
  borderBottom: '1px solid #dddddd',
});

// Custom TableHeaderCell component with border
const CustomTableHeaderCell = styled(TableCell)({
  border: '1px solid #dddddd',
});

const ViewMeritMatrix = () => {
  const router = useRouter();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const ratingsData = useSelector(({ratings}) => ratings.ratingsData);
  const {id} = router.query;
  const dispatch = useDispatch();

  const initialMeritMatrix = {
    name: null,
    calculateType: null,
    status: 'ACTIVE',
    multiplier: null,
    company: {
      id: selectedCompany?.id,
    },
    meritMatrixVariables: [],
    meritMatrixMultiplier: [],
  };
  const initialFormError = {
    name: {isError: false, errorMessage: ''},
    calculateType: {isError: false, errorMessage: ''},
    status: {isError: false, errorMessage: ''},
    multiplier: {isError: false, errorMessage: ''},
    meritMatrixVariables: {isError: false, errorMessage: ''},
    meritMatrixMultiplier: {isError: false, errorMessage: ''},
  };

  const [meritMatrix, setMeritMatrix] = React.useState(initialMeritMatrix);
  const [formError, setFormError] = React.useState(initialFormError);

  const [isView, setIsView] = React.useState(false);
  const [variablesList, setVariablesList] = useState([]);
  const [matrixData, setMatrixData] = useState([]);
  const [variableOne, setVariableOne] = useState([]);
  const [variableTwo, setVariableTwo] = useState([]);
  const [dataLoading, setDataLoading] = React.useState(false);

  const [isLoading, setIsLoading] = useState(false);
  const [salaryData, setSalaryData] = useState([]);
  const [compaRangesData, setCompaRangesData] = React.useState(null);

  const [selectedRatings, setSelectedRatings] = useState([]);

  const [isMultiplier, setIsMultiplier] = useState(false);
  const [multiplierFormData, setMultiplierFormData] = React.useState([]);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();

  React.useEffect(() => {
    if (!isEmptyNullUndefined(selectedCompany.id)) {
      getVariableList();
      getAllActiveSalary(selectedCompany.id);
      getAllActiveCompaRange(selectedCompany.id);
      dispatch(getALLRatings(selectedCompany.id, 'ACTIVE'));
      if (!isEmptyNullUndefined(id)) {
        setIsView(true);
        getSavedMeritMatrix(id);
      }
    }
  }, []);

  const getVariableList = async () => {
    try {
      const res = await jwtAxios.get(`${API_ROUTS.meritMatrixDropdown}`, {
        cancelToken: source.token,
      });
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no variables'));
          setVariablesList([]);
        } else {
          setVariablesList(res.data);
        }
      } else {
        setVariablesList([]);
      }
    } catch (e) {
      if (axios.isCancel(e)) {
      } else {
        apiCatchErrorMessage(e, dispatch, fetchError);
      }
      setVariablesList([]);
    }
  };

  const getAllActiveCompaRange = async (companyId) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.getCompaRangeByStatus}/${companyId}/ACTIVE`,
        {cancelToken: source.token},
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no Range for selected company'));
          setCompaRangesData([]);
        } else {
          //*******Reversed original array***********/
          setCompaRangesData(res.data);
        }
      } else {
        setCompaRangesData([]);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setCompaRangesData([]);
    }
  };

  const getSavedMeritMatrix = async (Id) => {
    setDataLoading(() => true);
    try {
      const res = await jwtAxios.get(`${API_ROUTS.getMeritMatrix}/${Id}`, {
        cancelToken: source.token,
      });
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no matrix data'));
          setMatrixData([]);
          setDataLoading(() => false);
        } else {
          setMatrixData(res.data);
          let tempMat = {
            name: res.data.meritMatrixEntity.name,
            calculateType: res.data.meritMatrixEntity.calculateType,
            status: res.data.meritMatrixEntity.status,
            rangeCalculateType: res.data.meritMatrixEntity.rangeCalculateType,
            salarySetUpId: res.data.meritMatrixEntity.salarySetUpId,
            // multiplier: res.data.meritMatrixEntity?.multiplier,
            multiplier: !isEmptyNullUndefined(
              res.data.meritMatrixEntity?.meritMatrixMultiplier,
            ),
            meritMatrixMultiplier:
              res.data.meritMatrixEntity.meritMatrixMultiplier,
            meritMatrixVariables:
              res.data.meritMatrixEntity.meritMatrixVariables,
          };
          let RatingVariable =
            res.data.meritMatrixEntity.meritMatrixVariables.find(
              (rating) => rating.name == 'Rating',
            );
          if (!isEmptyNullUndefined(RatingVariable)) {
            setSelectedRatings(() => RatingVariable?.ratingIds);
          }
          setMeritMatrix(tempMat);
          setVariableOne(res.data['variable 1']);
          setVariableTwo(res.data['variable 2']);

          let tempIsMultiplier = isEmptyNullUndefined(
            res.data.meritMatrixEntity?.meritMatrixMultiplier,
          )
            ? false
            : true;
          setIsMultiplier(tempIsMultiplier);

          const sortedData =
            res.data.meritMatrixEntity?.meritMatrixMultiplier.map((item) => ({
              ...item,
              // meritMatrixMultiplierScales: [...item.meritMatrixMultiplierScales]?.sort((a, b) => a.scaleName - b.scaleName),
              meritMatrixMultiplierScales: [
                ...item.meritMatrixMultiplierScales,
              ]?.sort((a, b) => {
                if (a.scaleName < b.scaleName) return -1;
                if (a.scaleName > b.scaleName) return 1;
                return 0;
              }),
            }));
          setMultiplierFormData(sortedData);
          setDataLoading(() => false);
        }
      } else {
        setMatrixData([]);
        setDataLoading(() => false);
      }
    } catch (e) {
      if (axios.isCancel(e)) {
      } else {
        apiCatchErrorMessage(e, dispatch, fetchError);
      }
      setMatrixData([]);
      setDataLoading(() => false);
    }
  };

  const getAllActiveSalary = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.salarySetup_companyID}${companyId}?status=ACTIVE`,
        {cancelToken: source.token},
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no salary for selected company'));
          setSalaryData([]);
        } else {
          let tempRes = JSON.parse(JSON.stringify(res.data));
          const onlyActive = tempRes.filter((e) => e.status === 'ACTIVE');
          // Create a copy of the filtered array and then reverse it
          const reversed = [...onlyActive].reverse();
          setSalaryData(reversed);
        }
        setIsLoading(() => false);
      } else {
        setSalaryData([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setSalaryData([]);
    }
    setIsLoading(() => false);
  };

  const renderMenuItem = (variable, index) => {
    const isSelected = meritMatrix.meritMatrixVariables?.some(
      (item) => item.name === variable.name,
    );

    return (
      <MenuItem
        key={'role_' + index}
        value={variable.name}
        disabled={!isSelected && meritMatrix.meritMatrixVariables?.length === 2}
      >
        <ListItemIcon>
          <Checkbox checked={isSelected} />
        </ListItemIcon>
        <ListItemText primary={variable.name} />
      </MenuItem>
    );
  };

  const handleDownloadExcel = async () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Sheet1');

    // Add table data
    if (
      !isEmptyNullUndefined(variableOne) &&
      !isEmptyNullUndefined(variableTwo)
    ) {
      // Add table headers
      const headerRow = worksheet.addRow(['', ...variableOne]);
      headerRow.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: {argb: 'F0F0F0'},
      };

      variableTwo.forEach((variable2) => {
        const rowData = [variable2];
        variableOne.forEach((variable1) => {
          const cellData = matrixData['matrix '].find(
            (item) =>
              item['variable 1'] === variable1 &&
              item['variable 2'] === variable2,
          );

          if (cellData) {
            if (meritMatrix.calculateType === 'Range') {
              const value1 = cellData.meritMatrixValue.minRange;
              const value2 = cellData.meritMatrixValue.maxRange;
              rowData.push(
                value1 !== null && value2 !== null
                  ? `${value1}--${value2}`
                  : '',
              );
            } else {
              rowData.push(
                cellData.meritMatrixValue.matrixValue !== null
                  ? cellData.meritMatrixValue.matrixValue
                  : '',
              );
            }
          } else {
            rowData.push('');
          }
        });
        worksheet.addRow(rowData);
      });
    } else {
      // Add table data for variableOne in rows
      const headers = ['Name', ...variableOne];
      worksheet.addRow(headers);

      const values = ['Value'];
      variableOne.forEach((variable) => {
        const cellData = matrixData['matrix '].find(
          (item) => item['variable 1'] === variable,
        );

        if (cellData) {
          if (meritMatrix.calculateType === 'Range') {
            const value1 = cellData.meritMatrixValue.minRange;
            const value2 = cellData.meritMatrixValue.maxRange;
            values.push(
              value1 !== null && value2 !== null ? `${value1}-${value2}` : '',
            );
          } else {
            values.push(
              cellData.meritMatrixValue.matrixValue !== null
                ? cellData.meritMatrixValue.matrixValue
                : '',
            );
          }
        } else {
          values.push('');
        }
      });
      worksheet.addRow(values);
    }

    // Generate a blob from the workbook
    const excelBlob = await workbook.xlsx.writeBuffer();

    // Create a downloadable URL for the blob
    const excelBlobUrl = window.URL.createObjectURL(new Blob([excelBlob]));

    // Create an anchor element to trigger the download
    const downloadLink = document.createElement('a');
    downloadLink.href = excelBlobUrl;
    downloadLink.download = 'merit-matrix.xlsx';

    // Append the anchor element to the body and trigger the click event
    document.body.appendChild(downloadLink);
    downloadLink.click();

    // Clean up: remove the anchor element and revoke the URL
    document.body.removeChild(downloadLink);
    window.URL.revokeObjectURL(excelBlobUrl);
  };

  const isCombinedRatingPresent = (data) => {
    return data.some((item) => item.name == 'Rating');
  };

  const getRatingName = (list, id) => {
    const rating = list.find((item) => item.id == id);
    if (!isEmptyNullUndefined(rating)) {
      return rating.ratingParameter ? rating.ratingParameter : '';
    }
    return '';
  };

  const getCompaRangeName = (list, id) => {
    const compaRange = list.find((item) => item.id == id);
    if (!isEmptyNullUndefined(compaRange)) {
      return compaRange.name ? compaRange.name : '';
    }
    return '';
  };
  const getCompaRangeLowerOrUpper = (list, id, name, field) => {
    const compaRange = list.find((item) => item.id == id);
    if (!isEmptyNullUndefined(compaRange)) {
      const compaRangeData = compaRange?.compaRangeData?.find(
        (item) => item.name == name,
      );
      
      if (field == 'lowerRange') {
        return compaRangeData?.lowerRange || '';
      }
      if (field == 'upperRange') {
        return compaRangeData?.upperRange || '';
      }
    }
    return '';
  };
  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        <IntlMessages id='matrix.viewMeritMatrix' />
      </h2>

      <AppCard>
        <Stack>
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>
                <IntlMessages id='matrix.nameOfMeritMatrix' />
              </Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                {dataLoading ? (
                  <Skeleton variant='rounded' height={50} />
                ) : (
                  <TextField
                    size='small'
                    name='name'
                    label={<IntlMessages id='calibration.Name' />}
                    variant='outlined'
                    disabled={isView}
                    value={meritMatrix.name ? meritMatrix.name : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'red',
                          borderLeftWidth: 3,
                        },
                      },
                      width: '100%',
                    }}
                  />
                )}
              </FormControl>
            </Stack>
          </Stack>

          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>Merit matrix status : </Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                {dataLoading ? (
                  <Skeleton variant='rounded' height={50} />
                ) : (
                  <>
                    <InputLabel size='small' id='status'>
                      <IntlMessages id='configuration.dialogbox.Status' />
                    </InputLabel>

                    <Select
                      size='small'
                      name='status'
                      disabled={isView}
                      label='Status'
                      labelId='status'
                      value={meritMatrix?.status || ''}
                      error={formError.status?.isError}
                      helperText={formError.status?.errorMessage}
                      onChange={(event) =>
                        handleChangeMeritMatrix(event, 'dropdown', 'status')
                      }
                      variant='outlined'
                      sx={{...textFieldStyled, width: '100%'}}
                    >
                      <MenuItem key='Active' value='ACTIVE'>
                        <IntlMessages id='configuration.dialogbox.Status.Active' />
                      </MenuItem>
                      <MenuItem key='Inactive' value='INACTIVE'>
                        <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                      </MenuItem>
                    </Select>

                    {formError.status?.isError && (
                      <FormHelperText style={{color: '#d32f2f'}}>
                        {formError.status.errorMessage}
                      </FormHelperText>
                    )}
                  </>
                )}
              </FormControl>
            </Stack>
          </Stack>

          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>
                <IntlMessages id='matrix.whatVariables' />
              </Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                {dataLoading ? (
                  <Skeleton variant='rounded' height={50} />
                ) : (
                  <>
                    <InputLabel size='small' id='label_employeeRoles'>
                      <IntlMessages id='matrix.selectVariables' />
                    </InputLabel>

                    <Select
                      name='meritMatrixVariables'
                      labelId='label_salary'
                      disabled={isView}
                      value={
                        meritMatrix?.meritMatrixVariables?.map(
                          (variable) => variable.name,
                        ) || []
                      }
                      label={<IntlMessages id='matrix.selectVariables' />}
                      variant='outlined'
                      size='small'
                      multiple
                      renderValue={(selected) => selected.join(', ')}
                    >
                      {variablesList.map((variable, index) =>
                        renderMenuItem(variable, index),
                      )}
                    </Select>
                  </>
                )}
              </FormControl>
            </Stack>
          </Stack>

          {meritMatrix.meritMatrixVariables &&
            isCombinedRatingPresent(meritMatrix.meritMatrixVariables) && (
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%'}}>
                  <Stack fontWeight={500}>
                    {/* <IntlMessages id='matrix.whatVariables' /> */}
                    Select ratings
                  </Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <FormControl
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'red',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  >
                    {dataLoading ? (
                      <Skeleton variant='rounded' height={50} />
                    ) : (
                      <>
                        <InputLabel size='small' id='Ratings'>
                          {/* <IntlMessages id='matrix.selectVariables' /> */}
                          Ratings
                        </InputLabel>

                        <Select
                          value={selectedRatings || []}
                          multiple
                          labelId='ratings'
                          name='selectedRatings'
                          variant='outlined'
                          label={<IntlMessages id='calibration.Ratings' />}
                          size='small'
                          disabled={isView}
                          onChange={(event) =>
                            handleChangeMeritMatrix(
                              event,
                              'selectedRatings',
                              'selectedRatings',
                            )
                          }
                          sx={{
                            ...textFieldStyled,
                            '& .MuiOutlinedInput-root': {
                              '& fieldset': {
                                borderLeftColor: 'red',
                                borderLeftWidth: 3,
                              },
                            },
                            width: '460px',
                          }}
                        >
                          {ratingsData.map((rating, index) => (
                            <MenuItem
                              id={`employeeSubFunction-MenuItem-${index}`}
                              key={index}
                              value={rating.id}
                            >
                              {rating.ratingParameter}
                            </MenuItem>
                          ))}
                        </Select>
                        {formError.selectedRatings?.isError && (
                          <FormHelperText className='Mui-error'>
                            {formError.selectedRatings?.errorMessage}
                          </FormHelperText>
                        )}
                      </>
                    )}
                  </FormControl>
                </Stack>
              </Stack>
            )}

          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>
                <IntlMessages id='matrix.expectedOutput' />
              </Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                {dataLoading ? (
                  <Skeleton variant='rounded' height={50} />
                ) : (
                  <>
                    <InputLabel size='small' id='calculateType'>
                      <IntlMessages id='matrix.calculateType' />
                    </InputLabel>
                    <Select
                      size='small'
                      name='calculateType'
                      disabled={isView}
                      label={<IntlMessages id='matrix.calculateType' />}
                      labelId='calculateType'
                      value={meritMatrix?.calculateType || ''}
                      variant='outlined'
                      sx={{...textFieldStyled, width: '100%'}}
                    >
                      <MenuItem key='Active' value='Percentage'>
                        <IntlMessages id='matrix.percentage' />
                      </MenuItem>
                      <MenuItem key='Inactive' value='Amount'>
                        <IntlMessages id='matrix.amount' />
                      </MenuItem>
                      <MenuItem key='Inactive' value='Range'>
                        <IntlMessages id='matrix.range' />
                      </MenuItem>
                    </Select>
                  </>
                )}
              </FormControl>
            </Stack>
          </Stack>

          {meritMatrix?.calculateType == 'Range' && (
            <Stack
              id='addEnrollmentStack'
              direction='row'
              sx={{mt: 5, ml: 3}}
              justifyContent='space-between'
              alignItems='flex-start'
              spacing={2}
            >
              <Stack sx={{width: '40%'}}>
                <Stack fontWeight={500}>
                  {/* What is your expected output of matrix ? */}
                  {/* <IntlMessages id='matrix.expectedOutput' /> */}
                  Select range calculate type:
                </Stack>
              </Stack>

              <Stack direction={'row'} sx={{width: '60%'}}>
                <FormControl
                  sx={{
                    ...textFieldStyled,
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                    },
                  }}
                >
                  {dataLoading ? (
                    <Skeleton variant='rounded' height={50} />
                  ) : (
                    <>
                      <InputLabel size='small' id='rangeCalculateType'>
                        {/* <IntlMessages id='matrix.calculateType' /> */}
                        Range Calculate Type
                      </InputLabel>

                      <Select
                        size='small'
                        name='rangeCalculateType'
                        disabled={isView || !isEmptyNullUndefined(matrixData)}
                        // label={<IntlMessages id='matrix.calculateType' />}
                        label='Range Calculate Type'
                        labelId='rangeCalculateType'
                        value={meritMatrix?.rangeCalculateType || ''}
                        error={formError.rangeCalculateType?.isError}
                        helperText={formError.rangeCalculateType?.errorMessage}
                        onChange={(event) =>
                          handleChangeMeritMatrix(
                            event,
                            'dropdown',
                            'rangeCalculateType',
                          )
                        }
                        variant='outlined'
                        sx={{...textFieldStyled, width: '100%'}}
                      >
                        <MenuItem key='Percentage' value='Percentage'>
                          <IntlMessages id='matrix.percentage' />
                        </MenuItem>
                        <MenuItem key='Amount' value='Amount'>
                          <IntlMessages id='matrix.amount' />
                        </MenuItem>
                      </Select>
                      {formError.rangeCalculateType?.isError && (
                        <FormHelperText style={{color: '#d32f2f'}}>
                          {formError.rangeCalculateType.errorMessage}
                        </FormHelperText>
                      )}
                    </>
                  )}
                </FormControl>
              </Stack>
            </Stack>
          )}

          {(meritMatrix?.calculateType == 'Percentage' ||
            (meritMatrix?.calculateType == 'Range' &&
              meritMatrix.rangeCalculateType == 'Percentage')) && (
            <Stack
              id='addEnrollmentStack'
              direction='row'
              sx={{mt: 5, ml: 3}}
              justifyContent='space-between'
              alignItems='flex-start'
              spacing={2}
            >
              <Stack sx={{width: '40%'}}>
                <Stack fontWeight={500}>Select salary head:</Stack>
              </Stack>

              <Stack direction={'row'} sx={{width: '60%'}}>
                <FormControl
                  sx={{
                    ...textFieldStyled,
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                    },
                  }}
                >
                  {dataLoading ? (
                    <Skeleton variant='rounded' height={50} />
                  ) : (
                    <>
                      <InputLabel size='small' id='salaryType'>
                        {/* <IntlMessages id='matrix.calculateType' /> */}
                        Salary Head
                      </InputLabel>

                      <Select
                        size='small'
                        name='salarySetUpId'
                        disabled={isView || !isEmptyNullUndefined(matrixData)}
                        // label={<IntlMessages id='matrix.calculateType' />}
                        label='Salary Head'
                        labelId='salarySetUpId'
                        value={meritMatrix?.salarySetUpId || ''}
                        error={formError.salarySetUpId?.isError}
                        helperText={formError.salarySetUpId?.errorMessage}
                        onChange={(event) =>
                          handleChangeMeritMatrix(
                            event,
                            'dropdown',
                            'rangeCalculateType',
                          )
                        }
                        variant='outlined'
                        sx={{...textFieldStyled, width: '100%'}}
                      >
                        {salaryData &&
                          salaryData.map((sal, index) => {
                            return (
                              <MenuItem key={index} value={sal.id}>
                                {/* {sal.name} */}
                                {sal.salaryTypes}
                              </MenuItem>
                            );
                          })}
                      </Select>
                      {formError.salarySetUpId?.isError && (
                        <FormHelperText style={{color: '#d32f2f'}}>
                          {formError.salarySetUpId?.errorMessage}
                        </FormHelperText>
                      )}
                    </>
                  )}
                </FormControl>
              </Stack>
            </Stack>
          )}

          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3, mb: 5}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}></Stack>

            <Stack
              direction={'row'}
              sx={{width: '60%', alignItems: 'flex-end'}}
              justifyContent='flex-end'
            >
              {!isEmptyNullUndefined(matrixData) && (
                <Button
                  variant='contained'
                  disabled={dataLoading}
                  onClick={handleDownloadExcel}
                  sx={{mr: 8}}
                >
                  <IntlMessages id='matrix.downloadExcel' />
                </Button>
              )}
            </Stack>
          </Stack>

          {!isEmptyNullUndefined(matrixData) && !dataLoading && (
            <Stack
              id='addEnrollmentStack'
              direction='row'
              sx={{mt: 5, ml: 5, mr: 5, mb: 10}}
              justifyContent='space-between'
              alignItems='flex-start'
              spacing={2}
              width='100%'
            >
              {!isEmptyNullUndefined(variableOne) &&
              !isEmptyNullUndefined(variableTwo) ? (
                <div style={{overflowX: 'auto', width: '100%'}}>
                  <TableContainer
                    component={Paper}
                    // style={{overflowX: 'auto', width: '95%'}}
                    style={tableContainerStyle}
                  >
                    <Table id='matrix-table'>
                      <TableHead>
                        <TableRow>
                          <CustomTableHeaderCell
                            // style={{backgroundColor: '#f0f0f0'}}
                            style={stickyColumnHeaderStyle}
                          ></CustomTableHeaderCell>
                          {variableOne?.map((value) => (
                              <CustomTableHeaderCell
                                key={value}
                                // style={{backgroundColor: '#f0f0f0'}}
                                style={stickyHeaderStyle}
                              >
                                {value}
                              </CustomTableHeaderCell>
                            ))}
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {variableTwo?.map((variable2, rowIndex) => (
                            <TableRow key={variable2}>
                              <CustomTableHeaderCell
                                component='th'
                                scope='row'
                                // style={{backgroundColor: '#f0f0f0'}}
                                style={stickyColumnStyle}
                              >
                                {variable2}
                              </CustomTableHeaderCell>{' '}
                              {/* Row header */}
                              {variableOne?.map((variable1, colIndex) => {
                                  const cellData = matrixData['matrix '].find(
                                    (item) =>
                                      item['variable 1'] === variable1 &&
                                      item['variable 2'] === variable2,
                                  );

                                  return (
                                    <CustomTableCell
                                      key={variable1}
                                      // style={{border: '1px solid #dddddd'}}
                                      style={tableCellStyle}
                                    >
                                      {meritMatrix.calculateType == 'Range' ? (
                                        <>
                                          {isView ? (
                                            <div>
                                              {cellData &&
                                              cellData.meritMatrixValue
                                                .minRange !== null
                                                ? cellData.meritMatrixValue
                                                    .minRange
                                                : ''}{' '}
                                              <span>
                                                {cellData.meritMatrixValue
                                                  .minRange !== null &&
                                                  meritMatrix.rangeCalculateType ==
                                                    'Percentage' &&
                                                  ' % '}
                                              </span>
                                              -
                                              {cellData &&
                                              cellData.meritMatrixValue
                                                .maxRange !== null
                                                ? cellData.meritMatrixValue
                                                    .maxRange
                                                : ''}{' '}
                                              <span>
                                                {cellData.meritMatrixValue
                                                  .maxRange !== null &&
                                                  meritMatrix.rangeCalculateType ==
                                                    'Percentage' &&
                                                  ' % '}
                                              </span>
                                            </div>
                                          ) : null}
                                        </>
                                      ) : (
                                        <>
                                          {isView ? (
                                            <div>
                                              {cellData &&
                                              cellData.meritMatrixValue
                                                .matrixValue !== null
                                                ? cellData.meritMatrixValue
                                                    .matrixValue
                                                : ''}{' '}
                                              <span>
                                                {cellData &&
                                                  cellData.meritMatrixValue
                                                    .matrixValue !== null &&
                                                  meritMatrix.calculateType ==
                                                    'Percentage' &&
                                                  ' % '}
                                              </span>
                                            </div>
                                          ) : null}
                                        </>
                                      )}
                                    </CustomTableCell>
                                  );
                                })}
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </div>
              ) : (
                <div style={{overflowX: 'auto', width: '100%'}}>
                  <TableContainer
                    component={Paper}
                    style={{overflowX: 'auto', width: '95%'}}
                  >
                    <Table id='matrix-table'>
                      <TableHead>
                        <TableRow>
                          <CustomTableHeaderCell
                            style={{
                              backgroundColor: '#f0f0f0',
                              width: '200px',
                            }}
                          >
                            Name
                          </CustomTableHeaderCell>
                          {variableOne?.map((value) => (
                              <CustomTableHeaderCell
                                key={value}
                                style={{backgroundColor: '#f0f0f0'}}
                              >
                                {value}
                              </CustomTableHeaderCell>
                            ))}
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        <TableRow key={'variable2'}>
                          <CustomTableHeaderCell
                            style={{
                              backgroundColor: '#f0f0f0',
                              width: '200px',
                            }}
                          >
                            Value
                          </CustomTableHeaderCell>
                          {variableOne?.map((variable1) => {
                              const cellData = matrixData['matrix '].find(
                                (item) => item['variable 1'] === variable1,
                              );

                              const cellIndex = matrixData['matrix '].findIndex(
                                (item) => item['variable 1'] === variable1,
                              );

                              return (
                                <CustomTableCell
                                  key={variable1}
                                  style={{border: '1px solid #dddddd'}}
                                >
                                  {meritMatrix.calculateType == 'Range' ? (
                                    <>
                                      {isView ? (
                                        <div>
                                          {cellData &&
                                          cellData.meritMatrixValue.minRange !==
                                            null
                                            ? cellData.meritMatrixValue.minRange
                                            : ''}
                                          <span>
                                            {cellData.meritMatrixValue
                                              .minRange !== null &&
                                              meritMatrix.rangeCalculateType ==
                                                'Percentage' &&
                                              ' % '}
                                          </span>
                                          -
                                          {cellData &&
                                          cellData.meritMatrixValue.maxRange !==
                                            null
                                            ? cellData.meritMatrixValue.maxRange
                                            : ''}
                                          <span>
                                            {cellData.meritMatrixValue
                                              .maxRange !== null &&
                                              meritMatrix.rangeCalculateType ==
                                                'Percentage' &&
                                              ' % '}
                                          </span>
                                        </div>
                                      ) : null}
                                    </>
                                  ) : (
                                    <>
                                      {isView ? (
                                        <div>
                                          {cellData &&
                                          cellData.meritMatrixValue
                                            .matrixValue !== null
                                            ? cellData.meritMatrixValue
                                                .matrixValue
                                            : ''}{' '}
                                          <span>
                                            {cellData.meritMatrixValue
                                              .matrixValue !== null &&
                                              meritMatrix.calculateType ==
                                                'Percentage' &&
                                              ' % '}
                                          </span>
                                        </div>
                                      ) : null}
                                    </>
                                  )}
                                </CustomTableCell>
                              );
                            })}
                        </TableRow>
                      </TableBody>
                    </Table>
                  </TableContainer>
                </div>
              )}
            </Stack>
          )}
        </Stack>
        {!dataLoading && (
          <Stack sx={{marginBottom: '20px', ml: 3}}>
            <Stack
              id='addEnrollmentStack'
              direction='row'
              sx={{mt: 5, ml: 3}}
              justifyContent='space-between'
              alignItems='flex-start'
              spacing={2}
            >
              <Stack sx={{width: '40%'}}>
                <Stack fontWeight={500}>Is there any other multipliers ?</Stack>
              </Stack>

              <Stack direction={'row'} sx={{width: '60%'}}>
                <RadioGroup
                  value={isMultiplier}
                  row
                  aria-labelledby='demo-row-radio-buttons-group-label'
                  name='multiplier'
                >
                  <FormControlLabel
                    value={true}
                    control={<Radio />}
                    disabled={isView}
                    label={<IntlMessages id='common.button.Yes' />}
                  />
                  <FormControlLabel
                    value={false}
                    control={<Radio />}
                    disabled={isView}
                    label={<IntlMessages id='common.button.No' />}
                  />
                </RadioGroup>
              </Stack>
            </Stack>

            {(isMultiplier == 'true' || isMultiplier == true) && (
              <>
                {multiplierFormData?.map((formData, formIndex) => (
                    <Box key={formIndex + "-" + formData?.name} sx={{boxShadow: 3, borderRadius: 3, mt: 3, mb: 3}}>
                        <CardContent>
                          <Stack>
                            {!formData.isWriteAction && (
                              <Stack>
                                  <Stack
                                    id='addEnrollmentStack'
                                    direction='row'
                                    sx={{mt: 5, ml: 3}}
                                    justifyContent='space-between'
                                    alignItems='flex-start'
                                    spacing={2}
                                  >
                                    <Stack sx={{width: '40%'}}>
                                      <Stack fontWeight={500}>
                                        Selected Variable
                                      </Stack>
                                    </Stack>

                                    <Stack
                                      direction={'row'}
                                      sx={{width: '60%'}}
                                    >
                                      {formData?.name || ''}
                                    </Stack>
                                  </Stack>

                                  {formData?.name &&
                                    formData?.name == 'Rating' && (
                                      <Stack
                                        id='addEnrollmentStack'
                                        direction='row'
                                        sx={{mt: 5, ml: 3}}
                                        justifyContent='space-between'
                                        alignItems='flex-start'
                                        spacing={2}
                                      >
                                        <Stack sx={{width: '40%'}}>
                                          <Stack fontWeight={500}>
                                            Selected rating
                                          </Stack>
                                        </Stack>

                                        <Stack
                                          direction={'row'}
                                          sx={{width: '60%'}}
                                        >
                                          {getRatingName(
                                            ratingsData,
                                            formData?.ratingIds,
                                          )}
                                        </Stack>
                                      </Stack>
                                    )}

                                  {formData.name == 'Range' && (
                                    <Stack
                                      id='addEnrollmentStack'
                                      direction='row'
                                      sx={{mt: 5, ml: 3}}
                                      justifyContent='space-between'
                                      alignItems='flex-start'
                                      spacing={2}
                                    >
                                      <Stack sx={{width: '40%'}}>
                                        <Stack fontWeight={500}>
                                          Selected Range
                                        </Stack>
                                      </Stack>

                                      <Stack
                                        direction={'row'}
                                        sx={{width: '60%'}}
                                      >
                                        {getCompaRangeName(
                                          compaRangesData,
                                          formData?.multiplierVariableId,
                                        )}
                                      </Stack>
                                    </Stack>
                                  )}

                                  <Stack
                                    id='addEnrollmentStack'
                                    direction='row'
                                    sx={{mt: 5, ml: 3}}
                                    justifyContent='space-between'
                                    alignItems='flex-start'
                                    spacing={2}
                                  >
                                    <Stack sx={{width: '40%'}}>
                                      <Stack fontWeight={500}>
                                        Selected Calculate Type
                                      </Stack>
                                    </Stack>

                                    <Stack
                                      direction={'row'}
                                      sx={{width: '60%'}}
                                    >
                                      {formData?.calculateType || ''}
                                    </Stack>
                                  </Stack>

                                  {!isEmptyNullUndefined(formData.name) && (
                                    <Stack
                                      direction='column'
                                      justifyContent='center'
                                      alignItems='center'
                                      spacing={2}
                                      sx={{mb: 10, mt: 5}}
                                    >
                                      <div>
                                        <TableContainer
                                          component={Paper}
                                          style={{
                                            overflowX: 'auto',
                                            width: '100%',
                                          }}
                                        >
                                          <Table id='multiplier-table'>
                                            <TableHead>
                                              <TableRow>
                                                <CustomTableHeaderCell
                                                  style={{
                                                    backgroundColor: '#f0f0f0',
                                                    width: '400px',
                                                  }}
                                                >
                                                  Name
                                                </CustomTableHeaderCell>
                                                {formData.name == 'Range' && (
                                                  <>
                                                    <CustomTableHeaderCell
                                                      style={{
                                                        backgroundColor:
                                                          '#f0f0f0',
                                                        width: '400px',
                                                      }}
                                                    >
                                                      Lower Range (exclusive
                                                      &gt;)
                                                    </CustomTableHeaderCell>
                                                    <CustomTableHeaderCell
                                                      style={{
                                                        backgroundColor:
                                                          '#f0f0f0',
                                                        width: '400px',
                                                      }}
                                                    >
                                                      Upper Range (inclusive
                                                      &le;)
                                                    </CustomTableHeaderCell>
                                                  </>
                                                )}
                                                <CustomTableHeaderCell
                                                  style={{
                                                    backgroundColor: '#f0f0f0',
                                                    width: '450px',
                                                  }}
                                                >
                                                  {formData?.calculateType ==
                                                  'Amount'
                                                    ? 'Amount'
                                                    : 'Multiplier'}
                                                </CustomTableHeaderCell>
                                              </TableRow>
                                            </TableHead>
                                            <TableBody>
                                              {multiplierFormData[formIndex]
                                                .meritMatrixMultiplierScales &&
                                                multiplierFormData[
                                                  formIndex
                                                ].meritMatrixMultiplierScales.map(
                                                  (row, index) => (
                                                    <TableRow key={index}>
                                                      <CustomTableHeaderCell>
                                                        {row.scaleName || ''}
                                                      </CustomTableHeaderCell>
                                                      {formData.name ==
                                                        'Range' && (
                                                        <>
                                                          <CustomTableHeaderCell>
                                                            {getCompaRangeLowerOrUpper(
                                                              compaRangesData,
                                                              formData.multiplierVariableId,
                                                              row.scaleName,
                                                              'lowerRange',
                                                            )}
                                                          </CustomTableHeaderCell>
                                                          <CustomTableHeaderCell>
                                                            {getCompaRangeLowerOrUpper(
                                                              compaRangesData,
                                                              formData.multiplierVariableId,
                                                              row.scaleName,
                                                              'upperRange',
                                                            )}
                                                          </CustomTableHeaderCell>
                                                        </>
                                                      )}
                                                      <CustomTableHeaderCell>
                                                        {row.scaleValue || ''}
                                                      </CustomTableHeaderCell>
                                                    </TableRow>
                                                  ),
                                                )}
                                            </TableBody>
                                          </Table>
                                        </TableContainer>
                                      </div>
                                    </Stack>
                                  )}
                                </Stack>
                            )}
                          </Stack>
                        </CardContent>
                      </Box>
                  ))}
              </>
            )}
          </Stack>
        )}

        {/* ////////add Stack for fixed////// */}
        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0,
          }}
        >
          <Stack
            direction='row'
            justifyContent='end'
            alignItems='center'
            spacing={2}
            sx={{
              pt: 5,
              ml: 3,
              margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
            }}
          >
            <Button
              color={footerButton.back.color}
              variant={footerButton.back.variant}
              sx={footerButton.back.sx}
              size={footerButton.back.size}
              onClick={() => Router.push('/company-builder/merit-matrix')}
            >
              <IntlMessages id='common.button.Back' />
            </Button>
          </Stack>
        </Stack>
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default ViewMeritMatrix;
