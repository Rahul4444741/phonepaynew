import jwtAxios from '@crema/services/auth/jwt-auth';
import IntlMessages from '@crema/utility/IntlMessages';
import {TextField} from '@mui/material';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import {AgGridReact} from 'ag-grid-react';
import axios from 'axios';
import Error403 from 'modules/errorPages/Error403';
import Router from 'next/router';
import * as React from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {
  apiCatchErrorMessage,
  buttonStyle,
  isAllowedUser,
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import {permissionName} from 'shared/utils/PermissionName';
import {AppCard} from '../../../@crema';
import AppAnimate from '../../../@crema/core/AppAnimate';
import AppInfoView from '../../../@crema/core/AppInfoView';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import {
  fetchError,
  fetchStart,
  showInfo,
  showMessage,
} from '../../../redux/actions';
import AlertDialog from '../../Common/AlertDialog';
import {useCallback} from 'react';

const MeritMatrix = () => {
  const dispatch = useDispatch();
  const [allMeritMetrix, setAllMeritMetrix] = React.useState(null);
  const [overlayMessage, setOverlayMessage] = React.useState('No Rows To Show');
  const [isLoading, setIsLoading] = React.useState(true);
  const [alertProps, setAlertProps] = React.useState({
    isHideShow: false,
    message: '',
    title: '',
    alertType: '',
    actionParams: null,
  });

  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);
  const fileInputRef = React.useRef(null);
  const [isUploadingFile, setIsUploadingFile] = React.useState(false);
  React.useEffect(() => {
    if (isAllowedUser(permissionName.SET_UP_COMPENSATION_MERIT_MATRIX)) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  const CustomHeaderName = <IntlMessages id='aggrid.tableHeader.Name' />;
  const CustomHeaderCalculateType = (
    <IntlMessages id='aggrid.tableHeader.CalculateType' />
  );
  const CustomHeaderStatus = <IntlMessages id='aggrid.tableHeader.Status' />;
  const CustomHeaderAction = <IntlMessages id='aggrid.tableHeader.Action' />;

  const [columnDefs] = React.useState([
    {
      field: 'name',
      filter: true,
      headerName: 'Competency Name',
      flex: 1,
      headerComponentFramework: CustomHeaderName,
    },
    {
      field: 'competencyCategory.name',
      filter: true,
      headerName: 'Competency Category',
      flex: 1,
      headerComponentFramework: CustomHeaderCalculateType,
    },
    {
      field: 'status',
      filter: true,
      headerName: 'Status',
      headerComponentFramework: CustomHeaderStatus,
      flex: 1,
      cellRenderer: function (params) {
        return (
          <Stack direction='row'>
            {params.data.status == 'ACTIVE' ? (
              <div style={{color: '#11C15B'}}>{params.data.status}</div>
            ) : params.data.isDraft == true ? (
              <div style={{color: '#ebe134'}}>{'DRAFT'}</div>
            ) : (
              <div style={{color: '#D32F2F'}}>{params.data.status}</div>
            )}
          </Stack>
        );
      },
    },
    {
      headerName: 'Action',

      headerComponentFramework: CustomHeaderAction,
      flex: 1,
      cellRenderer: function (params) {
        return (
          <Stack direction='row'>
            {isAllowedUser(permissionName.UPDATE) && (
              <Button
                onClick={() => handleRedirectEditMeritMatrix(params)}
                style={buttonStyle}
              >
                <IntlMessages id='common.button.Edit' />
              </Button>
            )}
            {isAllowedUser(permissionName.READ) && (
              <Button
                onClick={() => handleRedirectViewMeritMatrix(params)}
                style={buttonStyle}
              >
                <IntlMessages id='common.button.View' />
              </Button>
            )}
            {isAllowedUser(permissionName.DEACTIVATE) &&
              params.data.status == 'ACTIVE' && (
                <Button
                  onClick={() => handleDeactivateConfirmation(params)}
                  style={buttonStyle}
                >
                  <IntlMessages id='common.button.Deactivate' />
                </Button>
              )}
            {isAllowedUser(permissionName.ACTIVATE) &&
              params.data.status == 'INACTIVE' &&
              params.data.isDraft != true && (
                <Button
                  onClick={() => handleActivateConfirmation(params)}
                  style={buttonStyle}
                >
                  <IntlMessages id='common.button.Activate' />
                </Button>
              )}
          </Stack>
        );
      },
    },
  ]);

  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const employeeDetails = JSON.parse(localStorage.getItem('userDetails'));

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();
  React.useEffect(() => {
    dispatch(fetchStart);
    if (
      isAuthorized &&
      selectedCompany != null &&
      selectedCompany != undefined
    ) {
      getAllActiveMeritMatrix(selectedCompany.id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, [isAuthorized, selectedCompany]);

  const gridRef = React.useRef();
  const defaultColDef = React.useMemo(() => ({
    sortable: true,
  }));

  const getAllActiveMeritMatrix = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.competancyEntity}/get-all/${companyId}/ACTIVE`,
        {cancelToken: source.token},
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(
            showInfo('You have no active competancy for selected company'),
          );
          setAllMeritMetrix([]);
        } else {
          //*******Reversed original array***********/
          // const reversed = res.data.reverse();
          const sortedData = res.data?.sort(
            (a, b) =>
              new Date(b.lastModifiedDate) - new Date(a.lastModifiedDate),
          );
          setAllMeritMetrix(sortedData);
        }
        setIsLoading(() => false);
      } else {
        setAllMeritMetrix([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setAllMeritMetrix([]);
    }
    setIsLoading(() => false);
  };
  const getAllInactiveMeritMatrix = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.competancyEntity}/get-all/${companyId}/INACTIVE`,
        {cancelToken: source2.token},
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(
            showInfo('You have no inactive competancy for selected company'),
          );
          setAllMeritMetrix([]);
        } else {
          //*******Reversed original array***********/
          // const reversed = res.data.reverse();
          const sortedData = res.data?.sort(
            (a, b) =>
              new Date(b.lastModifiedDate) - new Date(a.lastModifiedDate),
          );
          setAllMeritMetrix(sortedData);
        }
        setIsLoading(() => false);
      } else {
        setAllMeritMetrix([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setAllMeritMetrix([]);
      setIsLoading(() => false);
    }
  };

  const handleRedirectAddMeritMatrixNew = () => {
    Router.push('/company-builder/add-competancy');
  };

  const handleRedirectEditMeritMatrix = (params) => {
    console.log(params, 'ss');
    Router.push(`/company-builder/add-competancy?id=${params.data?.id}`);
  };

  const handleRedirectViewMeritMatrix = (params) => {
    Router.push(
      `/company-builder/add-competancy?id=${params.data?.id}&view=true`,
    );
  };

  const handleDeactivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = <IntlMessages id='warning.deactivateMeritMatrix' />;

    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureDeactivate' /> {params.data.name} ?
      </span>
    );

    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleAlertYes = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.actionParams.data.status == 'ACTIVE' &&
      handleDeactivateMeritMatrix(tempAlertProps.actionParams);
    tempAlertProps.actionParams.data.status == 'INACTIVE' &&
      handleActivateMeritMatrix(tempAlertProps.actionParams);
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };

  const handleAlertNo = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };
  const handleDeactivateMeritMatrix = async (params) => {
    let payload={
      id:params.data.id,
      companyId: selectedCompany?.id,
      status: "INACTIVE"
  }
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));
      const response = await jwtAxios.put(
        `${API_ROUTS.competancyEntity}/update-status`,payload
      );
      if (response.status == 200) {
        dispatch(showMessage('Competency deactivate successfully..!'));

        const roleIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );

        if (roleIndex != -1) {
          rowData[roleIndex].status = 'INACTIVE';
        }
        getAllInactiveMeritMatrix(selectedCompany.id);
        setAlignment('INACTIVE');
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleActivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = <IntlMessages id='warning.activateMeritMatrix' />;
    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureActivate' /> {params.data.name} ?
      </span>
    );
    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleActivateMeritMatrix = async (params) => {
    let payload={
      id:params.data.id,
      companyId: selectedCompany?.id,
      status: "ACTIVE"
  }
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));
      const response = await jwtAxios.put(
        `${API_ROUTS.competancyEntity}/update-status`,payload
      );
      if (response.status == 200) {
        dispatch(showMessage('Competency activate successfully..!'));
        const roleIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );
        if (roleIndex != -1) {
          rowData[roleIndex].status = 'ACTIVE';
        }
        getAllActiveMeritMatrix(selectedCompany.id);
        setAlignment('ACTIVE');
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const [alignment, setAlignment] = React.useState('ACTIVE');

  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
  };

  const onFilterTextBoxChanged = useCallback(() => {
    const filterText = document.getElementById('filter-text-box').value;
    gridRef.current.api.setGridOption('quickFilterText', filterText);
    const totalResults = gridRef.current.api.getDisplayedRowCount();
    if (!isEmptyNullUndefined(allMeritMetrix) && allMeritMetrix.length > 0) {
      if (totalResults === 0 && !isEmptyNullUndefined(filterText)) {
        setOverlayMessage('No Record Found');
        gridRef.current.api.showNoRowsOverlay();
      } else if (totalResults !== 0) {
        setOverlayMessage('No Rows To Show');
        gridRef.current.api.hideOverlay();
      }
    }
  }, []);

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (!isAuthorized) {
    return <Error403 />;
  }

  const handleButtonClick = () => {
    fileInputRef.current.click(); // Programmatically click the hidden input
  };

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    if (selectedFile) {
      console.log('Selected file:', selectedFile.name);
      UploadFile(selectedFile);
    }
    event.target.value = null;
  };
  const UploadFile = async (file) => {
    setIsUploadingFile(() => true);
    const formData = new FormData();
    formData.append('file', file);
    // const tempCase = JSON.parse(JSON.stringify(cases));
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.competancyEntity}/upload-file/${selectedCompany.id}`,
        formData,

        // {headers: {ContentType: 'multipart/form-data'}},
      );
      if (response.status == 201 || response.status == 200) {
        dispatch(showMessage('File uploaded successfully!'));
        // tempCase.fileUploadStatus = 'LOADED';
        // tempCase.fileUrl = response.data;
      } else {
        //.fileUploadStatus = 'NA';
        dispatch(showInfo('File not uploaded ..!'));
      }
    } catch (e) {
      dispatch(fetchError(e.message));
    } finally {
      setIsUploadingFile(() => false);
    }
    // setFormError(tempError);
    // setFormError({
    //   ...formError,
    //   fileUrl: {isError: false},
    // });
  };

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        <IntlMessages id='matrix.meritMatrix' />
      </h2>
      <AppCard>
        <Stack style={{width: '100%'}}>
          <Stack direction='row' sx={{mb: 2}} justifyContent={'end'}>
            <TextField
              //size='small'
              sx={{width: 200, mr: 2}}
              id='filter-text-box'
              disabled={isUploadingFile}
              onInput={onFilterTextBoxChanged}
              type={'search'}
              name='search'
              label={<IntlMessages id='common.button.Search' />}
              variant='outlined'
            />
            <Button sx={{mr: 2}} variant='outlined' onClick={handleButtonClick}>
              Add Upload Excel
            </Button>
            <input
              type='file'
              ref={fileInputRef}
              hidden
              onChange={handleFileChange}
            />
            {isAllowedUser(permissionName.CREATE) && (
              <Button
                sx={{mr: 2}}
                variant='outlined'
                onClick={() => handleRedirectAddMeritMatrixNew()}
              >
                <IntlMessages id='matrix.addMeritMatrix' />
              </Button>
            )}
            <ToggleButtonGroup
              color='primary'
              value={alignment}
              exclusive
              onChange={handleChange}
            >
              <ToggleButton
                value='ACTIVE'
                onClick={() => getAllActiveMeritMatrix(selectedCompany.id)}
              >
                <IntlMessages id='common.button.Active' />
              </ToggleButton>
              <ToggleButton
                value='INACTIVE'
                onClick={() => getAllInactiveMeritMatrix(selectedCompany.id)}
              >
                <IntlMessages id='common.button.Inactive' />
              </ToggleButton>
            </ToggleButtonGroup>
          </Stack>
          {isLoading ? (
            domCreactionGridSkeletonLoader()
          ) : (
            <Stack
              className='ag-theme-alpine'
              style={{height: 525, width: '100%'}}
            >
              <AgGridReact
                ref={gridRef}
                rowData={allMeritMetrix}
                columnDefs={columnDefs}
                defaultColDef={defaultColDef}
                autoSizeStrategy={'fitGridWidth'}
                animateRows={true}
                pagination={true}
                paginationPageSize={10}
                overlayLoadingTemplate={
                  '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'
                }
                overlayNoRowsTemplate={`<span class="ag-overlay-loading-center">${overlayMessage}</span>`}
              />
            </Stack>
          )}
        </Stack>

        {alertProps.isHideShow && (
          <AlertDialog
            alertProps={alertProps}
            handleYes={() => handleAlertYes()}
            handleNo={() => handleAlertNo()}
          />
        )}
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default MeritMatrix;
