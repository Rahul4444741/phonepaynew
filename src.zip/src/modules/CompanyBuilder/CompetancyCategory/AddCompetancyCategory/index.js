import React from 'react';
import {useDispatch, useSelector} from 'react-redux';
import AppAnimate from '../../../../@crema/core/AppAnimate';
import AppPageMeta from '../../../../@crema/core/AppPageMeta';
import {AppCard, AppInfoView} from '../../../../@crema';
import Stack from '@mui/material/Stack';
import {DesktopDatePicker, LocalizationProvider} from '@mui/x-date-pickers';
import {AdapterDateFns} from '@mui/x-date-pickers/AdapterDateFns';
import TextField from '@mui/material/TextField';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import {
  getCompanyDateFormatForInputs,
  apiCatchErrorMessage,
  isEmptyNullUndefined,
} from '../../../../shared/utils/CommonUtils';
import Button from '@mui/material/Button';
import Router, {useRouter} from 'next/router';
import {fetchError, showMessage} from '../../../../redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import FormHelperText from '@mui/material/FormHelperText';
import {footerButton} from 'shared/constants/AppConst';
import Card from '@mui/material/Card';
import IntlMessages from '@crema/utility/IntlMessages';
import {CircularProgress} from '@mui/material';
import axios from 'axios';

const textFieldStyled = {
  backgroundColor: 'white',
  mb: 2,
  width: {xs: '100%', xl: '60%', md: '75%'},
};

const AddJobCode = () => {
  const router = useRouter();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const {id, view} = router.query;
  const dispatch = useDispatch();

  const initialJobCode = {
    id: null,
    status: null,
    name: null,
    libraryName: null,
    libraryCode: null,
    code: null,
    breakoutName: null,
    peerGroupName: null,
    monetaryUnit: null,
    jobModule: null,
    jobFunction: null,
    jobArea: null,
    jobFocus: null,
    jobCategory: null,
    jobFamily: null,
    jobLevel: null,
    jobCode: null,
    techOrNonTech: null,
    roleType: null,
  };

  const initialJobCodeError = {
    status: {isError: false, errorMessage: ''},
    name: {isError: false, errorMessage: ''},
    libraryName: {isError: false, errorMessage: ''},
    libraryCode: {isError: false, errorMessage: ''},
    code: {isError: false, errorMessage: ''},
    breakoutName: {isError: false, errorMessage: ''},
    peerGroupName: {isError: false, errorMessage: ''},
    monetaryUnit: {isError: false, errorMessage: ''},
    jobModule: {isError: false, errorMessage: ''},
    jobFunction: {isError: false, errorMessage: ''},
    jobArea: {isError: false, errorMessage: ''},
    jobFocus: {isError: false, errorMessage: ''},
    jobCategory: {isError: false, errorMessage: ''},
    jobFamily: {isError: false, errorMessage: ''},
    jobLevel: {isError: false, errorMessage: ''},
    jobCode: {isError: false, errorMessage: ''},
    techOrNonTech: {isError: false, errorMessage: ''},
    roleType: {isError: false, errorMessage: ''},
  };

  const [jobCode, setJobCode] = React.useState(initialJobCode);
  const [jobCodeError, setJobCodeError] = React.useState(initialJobCodeError);
  const [loading, setLoading] = React.useState(false);
  const [isEdit, setIsEdit] = React.useState(false);

  console.log('jobCode', jobCode);
  const [isView, setIsView] = React.useState(false);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  React.useEffect(() => {
    if (!isEmptyNullUndefined(id)) {
      if (view || view == 'true') {
        getJobCodeDetails(id);
        setIsView(true);
      } else {
        getJobCodeDetails(id);
        setIsEdit(true);
      }
    }
    return () => {
      source2.cancel('Aborting all previous operations.');
    };
  }, []);

  const getJobCodeDetails = async (Id) => {
    try {
      const res = await jwtAxios.get(`${API_ROUTS.CompetencyCategory}${Id}`, {
        cancelToken: source.token,
      });

      if (res.status == 200) {
        let data = {...res.data};

        setJobCode(data);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
    }
  };

  const handleChangeJobCode = (event, fieldType, name) => {
    const tempJobCode = {...jobCode};
    const tempError = {...jobCodeError};

    if (
      fieldType == 'textfield' ||
      fieldType == 'dropdown' ||
      fieldType == 'radio'
    ) {
      tempJobCode[event.target.name] = event.target.value;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
    } else if (fieldType == 'date') {
      tempJobCode[name] = event;
      tempError[name].isError = false;
      tempError[name].errorMessage = '';
    }

    setJobCode(tempJobCode);
    setJobCodeError(tempError);
  };

  const validateJobCode = () => {
    let isValid = true;
    const tempError = {...jobCodeError};

    if (isEmptyNullUndefined(jobCode.status)) {
      tempError.status.isError = true;
      tempError.status.errorMessage = 'Please select status';
      isValid = false;
    }

    if (isEmptyNullUndefined(jobCode.name)) {
      tempError.name.isError = true;
      tempError.name.errorMessage = 'Please enter breakout name';
      isValid = false;
    }

    console.log('cliecked', isValid, jobCode);
    if (isValid) {
      if (isEdit) {
        updateForm();
      } else {
        submitForm();
      }
    } else {
      setJobCodeError(() => tempError);
    }
  };

  const submitForm = async () => {
    setLoading(() => true);

    let payload = {
      name: jobCode.name,
      libraryCode:jobCode.libraryCode,
      libraryName:jobCode.libraryName,
      status: jobCode.status,
      code:jobCode.code,
      companyId: selectedCompany?.id,
    };

    console.log(`API , ${API_ROUTS.CompetencyCategory}`);
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.CompetencyCategory}save`,
        payload,
      );
      if (response.status == 200) {
        dispatch(showMessage('Competency category submitted successfully..!'));
        Router.push(`/company-builder/competancy-category`);
        setLoading(() => false);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
      setLoading(() => false);
    }
  };

  const updateForm = async () => {
    setLoading(() => true);

    let payload = {
      name: jobCode.name,
      id:id,
      code: jobCode.code,
      libraryCode:jobCode.libraryCode,
      libraryName:jobCode.libraryName,
      status: jobCode.status,
      companyId: selectedCompany?.id,
    };

    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.CompetencyCategory}save`,
        payload,
      );
      if (response.status == 200 || response.status == 201) {
        dispatch(showMessage('Competency category updated successfully..!'));
        Router.push(`/company-builder/competancy-category`);
        setLoading(() => false);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
      setLoading(() => false);
    }
  };

  const getTitle = () => {
    if (isView) {
      return 'View Competency Category';
    } else if (!isEdit) {
      return 'Add Competency Category';
    } else {
      return 'Edit Competency Category';
    }
  };

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>{getTitle()}</h2>

      <AppCard>
        <Stack
          sx={{display: 'flex', justifyContent: 'center', alignItems: 'center'}}
        >
          <Card
            variant='outlined'
            sx={{width: '80%', boxShadow: 1, p: 2, mb: 10}}
          >
            <Stack>
              {/* NAME*********************************************************************************** */}
              {/* <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Job Title:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <TextField
                    size='small'
                    name='name'
                    disabled={isView}
                    label={'Title'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.name?.isError}
                    helperText={jobCodeError.name?.errorMessage}
                    value={jobCode.name ? jobCode.name : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'red',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack> */}
              {/* jobCode*********************************************************************************** */}
              {/* NAME*********************************************************************************** */}
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Library Name:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <TextField
                    size='small'
                    name='libraryName'
                    disabled={isView}
                    label={!isView && 'Library Name'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.libraryName?.isError}
                    helperText={jobCodeError.libraryName?.errorMessage}
                    value={jobCode.libraryName ? jobCode.libraryName : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack>
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Library Code:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <TextField
                    size='small'
                    name='libraryCode'
                    disabled={isView}
                    label={!isView && 'Library Code:'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.libraryCode?.isError}
                    helperText={jobCodeError.libraryCode?.errorMessage}
                    value={jobCode.libraryCode ? jobCode.libraryCode : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack>
              
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}> Competency Category Name:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <TextField
                    size='small'
                    name='name'
                    disabled={isView}
                    label={!isView && 'Competency Category  Name'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.name?.isError}
                    helperText={jobCodeError.name?.errorMessage}
                    value={jobCode.name ? jobCode.name : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack>

              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}> Competency Category Code:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <TextField
                    size='small'
                    name='code'
                    disabled={isView}
                    label={!isView && ' Competency Category Code'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.code?.isError}
                    helperText={jobCodeError.code?.errorMessage}
                    value={jobCode.code ? jobCode.code : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack>
              {/* STATUS *********************************************************************************** */}
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Status:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <FormControl
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'red',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  >
                    <InputLabel size='small' id='status'>
                      <IntlMessages id='configuration.dialogbox.Status' />
                    </InputLabel>
                    <Select
                      size='small'
                      name='status'
                      disabled={isView}
                      label={
                        <IntlMessages id='configuration.dialogbox.Status' />
                      }
                      labelId='status'
                      value={jobCode?.status || ''}
                      error={jobCodeError.status?.isError}
                      helperText={jobCodeError.status?.errorMessage}
                      onChange={(event) =>
                        handleChangeJobCode(event, 'dropdown')
                      }
                      variant='outlined'
                      sx={{...textFieldStyled, width: '100%'}}
                    >
                      <MenuItem key='Active' value='ACTIVE'>
                        <IntlMessages id='configuration.dialogbox.Status.Active' />
                      </MenuItem>
                      <MenuItem key='Inactive' value='INACTIVE'>
                        <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                      </MenuItem>
                    </Select>
                    <FormHelperText style={{color: '#d32f2f'}}>
                      {jobCodeError.status.errorMessage}
                    </FormHelperText>
                  </FormControl>
                </Stack>
              </Stack>
              {/* *********************************************************************************** */}
            </Stack>
          </Card>
        </Stack>
        {/* ////////add Stack for fixed////// */}
        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0,
          }}
        >
          <Stack
            direction='row'
            justifyContent='end'
            alignItems='center'
            spacing={2}
            sx={{
              pt: 5,
              ml: 3,
              //// add marging for fixed stack///
              margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
            }}
          >
            <Button
              color={footerButton.back.color}
              variant={footerButton.back.variant}
              sx={footerButton.back.sx}
              size={footerButton.back.size}
              onClick={() =>
                Router.push('/company-builder/competancy-category')
              }
            >
              <IntlMessages id='common.button.Back' />
            </Button>
            {!isView && (
              <Button
                color={footerButton.submit.color}
                variant={footerButton.submit.variant}
                sx={footerButton.submit.sx}
                size={footerButton.submit.size}
                disabled={loading}
                onClick={() => {
                  validateJobCode();
                }}
              >
                {loading ? (
                  <CircularProgress
                    sx={{
                      margin: '0px 1rem',
                      color: '#000000',
                      width: '25px !important',
                      height: '25px !important',
                    }}
                  />
                ) : (
                  <Stack>
                    {isEdit ? (
                      <IntlMessages id='common.button.Update' />
                    ) : (
                      <IntlMessages id='common.button.Submit' />
                    )}
                  </Stack>
                )}
              </Button>
            )}
          </Stack>
        </Stack>
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default AddJobCode;
