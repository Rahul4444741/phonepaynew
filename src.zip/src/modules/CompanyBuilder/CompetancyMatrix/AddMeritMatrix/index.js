import jwtAxios from '@crema/services/auth/jwt-auth';
import IntlMessages from '@crema/utility/IntlMessages';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import EditIcon from '@mui/icons-material/Edit';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import {
  Card,
  Checkbox,
  CircularProgress,
  FormControlLabel,
  IconButton,
  InputAdornment,
  ListItemIcon,
  Paper,
  Radio,
  RadioGroup,
} from '@mui/material';
import Button from '@mui/material/Button';
import FormControl from '@mui/material/FormControl';
import FormHelperText from '@mui/material/FormHelperText';
import InputLabel from '@mui/material/InputLabel';
import ListItemText from '@mui/material/ListItemText';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import Stack from '@mui/material/Stack';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import TextField from '@mui/material/TextField';
import axios from 'axios';
import ExcelJS from 'exceljs';
import _ from 'lodash';
import Router, { useRouter } from 'next/router';
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getALLRatings } from 'redux/actions/Ratings';
import { API_ROUTS } from 'shared/constants/ApiRouts';
import { footerButton } from 'shared/constants/AppConst';
import { AppCard, AppInfoView } from '../../../../@crema';
import AppAnimate from '../../../../@crema/core/AppAnimate';
import AppPageMeta from '../../../../@crema/core/AppPageMeta';
import { fetchError, showInfo, showMessage } from '../../../../redux/actions';
import {
  apiCatchErrorMessage,
  isEmptyNullUndefined,
} from '../../../../shared/utils/CommonUtils';

const textFieldStyled = {
  backgroundColor: 'white',
  mb: 2,
  width: {xs: '100%', xl: '60%', md: '75%'},
};
const iconButtonStyled = {padding: '2px 10px'};

const CustomTableCell = styled(TableCell)({
  borderBottom: '1px solid #dddddd',
});

// Custom TableHeaderCell component with border
const CustomTableHeaderCell = styled(TableCell)({
  border: '1px solid #dddddd',
});

const StyledTableCell = styled(TableCell)(({theme}) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.primary,
    fontWeight: 'bold',
  },
  ['&.MuiTableCell-root']: {
    padding: '5px 10px 5px 10px',
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const conditionOptions = [
  {name: 'Equal To', value: '='},
  {name: 'Less Than', value: '<'},
  {name: 'Less Than Equal To', value: '<='},
  {name: 'Greater Than', value: '>'},
  {name: 'Greater Than Equal To', value: '>='},
];

const MeritMatrix = () => {
  const router = useRouter();

  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const ratingsData = useSelector(({ratings}) => ratings.ratingsData);

  const {id} = router.query;
  const dispatch = useDispatch();

  const initialMeritMatrix = {
    name: null,
    calculateType: null,
    rangeCalculateType: null,
    salarySetUpId: null,
    status: null,
    multiplier: false,
    company: {
      id: selectedCompany?.id,
    },
    meritMatrixVariables: [],
    meritMatrixMultiplier: [],
  };
  const initialFormError = {
    name: {isError: false, errorMessage: ''},
    calculateType: {isError: false, errorMessage: ''},
    rangeCalculateType: {isError: false, errorMessage: ''},
    salarySetUpId: {isError: false, errorMessage: ''},
    status: {isError: false, errorMessage: ''},
    multiplier: {isError: false, errorMessage: ''},
    meritMatrixVariables: {isError: false, errorMessage: ''},
    meritMatrixMultiplier: {isError: false, errorMessage: ''},
    selectedRatings: {isError: false, errorMessage: ''},
  };

  const [meritMatrix, setMeritMatrix] = React.useState(initialMeritMatrix);
  const [formError, setFormError] = React.useState(initialFormError);

  const [isEdit, setIsEdit] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [genrateLoading, setGenrateLoading] = React.useState(false);
  const [variablesList, setVariablesList] = useState([]);
  const [selectedRatings, setSelectedRatings] = useState([]);
  const [matrixData, setMatrixData] = useState([]);
  const [variableOne, setVariableOne] = useState([]);
  const [variableTwo, setVariableTwo] = useState([]);
  const [salaryData, setSalaryData] = useState([]);

  const [cellValueErrors, setCellValueErrors] = useState([]);

  const initialMultiplierForm = {
    id: null,
    multiplier: false,
    multiplierVariable: null,
    selectedRatings: null,
    calculateType: null,
    meritMatrixMultiplierScales: null,
  };
  const initialMultiplierFormError = {
    multiplier: {isError: false, errorMessage: ''},
    multiplierVariable: {isError: false, errorMessage: ''},
    selectedRatings: {isError: false, errorMessage: ''},
    calculateType: {isError: false, errorMessage: ''},
    meritMatrixMultiplierScales: {isError: false, errorMessage: ''},
  };
  const [multiplierForm, setMultiplierForm] = useState(initialMultiplierForm);
  const [multiplierFormError, setMultiplierFormError] = useState(
    initialMultiplierFormError,
  );

  let rawMultiplierData = {
    id: null,
    scaleName: null,
    lowerCondition: null,
    lowerCircuit: null,
    upperCondition: null,
    upperCircuit: null,
    scaleValue: null,
    isWriteAction: true,
  };

  let rawMultiplierDataError = {
    scaleName: {isError: false, errorMessage: ''},
    lowerCondition: {isError: false, errorMessage: ''},
    lowerCircuit: {isError: false, errorMessage: ''},
    upperCondition: {isError: false, errorMessage: ''},
    upperCircuit: {isError: false, errorMessage: ''},
    scaleValue: {isError: false, errorMessage: ''},
  };

  const [multiplierData, setMultiplierData] = React.useState([]);
  const [multiplierDataErrors, setMultiplierDataErrors] = React.useState([]);

  const [multiplierVariablesList, setMultiplierVariablesList] = useState([]);
  const [multiplierName, setMultiplierName] = useState([]);
  const [multiplierValues, setMultiplierValues] = useState([]);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();

  React.useEffect(() => {
    if (!isEmptyNullUndefined(selectedCompany.id)) {
      getVariableList();
      getAllActiveSalary(selectedCompany.id);
      dispatch(getALLRatings(selectedCompany.id, 'ACTIVE'));
      if (!isEmptyNullUndefined(id)) {
        setIsEdit(true);
        getSavedMeritMatrix(id);
      }
    }
  }, []);
  React.useEffect(() => {
    if (multiplierForm.multiplierVariable == 'Compa Ratio') {
      handleInsertMultiplierData();
    }
  }, []);

  React.useEffect(() => {
    if (multiplierForm.multiplier == true || multiplierForm.multiplier) {
      getMultipliersVariableList();
    }
  }, [multiplierForm.multiplier]);

  React.useEffect(() => {
    if (
      !isEdit &&
      !isEmptyNullUndefined(multiplierForm.multiplierVariable) &&
      multiplierForm.multiplierVariable != 'Compa Ratio'
    ) {
      if (multiplierForm.multiplierVariable == 'Rating') {
        if (!isEmptyNullUndefined(multiplierForm.selectedRatings)) {
          getMultiplierNameByVariable(
            multiplierForm.multiplierVariable,
            multiplierForm.selectedRatings,
          );
        }
      } else {
        getMultiplierNameByVariable(multiplierForm.multiplierVariable, null);
      }
    }
  }, [multiplierForm.multiplierVariable, multiplierForm.selectedRatings]);

  // Initialize multiplierValues with objects for all scaleName
  React.useEffect(() => {
    setMultiplierValues(
      multiplierName.map((scaleName) => ({
        scaleName: scaleName,
        scaleValue: null,
        lowerCircuit: null,
        upperCircuit: null,
        lowerCondition: null,
        upperCondition: null,
      })),
    );
  }, [multiplierName]);

  const getVariableList = async () => {
    try {
      const res = await jwtAxios.get(`${API_ROUTS.meritMatrixDropdown}`, {
        cancelToken: source.token,
      });
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no variables'));
          setVariablesList([]);
        } else {
          setVariablesList(res.data);
        }
      } else {
        setVariablesList([]);
      }
    } catch (e) {
      if (axios.isCancel(e)) {
      } else {
        apiCatchErrorMessage(e, dispatch, fetchError);
      }
      setVariablesList([]);
    }
  };

  const getMultipliersVariableList = async () => {
    try {
      const res = await jwtAxios.get(`${API_ROUTS.multiplierDropdown}`, {
        cancelToken: source.token,
      });
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no variables'));
          setMultiplierVariablesList([]);
        } else {
          setMultiplierVariablesList(res.data);
        }
      } else {
        setMultiplierVariablesList([]);
      }
    } catch (e) {
      if (axios.isCancel(e)) {
      } else {
        apiCatchErrorMessage(e, dispatch, fetchError);
      }
      setMultiplierVariablesList([]);
    }
  };

  const getSavedMeritMatrix = async (Id) => {
    try {
      const res = await jwtAxios.get(`${API_ROUTS.getMeritMatrix}/${Id}`, {
        cancelToken: source.token,
      });
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no matrix data'));
          setMatrixData([]);
        } else {
          setMatrixData(res.data);
          let tempMat = {
            name: res.data.meritMatrixEntity?.name,
            calculateType: res.data.meritMatrixEntity?.calculateType,
            status: res.data.meritMatrixEntity?.status,
            rangeCalculateType: res.data.meritMatrixEntity?.rangeCalculateType,
            salarySetUpId: res.data.meritMatrixEntity?.salarySetUpId,
            multiplier: res.data.meritMatrixEntity?.multiplier,
            meritMatrixMultiplier:
              res.data.meritMatrixEntity?.meritMatrixMultiplier,
            meritMatrixVariables:
              res.data.meritMatrixEntity?.meritMatrixVariables,
          };
          let RatingVariable =
            res.data.meritMatrixEntity.meritMatrixVariables?.find(
              (rating) => rating.name == 'Rating',
            );
          if (!isEmptyNullUndefined(RatingVariable)) {
            setSelectedRatings(() => RatingVariable?.ratingIds);
          }
          setMeritMatrix(tempMat);
          setVariableOne(res.data['variable 1']);
          setVariableTwo(res.data['variable 2']);

          let tempMultiplierForm = {
            id: res.data.meritMatrixEntity?.meritMatrixMultiplier[0]?.id,
            multiplier: res.data.meritMatrixEntity.multiplier,
            multiplierVariable:
              res.data.meritMatrixEntity.meritMatrixMultiplier[0]?.name,
            selectedRatings:
              res.data.meritMatrixEntity?.meritMatrixMultiplier[0]
                ?.ratingIds[0],
            calculateType:
              res.data.meritMatrixEntity.meritMatrixMultiplier[0]
                ?.calculateType,
            meritMatrixMultiplierScales: null,
          };
          setMultiplierForm(() => tempMultiplierForm);
          if (
            res.data.meritMatrixEntity.meritMatrixMultiplier[0]?.name ==
            'Compa Ratio'
          ) {
            setMultiplierData(
              res.data.meritMatrixEntity.meritMatrixMultiplier[0]
                ?.meritMatrixMultiplierScales,
            );

            let tempMultiplierDataError =
              res.data.meritMatrixEntity.meritMatrixMultiplier[0]?.meritMatrixMultiplierScales?.map(
                () => rawMultiplierDataError,
              );
            setMultiplierDataErrors(() => tempMultiplierDataError);
          } else {
            setMultiplierValues(
              res.data.meritMatrixEntity.meritMatrixMultiplier[0]
                ?.meritMatrixMultiplierScales,
            );
          }
        }
      } else {
        setMatrixData([]);
      }
    } catch (e) {
      if (axios.isCancel(e)) {
      } else {
        apiCatchErrorMessage(e, dispatch, fetchError);
      }
      setMatrixData([]);
    }
  };

  const getAllActiveSalary = async (companyId) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.salarySetup_companyID}${companyId}?status=ACTIVE`,
        {cancelToken: source.token},
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no salary for selected company'));
          setSalaryData([]);
        } else {
          let tempRes = JSON.parse(JSON.stringify(res.data));
          const onlyActive = tempRes.filter((e) => e.status === 'ACTIVE');
          // Create a copy of the filtered array and then reverse it
          const reversed = [...onlyActive].reverse();
          setSalaryData(reversed);
        }
      } else {
        setSalaryData([]);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setSalaryData([]);
    }
  };

  // ********************Table handlers*********************************************

  const handleInsertMultiplierData = () => {
    const tempMultiplierDataErrors = _.cloneDeep(multiplierDataErrors);
    const tempMultiplierData = [...multiplierData];

    tempMultiplierDataErrors.push(rawMultiplierDataError);
    tempMultiplierData.push(rawMultiplierData);
    setMultiplierDataErrors(() => tempMultiplierDataErrors);
    setMultiplierData(() => tempMultiplierData);
  };

  const handleEditMultiplierData = (index) => {
    const tempMultiplierData = JSON.parse(JSON.stringify(multiplierData));
    const selectedRow = tempMultiplierData[index];
    selectedRow.isWriteAction = true;
    tempMultiplierData[index] = selectedRow;
    setMultiplierData(() => tempMultiplierData);
  };

  const handleChangeMultiplierData = (event, index, fieldType) => {
    const tempMultiplierDataErrors = _.cloneDeep(multiplierDataErrors);
    const tempMultiplierFormError = _.cloneDeep(multiplierFormError);
    const tempMultiplierData = JSON.parse(JSON.stringify(multiplierData));
    const selectedRow = tempMultiplierData[index];
    const selectedRowError = tempMultiplierDataErrors[index];

    if (fieldType == 'textField' || fieldType == 'dropdown') {
      selectedRow[event.target.name] = event.target.value;
      selectedRowError[event.target.name].isError = false;
      selectedRowError[event.target.name].errorMessage = '';
      tempMultiplierFormError.meritMatrixMultiplierScales.isError = true;
      tempMultiplierFormError.meritMatrixMultiplierScales.errorMessage = '';
    }

    tempMultiplierData[index] = selectedRow;
    tempMultiplierDataErrors[index] = selectedRowError;

    setMultiplierFormError(() => tempMultiplierFormError);
    setMultiplierDataErrors(() => tempMultiplierDataErrors);
    setMultiplierData(() => tempMultiplierData);
  };

  
  const handleDeleteMultiplierData = async (index) => {
    const tempMultiplierDataErrors = _.cloneDeep(multiplierDataErrors);
    const tempMultiplierData = JSON.parse(JSON.stringify(multiplierData));

    tempMultiplierData.splice(index, 1);
    tempMultiplierDataErrors.splice(index, 1);
    setMultiplierDataErrors(() => tempMultiplierDataErrors);
    setMultiplierData(() => tempMultiplierData);
  };

  const handleAddMultiplierData = (index) => {
    const tempMultiplierData = _.cloneDeep(multiplierData);
    const selectedRow = tempMultiplierData[index];
    const isValid = getMultiplierDataIsValid(tempMultiplierData[index], index);

    if (isValid) {
      selectedRow.isWriteAction = false;
      tempMultiplierData[index] = selectedRow;
      setMultiplierData(tempMultiplierData);
    }
  };

  const getMultiplierDataIsValid = (multiplierRow, index) => {
    let isValid = true;
    const tempMultiplierDataErrors = _.cloneDeep(multiplierDataErrors);
    const tempMultiplierFormError = _.cloneDeep(multiplierFormError);
    const selectedRowError = tempMultiplierDataErrors[index];

    if (isEmptyNullUndefined(multiplierRow.scaleName)) {
      selectedRowError.scaleName.isError = true;
      selectedRowError.scaleName.errorMessage = (
        <IntlMessages id='error.required' />
      );
      isValid = false;
    }

    if (
      !isEmptyNullUndefined(multiplierRow.lowerCondition) &&
      isEmptyNullUndefined(multiplierRow.lowerCircuit)
    ) {
      selectedRowError.lowerCircuit.isError = true;
      selectedRowError.lowerCircuit.errorMessage = (
        <IntlMessages id='error.required' />
      );
      isValid = false;
    }

    if (
      multiplierForm?.calculateType == 'Range' &&
      !isEmptyNullUndefined(multiplierRow.upperCondition) &&
      isEmptyNullUndefined(multiplierRow.upperCircuit)
    ) {
      selectedRowError.upperCircuit.isError = true;
      selectedRowError.upperCircuit.errorMessage = (
        <IntlMessages id='error.required' />
      );
      isValid = false;
    }
    if (isEmptyNullUndefined(multiplierRow.scaleValue)) {
      selectedRowError.scaleValue.isError = true;
      selectedRowError.scaleValue.errorMessage = (
        <IntlMessages id='error.required' />
      );
      isValid = false;
    }

    if (
      multiplierForm?.calculateType == 'Range' &&
      isEmptyNullUndefined(multiplierRow.lowerCondition) &&
      isEmptyNullUndefined(multiplierRow.upperCondition)
    ) {
      tempMultiplierFormError.meritMatrixMultiplierScales.isError = true;
      tempMultiplierFormError.meritMatrixMultiplierScales.errorMessage =
        'Please select atleast one condition';
      isValid = false;
    }

    tempMultiplierDataErrors[index] = selectedRowError;
    setMultiplierDataErrors(tempMultiplierDataErrors);
    setMultiplierFormError(tempMultiplierFormError);
    return isValid;
  };

  // *************************************************************************
  const handleChangeMultiplier = (event, fieldType, name) => {
    const tempMultiplierForm = {...multiplierForm};
    const tempMultiplierFormError = {...multiplierFormError};

    if (
      fieldType === 'textfield' ||
      fieldType === 'dropdown' ||
      fieldType === 'radio'
    ) {
      tempMultiplierForm[event.target.name] = event.target.value;
      tempMultiplierFormError[event.target.name].isError = false;
      tempMultiplierFormError[event.target.name].errorMessage = '';
    }
    setMultiplierData(() => []);
    setMultiplierDataErrors(() => []);
    setMultiplierForm(() => tempMultiplierForm);
    setMultiplierFormError(() => tempMultiplierFormError);
  };

  const getTableName = (list, name) => {
    if (!isEmptyNullUndefined(list) && !isEmptyNullUndefined(name)) {
      const findObject = list?.find((item) => item.name == name);
      return findObject?.tableName ? findObject.tableName : '';
    }
  };

  const getMultiplierNameByVariable = async (variableName, ratingId) => {
    let payload = {
      id: selectedCompany && selectedCompany?.id,
      tableName: getTableName(multiplierVariablesList, variableName),
      ratingIds: ratingId ? [ratingId] : null,
    };

    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.multiplierDropdown}/values`,
        payload,
      );
      if (response.status == 201 || response.status == 200) {
        setMultiplierName(response.data);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleChangeMultiplierInput = (event, scaleName) => {
    const {value} = event.target;
    const scaleValue = value.trim() === '' ? null : value;

    // Update the scaleValue for the specific scaleName
    setMultiplierValues((prevState) => {
      const updatedValues = prevState.map((item) => {
        if (item.scaleName === scaleName) {
          return {...item, scaleValue};
        }
        return item;
      });
      return updatedValues;
    });
  };

  // *************************************************************************

  const handleChangeMeritMatrix = (event, fieldType, name) => {
    const tempMeritMatrix = {...meritMatrix};
    const tempError = {...formError};

    if (fieldType === 'textfield' || fieldType === 'dropdown') {
      tempMeritMatrix[event.target.name] = event.target.value;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
      if (event.target.value == 'Amount') {
        tempMeritMatrix.salarySetUpId = null;
        tempError.salarySetUpId.isError = false;
        tempError.salarySetUpId.errorMessage = '';
      }
    } else if (fieldType == 'radio') {
      tempMeritMatrix[event.target.name] = event.target.value;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
    } else if (fieldType === 'multiDropdown') {
      if (event.target.name === 'meritMatrixVariables') {
        const value = event.target.value;
        const selectedVariables = variablesList
          .filter((variable) => value.includes(variable.name))
          .map(({name, tableName}) => ({name, tableName}));

        tempMeritMatrix.meritMatrixVariables = selectedVariables;
        tempError.meritMatrixVariables.isError =
          selectedVariables.length === 0 || selectedVariables.length > 2;
        tempError.meritMatrixVariables.errorMessage =
          selectedVariables.length === 0 ? (
            <IntlMessages id='error.pleaseSelectTwoValues' />
          ) : selectedVariables.length > 2 ? (
            <IntlMessages id='error.pleaseSelectTwoValues' />
          ) : (
            ''
          );
      }
    } else if (fieldType == 'selectedRatings') {
      setSelectedRatings(() => event.target.value);
      tempError.selectedRatings.isError = false;
      tempError.selectedRatings.errorMessage = '';
    }

    setMeritMatrix(tempMeritMatrix);
    setFormError(tempError);
  };

  const generateTableHandler = () => {
    let isValid = true;
    let tempMeritMatrix = {...meritMatrix};
    let tempFormError = {...formError};

    if (isEmptyNullUndefined(meritMatrix.name)) {
      tempFormError.name.isError = true;
      tempFormError.name.errorMessage = (
        <IntlMessages id='error.pleaseEnterName' />
      );
      isValid = false;
    }
    if (isEmptyNullUndefined(meritMatrix.status)) {
      tempFormError.status.isError = true;
      tempFormError.status.errorMessage = (
        <IntlMessages id='error.pleaseSelectStatus' />
      );
      isValid = false;
    }
    if (isEmptyNullUndefined(meritMatrix.meritMatrixVariables)) {
      tempFormError.meritMatrixVariables.isError = true;
      tempFormError.meritMatrixVariables.errorMessage = (
        <IntlMessages id='error.pleaseSelectVariables' />
      );
      isValid = false;
    }

    if (
      isCombinedRatingPresent(meritMatrix.meritMatrixVariables) &&
      isEmptyNullUndefined(selectedRatings)
    ) {
      tempFormError.selectedRatings.isError = true;
      tempFormError.selectedRatings.errorMessage = 'Please select ratings.';
      isValid = false;
    }

    if (isEmptyNullUndefined(meritMatrix.calculateType)) {
      tempFormError.calculateType.isError = true;
      tempFormError.calculateType.errorMessage = (
        <IntlMessages id='error.pleaseSelectCalculationType' />
      );
      isValid = false;
    }
    if (
      meritMatrix.calculateType == 'Range' &&
      isEmptyNullUndefined(meritMatrix.rangeCalculateType)
    ) {
      tempFormError.rangeCalculateType.isError = true;
      tempFormError.rangeCalculateType.errorMessage = (
        <IntlMessages id='error.pleaseSelectCalculationType' />
      );
      isValid = false;
    }
    if (
      (meritMatrix?.calculateType == 'Percentage' ||
        (meritMatrix?.calculateType == 'Range' &&
          meritMatrix.rangeCalculateType == 'Percentage')) &&
      isEmptyNullUndefined(meritMatrix.salarySetUpId)
    ) {
      tempFormError.salarySetUpId.isError = true;
      tempFormError.salarySetUpId.errorMessage = (
        <IntlMessages id='error.pleaseSelectSalaryType' />
      );
      isValid = false;
    }

    if (isValid) {
      generate();
    } else {
      setFormError(tempFormError);
    }
  };

  const generate = async () => {
    setGenrateLoading(true);
    let tempMeritMatrix = {...meritMatrix};
    tempMeritMatrix.meritMatrixVariables = meritMatrix.meritMatrixVariables.map(
      (variable) => {
        if (variable.name === 'Rating') {
          return {
            ...variable,
            ratingIds: selectedRatings,
          };
        } else {
          return {
            ...variable,
            ratingIds: null,
          };
        }
      },
    );

    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.saveMeritMatrix}`,
        tempMeritMatrix,
      );
      if (response.status == 201 || response.status == 200) {
        dispatch(showMessage('Merit matrix generated successfully...!'));
        getSavedMeritMatrix(response.data.meritMatrixEntity.id);
        setGenrateLoading(false);
      } else {
        setGenrateLoading(false);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
      setGenrateLoading(false);
    }
  };

  const renderMenuItem = (variable, index) => {
    const isSelected = meritMatrix.meritMatrixVariables?.some(
      (item) => item.name === variable.name,
    );

    return (
      <MenuItem
        key={'role_' + index}
        value={variable.name}
        disabled={!isSelected && meritMatrix.meritMatrixVariables?.length === 2}
      >
        <ListItemIcon>
          <Checkbox checked={isSelected} />
        </ListItemIcon>
        <ListItemText primary={variable.name} />
      </MenuItem>
    );
  };
  //******************* */ Matrix Table Data onChangeHandler*****************************
  const handleCellChange = (event, variable1, variable2, type) => {
    const value = event.target.value;
    // Update the matrixData state with the new value for the corresponding cell
    let tempMatrixData = {...matrixData};
    let tempCellValueError = {...cellValueErrors};
    const updatedMatrixData = [...matrixData['matrix ']];
    let isValid = true;

    const cellIndex = updatedMatrixData.findIndex(
      (item) =>
        item['variable 1'] == variable1 && item['variable 2'] == variable2,
    );

    if (cellIndex !== -1) {
      if (type == 'minRange') {
        if (value < 0) {
          tempCellValueError[cellIndex] = {
            isError: true,
            errorMessage: <IntlMessages id='error.pleaseEnterPositiveValue' />,
          };
          isValid = false;
        }
        if (isValid) {
          updatedMatrixData[cellIndex].meritMatrixValue.minRange = value;
          updatedMatrixData[cellIndex].meritMatrixValue.matrixValue = null;
          tempMatrixData['matrix '] = updatedMatrixData;
          tempCellValueError[cellIndex] = {
            isError: false,
            errorMessage: '',
          };
        }
      }
      if (type == 'maxRange') {
        if (value < 0) {
          tempCellValueError[cellIndex] = {
            isError: true,
            // errorMessage: 'Please enter positive value',
            errorMessage: <IntlMessages id='error.pleaseEnterPositiveValue' />,
          };
          isValid = false;
        }
        if (isValid) {
          updatedMatrixData[cellIndex].meritMatrixValue.maxRange = value;
          updatedMatrixData[cellIndex].meritMatrixValue.matrixValue = null;
          tempMatrixData['matrix '] = updatedMatrixData;
          tempCellValueError[cellIndex] = {
            isError: false,
            errorMessage: '',
          };
        }
      }
      if (type == 'matrixValue') {
        if (value < 0) {
          tempCellValueError[cellIndex] = {
            isError: true,
            errorMessage: 'Enter positive value',
          };
          isValid = false;
        }
        if (
          meritMatrix.calculateType == 'Percentage' &&
          (value < 0 || value > 100)
        ) {
          tempCellValueError[cellIndex] = {
            isError: true,
            errorMessage: <IntlMessages id='error.percentageValidation' />,
          };
          isValid = false;
        }
        if (isValid) {
          updatedMatrixData[cellIndex].meritMatrixValue.matrixValue = value;
          updatedMatrixData[cellIndex].meritMatrixValue.minRange = null;
          updatedMatrixData[cellIndex].meritMatrixValue.maxRange = null;
          tempMatrixData['matrix '] = updatedMatrixData;
          tempCellValueError[cellIndex] = {
            isError: false,
            errorMessage: '',
          };
        }
      }
      setCellValueErrors(tempCellValueError);
      setMatrixData(tempMatrixData);
    }
  };

  const handleCellChangeSingle = (event, variable1, type) => {
    const value = event.target.value;

    // Update the matrixData state with the new value for the corresponding cell
    const updatedMatrixData = [...matrixData['matrix ']];
    const cellIndex = updatedMatrixData.findIndex(
      (item) => item['variable 1'] === variable1,
    );

    if (cellIndex !== -1) {
      let isValid = true;
      const tempMatrixData = {...matrixData};
      const tempCellValueError = {...cellValueErrors};

      if (type === 'minRange' || type === 'maxRange') {
        if (value < 0) {
          tempCellValueError[cellIndex] = {
            isError: true,
            errorMessage: <IntlMessages id='error.pleaseEnterPositiveValue' />,
          };
          isValid = false;
        }
        if (
          meritMatrix.rangeCalculateType === 'Percentage' &&
          (value < 0 || value > 100)
        ) {
          tempCellValueError[cellIndex] = {
            isError: true,
            errorMessage: <IntlMessages id='error.percentageValidation' />,
          };
          isValid = false;
        }
        if (isValid) {
          updatedMatrixData[cellIndex].meritMatrixValue[type] = value;
          updatedMatrixData[cellIndex].meritMatrixValue.matrixValue = null;
          tempCellValueError[cellIndex] = {
            isError: false,
            errorMessage: '',
          };
        }
      } else if (type === 'matrixValue') {
        if (value < 0) {
          tempCellValueError[cellIndex] = {
            isError: true,
            errorMessage: 'Enter positive value',
          };
          isValid = false;
        }
        if (
          meritMatrix.calculateType === 'Percentage' &&
          (value < 0 || value > 100)
        ) {
          tempCellValueError[cellIndex] = {
            isError: true,
            errorMessage: <IntlMessages id='error.percentageValidation' />,
          };
          isValid = false;
        }
        if (isValid) {
          updatedMatrixData[cellIndex].meritMatrixValue.matrixValue = value;
          updatedMatrixData[cellIndex].meritMatrixValue.minRange = null;
          updatedMatrixData[cellIndex].meritMatrixValue.maxRange = null;
          tempCellValueError[cellIndex] = {
            isError: false,
            errorMessage: '',
          };
        }
      }

      tempMatrixData['matrix '] = updatedMatrixData;
      setCellValueErrors(tempCellValueError);
      setMatrixData(tempMatrixData);
    }
  };

  // ******************************************************************
  const validateSubmitHandler = () => {
    let isValid = true;
    let tempMultiplierFormError = _.cloneDeep(multiplierFormError);

    if (
      multiplierForm.multiplier == 'true' ||
      multiplierForm.multiplier == true
    ) {
      if (isEmptyNullUndefined(multiplierForm.multiplierVariable)) {
        tempMultiplierFormError.multiplierVariable.isError = true;
        tempMultiplierFormError.multiplierVariable.errorMessage =
          'Please select multiplier variable';
        isValid = false;
      }
      if (
        multiplierForm.multiplierVariable == 'Rating' &&
        isEmptyNullUndefined(multiplierForm.selectedRatings)
      ) {
        tempMultiplierFormError.selectedRatings.isError = true;
        tempMultiplierFormError.selectedRatings.errorMessage =
          'Please select rating';
        isValid = false;
      }
      if (
        multiplierForm.multiplierVariable == 'Compa Ratio' &&
        isEmptyNullUndefined(multiplierForm.calculateType)
      ) {
        tempMultiplierFormError.calculateType.isError = true;
        tempMultiplierFormError.calculateType.errorMessage =
          'Please select multiplier calculate type';
        isValid = false;
      }
      if (
        multiplierForm.multiplierVariable == 'Compa Ratio' &&
        isEmptyNullUndefined(multiplierData)
      ) {
        tempMultiplierFormError.meritMatrixMultiplierScales.isError = true;
        tempMultiplierFormError.meritMatrixMultiplierScales.errorMessage =
          'Please add multiplier scale';
        isValid = false;
      }
      if (multiplierData.some((item) => item.isWriteAction == true)) {
        tempMultiplierFormError.meritMatrixMultiplierScales.isError = true;
        tempMultiplierFormError.meritMatrixMultiplierScales.errorMessage =
          'Close all rows checkboxes';
        isValid = false;
      }
    }
    if (isValid) {
      submitHandler();
    } else {
      setMultiplierFormError(() => tempMultiplierFormError);
    }
  };

  const submitHandler = async () => {
    // setLoading(true);
    const meritMatrixId = matrixData.meritMatrixEntity.id;
    let transformedData = [];
    if (meritMatrix.calculateType != 'Range') {
      transformedData = matrixData['matrix '].map((item) => ({
        meritMatrixId: meritMatrixId,
        matrixValue: item.meritMatrixValue.matrixValue,
        meritMatrixValueId: item.meritMatrixValue.id,
      }));
    } else {
      transformedData = matrixData['matrix '].map((item) => ({
        meritMatrixId: meritMatrixId,
        minRange: item.meritMatrixValue.minRange,
        maxRange: item.meritMatrixValue.maxRange,
        meritMatrixValueId: item.meritMatrixValue.id,
      }));
    }

    let compaRatioData = multiplierData?.map((item) => {
      const {isWriteAction, ...rest} = item;
      return rest;
    });

    let tempMeritMatrixMultiplier = [];
    tempMeritMatrixMultiplier.push({
      id: multiplierForm?.id || null,
      name: multiplierForm.multiplierVariable,
      tableName: getTableName(
        multiplierVariablesList,
        multiplierForm.multiplierVariable,
      ),
      ratingIds: multiplierForm.selectedRatings
        ? [multiplierForm?.selectedRatings]
        : null,
      calculateType: multiplierForm.calculateType,
      meritMatrixMultiplierScales:
        multiplierForm.multiplierVariable == 'Compa Ratio'
          ? compaRatioData
          : multiplierValues,
    });

    let payload = {
      matrixData: transformedData,
      matrixMultiplierData: {
        id: meritMatrixId,
        multiplier: multiplierForm.multiplier == 'true' ? true : false,
        meritMatrixMultiplier: tempMeritMatrixMultiplier,
      },
    };

    

    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.saveMeritMatrixTable}`,
        payload,
      );
      if (response.status == 200) {
        dispatch(showMessage('Merit matrix saved successfully...!'));
        Router.push('/company-builder/merit-matrix');
      } else {
        setLoading(false);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
      setLoading(false);
    }
  };

  const handleDownloadExcel = async () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Sheet1');

    // Add table data
    if (
      !isEmptyNullUndefined(variableOne) &&
      !isEmptyNullUndefined(variableTwo)
    ) {
      // Add table headers
      const headerRow = worksheet.addRow(['', ...variableOne]);
      headerRow.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: {argb: 'F0F0F0'},
      };

      variableTwo.forEach((variable2) => {
        const rowData = [variable2];
        variableOne.forEach((variable1) => {
          const cellData = matrixData['matrix '].find(
            (item) =>
              item['variable 1'] === variable1 &&
              item['variable 2'] === variable2,
          );

          if (cellData) {
            if (meritMatrix.calculateType === 'Range') {
              const value1 = cellData.meritMatrixValue.minRange;
              const value2 = cellData.meritMatrixValue.maxRange;
              rowData.push(
                value1 !== null && value2 !== null
                  ? `${value1}-${value2}`
                  : 'N.A',
              );
            } else {
              rowData.push(
                cellData.meritMatrixValue.matrixValue !== null
                  ? cellData.meritMatrixValue.matrixValue
                  : 'N.A',
              );
            }
          } else {
            rowData.push('N.A');
          }
        });
        worksheet.addRow(rowData);
      });
    } else {
      // Add table data for variableOne
      variableOne.forEach((variable) => {
        const rowData = [variable];

        const cellData = matrixData['matrix '].find(
          (item) => item['variable 1'] === variable,
        );

        if (cellData) {
          if (meritMatrix.calculateType === 'Range') {
            const value1 = cellData.meritMatrixValue.minRange;
            const value2 = cellData.meritMatrixValue.maxRange;
            rowData.push(
              value1 !== null && value2 !== null
                ? `${value1}-${value2}`
                : 'N.A',
            );
          } else {
            rowData.push(
              cellData.meritMatrixValue.matrixValue !== null
                ? cellData.meritMatrixValue.matrixValue
                : 'N.A',
            );
          }
        } else {
          rowData.push('N.A');
        }

        worksheet.addRow(rowData);
      });
    }
    // Generate a blob from the workbook
    const excelBlob = await workbook.xlsx.writeBuffer();

    // Create a downloadable URL for the blob
    const excelBlobUrl = window.URL.createObjectURL(new Blob([excelBlob]));

    // Create an anchor element to trigger the download
    const downloadLink = document.createElement('a');
    downloadLink.href = excelBlobUrl;
    downloadLink.download = 'merit-matrix.xlsx';

    // Append the anchor element to the body and trigger the click event
    document.body.appendChild(downloadLink);
    downloadLink.click();

    // Clean up: remove the anchor element and revoke the URL
    document.body.removeChild(downloadLink);
    window.URL.revokeObjectURL(excelBlobUrl);
  };

  const isCombinedRatingPresent = (data) => {
    return data.some((item) => item.name == 'Rating');
  };

  

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      {isEdit ? (
        <h2 style={{marginBottom: 20}}>
          {' '}
          <IntlMessages id='matrix.updateMeritMatrix' />
        </h2>
      ) : (
        <h2 style={{marginBottom: 20}}>
          <IntlMessages id='matrix.addMeritMatrix' />
        </h2>
      )}

      <AppCard>
        <Stack>
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>
                <IntlMessages id='matrix.nameOfMeritMatrix' />
                {/* Name of merit matrix */}
              </Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <TextField
                size='small'
                name='name'
                label={<IntlMessages id='calibration.Name' />}
                onChange={(event) =>
                  handleChangeMeritMatrix(event, 'textfield', 'name')
                }
                variant='outlined'
                disabled={isEdit || !isEmptyNullUndefined(matrixData)}
                error={formError.name.isError}
                helperText={formError.name.errorMessage}
                value={meritMatrix.name ? meritMatrix.name : ''}
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              />
            </Stack>
          </Stack>

          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>Merit matrix status : </Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id='status'>
                  <IntlMessages id='configuration.dialogbox.Status' />
                </InputLabel>
                <Select
                  size='small'
                  name='status'
                  disabled={isEdit || !isEmptyNullUndefined(matrixData)}
                  label='Status'
                  labelId='status'
                  value={meritMatrix?.status || ''}
                  error={formError.status?.isError}
                  helperText={formError.status?.errorMessage}
                  onChange={(event) =>
                    handleChangeMeritMatrix(event, 'dropdown', 'status')
                  }
                  variant='outlined'
                  sx={{...textFieldStyled, width: '100%'}}
                >
                  <MenuItem key='Active' value='ACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Active' />
                  </MenuItem>
                  <MenuItem key='Inactive' value='INACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                  </MenuItem>
                </Select>

                {formError.status?.isError && (
                  <FormHelperText style={{color: '#d32f2f'}}>
                    {formError.status.errorMessage}
                  </FormHelperText>
                )}
              </FormControl>
            </Stack>
          </Stack>

          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>
                <IntlMessages id='matrix.whatVariables' />
                {/* What are your variables for merit matrix ? */}
              </Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id='label_employeeRoles'>
                  {/* Select variables */}
                  <IntlMessages id='matrix.selectVariables' />
                </InputLabel>

                <Select
                  name='meritMatrixVariables'
                  labelId='label_salary'
                  disabled={isEdit || !isEmptyNullUndefined(matrixData)}
                  value={
                    meritMatrix?.meritMatrixVariables?.map(
                      (variable) => variable.name,
                    ) || []
                  }
                  error={formError.meritMatrixVariables.isError}
                  onChange={(event) =>
                    handleChangeMeritMatrix(
                      event,
                      'multiDropdown',
                      'meritMatrixVariables',
                    )
                  }
                  label={<IntlMessages id='matrix.selectVariables' />}
                  variant='outlined'
                  size='small'
                  multiple
                  renderValue={(selected) => selected.join(', ')}
                >
                  {variablesList.map((variable, index) =>
                    renderMenuItem(variable, index),
                  )}
                </Select>
                {formError.meritMatrixVariables.isError && (
                  <FormHelperText className='Mui-error'>
                    {formError.meritMatrixVariables.errorMessage}
                  </FormHelperText>
                )}
              </FormControl>
            </Stack>
          </Stack>

          {meritMatrix.meritMatrixVariables &&
            isCombinedRatingPresent(meritMatrix.meritMatrixVariables) && (
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%'}}>
                  <Stack fontWeight={500}>
                    {/* <IntlMessages id='matrix.whatVariables' /> */}
                    Select ratings
                  </Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <FormControl
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'red',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  >
                    <InputLabel size='small' id='Ratings'>
                      {/* <IntlMessages id='matrix.selectVariables' /> */}
                      Ratings
                    </InputLabel>

                    <Select
                      value={selectedRatings || []}
                      multiple
                      labelId='ratings'
                      name='selectedRatings'
                      variant='outlined'
                      label={<IntlMessages id='calibration.Ratings' />}
                      size='small'
                      disabled={isEdit || !isEmptyNullUndefined(matrixData)}
                      onChange={(event) =>
                        handleChangeMeritMatrix(
                          event,
                          'selectedRatings',
                          'selectedRatings',
                        )
                      }
                      sx={{
                        ...textFieldStyled,
                        '& .MuiOutlinedInput-root': {
                          '& fieldset': {
                            borderLeftColor: 'red',
                            borderLeftWidth: 3,
                          },
                        },
                        width: '460px',
                      }}
                    >
                      {ratingsData.map((rating, index) => (
                        <MenuItem
                          id={`employeeSubFunction-MenuItem-${index}`}
                          key={index}
                          value={rating.id}
                        >
                          {rating.ratingParameter}
                        </MenuItem>
                      ))}
                    </Select>
                    {formError.selectedRatings?.isError && (
                      <FormHelperText className='Mui-error'>
                        {formError.selectedRatings?.errorMessage}
                      </FormHelperText>
                    )}
                  </FormControl>
                </Stack>
              </Stack>
            )}

          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>
                {/* What is your expected output of matrix ? */}
                <IntlMessages id='matrix.expectedOutput' />
              </Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id='calculateType'>
                  {/* Calculate Type */}
                  <IntlMessages id='matrix.calculateType' />
                </InputLabel>

                <Select
                  size='small'
                  name='calculateType'
                  disabled={isEdit || !isEmptyNullUndefined(matrixData)}
                  label={<IntlMessages id='matrix.calculateType' />}
                  labelId='calculateType'
                  value={meritMatrix?.calculateType || ''}
                  error={formError.calculateType?.isError}
                  helperText={formError.calculateType?.errorMessage}
                  onChange={(event) =>
                    handleChangeMeritMatrix(event, 'dropdown', 'calculateType')
                  }
                  variant='outlined'
                  sx={{...textFieldStyled, width: '100%'}}
                >
                  <MenuItem key='Percentage' value='Percentage'>
                    {/* Percentage */}
                    <IntlMessages id='matrix.percentage' />
                  </MenuItem>
                  <MenuItem key='Amount' value='Amount'>
                    <IntlMessages id='matrix.amount' />
                  </MenuItem>
                  <MenuItem key='Range' value='Range'>
                    <IntlMessages id='matrix.range' />
                  </MenuItem>
                </Select>
                <FormHelperText style={{color: '#d32f2f'}}>
                  {formError.calculateType.errorMessage}
                </FormHelperText>
              </FormControl>
            </Stack>
          </Stack>

          {meritMatrix?.calculateType == 'Range' && (
            <Stack
              id='addEnrollmentStack'
              direction='row'
              sx={{mt: 5, ml: 3}}
              justifyContent='space-between'
              alignItems='flex-start'
              spacing={2}
            >
              <Stack sx={{width: '40%'}}>
                <Stack fontWeight={500}>
                  {/* What is your expected output of matrix ? */}
                  {/* <IntlMessages id='matrix.expectedOutput' /> */}
                  Select range calculate type:
                </Stack>
              </Stack>

              <Stack direction={'row'} sx={{width: '60%'}}>
                <FormControl
                  sx={{
                    ...textFieldStyled,
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                    },
                  }}
                >
                  <InputLabel size='small' id='rangeCalculateType'>
                    {/* <IntlMessages id='matrix.calculateType' /> */}
                    Range Calculate Type
                  </InputLabel>

                  <Select
                    size='small'
                    name='rangeCalculateType'
                    disabled={isEdit || !isEmptyNullUndefined(matrixData)}
                    // label={<IntlMessages id='matrix.calculateType' />}
                    label='Range Calculate Type'
                    labelId='rangeCalculateType'
                    value={meritMatrix?.rangeCalculateType || ''}
                    error={formError.rangeCalculateType?.isError}
                    helperText={formError.rangeCalculateType?.errorMessage}
                    onChange={(event) =>
                      handleChangeMeritMatrix(
                        event,
                        'dropdown',
                        'rangeCalculateType',
                      )
                    }
                    variant='outlined'
                    sx={{...textFieldStyled, width: '100%'}}
                  >
                    <MenuItem key='Percentage' value='Percentage'>
                      <IntlMessages id='matrix.percentage' />
                    </MenuItem>
                    <MenuItem key='Amount' value='Amount'>
                      <IntlMessages id='matrix.amount' />
                    </MenuItem>
                  </Select>
                  {formError.rangeCalculateType?.isError && (
                    <FormHelperText style={{color: '#d32f2f'}}>
                      {formError.rangeCalculateType.errorMessage}
                    </FormHelperText>
                  )}
                </FormControl>
              </Stack>
            </Stack>
          )}

          {(meritMatrix?.calculateType == 'Percentage' ||
            (meritMatrix?.calculateType == 'Range' &&
              meritMatrix.rangeCalculateType == 'Percentage')) && (
            <Stack
              id='addEnrollmentStack'
              direction='row'
              sx={{mt: 5, ml: 3}}
              justifyContent='space-between'
              alignItems='flex-start'
              spacing={2}
            >
              <Stack sx={{width: '40%'}}>
                <Stack fontWeight={500}>Select salary head:</Stack>
              </Stack>

              <Stack direction={'row'} sx={{width: '60%'}}>
                <FormControl
                  sx={{
                    ...textFieldStyled,
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                    },
                  }}
                >
                  <InputLabel size='small' id='salaryType'>
                    {/* <IntlMessages id='matrix.calculateType' /> */}
                    Salary Head
                  </InputLabel>

                  <Select
                    size='small'
                    name='salarySetUpId'
                    disabled={isEdit || !isEmptyNullUndefined(matrixData)}
                    // label={<IntlMessages id='matrix.calculateType' />}
                    label='Salary Head'
                    labelId='salarySetUpId'
                    value={meritMatrix?.salarySetUpId || ''}
                    error={formError.salarySetUpId?.isError}
                    helperText={formError.salarySetUpId?.errorMessage}
                    onChange={(event) =>
                      handleChangeMeritMatrix(
                        event,
                        'dropdown',
                        'rangeCalculateType',
                      )
                    }
                    variant='outlined'
                    sx={{...textFieldStyled, width: '100%'}}
                  >
                    {salaryData?.map((sal, index) => {
                        return (
                          <MenuItem key={index} value={sal.id}>
                            {/* {sal.name} */}
                            {sal.salaryTypes}
                          </MenuItem>
                        );
                      })}
                  </Select>
                  {formError.salarySetUpId?.isError && (
                    <FormHelperText style={{color: '#d32f2f'}}>
                      {formError.salarySetUpId?.errorMessage}
                    </FormHelperText>
                  )}
                </FormControl>
              </Stack>
            </Stack>
          )}

          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3, mb: 5}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}></Stack>

            <Stack
              direction={'row'}
              sx={{width: '60%', alignItems: 'flex-end'}}
              justifyContent='flex-end'
            >
              {!isEdit && (
                <Button
                  color='primary'
                  variant='contained'
                  sx={{...footerButton.back.sx, mr: 8}}
                  size={footerButton.back.size}
                  onClick={() => generateTableHandler()}
                  disabled={genrateLoading || !isEmptyNullUndefined(matrixData)}
                >
                  {genrateLoading ? (
                    <CircularProgress
                      sx={{
                        width: '15px !important',
                        margin: '4px !important',
                        height: '15px !important',
                      }}
                    />
                  ) : (
                    <p>
                      {/* Generate */}
                      <IntlMessages id='matrix.generate' />
                    </p>
                  )}
                </Button>
              )}
              {!isEmptyNullUndefined(matrixData) && (
                <Button
                  variant='contained'
                  onClick={handleDownloadExcel}
                  sx={{mr: 8}}
                >
                  {/* Download Excel */}
                  <IntlMessages id='matrix.downloadExcel' />
                </Button>
              )}
            </Stack>
          </Stack>

          {!isEmptyNullUndefined(matrixData) && (
            <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 5, mr: 5, mb: 10}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
                width='100%'
              >
                {!isEmptyNullUndefined(variableOne) &&
                !isEmptyNullUndefined(variableTwo) ? (
                  <div style={{overflowX: 'auto', width: '100%'}}>
                    <TableContainer
                      component={Paper}
                      style={{overflowX: 'auto', width: '95%'}}
                    >
                      <Table id='matrix-table'>
                        <TableHead>
                          <TableRow>
                            <CustomTableHeaderCell
                              style={{backgroundColor: '#f0f0f0'}}
                            ></CustomTableHeaderCell>
                            {variableOne?.map((value) => (
                                <CustomTableHeaderCell
                                  key={value}
                                  style={{backgroundColor: '#f0f0f0'}}
                                >
                                  {value}
                                </CustomTableHeaderCell>
                              ))}
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {variableTwo?.map((variable2, rowIndex) => (
                              <TableRow key={variable2}>
                                <CustomTableHeaderCell
                                  component='th'
                                  scope='row'
                                  style={{backgroundColor: '#f0f0f0'}}
                                >
                                  {variable2}
                                </CustomTableHeaderCell>{' '}
                                {/* Row header */}
                                {variableOne?.map((variable1, colIndex) => {
                                    const cellData = matrixData['matrix '].find(
                                      (item) =>
                                        item['variable 1'] === variable1 &&
                                        item['variable 2'] === variable2,
                                    );
                                    // const cellIndex =
                                    //   rowIndex * variableOne.length + colIndex;

                                    const cellIndex = matrixData[
                                      'matrix '
                                    ].findIndex(
                                      (item) =>
                                        item['variable 1'] === variable1 &&
                                        item['variable 2'] === variable2,
                                    );

                                    return (
                                      <CustomTableCell
                                        key={variable1}
                                        style={{border: '1px solid #dddddd'}}
                                      >
                                        {meritMatrix.calculateType ==
                                        'Range' ? (
                                          <div>
                                            <TextField
                                              label={
                                                <IntlMessages id='matrix.min' />
                                              }
                                              value={
                                                cellData &&
                                                cellData.meritMatrixValue
                                                  .minRange !== null
                                                  ? cellData.meritMatrixValue
                                                      .minRange
                                                  : ''
                                              }
                                              onChange={(event) =>
                                                handleCellChange(
                                                  event,
                                                  variable1,
                                                  variable2,
                                                  'minRange',
                                                )
                                              }
                                              variant='outlined'
                                              sx={{width: '140px'}}
                                              style={{marginRight: '1rem'}}
                                              type='number'
                                              InputProps={{
                                                endAdornment:
                                                  meritMatrix.rangeCalculateType ==
                                                    'Percentage' && (
                                                    <InputAdornment position='end'>
                                                      %
                                                    </InputAdornment>
                                                  ),
                                              }}
                                            />
                                            <TextField
                                              label={
                                                <IntlMessages id='matrix.max' />
                                              }
                                              value={
                                                cellData &&
                                                cellData.meritMatrixValue
                                                  .maxRange !== null
                                                  ? cellData.meritMatrixValue
                                                      .maxRange
                                                  : ''
                                              }
                                              onChange={(event) =>
                                                handleCellChange(
                                                  event,
                                                  variable1,
                                                  variable2,
                                                  'maxRange',
                                                )
                                              }
                                              variant='outlined'
                                              type='number'
                                              sx={{mt: 3, width: '140px'}}
                                              InputProps={{
                                                endAdornment:
                                                  meritMatrix.rangeCalculateType ==
                                                    'Percentage' && (
                                                    <InputAdornment position='end'>
                                                      %
                                                    </InputAdornment>
                                                  ),
                                              }}
                                            />
                                            <div>
                                              {cellValueErrors[cellIndex] &&
                                                cellValueErrors[cellIndex]
                                                  .isError && (
                                                  <FormHelperText
                                                    className='error'
                                                    sx={{color: 'red'}}
                                                  >
                                                    {cellValueErrors[
                                                      cellIndex
                                                    ] &&
                                                      cellValueErrors[cellIndex]
                                                        .isError &&
                                                      cellValueErrors[cellIndex]
                                                        .errorMessage}
                                                  </FormHelperText>
                                                )}
                                            </div>
                                          </div>
                                        ) : (
                                          <TextField
                                            value={
                                              cellData &&
                                              cellData.meritMatrixValue
                                                .matrixValue !== null
                                                ? cellData.meritMatrixValue
                                                    .matrixValue
                                                : ''
                                            }
                                            error={
                                              cellValueErrors[cellIndex] &&
                                              cellValueErrors[cellIndex].isError
                                            }
                                            helperText={
                                              cellValueErrors[cellIndex] &&
                                              cellValueErrors[cellIndex]
                                                .isError &&
                                              cellValueErrors[cellIndex]
                                                .errorMessage
                                            }
                                            onChange={(event) =>
                                              handleCellChange(
                                                event,
                                                variable1,
                                                variable2,
                                                'matrixValue',
                                              )
                                            }
                                            type='number'
                                            InputProps={{
                                              endAdornment:
                                                meritMatrix.calculateType ==
                                                  'Percentage' && (
                                                  <InputAdornment position='end'>
                                                    %
                                                  </InputAdornment>
                                                ),
                                            }}
                                            sx={{width: '140px'}}
                                          />
                                        )}
                                      </CustomTableCell>
                                    );
                                  })}
                              </TableRow>
                            ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </div>
                ) : (
                  <div style={{overflowX: 'auto', width: '100%'}}>
                    <TableContainer
                      component={Paper}
                      style={{overflowX: 'auto', width: '95%'}}
                    >
                      <Table id='matrix-table'>
                        <TableHead>
                          <TableRow>
                            {/* Render column headers */}
                            {variableOne?.map((value) => (
                                <CustomTableHeaderCell
                                  key={value}
                                  style={{backgroundColor: '#f0f0f0'}}
                                >
                                  {value}
                                </CustomTableHeaderCell>
                              ))}
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          <TableRow key={'variable2'}>
                            {/* Render input fields for each column */}
                            {variableOne?.map((variable1) => {
                                const cellData = matrixData['matrix '].find(
                                  (item) => item['variable 1'] === variable1,
                                );

                                const cellIndex = matrixData[
                                  'matrix '
                                ].findIndex(
                                  (item) => item['variable 1'] === variable1,
                                );

                                return (
                                  <CustomTableCell
                                    key={variable1}
                                    style={{border: '1px solid #dddddd'}}
                                  >
                                    {meritMatrix.calculateType == 'Range' ? (
                                      <div>
                                        <TextField
                                          label={
                                            <IntlMessages id='matrix.min' />
                                          }
                                          value={
                                            cellData &&
                                            cellData.meritMatrixValue
                                              .minRange !== null
                                              ? cellData.meritMatrixValue
                                                  .minRange
                                              : ''
                                          }
                                          onChange={(event) =>
                                            handleCellChangeSingle(
                                              event,
                                              variable1,
                                              'minRange',
                                            )
                                          }
                                          variant='outlined'
                                          sx={{width: '140px'}}
                                          style={{marginRight: '1rem'}}
                                          type='number'
                                          InputProps={{
                                            endAdornment:
                                              meritMatrix.rangeCalculateType ==
                                                'Percentage' && (
                                                <InputAdornment position='end'>
                                                  %
                                                </InputAdornment>
                                              ),
                                          }}
                                        />
                                        <TextField
                                          label={
                                            <IntlMessages id='matrix.max' />
                                          }
                                          value={
                                            cellData &&
                                            cellData.meritMatrixValue
                                              .maxRange !== null
                                              ? cellData.meritMatrixValue
                                                  .maxRange
                                              : ''
                                          }
                                          onChange={(event) =>
                                            handleCellChangeSingle(
                                              event,
                                              variable1,
                                              'maxRange',
                                            )
                                          }
                                          variant='outlined'
                                          type='number'
                                          sx={{mt: 3, width: '140px'}}
                                          InputProps={{
                                            endAdornment:
                                              meritMatrix.rangeCalculateType ==
                                                'Percentage' && (
                                                <InputAdornment position='end'>
                                                  %
                                                </InputAdornment>
                                              ),
                                          }}
                                        />
                                        <div>
                                          {cellValueErrors[cellIndex] &&
                                            cellValueErrors[cellIndex]
                                              .isError && (
                                              <FormHelperText
                                                className='error'
                                                sx={{color: 'red'}}
                                              >
                                                {cellValueErrors[cellIndex] &&
                                                  cellValueErrors[cellIndex]
                                                    .isError &&
                                                  cellValueErrors[cellIndex]
                                                    .errorMessage}
                                              </FormHelperText>
                                            )}
                                        </div>
                                      </div>
                                    ) : (
                                      <TextField
                                        value={
                                          cellData &&
                                          cellData.meritMatrixValue
                                            .matrixValue !== null
                                            ? cellData.meritMatrixValue
                                                .matrixValue
                                            : ''
                                        }
                                        error={
                                          cellValueErrors[cellIndex] &&
                                          cellValueErrors[cellIndex].isError
                                        }
                                        helperText={
                                          cellValueErrors[cellIndex] &&
                                          cellValueErrors[cellIndex].isError &&
                                          cellValueErrors[cellIndex]
                                            .errorMessage
                                        }
                                        onChange={(event) =>
                                          handleCellChangeSingle(
                                            event,
                                            variable1,
                                            'matrixValue',
                                          )
                                        }
                                        type='number'
                                        InputProps={{
                                          endAdornment:
                                            meritMatrix.calculateType ==
                                              'Percentage' && (
                                              <InputAdornment position='end'>
                                                %
                                              </InputAdornment>
                                            ),
                                        }}
                                        sx={{width: '140px'}}
                                      />
                                    )}
                                  </CustomTableCell>
                                );
                              })}
                          </TableRow>
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </div>
                )}
              </Stack>
          )}
        </Stack>

        {!isEmptyNullUndefined(matrixData) && (
          <Stack sx={{marginBottom: '20px', ml: 3}}>
            <Stack
              id='addEnrollmentStack'
              direction='row'
              sx={{mt: 5, ml: 3}}
              justifyContent='space-between'
              alignItems='flex-start'
              spacing={2}
            >
              <Stack sx={{width: '40%'}}>
                <Stack fontWeight={500}>Is there any other multipliers ?</Stack>
              </Stack>

              <Stack direction={'row'} sx={{width: '60%'}}>
                <RadioGroup
                  value={multiplierForm?.multiplier}
                  row
                  aria-labelledby='demo-row-radio-buttons-group-label'
                  name='multiplier'
                  onChange={(event) =>
                    handleChangeMultiplier(event, 'radio', 'multiplier')
                  }
                >
                  <FormControlLabel
                    value={true}
                    control={<Radio />}
                    disabled={isEdit}
                    label={<IntlMessages id='common.button.Yes' />}
                  />
                  <FormControlLabel
                    value={false}
                    control={<Radio />}
                    disabled={isEdit}
                    label={<IntlMessages id='common.button.No' />}
                  />
                </RadioGroup>
              </Stack>
            </Stack>
            {(multiplierForm.multiplier == 'true' ||
              multiplierForm.multiplier == true) && (
              <>
                <Stack
                  id='addEnrollmentStack'
                  direction='row'
                  sx={{mt: 5, ml: 3}}
                  justifyContent='space-between'
                  alignItems='flex-start'
                  spacing={2}
                >
                  <Stack sx={{width: '40%'}}>
                    <Stack fontWeight={500}>Select variable</Stack>
                  </Stack>

                  <Stack direction={'row'} sx={{width: '60%'}}>
                    <FormControl
                      sx={{
                        ...textFieldStyled,
                        '& .MuiOutlinedInput-root': {
                          '& fieldset': {
                            borderLeftColor: 'red',
                            borderLeftWidth: 3,
                          },
                        },
                      }}
                    >
                      <InputLabel size='small' id='SelectVariable'>
                        Select Variable
                      </InputLabel>

                      <Select
                        size='small'
                        name='multiplierVariable'
                        label='Select Variable'
                        labelId='SelectVariable'
                        disabled={isEdit}
                        value={multiplierForm?.multiplierVariable || ''}
                        error={multiplierFormError.multiplierVariable?.isError}
                        onChange={(event) =>
                          handleChangeMultiplier(
                            event,
                            'dropdown',
                            'multiplierVariable',
                          )
                        }
                        variant='outlined'
                        sx={{...textFieldStyled, width: '100%'}}
                      >
                        {multiplierVariablesList?.map((variable, index) => (
                            <MenuItem
                              id={`variable-MenuItem-${index}`}
                              key={index + "-" + variable.name}
                              value={variable.name}
                            >
                              {variable.name}
                            </MenuItem>
                          ))}
                      </Select>
                      {multiplierFormError.multiplierVariable?.isError && (
                        <FormHelperText style={{color: '#d32f2f'}}>
                          {multiplierFormError.multiplierVariable?.errorMessage}
                        </FormHelperText>
                      )}
                    </FormControl>
                  </Stack>
                </Stack>

                {multiplierForm?.multiplierVariable &&
                  multiplierForm?.multiplierVariable == 'Rating' && (
                    <Stack
                      id='addEnrollmentStack'
                      direction='row'
                      sx={{mt: 5, ml: 3}}
                      justifyContent='space-between'
                      alignItems='flex-start'
                      spacing={2}
                    >
                      <Stack sx={{width: '40%'}}>
                        <Stack fontWeight={500}>Select rating</Stack>
                      </Stack>

                      <Stack direction={'row'} sx={{width: '60%'}}>
                        <FormControl
                          sx={{
                            ...textFieldStyled,
                            '& .MuiOutlinedInput-root': {
                              '& fieldset': {
                                borderLeftColor: 'red',
                                borderLeftWidth: 3,
                              },
                            },
                          }}
                        >
                          <InputLabel size='small' id='Ratings'>
                            {/* <IntlMessages id='matrix.selectVariables' /> */}
                            Select rating
                          </InputLabel>

                          <Select
                            value={multiplierForm.selectedRatings}
                            labelId='ratings'
                            name='selectedRatings'
                            variant='outlined'
                            label=' Select rating'
                            size='small'
                            disabled={isEdit}
                            onChange={(event) =>
                              handleChangeMultiplier(
                                event,
                                'dropdown',
                                'selectedRatings',
                              )
                            }
                            sx={{
                              ...textFieldStyled,
                              '& .MuiOutlinedInput-root': {
                                '& fieldset': {
                                  borderLeftColor: 'red',
                                  borderLeftWidth: 3,
                                },
                              },
                               width: '100%'
                            }}
                          >
                            {ratingsData.map((rating, index) => (
                              <MenuItem
                                id={`employeeSubFunction-MenuItem-${index}`}
                                key={index + "-" + rating.id}
                                value={rating.id}
                              >
                                {rating.ratingParameter}
                              </MenuItem>
                            ))}
                          </Select>
                          {multiplierFormError.selectedRatings?.isError && (
                            <FormHelperText className='Mui-error'>
                              {
                                multiplierFormError.selectedRatings
                                  ?.errorMessage
                              }
                            </FormHelperText>
                          )}
                        </FormControl>
                      </Stack>
                    </Stack>
                  )}

                {multiplierForm.multiplierVariable == 'Compa Ratio' && (
                  <Stack
                    id='addEnrollmentStack'
                    direction='row'
                    sx={{mt: 5, ml: 3}}
                    justifyContent='space-between'
                    alignItems='flex-start'
                    spacing={2}
                  >
                    <Stack sx={{width: '40%'}}>
                      <Stack fontWeight={500}>Is it range or amount</Stack>
                    </Stack>

                    <Stack direction={'row'} sx={{width: '60%'}}>
                      <FormControl
                        sx={{
                          ...textFieldStyled,
                          '& .MuiOutlinedInput-root': {
                            '& fieldset': {
                              borderLeftColor: 'red',
                              borderLeftWidth: 3,
                            },
                          },
                        }}
                      >
                        <InputLabel size='small' id='SelectType'>
                          Select Type
                        </InputLabel>

                        <Select
                          size='small'
                          name='calculateType'
                          label='Select Type'
                          labelId='SelectType'
                          // disabled={isEdit}
                          value={multiplierForm?.calculateType || ''}
                          error={multiplierFormError.calculateType?.isError}
                          onChange={(event) =>
                            handleChangeMultiplier(
                              event,
                              'dropdown',
                              'calculateType',
                            )
                          }
                          variant='outlined'
                          sx={{...textFieldStyled, width: '100%'}}
                        >
                          <MenuItem key='range' value='Range'>
                            Range
                          </MenuItem>
                          <MenuItem key='amount' value='Amount'>
                            Amount
                          </MenuItem>
                        </Select>
                        {multiplierFormError.calculateType?.isError && (
                          <FormHelperText style={{color: '#d32f2f'}}>
                            {multiplierFormError.calculateType?.errorMessage}
                          </FormHelperText>
                        )}
                      </FormControl>
                    </Stack>
                  </Stack>
                )}

                {/* Table start */}

                {multiplierForm.multiplierVariable == 'Compa Ratio' &&
                  !isEmptyNullUndefined(multiplierForm.calculateType) && (
                    <Stack
                      direction='row'
                      sx={{mt: 3, mb: 10, ml: 3}}
                      alignItems='flex-start'
                    >
                      <TableContainer component={Card}>
                        <Stack
                          direction='row'
                          justifyContent='flex-end'
                          sx={{mb: 2, mr: 5, py: 2}}
                          spacing={2}
                        >
                          {multiplierFormError?.meritMatrixMultiplierScales
                            ?.isError && (
                            <FormHelperText
                              sx={{width: 200, fontSize: '12px'}}
                              className='Mui-error'
                            >
                              {
                                multiplierFormError?.meritMatrixMultiplierScales
                                  ?.errorMessage
                              }
                            </FormHelperText>
                          )}
                          <Button
                            color={footerButton.addMore.color}
                            variant={footerButton.addMore.variant}
                            sx={footerButton.addMore.sx}
                            size={footerButton.addMore.size}
                            onClick={() => handleInsertMultiplierData()}
                          >
                            Add More
                          </Button>
                        </Stack>

                        <Table
                          stickyHeader
                          sx={{minWidth: 650}}
                          aria-label='simple table'
                        >
                          <TableHead>
                            <TableRow>
                              <StyledTableCell align='left' sx={{minWidth: 80}}>
                                Name
                              </StyledTableCell>

                              {multiplierForm?.calculateType == 'Range' && (
                                <>
                                  <StyledTableCell
                                    align='left'
                                    sx={{minWidth: 100}}
                                  >
                                    Lower Condition
                                  </StyledTableCell>

                                  <StyledTableCell
                                    align='left'
                                    sx={{minWidth: 80}}
                                  >
                                    Lower Circuit
                                  </StyledTableCell>

                                  <StyledTableCell
                                    align='left'
                                    sx={{minWidth: 100}}
                                  >
                                    Upper Condition
                                  </StyledTableCell>

                                  <StyledTableCell
                                    align='left'
                                    sx={{minWidth: 80}}
                                  >
                                    Upper Circuit
                                  </StyledTableCell>
                                </>
                              )}

                              <StyledTableCell align='left' sx={{minWidth: 80}}>
                                Multiplier
                              </StyledTableCell>

                              <StyledTableCell
                                align='left'
                                sx={{minWidth: 100}}
                              >
                                <IntlMessages id='aggrid.tableHeader.Action' />
                              </StyledTableCell>
                            </TableRow>
                          </TableHead>
                          <TableBody>
                            {multiplierData?.map((row, index) => (
                              <TableRow
                                key={index + "-" + row.scaleName}
                                sx={{
                                  '&:last-child td, &:last-child th': {
                                    border: 0,
                                  },
                                }}
                              >
                                {!row.isWriteAction && (
                                  <>
                                    <StyledTableCell align='left'>
                                      {row.scaleName}
                                    </StyledTableCell>

                                    {multiplierForm?.calculateType ==
                                      'Range' && (
                                      <>
                                        <StyledTableCell align='left'>
                                          {row.lowerCondition}
                                        </StyledTableCell>
                                        <StyledTableCell align='left'>
                                          {row.lowerCircuit}
                                        </StyledTableCell>

                                        <StyledTableCell align='left'>
                                          {row.upperCondition}
                                        </StyledTableCell>

                                        <StyledTableCell align='left'>
                                          {row.upperCircuit}
                                        </StyledTableCell>
                                      </>
                                    )}

                                    <StyledTableCell align='left'>
                                      {row.scaleValue}
                                    </StyledTableCell>

                                    <StyledTableCell align='left'>
                                      {
                                        <Stack direction='row'>
                                          <IconButton
                                            sx={{...iconButtonStyled}}
                                            aria-label='save'
                                            onClick={() =>
                                              handleEditMultiplierData(index)
                                            }
                                          >
                                            <EditIcon color='primary' />
                                          </IconButton>
                                          <IconButton
                                            sx={{...iconButtonStyled}}
                                            aria-label='delete'
                                            onClick={() =>
                                              handleDeleteMultiplierData(index)
                                            }
                                          >
                                            <HighlightOffIcon color='error' />
                                          </IconButton>
                                        </Stack>
                                      }
                                    </StyledTableCell>
                                  </>
                                )}
                                {row.isWriteAction && (
                                  <>
                                    <StyledTableCell align='left'>
                                      <TextField
                                        size='small'
                                        name='scaleName'
                                        label='Name'
                                        onChange={(event) =>
                                          handleChangeMultiplierData(
                                            event,
                                            index,
                                            'textField',
                                          )
                                        }
                                        variant='outlined'
                                        error={
                                          multiplierDataErrors[index]?.scaleName
                                            ?.isError
                                        }
                                        helperText={
                                          multiplierDataErrors[index]?.scaleName
                                            ?.errorMessage
                                        }
                                        value={row.scaleName || ''}
                                        sx={{
                                          ...textFieldStyled,
                                          '& .MuiOutlinedInput-root': {
                                            '& fieldset': {
                                              borderLeftColor: 'red',
                                              borderLeftWidth: 3,
                                            },
                                          },
                                          mt: 3,
                                          minWidth: '80px',
                                        }}
                                      />
                                    </StyledTableCell>
                                    {multiplierForm?.calculateType ==
                                      'Range' && (
                                      <>
                                        <StyledTableCell align='left'>
                                          <FormControl
                                            sx={{
                                              // ...textFieldStyled,
                                              '& fieldset': {
                                                borderLeftWidth: 3,
                                                borderLeftColor: 'gray',
                                              },
                                              // mt: 3,
                                              minWidth: '100px',
                                            }}
                                          >
                                            <InputLabel
                                              sx={{
                                                backgroundColor: '#ffffff',
                                                padding: '0px 0.5rem',
                                              }}
                                              size='small'
                                            >
                                              Lower Condition
                                            </InputLabel>
                                            <Select
                                              value={row.lowerCondition || ''}
                                              id={'lowerCondition'}
                                              name='lowerCondition'
                                              error={
                                                multiplierDataErrors[index]
                                                  ?.lowerCondition?.isError
                                              }
                                              onChange={(event) =>
                                                handleChangeMultiplierData(
                                                  event,
                                                  index,
                                                  'dropdown',
                                                )
                                              }
                                              variant='outlined'
                                              size='small'
                                            >
                                              {conditionOptions?.map(
                                                  (t, i) => {
                                                    return (
                                                      <MenuItem
                                                        value={t.value}
                                                        name={t.name}
                                                        size='small'
                                                        key={i}
                                                      >
                                                        {t.name}
                                                      </MenuItem>
                                                    );
                                                  },
                                                )}
                                            </Select>
                                            {multiplierDataErrors[index]
                                              ?.lowerCondition?.isError && (
                                              <FormHelperText
                                                sx={{width: 150}}
                                                className='Mui-error'
                                              >
                                                {
                                                  multiplierDataErrors[index]
                                                    .lowerCondition.errorMessage
                                                }
                                              </FormHelperText>
                                            )}
                                          </FormControl>
                                        </StyledTableCell>

                                        <StyledTableCell align='left'>
                                          <TextField
                                            size='small'
                                            name='lowerCircuit'
                                            label='Lower Circuit'
                                            type='number'
                                            onChange={(event) =>
                                              handleChangeMultiplierData(
                                                event,
                                                index,
                                                'textField',
                                              )
                                            }
                                            variant='outlined'
                                            error={
                                              multiplierDataErrors[index]
                                                ?.lowerCircuit?.isError
                                            }
                                            helperText={
                                              multiplierDataErrors[index]
                                                ?.lowerCircuit?.errorMessage
                                            }
                                            value={row.lowerCircuit || ''}
                                            sx={{
                                              ...textFieldStyled,
                                              '& .MuiOutlinedInput-root': {
                                                '& fieldset': {
                                                  borderLeftColor: 'gray',
                                                  borderLeftWidth: 3,
                                                },
                                              },
                                              mt: 3,
                                              minWidth: '80px',
                                            }}
                                          />
                                        </StyledTableCell>

                                        <StyledTableCell align='left'>
                                          <FormControl
                                            sx={{
                                              // ...textFieldStyled,
                                              '& fieldset': {
                                                borderLeftWidth: 3,
                                                borderLeftColor: 'gray',
                                              },
                                              // mt: 3,
                                              minWidth: '100px',
                                            }}
                                          >
                                            <InputLabel
                                              sx={{
                                                backgroundColor: '#ffffff',
                                                padding: '0px 0.5rem',
                                              }}
                                              size='small'
                                            >
                                              Upper Condition
                                            </InputLabel>
                                            <Select
                                              value={row.upperCondition || ''}
                                              id={'upperCondition'}
                                              name='upperCondition'
                                              error={
                                                multiplierDataErrors[index]
                                                  ?.upperCondition?.isError
                                              }
                                              onChange={(event) =>
                                                handleChangeMultiplierData(
                                                  event,
                                                  index,
                                                  'dropdown',
                                                )
                                              }
                                              variant='outlined'
                                              size='small'
                                            >
                                              {conditionOptions?.map(
                                                  (t, i) => {
                                                    return (
                                                      <MenuItem
                                                        value={t.value}
                                                        name={t.name}
                                                        size='small'
                                                        key={i}
                                                      >
                                                        {t.name}
                                                      </MenuItem>
                                                    );
                                                  },
                                                )}
                                            </Select>
                                            {multiplierDataErrors[index]
                                              ?.upperCondition?.isError && (
                                              <FormHelperText
                                                sx={{width: 150}}
                                                className='Mui-error'
                                              >
                                                {
                                                  multiplierDataErrors[index]
                                                    .upperCondition
                                                    ?.errorMessage
                                                }
                                              </FormHelperText>
                                            )}
                                          </FormControl>
                                        </StyledTableCell>

                                        <StyledTableCell align='left'>
                                          <TextField
                                            size='small'
                                            name='upperCircuit'
                                            label='Upper Circuit'
                                            onChange={(event) =>
                                              handleChangeMultiplierData(
                                                event,
                                                index,
                                                'textField',
                                              )
                                            }
                                            variant='outlined'
                                            error={
                                              multiplierDataErrors[index]
                                                ?.upperCircuit?.isError
                                            }
                                            helperText={
                                              multiplierDataErrors[index]
                                                ?.upperCircuit?.errorMessage
                                            }
                                            type='number'
                                            value={row.upperCircuit || ''}
                                            sx={{
                                              ...textFieldStyled,
                                              '& .MuiOutlinedInput-root': {
                                                '& fieldset': {
                                                  borderLeftColor: 'gray',
                                                  borderLeftWidth: 3,
                                                },
                                              },
                                              mt: 3,
                                              minWidth: '80px',
                                            }}
                                          />
                                        </StyledTableCell>
                                      </>
                                    )}

                                    <StyledTableCell align='left'>
                                      <TextField
                                        size='small'
                                        name='scaleValue'
                                        label='Multiplers'
                                        onChange={(event) =>
                                          handleChangeMultiplierData(
                                            event,
                                            index,
                                            'textField',
                                          )
                                        }
                                        type='number'
                                        variant='outlined'
                                        error={
                                          multiplierDataErrors[index]
                                            ?.scaleValue?.isError
                                        }
                                        helperText={
                                          multiplierDataErrors[index]
                                            ?.scaleValue?.errorMessage
                                        }
                                        value={row.scaleValue || ''}
                                        sx={{
                                          ...textFieldStyled,
                                          '& .MuiOutlinedInput-root': {
                                            '& fieldset': {
                                              borderLeftColor: 'red',
                                              borderLeftWidth: 3,
                                            },
                                          },
                                          mt: 3,
                                          minWidth: '80px',
                                        }}
                                      />
                                    </StyledTableCell>

                                    <StyledTableCell align='left'>
                                      {
                                        <Stack direction='row'>
                                          <IconButton
                                            sx={{...iconButtonStyled}}
                                            aria-label='save'
                                            onClick={() =>
                                              handleAddMultiplierData(index)
                                            }
                                          >
                                            <CheckBoxIcon color='success' />
                                          </IconButton>
                                          <IconButton
                                            sx={{...iconButtonStyled}}
                                            aria-label='delete'
                                            onClick={() =>
                                              handleDeleteMultiplierData(index)
                                            }
                                          >
                                            <HighlightOffIcon color='error' />
                                          </IconButton>
                                        </Stack>
                                      }
                                    </StyledTableCell>
                                  </>
                                )}
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </TableContainer>
                    </Stack>
                  )}

                {!isEmptyNullUndefined(multiplierForm.multiplierVariable) &&
                  multiplierForm.multiplierVariable != 'Compa Ratio' && (
                    <Stack
                      direction='column'
                      justifyContent='center'
                      alignItems='center'
                      spacing={2}
                      sx={{mb: 10}}
                    >
                      <div>
                        <TableContainer
                          component={Paper}
                          style={{overflowX: 'auto', width: '100%'}}
                        >
                          <Table id='multiplier-table'>
                            <TableHead>
                              <TableRow>
                                <CustomTableHeaderCell
                                  style={{
                                    backgroundColor: '#f0f0f0',
                                    width: '400px',
                                  }}
                                >
                                  Name
                                </CustomTableHeaderCell>
                                <CustomTableHeaderCell
                                  style={{
                                    backgroundColor: '#f0f0f0',
                                    width: '450px',
                                  }}
                                >
                                  Multiplier
                                </CustomTableHeaderCell>
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {multiplierValues.map((row, index) => (
                                  <TableRow key={index}>
                                    <CustomTableHeaderCell>
                                      {row.scaleName}
                                    </CustomTableHeaderCell>
                                    <CustomTableHeaderCell>
                                      <TextField
                                        size='small'
                                        name='scaleValue'
                                        label='Multiplier'
                                        onChange={(e) =>
                                          handleChangeMultiplierInput(
                                            e,
                                            row.scaleName,
                                          )
                                        }
                                        type='number'
                                        variant='outlined'
                                        value={row.scaleValue || ''}
                                        sx={{
                                          ...textFieldStyled,
                                          '& .MuiOutlinedInput-root': {
                                            '& fieldset': {
                                              borderLeftColor: 'gray',
                                              borderLeftWidth: 3,
                                            },
                                          },
                                          minWidth: '280px',
                                        }}
                                      />
                                    </CustomTableHeaderCell>
                                  </TableRow>
                                ))}
                            </TableBody>
                          </Table>
                        </TableContainer>
                      </div>
                    </Stack>
                  )}
              </>
            )}
            {/* Table end */}
          </Stack>
        )}
        {/* ////////add Stack for fixed////// */}
        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0,
          }}
        >
          <Stack
            direction='row'
            justifyContent='end'
            alignItems='center'
            spacing={2}
            sx={{
              pt: 5,
              ml: 3,
              margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
            }}
          >
            <Button
              color={footerButton.back.color}
              variant={footerButton.back.variant}
              sx={footerButton.back.sx}
              size={footerButton.back.size}
              onClick={() => Router.push('/company-builder/merit-matrix')}
            >
              <IntlMessages id='common.button.Back' />
            </Button>

            <Button
              color={footerButton.submit.color}
              variant={footerButton.submit.variant}
              sx={footerButton.submit.sx}
              size={footerButton.submit.size}
              disabled={loading || isEmptyNullUndefined(matrixData)}
              onClick={() => {
                validateSubmitHandler();
              }}
            >
              {isEdit ? (
                <IntlMessages id='common.button.Update' />
              ) : (
                <IntlMessages id='common.button.Submit' />
              )}
            </Button>
          </Stack>
        </Stack>
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default MeritMatrix;
