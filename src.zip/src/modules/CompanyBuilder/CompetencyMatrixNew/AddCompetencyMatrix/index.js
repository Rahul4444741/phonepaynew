import React, {useRef} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import AppAnimate from '../../../../@crema/core/AppAnimate';
import AppPageMeta from '../../../../@crema/core/AppPageMeta';
import {AppCard, AppInfoView} from '../../../../@crema';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import {
  isEmptyNullUndefined,
  apiCatchErrorMessage,
} from '../../../../shared/utils/CommonUtils';
import Button from '@mui/material/Button';
import Router, {useRouter} from 'next/router';
import {showMessage, fetchError} from '../../../../redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import FormHelperText from '@mui/material/FormHelperText';
import {footerButton} from 'shared/constants/AppConst';
import IntlMessages from '@crema/utility/IntlMessages';
import {Box, CircularProgress, IconButton, Typography} from '@mui/material';
import axios from 'axios';
import {domCreactionHeaderTitle} from 'shared/utils/domCreaction';
import {
  CloudUpload as CloudUploadIcon,
  Delete as DeleteIcon,
} from '@mui/icons-material';

const textFieldStyled = {
  backgroundColor: 'white',
  mb: 2,
  width: {xs: '100%', xl: '60%', md: '75%'},
};

const AddCompetencyMatrix = () => {
  const router = useRouter();
  const fileInputRef = useRef();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const {id, view} = router.query;
  const dispatch = useDispatch();

  const initialCompetencyMatrix = {
    name: null,
    status: null,
    companyId: null,
    matrixType: 'COMPETENCY',
    file: null,
  };

  const initialCompetencyMatrixError = {
    name: {isError: false, errorMessage: ''},
    status: {isError: false, errorMessage: ''},
    matrixType: {isError: false, errorMessage: ''},
    file: {isError: false, errorMessage: ''},
  };

  const [competencyMatrix, setCompetencyMatrix] = React.useState(
    initialCompetencyMatrix,
  );
  const [competencyMatrixError, setCompetencyMatrixError] = React.useState(
    initialCompetencyMatrixError,
  );
  const [loading, setLoading] = React.useState(false);
  const [isUploadingFile, setIsUploadingFile] = React.useState(false);
  const [isDeleteFile, setIsDeleteFile] = React.useState(false);
  const [isEdit, setIsEdit] = React.useState(false);
  const [isView, setIsView] = React.useState(false);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  React.useEffect(() => {
    if (!isEmptyNullUndefined(id)) {
      getCompetencyMatrix(id);
      if (view == 'true' || view == true) {
        setIsView(true);
      } else {
        setIsEdit(true);
      }
    }

    return () => {
      source2.cancel('Aborting all previous operations.');
    };
  }, []);

  const getCompetencyMatrix = async (id) => {
    try {
      const response = await jwtAxios.get(
        `${API_ROUTS.competencyMatrix}/${id}`,
        {
          cancelToken: source2.token,
        },
      );
      if (response.status == 200) {
        setCompetencyMatrix(response.data);
      }
    } catch (e) {
      dispatch(fetchError(e.response?.data?.detail));
    }
  };

  const handleChangeCompetencyMatrix = (event, fieldType, name) => {
    const tempCompetencyMatrix = {...competencyMatrix};

    const tempError = {...competencyMatrixError};

    if (fieldType == 'textfield' || fieldType == 'dropdown') {
      tempCompetencyMatrix[event.target.name] = event.target.value;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
    }
    setCompetencyMatrix(tempCompetencyMatrix);
    setCompetencyMatrixError(tempError);
  };

  const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB

  const handleCaptureFile = (event) => {
    const tempCompetencyMatrix = {...competencyMatrix};
    const tempCompetencyMatrixError = {...competencyMatrixError};
    const file = event.target.files[0];
    let isValid = true;
    if (file) {
      // Validation: Check file type
      const validFileTypes = [
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      ];

      if (!validFileTypes.includes(file.type)) {
        tempCompetencyMatrixError.file.isError = true;
        tempCompetencyMatrixError.file.errorMessage =
          'Invalid file type. Please upload an .xlsx or .xls file.';
        isValid = false;
      }

      // Validation: Check file size
      if (file.size > MAX_FILE_SIZE) {
        tempCompetencyMatrixError.file.isError = true;
        tempCompetencyMatrixError.file.errorMessage =
          'File size exceeds the 5MB limit.';
        isValid = false;
      }
      if (isValid) {
        // If validations pass, call UploadFile
        UploadFile(file);
      } else {
        setCompetencyMatrixError(() => tempCompetencyMatrixError);
      }
    } else {
      tempCompetencyMatrix.file = null;
    }
    setCompetencyMatrix(() => tempCompetencyMatrix);
  };

  const UploadFile = async (file) => {
    setIsUploadingFile(() => true);

    const formData = new FormData();
    formData.append('file', file);

    const tempCompetencyMatrix = JSON.parse(JSON.stringify(competencyMatrix));
    const tempCompetencyMatrixError = JSON.parse(
      JSON.stringify(competencyMatrixError),
    );

    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.file_Upload_With_Folder_Name}?companyName=${
          selectedCompany.companyName
        }&folder=${'Competancy_Matrix'}`,
        formData,
      );
      if (response.status == 201) {
        tempCompetencyMatrix.file = response.data;
        tempCompetencyMatrixError.file.isError = false;
        tempCompetencyMatrixError.file.errorMessage = '';
        dispatch(showMessage('File uploaded successfully..!'));
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
    }
    setCompetencyMatrix(tempCompetencyMatrix);
    setCompetencyMatrixError(tempCompetencyMatrixError);
    setIsUploadingFile(() => false);
  };
  const handleRemoveFile = async (fileId) => {
    const tempCompetencyMatrix = {...competencyMatrix};
    tempCompetencyMatrix.file = null;
    if (fileInputRef.current) {
      fileInputRef.current.value = null; // Clear the input value
    }
    if (!isEmptyNullUndefined(fileId)) {
      await DeleteFile(fileId);
    }
    setCompetencyMatrix(() => tempCompetencyMatrix);
  };
  const DeleteFile = async (fileId) => {
    setIsDeleteFile(() => true);
    try {
      const response = await jwtAxios.delete(
        `${API_ROUTS.file_Delete}/${fileId}`,
      );
      if (response.status == 204) {
        dispatch(showMessage('File removed successfully..!'));
      }
    } catch (e) {
      apiCatchErrorMessage(e, dispatch, fetchError);
    } finally {
      setIsDeleteFile(() => false);
    }
  };

  const validateCompetencyMatrixData = () => {
    const tempError = {...competencyMatrixError};
    let isValid = true;

    if (isEmptyNullUndefined(competencyMatrix.name)) {
      tempError.name.isError = true;
      tempError.name.errorMessage = 'Please enter compentency matrix name';
      isValid = false;
    }

    if (isEmptyNullUndefined(competencyMatrix.status)) {
      tempError.status.isError = true;
      tempError.status.errorMessage = (
        <IntlMessages id='error.PleaseSelectStatus' />
      );
      isValid = false;
    }

    if (isEmptyNullUndefined(competencyMatrix.matrixType)) {
      tempError.matrixType.isError = true;
      tempError.matrixType.errorMessage =
        'Please select compentency matrix type.';
      isValid = false;
    }

    if (
      competencyMatrix.matrixType == 'COMPETENCY' &&
      isEmptyNullUndefined(competencyMatrix.file)
    ) {
      tempError.file.isError = true;
      tempError.file.errorMessage =
        'Please upload excel data for compentency matrix.';
      isValid = false;
    }

    if (isValid) {
      if (!isEdit) {
        SubmitCompetencyMatrix();
      } else {
        UpdateCompetencyMatrix();
      }
    } else {
      setCompetencyMatrixError(tempError);
    }
  };

  const SubmitCompetencyMatrix = async () => {
    let tempCompetencyMatrix = {
      ...competencyMatrix,
      companyId: selectedCompany?.id,
    };

    const submit = async () => {
      setLoading(true);
      try {
        const response = await jwtAxios.post(
          `${API_ROUTS.competencyMatrix}/upload-competency`,
          tempCompetencyMatrix,
        );
        if (response.status == 200) {
          dispatch(showMessage('Competency matrix added successfully..!'));
          Router.push('/company-builder/compentency-matrix');
        } else {
          setLoading(false);
        }
      } catch (error) {
        apiCatchErrorMessage(error, dispatch, fetchError);
        setLoading(false);
      }
    };
    await submit();
  };

  const UpdateCompetencyMatrix = async () => {
    let tempCompetencyMatrix = {
      ...competencyMatrix,
      companyId: selectedCompany?.id,
      id: id,
    };
    const update = async () => {
      setLoading(true);
      try {
        const response = await jwtAxios.post(
          `${API_ROUTS.competencyMatrix}/upload-competency`,
          tempCompetencyMatrix,
        );
        if (response.status == 200) {
          dispatch(showMessage('Competency matrix updated successfully..!'));
          Router.push('/company-builder/compentency-matrix');
        } else {
          setLoading(false);
        }
      } catch (error) {
        apiCatchErrorMessage(error, dispatch, fetchError);
        setLoading(false);
      }
    };
    // await update();
  };

  const getHeadingText = () => {
    if (isView) return 'View Competency Matrix';
    if (!isEdit) return 'Add Competency Matrix';
    return 'Edit Competency Matrix';
  };

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>{getHeadingText()}</h2>

      <AppCard>
        <Stack sx={{mb: 10}}>
          <Stack>
            {domCreactionHeaderTitle(
              <IntlMessages id='calibration.BasicInfo' />,
            )}
          </Stack>
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>Name :</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <TextField
                size='small'
                name='name'
                disabled={isView}
                label={<IntlMessages id='calibration.Name' />}
                onChange={(event) =>
                  handleChangeCompetencyMatrix(event, 'textfield')
                }
                variant='outlined'
                error={competencyMatrixError.name.isError}
                helperText={competencyMatrixError.name.errorMessage}
                value={competencyMatrix.name ? competencyMatrix.name : ''}
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              />
            </Stack>
          </Stack>

          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>Status :</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id='status'>
                  <IntlMessages id='configuration.dialogbox.Status' />
                </InputLabel>
                <Select
                  size='small'
                  name='status'
                  disabled={isView}
                  label={<IntlMessages id='configuration.dialogbox.Status' />}
                  labelId='status'
                  value={competencyMatrix?.status || ''}
                  error={competencyMatrixError.status?.isError}
                  helperText={competencyMatrixError.status?.errorMessage}
                  onChange={(event) =>
                    handleChangeCompetencyMatrix(event, 'dropdown')
                  }
                  variant='outlined'
                  sx={{...textFieldStyled, width: '100%'}}
                >
                  <MenuItem key='Active' value='ACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Active' />
                  </MenuItem>
                  <MenuItem key='Inactive' value='INACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                  </MenuItem>
                </Select>
                <FormHelperText style={{color: '#d32f2f'}}>
                  {competencyMatrixError.status.errorMessage}
                </FormHelperText>
              </FormControl>
            </Stack>
          </Stack>
          {/* Matrix Type */}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>Matrix Type :</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id='Type'>
                  Type
                </InputLabel>
                <Select
                  size='small'
                  name='matrixType'
                  disabled={isView}
                  label={'Type'}
                  labelId='Type'
                  value={competencyMatrix?.matrixType || ''}
                  error={competencyMatrixError.matrixType?.isError}
                  helperText={competencyMatrixError.matrixType?.errorMessage}
                  onChange={(event) =>
                    handleChangeCompetencyMatrix(event, 'dropdown')
                  }
                  variant='outlined'
                  sx={{...textFieldStyled, width: '100%'}}
                >
                  <MenuItem key='none' value={null}>
                    None
                  </MenuItem>
                  <MenuItem key='COMPETENCY' value='COMPETENCY'>
                    Competency
                  </MenuItem>
                  <MenuItem key='MATRIX' value='MATRIX'>
                    Matrix
                  </MenuItem>
                </Select>
                <FormHelperText style={{color: '#d32f2f'}}>
                  {competencyMatrixError.matrixType.errorMessage}
                </FormHelperText>
              </FormControl>
            </Stack>
          </Stack>

          {/* File upload section */}
          {competencyMatrix?.matrixType == 'COMPETENCY' && (
            <Stack sx={{mt: 3, mb: 3}}>
              <Stack>{domCreactionHeaderTitle('File Upload')}</Stack>
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%'}}>
                  <Stack fontWeight={500}>Upload an Excel file : </Stack>
                </Stack>

                <Stack sx={{mt: 10, alignItems: 'start', width: '60%'}}>
                  <Box
                    sx={{
                      width: '80%',
                      // maxWidth: 400,
                      p: 3,
                      border: '1px solid #e0e0e0',
                      borderRadius: 2,
                      boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',
                      textAlign: 'center',
                      backgroundColor: '#f9f9f9',
                      position: 'relative',
                    }}
                  >
                    {isUploadingFile || isDeleteFile ? (
                      <CircularProgress
                        sx={{
                          margin: '0px 1rem',
                          color: '#000000',
                          width: '40px !important',
                          height: '40px !important',
                        }}
                      />
                    ) : (
                      <Stack>
                        {competencyMatrix?.file?.orignalFileName ? (
                          <Stack
                            direction='row'
                            alignItems='center'
                            spacing={1}
                            sx={{minHeight: '13vh', position: 'relative'}}
                          >
                            <Typography alignSelf='center' variant='body1' color='error'>
                              {competencyMatrix.file.orignalFileName}
                            </Typography>
                            <IconButton
                              onClick={() =>
                                handleRemoveFile(competencyMatrix.file.id)
                              }
                              color='error'
                              sx={{
                                position: 'absolute',
                                top: 13,
                                right: -30,
                                backgroundColor: '#ffffff',
                                boxShadow: '0px 2px 6px rgba(0, 0, 0, 0.2)',
                                '&:hover': {
                                  backgroundColor: '#f5f5f5',
                                },
                              }}
                            >
                              <DeleteIcon />
                            </IconButton>
                          </Stack>
                        ) : (
                          <>
                            <Typography
                              variant='h5'
                              sx={{color: 'text.secondary'}}
                            >
                              No file selected
                            </Typography>
                            <Typography
                              variant='h6'
                              sx={{mt: 2, mb: 2, color: 'text.secondary'}}
                            >
                              Supported formats: .xlsx, .xls
                            </Typography>
                            <Button
                              variant='contained'
                              component='label'
                              color='primary'
                              startIcon={<CloudUploadIcon />}
                              sx={{
                                textTransform: 'none',
                                fontWeight: 'bold',
                                borderRadius: 2,
                                py: 1.5,
                                px: 3,
                                backgroundColor: '#1976d2',
                                '&:hover': {
                                  backgroundColor: '#1565c0',
                                },
                                mt: 2,
                                width: '100%',
                              }}
                            >
                              Choose File
                              <input
                                type='file'
                                accept='.xlsx, .xls'
                                hidden
                                onChange={handleCaptureFile}
                                ref={fileInputRef}
                              />
                            </Button>
                          </>
                        )}
                      </Stack>
                    )}
                  </Box>
                  {competencyMatrixError.file?.isError && (
                    <FormHelperText style={{color: '#d32f2f', ml: 1, mt: 2}}>
                      {competencyMatrixError.file?.errorMessage}
                    </FormHelperText>
                  )}
                </Stack>
              </Stack>
            </Stack>
          )}
        </Stack>
        {/* ////////add Stack for fixed////// */}
        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0,
          }}
        >
          <Stack
            direction='row'
            justifyContent='end'
            alignItems='center'
            spacing={2}
            sx={{
              pt: 5,
              ml: 3,
              //// add marging for fixed stack///
              margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
            }}
          >
            <Button
              color={footerButton.back.color}
              variant={footerButton.back.variant}
              sx={footerButton.back.sx}
              size={footerButton.back.size}
              onClick={() => Router.push('/company-builder/competancy-matrix')}
            >
              <IntlMessages id='common.button.Back' />
            </Button>
            {!isView && (
              <Button
                color={footerButton.submit.color}
                variant={footerButton.submit.variant}
                sx={footerButton.submit.sx}
                size={footerButton.submit.size}
                disabled={loading}
                onClick={() => {
                  validateCompetencyMatrixData();
                }}
              >
                {loading ? (
                  <CircularProgress
                    sx={{
                      margin: '0px 1rem',
                      color: '#000000',
                      width: '25px !important',
                      height: '25px !important',
                    }}
                  />
                ) : (
                  <Stack>
                    {isEdit ? (
                      <IntlMessages id='common.button.Update' />
                    ) : (
                      <IntlMessages id='common.button.Submit' />
                    )}
                  </Stack>
                )}
              </Button>
            )}
          </Stack>
        </Stack>
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default AddCompetencyMatrix;
