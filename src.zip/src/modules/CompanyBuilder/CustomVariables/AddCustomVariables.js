import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import Stack from '@mui/material/Stack';
import { AppCard } from '../../../@crema';
import { showMessage, fetchError } from '../../../redux/actions';
import TextField from '@mui/material/TextField';
import PropTypes from 'prop-types';
import AppInfoView from '../../../@crema/core/AppInfoView';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import { useDispatch } from 'react-redux';
import jwtAxios from '@crema/services/auth/jwt-auth';
import { API_ROUTS } from 'shared/constants/ApiRouts';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import { EnumType } from 'shared/constants/AppConst';
import OptionTable from './OptionTable';
import {
  apiCatchErrorMessage, isEmptyNullUndefined,
  isStrExceeds
} from 'shared/utils/CommonUtils';
import IntlMessages from '@crema/utility/IntlMessages';

const AddCustomVariables = ({
  company,
  isEdit,
  handleClose,
  editCustomVariables,
  handleAddCustomVariables,
  isAddCustomVariablesOpen,
  handleUpdateCustomVariables,
  customVariables,
}) => {
  const textFieldStyled = {
    backgroundColor: 'white',
    mb: 2,
    width: '100%',
  };
  const formHelperTextStyle = {
    color: '#d32f2f',
    fontSize: '0.75rem',
    margin: '-4px 14px 4px',
  };
  const [isSubmitLoading, setIsSubmitLoading] = React.useState(false);
  const initialEmptyCustomVariablesList = {
    relationTable: '',
    variableName: '',
    dataType: '',
    company: {
      id: company?.id,
    },
    isRequired: false,
    isUnique: false,
    isMultiselect: false,
    options: [],
    status: '',
  };
  const initialFormErrorList = {
    relationTable: {isError: false, errorMessage: ''},
    variableName: {isError: false, errorMessage: ''},
    dataType: {isError: false, errorMessage: ''},
    isRequired: {isError: false, errorMessage: ''},
    isUnique: {isError: false, errorMessage: ''},
    isMultiselect: {isError: false, errorMessage: ''},
    options: {isError: false, errorMessage: ''},
    status: {isError: false, errorMessage: ''},
  };
  const [customVariablesData, setCustomVariablesData] = React.useState(
    initialEmptyCustomVariablesList,
  );
  const [formError, setFormError] = React.useState(initialFormErrorList);
  const dispatch = useDispatch();
  React.useEffect(() => {
    if (isEdit) {
      let tempEditCustomVariables = {...editCustomVariables};
      if (isEmptyNullUndefined(tempEditCustomVariables.company)) {
        tempEditCustomVariables.company = {
          id: company?.id,
        };
      }
      setCustomVariablesData(tempEditCustomVariables);
    }
  }, []);
  const handleChangeCustomVariablesData = (event, fieldType) => {
    const tempCustomVariables = {...customVariablesData};
    const tempError = {...formError};
    if (fieldType == 'textfield' || fieldType == 'dropdown') {
      tempCustomVariables[event.target.name] = event.target.value;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
    } else if (fieldType == 'isRequiredCheckbox') {
      tempCustomVariables.isRequired = event.target.checked;
    } else if (fieldType == 'isUniqueCheckbox') {
      tempCustomVariables.isUnique = event.target.checked;
    } else if (fieldType == 'isMultiselectCheckbox') {
      tempCustomVariables.isMultiselect = event.target.checked;
    }
    setCustomVariablesData(tempCustomVariables);
    setFormError(tempError);
  };
  const handleupdateOptions = (optionsRules) => {
    const tempError = {...formError};
    const tempCustomVariables = {...customVariablesData};
    tempCustomVariables.options = optionsRules;
    tempError.options = [];
    if (optionsRules.length > 0) {
      tempError.dataType.isError = false;
      tempError.dataType.errorMessage = '';
    }
    optionsRules.forEach((item) => {
      tempError.options.push({isError: false, errorMessage: ''});
    });

    setFormError(tempError);
    setCustomVariablesData(tempCustomVariables);
  };

  const handleValidateCustomVariables = async () => {
    let isValid = true;
    const tempError = JSON.parse(JSON.stringify(formError));
    const tempCustomVariables = JSON.parse(JSON.stringify(customVariablesData));

    if (tempCustomVariables.relationTable.trim() == '') {
      tempError.relationTable.isError = true;
      tempError.relationTable.errorMessage = (
        <IntlMessages id='error.pleaseSelectRelationTable' />
      );
      isValid = false;
    }
    if (tempCustomVariables.variableName.trim() == '') {
      tempError.variableName.isError = true;
      tempError.variableName.errorMessage = (
        <IntlMessages id='error.pleaseEnterVariableName' />
      );
      isValid = false;
    }
    if ((tempCustomVariables.variableName.trim().length < 3) || (tempCustomVariables.variableName.trim().length > 30 )) {
      tempError.variableName.isError = true;
      tempError.variableName.errorMessage = (
        'Variable name length must be between 3 - 30 chars'
      );
      isValid = false;
    }
    const regex = /^[^\d\s]+$/;
    if (!regex.test(tempCustomVariables.variableName)) {
      tempError.variableName.isError = true;
      tempError.variableName.errorMessage = (
        // <IntlMessages id='error.pleaseEnterVariableName' />
        'Only characters allowed'
      );
      isValid = false;
    }
    if (/\s/.test(tempCustomVariables.variableName)) {
      tempError.variableName.isError = true;
      tempError.variableName.errorMessage = (
        // <IntlMessages id='error.pleaseEnterVariableName' />
        'Remove blank space'
      );
      isValid = false;
    }

    if (
      !isEdit &&
      (customVariables
        .map((item) => item.variableName)
        .includes(tempCustomVariables.variableName) ||
        customVariables
          .map((item) => item.variableName.toLowerCase())
          .includes(tempCustomVariables.variableName.toLowerCase()))
    ) {
      tempError.variableName.isError = true;
      tempError.variableName.errorMessage = (
        <IntlMessages id='error.duplicateEntryFound' />
      );
      isValid = false;
    }

    if (
      isEdit &&
      (customVariables
        .map((item) =>
          item.id != tempCustomVariables.id ? item.variableName : null,
        )
        .includes(tempCustomVariables.variableName) ||
        customVariables
          .map((item) =>
            item.id != tempCustomVariables.id
              ? item.variableName.toLowerCase()
              : null,
          )
          .includes(tempCustomVariables.variableName.toLowerCase))
    ) {
      tempError.variableName.isError = true;
      tempError.variableName.errorMessage = (
        <IntlMessages id='error.duplicateEntryFound' />
      );
      isValid = false;
    }

    if (
      !isEdit &&
      customVariables
        .map((item) => item.variableName.trim())
        .includes(tempCustomVariables.variableName.trim())
    ) {
      tempError.variableName.isError = true;
      tempError.variableName.errorMessage = (
        <IntlMessages id='error.duplicateEntryFound' />
      );
      isValid = false;
    }

    if (
      isEdit &&
      customVariables
        .map((item) =>
          item.id != tempCustomVariables.id ? item.variableName.trim() : null,
        )
        .includes(tempCustomVariables.variableName.trim())
    ) {
      tempError.variableName.isError = true;
      tempError.variableName.errorMessage = (
        <IntlMessages id='error.duplicateEntryFound' />
      );
      isValid = false;
    }
    if (
      tempCustomVariables.status == null ||
      tempCustomVariables.status.trim() == ''
    ) {
      tempError.status.isError = true;
      tempError.status.errorMessage = (
        <IntlMessages id='error.pleaseSelectStatus' />
      );
      isValid = false;
    }
    if (isStrExceeds(tempCustomVariables.variableName, 50)) {
      tempError.variableName.isError = true;
      tempError.variableName.errorMessage = 'should not exceed 50 characters';
      isValid = false;
    }
    if (tempCustomVariables.dataType.trim() == '') {
      tempError.dataType.isError = true;
      tempError.dataType.errorMessage = (
        <IntlMessages id='error.pleaseSelectDataType' />
      );
      isValid = false;
    }
    if (
      tempCustomVariables.dataType === 'Array' &&
      tempCustomVariables.options.length == 0
    ) {
      tempError.dataType.isError = true;
      tempError.dataType.errorMessage =
        'Array needs to have atleast one option';
      isValid = false;
    }
    if (Array.isArray(tempCustomVariables.options)) {
      if (tempCustomVariables.options.length > 0) {
        tempError.options = [];
        tempCustomVariables.options.forEach((item) => {
          if (item.trim() != '') {
            tempError.options.push({isError: false, errorMessage: ''});
          } else {
            tempError.options.push({
              isError: true,
              errorMessage: (
                <IntlMessages id='error.pleaseEnter/deleteOption' />
              ),
            });
            isValid = false;
          }
        });
      }
    }

    //do Submit
    if (isValid) {
      if (isEdit) {
        updateCustomVariables();
      } else {
        submitCustomVariables();
      }
    } else {
      setFormError(tempError);
    }
  };

  const submitCustomVariables = async () => {
    setIsSubmitLoading(true);
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.customvariables}`,
        customVariablesData,
      );
      if (response.status == 200) {
        dispatch(
          showMessage(
            response.data.variableName +
              ' Custom Variable added successfully..!',
          ),
        );
        handleAddCustomVariables(response.data);
        setIsSubmitLoading(false);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
      setIsSubmitLoading(false);
    }
  };
  const updateCustomVariables = async () => {
    setIsSubmitLoading(true);
    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.customvariables}/${customVariablesData.id}`,
        customVariablesData,
      );
      if (response.status == 200) {
        dispatch(
          showMessage(
            response.data.variableName +
              ' Custom Variables updated successfully..!',
          ),
        );
        handleUpdateCustomVariables(response.data);
        setIsSubmitLoading(false);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
      setIsSubmitLoading(false);
    }
  };
  return (
    <Dialog maxWidth={'sm'} open={true}>
      <DialogContent>
        <Stack direction='row' justifyContent='center' sx={{mt: '2%'}}>
          <AppCard style={{width: '350px'}}>
            <h4 style={{display: 'flex'}}>
              {!isEdit ? (
                <IntlMessages id='customVariables.addCustomVariable' />
              ) : (
                <IntlMessages id='customVariables.updateCustomVariable' />
              )}
            </h4>
            <Stack sx={{mt: 2}} display='flex' justifyContent='center'>
              <FormControl sx={{mb: 0}}>
                <InputLabel size='small' id='event-type'>
                  <IntlMessages id='configuration.dialogbox.RelationTable' />
                </InputLabel>
                <Select
                  size='small'
                  name='relationTable'
                  label='Relation Table'
                  value={customVariablesData?.relationTable}
                  error={formError?.relationTable?.isError}
                  helperText={formError?.relationTable?.errorMessage}
                  onChange={(event) =>
                    handleChangeCustomVariablesData(event, 'dropdown')
                  }
                  variant='outlined'
                  sx={{
                    ...textFieldStyled,
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  }}
                >
                  <MenuItem key='employee' value='Employee'>
                    <IntlMessages id='configuration.dialogbox.Employee' />
                  </MenuItem>
                </Select>
                <FormHelperText style={formHelperTextStyle}>
                  {formError.relationTable.errorMessage}
                </FormHelperText>
              </FormControl>
              <TextField
                size='small'
                name='variableName'
                label={
                  <IntlMessages id='configuration.dialogbox.VariableName' />
                }
                onChange={(event) =>
                  handleChangeCustomVariablesData(event, 'textfield')
                }
                value={customVariablesData?.variableName}
                error={formError.variableName.isError}
                helperText={formError.variableName.errorMessage}
                variant='outlined'
                sx={{
                  ...textFieldStyled,
                  '& fieldset': {
                    borderLeftColor: 'red',
                    borderLeftWidth: 3,
                  },
                }}
              />
              <FormControl sx={{mb: 0}}>
                <InputLabel size='small' id='event-type'>
                  <IntlMessages id='configuration.dialogbox.DataType' />
                </InputLabel>
                <Select
                  size='small'
                  name='dataType'
                  label={<IntlMessages id='configuration.dialogbox.DataType' />}
                  value={customVariablesData?.dataType}
                  error={formError.dataType.isError}
                  helperText={formError.dataType.errorMessage}
                  onChange={(event) =>
                    handleChangeCustomVariablesData(event, 'dropdown')
                  }
                  variant='outlined'
                  sx={{
                    ...textFieldStyled,
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  }}
                >
                  {EnumType?.map((data) => (
                    <MenuItem key={data} value={data}>
                      {data}
                    </MenuItem>
                  ))}
                </Select>
                <FormHelperText style={formHelperTextStyle}>
                  {formError.dataType.errorMessage}
                </FormHelperText>
              </FormControl>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id='event-type'>
                  <IntlMessages id='configuration.dialogbox.Status' />
                </InputLabel>
                <Select
                  size='small'
                  name='status'
                  label='Status'
                  value={customVariablesData?.status}
                  error={formError.status.isError}
                  helperText={formError.status.errorMessage}
                  onChange={(event) =>
                    handleChangeCustomVariablesData(event, 'dropdown')
                  }
                  variant='outlined'
                  sx={{...textFieldStyled}}
                >
                  <MenuItem key='Active' value='ACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Active' />
                  </MenuItem>
                  <MenuItem key='Inactive' value='INACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Inactive' />
                  </MenuItem>
                </Select>
                <FormHelperText sx={{color: '#d32f2f', mt: -1}}>
                  {formError.status.errorMessage}
                </FormHelperText>
              </FormControl>
              <Stack direction='row' justifyContent='left'>
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={customVariablesData?.isRequired}
                      size='small'
                      onChange={(event) =>
                        handleChangeCustomVariablesData(
                          event,
                          'isRequiredCheckbox',
                        )
                      }
                    />
                  }
                  label={
                    <IntlMessages id='configuration.dialogbox.IsRequired' />
                  }
                />
                <FormControlLabel
                  control={
                    <Checkbox
                      checked={customVariablesData?.isUnique}
                      size='small'
                      onChange={(event) =>
                        handleChangeCustomVariablesData(
                          event,
                          'isUniqueCheckbox',
                        )
                      }
                    />
                  }
                  label={<IntlMessages id='configuration.dialogbox.IsUnique' />}
                  sx={{ml: 15}}
                />
              </Stack>
              {isAddCustomVariablesOpen &&
              customVariablesData?.dataType === 'Array' ? (
                <Stack direction='row' justifyContent='left'>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={customVariablesData?.isMultiselect}
                        size='small'
                        onChange={(event) =>
                          handleChangeCustomVariablesData(
                            event,
                            'isMultiselectCheckbox',
                          )
                        }
                      />
                    }
                    // label={
                    //   <IntlMessages id='configuration.dialogbox.IsRequired' />
                    // }
                    label={'Is MultiSelect'}
                  />
                </Stack>
              ) : null}
            </Stack>

            {isAddCustomVariablesOpen &&
            customVariablesData?.dataType === 'Array' ? (
              <Stack
                direction='row'
                sx={{mt: 2, mb: 2}}
                alignItems='flex-start'
              >
                <OptionTable
                  existingOptions={customVariablesData?.options}
                  handleupdateOptions={(option) => handleupdateOptions(option)}
                  formError={formError}
                  setFormError={setFormError}
                ></OptionTable>
              </Stack>
            ) : (
              ''
            )}
          </AppCard>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button
          name='submit'
          disabled={isSubmitLoading}
          onClick={() => handleValidateCustomVariables()}
        >
          <IntlMessages id='common.button.Submit' />
        </Button>
        <Button name='close' onClick={() => handleClose()}>
          <IntlMessages id='common.button.Close' />
        </Button>
      </DialogActions>
      <AppInfoView />
    </Dialog>
  );
};
export default AddCustomVariables;
AddCustomVariables.propTypes = {
  company: PropTypes.object,
  handleAddCustomVariables: PropTypes.func,
  handleUpdateCustomVariables: PropTypes.func,
  handleClose: PropTypes.func,
  isEdit: PropTypes.bool,
  editCustomVariables: PropTypes.object,
  isAddCustomVariablesOpen: PropTypes.bool,
  customVariables: PropTypes.array,
};
