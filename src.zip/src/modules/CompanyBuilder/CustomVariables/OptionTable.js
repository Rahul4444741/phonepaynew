import * as React from 'react';
import Table from '@mui/material/Table';
import TextField from '@mui/material/TextField';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import TableRow from '@mui/material/TableRow';
import { styled } from '@mui/material/styles';
import Card from '@mui/material/Card';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import { useDispatch } from 'react-redux';
import HighlightOffIcon from '@mui/icons-material/HighlightOff';
import PropTypes from 'prop-types';
import { Divider } from '@mui/material';
import { fetchError } from '../../../redux/actions';
import IntlMessages from '@crema/utility/IntlMessages';

const iconButtonStyled = {padding: '2px 10px'};
const StyledTableCell = styled(TableCell)(({theme}) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.primary,
    fontWeight: 'bold',
  },
  ['&.MuiTableCell-root']: {
    padding: '5px 10px 5px 10px',
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

export default function OptionTable({
  handleupdateOptions,
  existingOptions,
  formError,
  setFormError,
}) {
  const [options, setOptions] = React.useState(
    existingOptions.length == 0 ? [''] : existingOptions,
  );
  const [optionsArrayUploading, setOptionsArrayUploading] =
    React.useState(false);
  const rawOptionsError = {
    isError: false,
    errorMessage: '',
  };

  React.useEffect(() => {
    if (existingOptions.length == 0) {
      handleChangeOptionsData({target: {value: ''}}, 0, 'textfield');
    } else {
      handleupdateOptions(existingOptions);
    }
  }, []);

  const handleChangeOptionsData = (event, index, fieldType) => {
    let tempOptions = [...options];
    const tempError = {...formError};
    tempError.options = [];
    tempOptions.forEach((item) => {
      tempError.options.push({isError: false, errorMessage: ''});
    });
    let optionsEdit = [...tempOptions];
    if (fieldType == 'textfield') {
      optionsEdit[index] = event.target.value;
      tempOptions = optionsEdit;
    }
    setFormError(tempError);
    setOptions(tempOptions);
    handleupdateOptions(tempOptions);
  };

  const handleDeleteOptions = (index) => {
    const tempError = {...formError};
    const tempOptions = [...options];
    tempOptions.splice(index, 1);
    tempError.options.splice(index, 1);
    setFormError(tempError);
    setOptions(tempOptions);
    handleupdateOptions(tempOptions);
  };

  const handleInsertOptions = () => {
    let rawOptions = '';
    const tempError = {...formError};
    tempError.options = [];
    const tempOptions = [...options];
    tempError.options.push(rawOptionsError);
    tempOptions.push(rawOptions);
    setFormError(tempError);
    setOptions(tempOptions);
    handleupdateOptions(tempOptions);
  };

  const textFieldStyled = {
    backgroundColor: 'white',
    mb: 0,
    width: {xs: '100%', xl: '50%', md: '100%'},
  };
  const dispatch = useDispatch();

  const handleCaptureFile = (event) => {
    setOptionsArrayUploading(true);
    const file =
      event.target.files.length > 0 ? event.target.files[0] : undefined;

    if (!file) {
      dispatch(fetchError('Invalid file'));
      setOptionsArrayUploading(false);
      return;
    }

    let rawOptions = '';

    const tempError = {...formError};
    tempError.options = [];
    let tempOptions = [...options];
    let updatedTempOptions = tempOptions.filter((str) => str.trim() !== '');

    const processCSV = async (str, delim = ',') => {
      const optionsInFile = str.split('\n');
      optionsInFile.forEach((option, index) => {
        if (option.trim() != '') {
          tempError.options.push(rawOptionsError);
          updatedTempOptions.push(rawOptions);
          updatedTempOptions[updatedTempOptions.length - 1] = option
            .split(delim)[0]
            .trim();
        }
      });
      setFormError(tempError);
      setOptions(updatedTempOptions);
      handleupdateOptions(updatedTempOptions);
      setOptionsArrayUploading(false);
    };

    const reader = new FileReader();

    reader.onload = function (e) {
      const text = e.target.result;

      processCSV(text, ',');
    };
    reader.readAsText(file);
  };

  return (
    <TableContainer component={Card}>
      <Backdrop
        sx={{color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1}}
        open={optionsArrayUploading}
      >
        <CircularProgress color='inherit' />
      </Backdrop>
      <Divider color='grey' sx={{my: 3}} varint='fullWidth' />
      <Stack
        direction='row'
        justifyContent='flex-end'
        sx={{mt: 2, mb: 2, mr: 1}}
      >
        <Button
          name='add'
          variant='outlined'
          size='small'
          onClick={() => handleInsertOptions()}
        >
          <IntlMessages id='customVariables.view.add' />
        </Button>
        <Button
          variant='outlined'
          component='label'
          disabled={optionsArrayUploading}
          size='small'
          sx={{whiteSpace: 'nowrap', ml: 2}}
        >
          <IntlMessages id='customVariables.view.upload' />
          <input
            type='file'
            hidden
            onChange={(event) => handleCaptureFile(event)}
            accept='.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'
          />
        </Button>
      </Stack>
      <Table stickyHeader sx={{minWidth: 280}} aria-label='simple table'>
        <TableBody>
          {options?.map((row, index) => (
            <TableRow
              key={index}
              sx={{'&:last-child td, &:last-child th': {border: 0}}}
            >
              <>
                <StyledTableCell align='left'>
                  {
                    <Stack direction='row'>
                      <TextField
                        size='small'
                        name='options'
                        // label='Option'
                        label={
                          <IntlMessages id='customVariables.view.option' />
                        }
                        onChange={(event) =>
                          handleChangeOptionsData(event, index, 'textfield')
                        }
                        value={row}
                        error={
                          formError?.options[index]?.isError
                            ? formError?.options[index]?.isError
                            : false
                        }
                        helperText={
                          formError?.options[index]?.errorMessage
                            ? formError?.options[index]?.errorMessage
                            : ''
                        }
                        variant='outlined'
                        sx={{...textFieldStyled}}
                      />
                    </Stack>
                  }
                </StyledTableCell>
                <StyledTableCell align='left'>
                  {
                    <Stack direction='row' sx={{mb: 0}}>
                      <IconButton
                        sx={{...iconButtonStyled}}
                        aria-label='delete'
                        onClick={() => handleDeleteOptions(index)}
                      >
                        <HighlightOffIcon color='error' />
                      </IconButton>
                    </Stack>
                  }
                </StyledTableCell>
              </>
              {/* )} */}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

OptionTable.propTypes = {
  handleupdateOptions: PropTypes.func.isRequired,
  existingOptions: PropTypes.array.isRequired,
  formError: PropTypes.object.isRequired,
  setFormError: PropTypes.object.isRequired,
};
