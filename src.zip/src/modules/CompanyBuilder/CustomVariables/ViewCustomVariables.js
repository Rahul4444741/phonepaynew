import * as React from 'react';
import Stack from '@mui/material/Stack';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard} from '../../../@crema';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import Router, {useRouter} from 'next/router';
import {useDispatch} from 'react-redux';
import {fetchError} from '../../../redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import axios from 'axios';
import {Button} from '@mui/material';
import {footerButton} from 'shared/constants/AppConst';
import {apiCatchErrorMessage} from 'shared/utils/CommonUtils';
import IntlMessages from '@crema/utility/IntlMessages';

const ViewCustomVariables = () => {
  const [customVariables, setCustomVariables] = React.useState(null);
  const router = useRouter();
  const dispatch = useDispatch();
  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  React.useEffect(() => {
    const {id} = router.query;
    getCustomVariablesDetails(id);
    return () => {
      source.cancel('Aborting all previous operations.');
    };
  }, [router]);
  const getCustomVariablesDetails = async (variableId) => {
    try {
      const response = await jwtAxios.get(
        `${API_ROUTS.customvariables}/${variableId}`,
        {cancelToken: source.token},
      );
      if (response.status == 200) {
        setCustomVariables(response.data);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
    }
  };
  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 2}}>
        <IntlMessages id='customVariables.view.pageHeaderName' />
      </h2>
      <AppCard>
        <h3
          style={{
            marginBottom: 10,
            backgroundColor: '#D3D3D3',
            borderRadius: 10,
            padding: 5,
          }}
        >
          <IntlMessages id='customVariables.view.customVariableInfo' /> :
        </h3>
        <Stack
          direction='row'
          sx={{mt: 2, ml: 10}}
          justifyContent='space-between'
          alignItems='flex-start'
          spacing={2}
        >
          <Stack sx={{width: '50%'}}>
            <div>
              <b>
                <IntlMessages id='customVariables.view.relationTable' />
              </b>
              <span style={{marginLeft: 75}}>
                {customVariables?.relationTable}
              </span>
            </div>
          </Stack>
          <Stack sx={{width: '50%'}} style={{marginLeft: 120}}>
            <div>
              <b>
                <IntlMessages id='customVariables.view.variableName' />
              </b>
              <span style={{marginLeft: 75}}>
                {customVariables?.variableName}
              </span>
            </div>
          </Stack>
        </Stack>
        <Stack
          direction='row'
          sx={{mt: 2, ml: 10}}
          justifyContent='space-between'
          alignItems='flex-start'
          spacing={2}
        >
          <Stack sx={{width: '50%'}}>
            <div>
              <b>
                <IntlMessages id='customVariables.view.dataType' />
              </b>
              <span style={{marginLeft: 103}}>{customVariables?.dataType}</span>
            </div>
          </Stack>
          <Stack sx={{width: '50%'}} style={{marginLeft: 120}}>
            <div>
              <b>
                <IntlMessages id='customVariables.view.isRequired' />
              </b>
              <span style={{marginLeft: 101}}>
                {customVariables?.isRequired ? 'Yes' : 'No'}
              </span>
            </div>
          </Stack>
        </Stack>
        <Stack
          direction='row'
          sx={{mt: 2, ml: 10}}
          justifyContent='space-between'
          alignItems='flex-start'
          spacing={2}
        >
          <Stack sx={{width: '50%'}}>
            <div>
              <b>
                <IntlMessages id='customVariables.view.isUnique' />
              </b>
              <span style={{marginLeft: 111}}>
                {customVariables?.isUnique ? 'Yes' : 'No'}
              </span>
            </div>
          </Stack>
        </Stack>
        {customVariables?.dataType === 'Array' ? (
          <>
            <h3
              style={{
                marginTop: 10,
                backgroundColor: '#D3D3D3',
                borderRadius: 10,
                padding: 5,
              }}
            >
              Options Information :
            </h3>
            <Stack
              direction='row'
              sx={{mt: -2, ml: 10}}
              justifyContent='space-between'
              alignItems='flex-start'
              spacing={2}
            >
              <Stack sx={{width: '50%'}}>
                <div>
                  <span style={{marginLeft: 120}}>
                    {customVariables?.options.map((item) => (
                      <li key={item}>{item}</li>
                    ))}
                  </span>
                </div>
              </Stack>
            </Stack>
          </>
        ) : (
          ''
        )}
        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0,
          }}
        >
          <Stack
            direction='row'
            justifyContent='end'
            alignItems='center'
            spacing={2}
            sx={{
              pt: 5,
              ml: 3,
              margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
            }}
          >
            <Button
              color={footerButton.back.color}
              variant={footerButton.back.variant}
              sx={footerButton.back.sx}
              size={footerButton.back.size}
              onClick={() => Router.push('/company-builder/custom-variables')}
            >
              <IntlMessages id='common.button.Back' />
            </Button>
          </Stack>
        </Stack>
      </AppCard>
    </AppAnimate>
  );
};

export default ViewCustomVariables;
