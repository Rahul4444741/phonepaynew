import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import {useDispatch, useSelector} from 'react-redux';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard} from '../../../@crema';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import {
  showMessage,
  fetchError,
  fetchStart,
  showInfo,
} from '../../../redux/actions';
import Router from 'next/router';
import AppInfoView from '../../../@crema/core/AppInfoView';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {AgGridReact} from 'ag-grid-react';
import AddCustomVariables from './AddCustomVariables';
import {TextField, ToggleButton, ToggleButtonGroup} from '@mui/material';
import axios from 'axios';
import {
  isEmptyNullUndefined,
  buttonStyle,
  apiCatchErrorMessage,
  isAllowedUser,
} from 'shared/utils/CommonUtils';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import AlertDialog from 'modules/Common/AlertDialog';
import IntlMessages from '@crema/utility/IntlMessages';
import {permissionName} from 'shared/utils/PermissionName';
import Error403 from 'modules/errorPages/Error403';
import { useCallback } from 'react';


const CustomHeaderRelationTable = () => (
  <IntlMessages id='aggrid.tableHeader.RelationTable' />
);
const CustomHeaderVariableName = () => (
  <IntlMessages id='aggrid.tableHeader.VariableName' />
);
const CustomHeaderDataType = () => (
  <IntlMessages id='aggrid.tableHeader.DataType' />
);
const CustomHeaderStatus = () => (
  <IntlMessages id='aggrid.tableHeader.Status' />
);
const CustomHeaderAction = () => (
  <IntlMessages id='aggrid.tableHeader.Action' />
);

const CustomVariables = () => {
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const dispatch = useDispatch();
  const [isAddCustomVariablesOpen, setIsAddCustomVariablesOpen] =
    React.useState(false);
  const [isEdit, setIsEdit] = React.useState(false);
  const [editCustomVariables, setEditCustomVariables] =
    React.useState(undefined);
  const [customVariables, setCustomVariables] = React.useState(null);
  const [overlayMessage, setOverlayMessage] = React.useState('No Rows To Show');
  const [isLoading, setIsLoading] = React.useState(true);

  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);

  React.useEffect(() => {
    if (isAllowedUser(permissionName.COMPANY_VARIABLES_CUSTOM_VARIABLES)) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  const StatusRenderer = (params) => (
    <Stack direction='row'>
      <div style={{ color: params.data.status === 'ACTIVE' ? '#11C15B' : '#D32F2F' }}>
        {params.data.status}
      </div>
    </Stack>
  );
  const ActionRenderer = (params) => (
    <Stack direction='row'>
      {isAllowedUser(permissionName.READ) && (
        <Button
          name='view'
          onClick={() => handleRedirectViewCustomVariables(params)}
          style={buttonStyle}
        >
          <IntlMessages id='common.button.View' />
        </Button>
      )}
      {isAllowedUser(permissionName.UPDATE) && (
        <Button
          name='edit'
          onClick={() => handleOpenEditCustomVariables(params)}
          style={buttonStyle}
        >
          <IntlMessages id='common.button.Edit' />
        </Button>
      )}
      {isAllowedUser(permissionName.DEACTIVATE) && params.data.status === 'ACTIVE' && (
        <Button
          onClick={() => handleDeactivateConfirmation(params)}
          style={buttonStyle}
        >
          <IntlMessages id='common.button.Deactivate' />
        </Button>
      )}
      {isAllowedUser(permissionName.ACTIVATE) && params.data.status === 'INACTIVE' && (
        <Button
          onClick={() => handleActivateConfirmation(params)}
          style={buttonStyle}
        >
          <IntlMessages id='common.button.Activate' />
        </Button>
      )}
    </Stack>
  );

  const columnDefs = [
    {
      field: 'relationTable',
      filter: true,
      headerName: 'Relation Table',
      headerComponentFramework: CustomHeaderRelationTable,
      minWidth: 100,
    },
    {
      field: 'variableName',
      filter: true,
      headerName: 'Variable Name',
      headerComponentFramework: CustomHeaderVariableName,
      minWidth: 100,
    },
    {
      field: 'dataType',
      filter: true,
      headerName: 'Data Type',
      headerComponentFramework: CustomHeaderDataType,
      minWidth: 100,
    },
    {
      field: 'status',
      filter: true,
      headerName: 'Status',
      headerComponentFramework: CustomHeaderStatus,
      minWidth: 100,
      cellRenderer: StatusRenderer,  // Use custom status renderer
    },
    {
      headerName: 'Action',
      headerComponentFramework: CustomHeaderAction,
      minWidth: 100,
      cellRenderer: ActionRenderer,  // Use custom action renderer
    },
  ];
      
  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  React.useEffect(() => {
    dispatch(fetchStart);
    if (
      isAuthorized &&
      selectedCompany != null &&
      selectedCompany != undefined
    ) {
      getAllCustomVariables(selectedCompany.id, 'ACTIVE');
    }
    return () => {
      source.cancel('Aborting all previous operations.');
    };
  }, [isAuthorized && selectedCompany]);

  const gridRef = React.useRef();
  const defaultColDef = React.useMemo(() => ({
    sortable: true,
    flex: 1,
  }));
  const handleRedirectViewCustomVariables = (variable) => {
    Router.push('/company-builder/view-customVariables?id=' + variable.data.id);
  };
  const [alignment, setAlignment] = React.useState('ACTIVE');
  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
  };
  const [alertProps, setAlertProps] = React.useState({
    isHideShow: false,
    message: '',
    title: '',
    alertType: '',
    actionParams: null,
  });
  const handleDeactivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = (
      <IntlMessages id='warning.deactivateCustomVariable' />
    );
    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureDeactivate' />{' '}
        {params.data.variableName} ?
      </span>
    );
    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleActivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = <IntlMessages id='warning.activateCustomVariable' />;
    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureActivate' />{' '}
        {params.data.variableName} ?
      </span>
    );

    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleAlertYes = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.actionParams.data.status == 'ACTIVE' &&
      handleDeactivateCV(tempAlertProps.actionParams, selectedCompany.id);
    tempAlertProps.actionParams.data.status == 'INACTIVE' &&
      handleActivateCV(tempAlertProps.actionParams, selectedCompany.id);
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };
  const handleAlertNo = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };
  const handleDeactivateCV = async (params, companyId) => {
    setIsLoading(() => true);
    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.customvariables}/inactivate/${params.data.id}`,
      );
      if (response.status == 200) {
        dispatch(
          showMessage(
            `${response.data.variableName} variable deactivated successfully..!`,
          ),
        );
        getAllCustomVariables(selectedCompany.id, 'INACTIVE');
        setAlignment('INACTIVE');
        setIsLoading(() => false);
      } else {
        setIsLoading(() => false);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
      setIsLoading(() => false);
    }
  };

  const handleActivateCV = async (params, companyId) => {
    setIsLoading(() => true);
    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.customvariables}/activate/${params.data.id}`,
      );
      if (response.status == 200) {
        dispatch(
          showMessage(
            `${response.data.variableName} variable activated successfully..!`,
          ),
        );
        getAllCustomVariables(selectedCompany.id, 'ACTIVE');
        setAlignment('ACTIVE');
        setIsLoading(() => false);
      } else {
        setIsLoading(() => false);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
      setIsLoading(() => false);
    }
  };
  const getAllCustomVariables = async (companyId, status) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.customvariables_company}${companyId}?status=${status}`,
        {cancelToken: source.token},
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(
            showInfo(
              `You have no ${status.toLowerCase()} Custom Variables for selected company`,
            ),
          );
          setCustomVariables([]);
        } else {
          setCustomVariables(res.data.reverse());
        }
        setIsLoading(() => false);
      } else {
        setCustomVariables([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setCustomVariables([]);
      setIsLoading(() => false);
    }
  };
  const handleOpenEditCustomVariables = (params) => {
    let rowData = [];
    params.api.forEachNode((node) => rowData.push(node.data));
    const customVariablesIndex = rowData.findIndex(
      (item) => item.id == params.data.id,
    );
    if (customVariablesIndex != -1)
      setEditCustomVariables(rowData[customVariablesIndex]);
    setIsEdit(true);
    setIsAddCustomVariablesOpen(true);
  };

  const handleAddCustomVariablesToList = (variable) => {
    const { status } = variable;
    const isActive = status === 'ACTIVE';
    const isAligned = alignment === status;
  
    if (isAligned) {
      setCustomVariables([variable, ...customVariables]);
    } else {
      setAlignment(isActive ? 'ACTIVE' : 'INACTIVE');
      getAllCustomVariables(selectedCompany.id, isActive ? 'ACTIVE' : 'INACTIVE');
    }
  
    setIsAddCustomVariablesOpen(false);
  };
  

  const handleUpdateCustomVariables = (variable) => {
    const isActive = variable.status === 'ACTIVE';
    const isInactive = variable.status === 'INACTIVE';
  
    // Update custom variables if the status and alignment match
    if ((isActive && alignment === 'ACTIVE') || (isInactive && alignment === 'INACTIVE')) {
      const tempCustomVariables = [...customVariables];
      const customVarIndex = tempCustomVariables.findIndex(
        (item) => item.id === variable.id,
      );
  
      if (customVarIndex !== -1) {
        tempCustomVariables[customVarIndex] = variable;
        setCustomVariables(tempCustomVariables);
      }
    }
  
    // Handle alignment changes and fetch data if needed
    if ((isActive && alignment === 'INACTIVE') || (isInactive && alignment === 'ACTIVE')) {
      setAlignment(isActive ? 'ACTIVE' : 'INACTIVE');
      getAllCustomVariables(selectedCompany.id, isActive ? 'ACTIVE' : 'INACTIVE');
    }
  
    // Cleanup
    setEditCustomVariables(null);
    setIsEdit(false);
    setIsAddCustomVariablesOpen(false);
  };
  
  const handleCloseAddCustomVariables = () => {
    setIsAddCustomVariablesOpen(false);
  };
  const handleOpenAddCustomVariables = () => {
    setIsAddCustomVariablesOpen(true);
    setIsEdit(false);
  };
 
  const onFilterTextBoxChanged = useCallback(() => {
    const filterText = document.getElementById("filter-text-box").value;
    gridRef.current.api.setGridOption("quickFilterText", filterText);
    const totalResults = gridRef.current.api.getDisplayedRowCount();
    if (!isEmptyNullUndefined(customVariables) && customVariables.length > 0) {
      if (totalResults === 0 && !isEmptyNullUndefined(filterText)) {
        setOverlayMessage('No Record Found');
        gridRef.current.api.showNoRowsOverlay();
      } else if (totalResults !== 0) {
        setOverlayMessage('No Rows To Show');
        gridRef.current.api.hideOverlay();
      }
    }
  }, []);

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (!isAuthorized) {
    return <Error403 />;
  }

  return (
      <AppAnimate animation='transition.slideUpIn' delay={500}>
        <AppPageMeta />
        <h2 style={{marginBottom: 20}}>
          <IntlMessages id='customVariables.pageHeaderName' />
        </h2>
        <AppCard>
          <Stack
            direction='row'
            sx={{mb: 2}}
            justifyContent={'end'}
            spacing={2}
          >
            <TextField
              // size='small'
              sx={{width: 200}}
              id="filter-text-box"
              onInput={onFilterTextBoxChanged}
              type={'search'}
              name='search'
              label={<IntlMessages id='common.button.Search' />}
              variant='outlined'
            />{' '}
            {isAllowedUser(permissionName.CREATE) && (
              <Button
                variant='outlined'
                name='addVariable'
                onClick={() => handleOpenAddCustomVariables()}
                sx={{ml: 1}}
              >
                <IntlMessages id='customVariables.addCustomVariable' />
              </Button>
            )}
            <ToggleButtonGroup
              color='primary'
              value={alignment}
              exclusive
              onChange={handleChange}
              sx={{ml: 1}}
            >
              <ToggleButton
                value='ACTIVE'
                onClick={() =>
                  getAllCustomVariables(selectedCompany.id, 'ACTIVE')
                }
                disabled={isLoading}
              >
                <IntlMessages id='common.button.Active' />
              </ToggleButton>
              <ToggleButton
                value='INACTIVE'
                onClick={() =>
                  getAllCustomVariables(selectedCompany.id, 'INACTIVE')
                }
                disabled={isLoading}
              >
                <IntlMessages id='common.button.Inactive' />
              </ToggleButton>
            </ToggleButtonGroup>
          </Stack>
          {isLoading ? (
            domCreactionGridSkeletonLoader()
          ) : (
            <Stack
              className='ag-theme-alpine'
              style={{height: 525, width: '100%'}}
            >
              <AgGridReact
                ref={gridRef}
                rowData={customVariables}
                columnDefs={columnDefs}
                defaultColDef={defaultColDef}
                animateRows={true}
                pagination={true}
                paginationPageSize={10}
                overlayLoadingTemplate={
                  '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'
                }
                overlayNoRowsTemplate={`<span class="ag-overlay-loading-center">${overlayMessage}</span>`}
              />
            </Stack>
          )}
          {isAddCustomVariablesOpen && (
            <AddCustomVariables
              company={selectedCompany}
              isEdit={isEdit}
              editCustomVariables={editCustomVariables}
              handleAddCustomVariables={(variable) =>
                handleAddCustomVariablesToList(variable)
              }
              isAddCustomVariablesOpen={isAddCustomVariablesOpen}
              handleUpdateCustomVariables={(variable) =>
                handleUpdateCustomVariables(variable)
              }
              handleClose={() => handleCloseAddCustomVariables()}
              customVariables={customVariables}
            ></AddCustomVariables>
          )}
          {alertProps.isHideShow && (
            <AlertDialog
              alertProps={alertProps}
              handleYes={() => handleAlertYes()}
              handleNo={() => handleAlertNo()}
            />
          )}
        </AppCard>
        <AppInfoView />
      </AppAnimate>
  );
};

export default CustomVariables;
