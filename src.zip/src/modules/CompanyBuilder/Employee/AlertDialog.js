import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import PropTypes from 'prop-types';
import Stack from '@mui/material/Stack';
import IconButton from '@mui/material/IconButton';
import WarningIcon from '@mui/icons-material/Warning';
import IntlMessages from '@crema/utility/IntlMessages';
import {Typography} from '@mui/material';

const AlertDialog = ({alertProps, handleNo, handleYes}) => {
  const iconButtonStyled = {padding: '2px 10px'};
  return (
    <div>
      <Dialog
        open={true}
        onClose={() => handleNo()}
        aria-labelledby='alert-dialog-title'
        aria-describedby='alert-dialog-description'
      >
        <DialogTitle id='alert-dialog-title'>
          <Stack direction='row'>
            <IconButton sx={{...iconButtonStyled}} aria-label='save'>
              <WarningIcon color='warning' />
            </IconButton>
            <Stack sx={{fontSize: 20}}>{alertProps.title}</Stack>
          </Stack>
        </DialogTitle>

        <DialogContent sx={{marginBottom: '3px', overflow: 'visible'}}>
          <DialogContentText id='alert-dialog-description'>
            <Stack sx={{fontSize: 16}}>{alertProps.message}</Stack>
          </DialogContentText>
        </DialogContent>
        <DialogContent sx={{marginBottom: '2px', overflow: 'visible'}}>
          <DialogContentText id='alert-dialog-description'>
            <Stack sx={{fontSize: 16}}>
              {/* selected Employee:- */}
              <IntlMessages id='common.button.selected_Employee' />
            </Stack>
          </DialogContentText>
        </DialogContent>
        <DialogContent>
          <DialogContentText id='alert-dialog-description'>
            <Stack sx={{fontSize: 16}}>
              {alertProps.selectedEmployeeName.map((name, index) => (
                <Typography
                  key={index}
                  component='span'
                  sx={{
                    color:
                      index % 2 === 0
                        ? 'rgb(107, 114, 128)'
                        : 'rgb(107, 114, 128)',
                  }} // Change colors as needed
                >
                  {name}
                  {index < alertProps.selectedEmployeeName.length - 1 && ', '}
                </Typography>
              ))}
            </Stack>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            id='alert-dialog-accept-submit-button'
            onClick={() => handleYes()}
          >
            {/* <IntlMessages id='common.button.Yes' /> */}
            <IntlMessages id='common.button.YesIAmSure' />
          </Button>
          <Button
            id='alert-dialog-reject-submit-button'
            onClick={() => handleNo()}
          >
            <IntlMessages id='common.button.No' />
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};

AlertDialog.propTypes = {
  alertProps: PropTypes.object.isRequired,
  handleNo: PropTypes.func.isRequired,
  handleYes: PropTypes.func.isRequired,
};
export default AlertDialog;
