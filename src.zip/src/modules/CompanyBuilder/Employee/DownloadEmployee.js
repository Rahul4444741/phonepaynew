import {Button, FormControl, InputLabel, MenuItem, Select} from '@mui/material';
import React, {useEffect, useState} from 'react';
import {FaFileCsv} from 'react-icons/fa';
import {RiFileExcel2Fill} from 'react-icons/ri';
import ExcelJS from 'exceljs';
import {format} from 'date-fns';
import PropTypes from 'prop-types';
import IntlMessages from '@crema/utility/IntlMessages';
import axios from 'axios';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {fetchError, showInfo} from 'redux/actions';
import {apiCatchErrorMessage} from 'shared/utils/CommonUtils';
import {useDispatch, useSelector} from 'react-redux';
import jwtAxios from '@crema/services/auth/jwt-auth';

const extractNestedValue = (obj, key) => {
  const keys = key.split('.');
  let value = obj;
  for (const k of keys) {
    value = value[k];
    if (!value) break;
  }
  return value !== undefined ? value : '';
};

const DownloadEmployee = ({data, columns}) => {
  const dispatch = useDispatch();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const [employeeDisplay, setEmployeeDisplay] = React.useState([]);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();

  React.useEffect(() => {
      getAllVariableNameMapping();
  }, []);

  const getAllVariableNameMapping = async () => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.variable_name_mapping}/find-by-entity/Employee/${selectedCompany.id}`,
        {headers: {}},
        {
          cancelToken: source.token,
        },
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(
            showInfo('You have no Variable Name Mapping for selected company'),
          );
          setEmployeeDisplay([]);
        } else {
          setEmployeeDisplay(res.data);
        }
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
      }
      setEmployeeDisplay([]);
    }
  };

  const getLable = (name) => {
    const field = employeeDisplay?.find((item) => item.variableName == name);
    return field?.displayName;
  };

  const selectedColumns = [
    {label: getLable('name'), key: 'name'},
    {label: getLable('emailId'), key: 'emailId'},
    {label: getLable('dateOfBirth'), key: 'dateOfBirth'},
    {label: getLable('employeeId'), key: 'employeeId'},
    {label: getLable('employeeDesignation'), key: 'employeeDesignation'},
    {label: getLable('dateOfJoining'), key: 'dateOfJoining'},
    {label: getLable('employeeLevel'), key: 'employeeLevel.name'},
    {label: getLable('empstatus'), key: 'empstatus.name'},
    {label: getLable('employmentStatus'), key: 'employmentStatus.name'},
    {label: getLable('employeeType'), key: 'employeeType.name'},
    {label: getLable('employeeGrade'), key: 'employeeGrade.name'},
    {label: getLable('employeeFunction'), key: 'employeeFunction.name'},
    {label: getLable('employeeSubFunction'), key: 'employeeSubFunction.name'},
    {label: getLable('isManager'), key: 'isManager'},
    {label: getLable('isFunctionalLeader'), key: 'isFunctionalLeader'},
    {label: `Manger ${getLable('name')}`, key: 'manager.name'},
    {label: `Manger ${getLable('employeeId')}`, key: 'manager.employeeId'},
    {label: `Manger ${getLable('emailId')}`, key: 'manager.emailId'},
  ];

  const handleExportCSV = () => {
    const formattedCSVData = data.map((item) => {
      return selectedColumns.map((col) => {
        if (
          col.key === 'dateOfBirth' ||
          col.key === 'dateOfJoining' ||
          col.key === 'effectiveDate'
        ) {
          return item[col.key]
            ? format(new Date(item[col.key]), 'dd/MM/yyyy')
            : '';
        } else {
          return extractNestedValue(item, col.key);
        }
      });
    });

    const csvContent = [
      selectedColumns.map((col) => col.label),
      ...formattedCSVData.map((row) => row.join(',')),
    ].join('\n');

    const blob = new Blob([csvContent], {type: 'text/csv'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'data.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleExportExcel = () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Sheet1');

    const headers = selectedColumns.map((col) => col.label);
    worksheet.addRow(headers);

    const formattedData = data.map((item) => {
      return selectedColumns.map((col) => {
        if (
          col.key === 'dateOfBirth' ||
          col.key === 'dateOfJoining' ||
          col.key === 'effectiveDate'
        ) {
          return item[col.key]
            ? format(new Date(item[col.key]), 'dd/MM/yyyy')
            : '';
        } else {
          return extractNestedValue(item, col.key);
        }
      });
    });

    formattedData.forEach((row) => worksheet.addRow(row));

    workbook.xlsx.writeBuffer().then((buffer) => {
      const blob = new Blob([buffer], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'data.xlsx';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    });
  };

  return (
    <div>
      <FormControl sx={{m: 1, minWidth: 120}} size='small'>
        <InputLabel id='demo-select-small-label'>
          {/* Download */}
          <IntlMessages id='employee.download' />
        </InputLabel>
        <Select
          id={'download'}
          name='download'
          variant='outlined'
          size='small'
          // label='Download'
          label={<IntlMessages id='employee.download' />}
          sx={{backgroundColor: 'white', width: '100%'}}
        >
          <MenuItem id='downloadCSV' name='downloadCSV' size='small'>
            <FaFileCsv style={{fontSize: '1.5rem'}} /> &nbsp;
            <Button onClick={handleExportCSV}>
              {/* Download as CSV */}
              <IntlMessages id='employee.download.downloadCSV' />
            </Button>
          </MenuItem>

          <MenuItem id='downloadEXCEL' name='downloadEXCEL' size='small'>
            <RiFileExcel2Fill style={{fontSize: '1.5rem'}} /> &nbsp;
            <Button onClick={handleExportExcel}>
              {/* Download as Excel */}
              <IntlMessages id='employee.download.downloadExcel' />
            </Button>
          </MenuItem>
        </Select>
      </FormControl>
    </div>
  );
};

DownloadEmployee.propTypes = {
  data: PropTypes.arrayOf(PropTypes.object),
};

export default DownloadEmployee;
