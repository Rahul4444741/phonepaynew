import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import Stack from '@mui/material/Stack';
import {AppCard} from '../../../@crema';
import {fetchStart, showMessage, fetchError} from '../../../redux/actions';
import TextField from '@mui/material/TextField';
import PropTypes from 'prop-types';
import AppInfoView from '../../../@crema/core/AppInfoView';
import {useDispatch} from 'react-redux';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {DesktopDatePicker} from '@mui/x-date-pickers/DesktopDatePicker';
import {LocalizationProvider} from '@mui/x-date-pickers/LocalizationProvider';
import {AdapterDateFns} from '@mui/x-date-pickers/AdapterDateFns';
import {useSelector} from 'react-redux';
import {API_ROUTS} from 'shared/constants/ApiRouts';
// import ReactJsonViewCompare from '../../../../node_modules/react-json-view-compare';
import {getCompanyDateFormatForInputs} from 'shared/utils/CommonUtils';
import moment from 'moment';
import dynamic from "next/dynamic";
import {getEventLogAction} from 'redux/actions/EventlogAction';
import IntlMessages from '@crema/utility/IntlMessages';
const ReactJsonViewCompare = dynamic(() => import("../../../../node_modules/react-json-view-compare"), {
    ssr: false,
  });
const JsonRenderModal = ({
  handleClose,
  selectedSnapShotJsonRender,
  selectedSnapShotForCompare,
}) => {
  const dispatch = useDispatch();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const textFieldStyled = {
    backgroundColor: 'white',
    mb: 4,
    width: {xs: '100%'},
  };

  return (
    <Dialog maxWidth={'sm'} open={true}>
      <DialogContent>
        <Stack direction='row' justifyContent='center' sx={{mt: '7%'}}> 
          <AppCard style={{width: '350px'}}>
          {Object.keys(selectedSnapShotForCompare).length !==0 &&
            <p style={{textAlign:'center',color:'red', fontSize:'17px', marginBottom:'5px'}}>Previous changes</p>
          }
          <div className='oldData'>
            <ReactJsonViewCompare 
              oldData={selectedSnapShotJsonRender} 
              newData={selectedSnapShotForCompare && selectedSnapShotForCompare} 
              />
            </div>    
          </AppCard>
        
          {Object.keys(selectedSnapShotForCompare).length !==0 &&
            (<AppCard style={{width: '350px'}}>
              <p style={{textAlign:'center',color:'red', fontSize:'17px',marginBottom:'5px'}}>Latest changes</p>
              <div className='newData'>
                <ReactJsonViewCompare 
                  oldData={selectedSnapShotJsonRender} 
                  newData={selectedSnapShotForCompare && selectedSnapShotForCompare} 
                  />
              </div>
            </AppCard> )
          }
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={() => handleClose()}><IntlMessages id='common.button.Close'/></Button>
      </DialogActions>
      <AppInfoView />
    </Dialog>
  );
};

export default JsonRenderModal;
JsonRenderModal.propTypes = {
  handleClose: PropTypes.func,
  selectedSnapShotJsonRender: PropTypes.object,
  selectedSnapShotForCompare: PropTypes.object
};
