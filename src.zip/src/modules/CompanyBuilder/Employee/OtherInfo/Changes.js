import * as React from 'react';
import Stack from '@mui/material/Stack';
import AppAnimate from '../../../../@crema/core/AppAnimate';
import {AppCard, AppInfoView} from '../../../../@crema';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import {AgGridReact} from 'ag-grid-react';
import AppPageMeta from '../../../../@crema/core/AppPageMeta';
import {useDispatch, useSelector} from 'react-redux';
import {showMessage, fetchError, showInfo} from '../../../../redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {
  Checkbox,
  CircularProgress,
  FormControl,
  FormControlLabel,
  InputLabel,
  MenuItem,
  Select,
  Skeleton,
  Slide,
  Typography,
} from '@mui/material';
import {ToggleButton, ToggleButtonGroup} from '@mui/material';
import {
  apiCatchErrorMessage,
  buttonStyle,
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';
import {getCompanyDateFormat} from 'shared/utils/CommonUtils';
import moment from 'moment';
import axios from 'axios';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import IntlMessages from '@crema/utility/IntlMessages';
import PropTypes from 'prop-types';
import {
  Timeline,
  TimelineConnector,
  TimelineContent,
  TimelineDot,
  TimelineItem,
  TimelineOppositeContent,
  TimelineSeparator,
} from '@mui/lab';
import {green, yellow} from '@mui/material/colors';
import SquareIcon from '@mui/icons-material/Square';
import CircleOutlinedIcon from '@mui/icons-material/CircleOutlined';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import JsonRenderModal from '../JsonRenderModal';

const Changes = ({id}) => {
  const gridRef = React.useRef();
  const dispatch = useDispatch();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const defaultColDef = React.useMemo(() => ({
    sortable: true,
    flex: 1,
    resizable: true,
  }));

  const [changesStatus, setChangesStatus] = React.useState('ACTIVE');
  const [changesData, setChangesData] = React.useState(null);

  const [selectedSnapShotJsonRender, setSelectedSnapShotJsonRender] =
    React.useState(null);
  const [selectedSnapShotForCompare, setSelectedSnapShotForCompare] =
    React.useState(null);
  const [isJsonRenderModalOpen, setIsJsonRenderModalOpen] =
    React.useState(false);

  const [selectedDependantObject, setSelectedDependantObject] =
    React.useState(null);
  const [dependantsData, setDependantsData] = React.useState(null);
  const [isDependantLoading, setIsDependantLoading] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(true);
  const [snapshotCategory, SetSnapshotCategory] = React.useState('Employee');

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  React.useEffect(() => {
    getActivechangesData(id, 'Employee');
  }, []);

  const isFirstColumn = (params) => {
    var displayedColumns = params.api.getAllDisplayedColumns();
    var thisIsFirstColumn = displayedColumns[0] === params.column;
    return thisIsFirstColumn;
  };

  const defaultColDefForChanges = React.useMemo(() => ({
    sortable: true,
    flex: 1,
    resizable: true,
    checkboxSelection: changesStatus == 'ACTIVE' ? isFirstColumn : null,
    sortable: true,
    flex: 1,
  }));

  const CustomHeaderAuthor = () => (
    <IntlMessages id='aggrid.tableHeader.Author' />
  );
  const CustomHeadercommitDate = () => (
    <IntlMessages id='aggrid.tableHeader.commitDate' />
  );
  const CustomHeaderchangedProperties = () => (
    <IntlMessages id='aggrid.tableHeader.changedProperties' />
  );
  const CustomHeadertype = () => <IntlMessages id='aggrid.tableHeader.type' />;
  const CustomHeaderproperty = () => (
    <IntlMessages id='aggrid.tableHeader.property' />
  );
  const CustomHeaderInitialValue = () => (
    <IntlMessages id='aggrid.tableHeader.InitialValue' />
  );
  const CustomHeaderCurrentValue = () => (
    <IntlMessages id='aggrid.tableHeader.CurrentValue' />
  );
  const CustomHeaderAction = () => (
    <IntlMessages id='aggrid.tableHeader.Action' />
  );

  const [columnDefsSnapshot] = React.useState([
    {
      field: 'commitMetadata.author',
      headerComponentFramework: CustomHeaderAuthor,
      minWidth: 120,
    },
    {
      headerComponentFramework: CustomHeadercommitDate,
      filter: true,
      minWidth: 175,
      valueGetter: function sumField(params) {
        return moment(params.data?.commitMetadata?.commitDate).format(
          `${getCompanyDateFormat(selectedCompany)} hh:mm a`,
        );
      },
    },
    {
      field: 'changedProperties',
      filter: true,
      headerComponentFramework: CustomHeaderchangedProperties,
      minWidth: 175,
    },
    {
      field: 'type',
      filter: true,
      headerComponentFramework: CustomHeadertype,
      minWidth: 175,
    },

    {
      headerName: 'Action',
      headerComponentFramework: CustomHeaderAction,
      minWidth: 120,
      cellRenderer: function (params) {
        return (
          <Stack direction='row'>
            <div
              style={buttonStyle}
              // onClick={() => setIsJsonRenderModalOpen(true)}
              onClick={() => {
                setSelectedSnapShotJsonRender(params?.data?.state);
                setSelectedSnapShotForCompare({});
                setIsJsonRenderModalOpen(true);
              }}
            >
              <IntlMessages id='common.button.View' />
            </div>
          </Stack>
        );
      },
    },
  ]);

  const handleChangesStatusChange = (event, newValue) => {
    SetSnapshotCategory('Employee');
    setSelectedDependantObject(null);
    setChangesStatus(newValue);
  };

  const handleCloseJsonRenderModal = () => {
    deselectAllRows();
    setIsJsonRenderModalOpen(false);
  };

  const handleChangeSelectDependant = (event) => {
    let seletedObject = null;
    seletedObject = dependantsData.find((e) => e.id == event.target.value);
    setSelectedDependantObject(seletedObject);
    getActivechangesData(id, snapshotCategory, seletedObject.id);
  };

  const handleChangeSnapShotCategory = async (event) => {
    SetSnapshotCategory(() => event.target.value);
    if (event.target.value != 'Dependants') {
      getActivechangesData(id, event.target.value);
    } else {
      setSelectedDependantObject(null);
      setChangesData([]);
      if (dependantsData == null) {
        // getActiveDependantsData(id);
      }
    }
  };

  const getActiveDependantsData = async (id) => {
    setIsDependantLoading(() => true);
    try {
      const response = await jwtAxios.get(
        `${API_ROUTS.dependants_employee}/${id}?status=ACTIVE`,
        {
          cancelToken: source2.token,
        },
      );
      if (response.status == 200) {
        setDependantsData(response.data.reverse());
        setIsDependantLoading(() => false);
      } else {
        setIsDependantLoading(() => false);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setIsDependantLoading(() => false);
    }
  };

  const getActivechangesData = async (id, snapshotCategory, dependantId) => {
    setIsLoading(() => true);
    try {
      const response = await jwtAxios.get(
        !isEmptyNullUndefined(dependantId)
          ? `${API_ROUTS.audit_snapshot}/${snapshotCategory}/${id}?childId=${dependantId}`
          : `${API_ROUTS.audit_snapshot}/${snapshotCategory}/${id}`,
        {
          cancelToken: source.token,
        },
      );
      if (response.status == 200) {
        if (typeof response.data === 'object') {
          setChangesData(response.data.reverse());
        } else {
          dispatch(fetchError('Something went wrong.'));
          setChangesData([]);
        }
        setIsLoading(() => false);
      } else {
        setIsLoading(() => false);
        setChangesData([]);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setIsLoading(() => false);
      setChangesData([]);
    }
  };
  const getInactivechangesData = async (id) => {
    setIsLoading(() => true);
    try {
      const response = await jwtAxios.get(
        `${API_ROUTS.audit_changes_Employee}/${id}`,
        {
          cancelToken: source2.token,
        },
      );
      if (response.status == 200) {
        sortDataByDate(response.data);
        setIsLoading(() => false);
      } else {
        setIsLoading(() => false);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setIsLoading(() => false);
    }
  };

  const sortDataByDate = (data) => {
    const sortedData = data?.sort(function (a, b) {
      return (
        new Date(b.commitMetadata?.commitDate) -
        new Date(a.commitMetadata?.commitDate)
      );
    });
    setChangesData(sortedData);
  };

  const onSelectionChanged = (event) => {
    let tempSelectedRow = [];
    let rowData = event.api.getSelectedRows();
    tempSelectedRow = rowData.map((email) => email.state);
    const selectedRowForJsonCompare = JSON.parse(
      JSON.stringify(tempSelectedRow),
    );
    if (selectedRowForJsonCompare.length == 2) {
      setSelectedSnapShotJsonRender((e) => selectedRowForJsonCompare[0]);
      setSelectedSnapShotForCompare((e) => selectedRowForJsonCompare[1]);
      setIsJsonRenderModalOpen(true);
    }
  };

  const deselectAllRows = () => {
    if (gridApi) {
      gridApi.deselectAll();
    }
  };

  const [gridApi, setGridApi] = React.useState(null);

  function onGridReady(params) {
    setGridApi(params.api);
  }

  return (
    <>
      <AppAnimate animation='transition.slideUpIn' delay={500}>
        <AppPageMeta />
        <AppCard>
          <Stack
            direction='row'
            sx={{mb: 2}}
            justifyContent={'end'}
            spacing={2}
          ></Stack>
          <Stack style={{width: '100%'}}>
            <Stack
              direction='row'
              sx={{mb: 2}}
              justifyContent={'end'}
              spacing={2}
            ></Stack>
          </Stack>

          {changesStatus === 'INACTIVE' && (
            <Stack
              direction='row'
              style={{
                width: '35%',
                position: 'sticky',
                top: 0,
              }}
            >
              <FormControlLabel
                control={
                  <Checkbox
                    checkedIcon={<SquareIcon />}
                    checked={true}
                    style={{color: yellow[800]}}
                  />
                }
                // label='Initial'
                label={<IntlMessages id='employee.changes.initial' />}
              />
              <FormControlLabel
                control={
                  <Checkbox
                    checkedIcon={<SquareIcon />}
                    checked={true}
                    style={{color: green[800]}}
                  />
                }
                label={<IntlMessages id='employee.changes.final' />}
              />
            </Stack>
          )}
          <Stack direction='row' sx={{mb: 2}} justifyContent={'end'}>
            {changesStatus === 'ACTIVE' && (
              <>
                <Stack style={{width: '25%', marginRight: 5}}>
                  <FormControl sx={{mb: 2}}>
                    <InputLabel size='small' id='Category'>
                      <IntlMessages id='employee.ViewEmployee.button.Category' />
                    </InputLabel>
                    <Select
                      id='select-plan-for-Category'
                      labelId='Category'
                      label={
                        <IntlMessages id='employee.ViewEmployee.button.Category' />
                      }
                      value={snapshotCategory}
                      onChange={(event) => handleChangeSnapShotCategory(event)}
                      variant='outlined'
                      size='small'
                      sx={{backgroundColor: 'white', mb: 4}}
                      style={{marginBottom: '0px'}}
                    >
                      <MenuItem
                        key={'Employee'}
                        value={'Employee'}
                        name={'Employee'}
                      >
                        {'Employee'}
                      </MenuItem>
                    
                    </Select>
                  </FormControl>
                </Stack>
              
              </>
            )}
            <ToggleButtonGroup
              color='primary'
              value={changesStatus}
              exclusive
              onChange={handleChangesStatusChange}
              sx={{marginLeft: 2}}
            >
              <ToggleButton
                value='ACTIVE'
                onClick={() => getActivechangesData(id, 'Employee')}
              >
                <IntlMessages id='ViewEmployee.changes.snapshot' />
              </ToggleButton>
              <ToggleButton
                value='INACTIVE'
                onClick={() => getInactivechangesData(id)}
              >
                <IntlMessages id='ViewEmployee.changes.changes' />
              </ToggleButton>
            </ToggleButtonGroup>
          </Stack>
          {changesStatus === 'INACTIVE' ? (
            <div>
              {isLoading ? (
                domCreactionGridSkeletonLoader()
              ) : (
                <Stack
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: '65%',
                  }}
                >
                  {changesStatus === 'INACTIVE' && (
                    <Timeline my={2}>
                      {changesData?.length > 0 ? (
                        changesData.map((val, index) => (
                          <TimelineItem
                            key={`${val}_key_${index}`}
                            style={{left: '120px'}}
                          >
                            <TimelineOppositeContent color='text.secondary'>
                              <div style={{width: '240px'}}>
                                <div style={{display: 'flex'}}>
                                  <p style={{width: '240px'}}>
                                    Author : <p>{val.commitMetadata?.author}</p>
                                  </p>
                                </div>
                                <div
                                  style={{display: 'flex', marginTop: '5px'}}
                                >
                                  <p>
                                    Commit Date:{' '}
                                    <span>
                                      {moment(
                                        val?.commitMetadata?.commitDate,
                                      ).format(
                                        `${getCompanyDateFormat(
                                          selectedCompany,
                                        )} hh:mm a`,
                                      )}
                                    </span>
                                  </p>
                                </div>
                              </div>
                            </TimelineOppositeContent>
                            <TimelineSeparator>
                              <TimelineDot
                                style={{
                                  background: 'transparent',
                                  width: '0.75rem',
                                  height: '0.75rem',
                                  diplay: 'flex',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  border: 'none',
                                }}
                              >
                                <Checkbox
                                  icon={
                                    <CircleOutlinedIcon
                                      style={{color: '#BDBDBD'}}
                                    />
                                  }
                                  checkedIcon={<CheckCircleOutlineIcon />}
                                  checked={false}
                                  style={{
                                    color: green[800],
                                  }}
                                />
                              </TimelineDot>
                              <TimelineConnector />
                            </TimelineSeparator>
                            <TimelineContent>
                              <div style={{width: '240px'}}>
                                <Typography
                                  variant='h5'
                                  style={{marginTop: '5px'}}
                                >
                                  {val?.property}
                                </Typography>

                                <Typography
                                  style={{color: 'rgb(249, 168, 37)'}}
                                  variant='h5'
                                >
                                  {val?.left?.entity || val?.left}
                                </Typography>

                                <Typography
                                  style={{color: 'rgb(46, 125, 50)'}}
                                  variant='h5'
                                >
                                  {val?.right?.entity || val?.right}
                                </Typography>
                              </div>
                            </TimelineContent>
                          </TimelineItem>
                        ))
                      ) : (
                        <Typography>No Changes Available</Typography>
                      )}
                    </Timeline>
                  )}
                </Stack>
              )}
            </div>
          ) : (
            <div>
              {isLoading ? (
                domCreactionGridSkeletonLoader()
              ) : (
                <Stack
                  className='ag-theme-alpine'
                  style={{height: '50vh', width: `100%`}}
                >
                  {changesStatus === 'ACTIVE' && (
                    <AgGridReact
                      ref={gridRef}
                      rowData={changesData}
                      columnDefs={
                        changesStatus == 'ACTIVE'
                          ? columnDefsSnapshot
                          : columnDefsChanges
                      }
                      defaultColDef={defaultColDefForChanges}
                      onGridReady={onGridReady}
                      animateRows={true}
                      pagination={changesData?.length > 10 ? true : false}
                      paginationPageSize={10}
                      suppressRowClickSelection={true}
                      rowSelection={'multiple'}
                      onSelectionChanged={(event) => onSelectionChanged(event)}
                    />
                  )}
                </Stack>
              )}
            </div>
          )}
          <div>
            {isJsonRenderModalOpen && (
              <JsonRenderModal
                handleClose={() => handleCloseJsonRenderModal()}
                selectedSnapShotJsonRender={selectedSnapShotJsonRender}
                selectedSnapShotForCompare={selectedSnapShotForCompare}
              ></JsonRenderModal>
            )}
          </div>
        </AppCard>
        <AppInfoView />
      </AppAnimate>
    </>
  );
};
export default Changes;
Changes.propTypes = {
  id: PropTypes.oneOfType([PropTypes.string, PropTypes.node]).isRequired,
};
