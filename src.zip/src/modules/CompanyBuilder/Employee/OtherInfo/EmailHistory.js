import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../../@crema/core/AppAnimate';
import {AppCard, AppInfoView} from '../../../../@crema';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import {AgGridReact} from 'ag-grid-react';
import AppPageMeta from '../../../../@crema/core/AppPageMeta';
import {useDispatch, useSelector} from 'react-redux';
import {showMessage, fetchError, showInfo} from '../../../../redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import Backdrop from '@mui/material/Backdrop';
import {
  CircularProgress,
  Slide,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
} from '@mui/material';
import AlertDialog from '../../../Common/AlertDialog';
import {
  apiCatchErrorMessage,
  buttonStyle,
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';
import {getCompanyDateFormat} from 'shared/utils/CommonUtils';
import moment from 'moment';
import axios from 'axios';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import IntlMessages from '@crema/utility/IntlMessages';
import PropTypes from 'prop-types';
import { useCallback } from 'react';

const EmailHistory = (employeeEmail) => {
  const dispatch = useDispatch();
  const {id} = JSON.parse(localStorage.getItem('userDetails'));
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const [emailsData, setemailsData] = React.useState([]);
  const [emailsGridData, setemailsGridData] = React.useState(null);
  const [alignment, setAlignment] = React.useState('PENDING');
  const [loading, setLoading] = React.useState(false);
  const [selectedemails, setSelectedemails] = React.useState([]);
  const [noDataMessage, setNoDataMessage] = React.useState(
    'No pending emails to display.',
  );
  const [loadingDataMessage, setLoadingDataMessage] = React.useState(
    'Please wait while pending emails are loading...',
  );
  const [alertProps, setAlertProps] = React.useState({});
  const [gridApi, setGridApi] = React.useState(null);
  const [isLoadingGridData, setIsLoadingGridData] = React.useState(false);


  const chipViewPageHandleClick = (row) => {
    if (row?.path) {
      window.open(`${row.path}`);
    } else {
      dispatch(fetchError('Something went wrong!'));
    }
  };

  const onFilterTextBoxChanged = useCallback(() => {
    const filterText = document.getElementById("filter-text-box").value;
    gridRef.current.api.setGridOption("quickFilterText", filterText);
    const totalResults = gridRef.current.api.getDisplayedRowCount();
    if (!isEmptyNullUndefined(emailsGridData) && emailsGridData.length > 0) {
      if (totalResults === 0 && !isEmptyNullUndefined(filterText)) {
        setOverlayMessage('No Record Found');
        gridRef.current.api.showNoRowsOverlay();
      } else if (totalResults !== 0) {
        setOverlayMessage('No Rows To Show');
        gridRef.current.api.hideOverlay();
      }
    }
  }, []);

  const CustomHeaderAction = () => (
    <IntlMessages id='aggrid.tableHeader.Action' />
  );
  const CustomHeaderEmployeeName = () => (
    <IntlMessages id='aggrid.tableHeader.EmployeeName' />
  );
  const CustomHeaderDate = () => <IntlMessages id='aggrid.tableHeader.Date' />;
  const CustomHeaderSubject = () => (
    <IntlMessages id='aggrid.tableHeader.Subject' />
  );
  const CustomHeaderTo = () => <IntlMessages id='aggrid.tableHeader.To' />;
  const CustomHeaderStatus = () => (
    <IntlMessages id='aggrid.tableHeader.Status' />
  );
  const CustomHeaderviewfile = () => (
    <IntlMessages id='aggrid.tableHeader.viewfile' />
  );

  const [columnDefs, setColumnDefs] = React.useState([
    {
      field: 'subject',
      filter: true,
      headerName: 'Subject',
      headerComponentFramework: CustomHeaderSubject,
      minWidth: 260,
    },
    {
      field: 'to',
      filter: true,
      headerName: 'To',
      headerComponentFramework: CustomHeaderTo,
      minWidth: 260,
    },
    {
      headerComponentFramework: CustomHeaderDate,
      filter: true,
      minWidth: 175,
      valueGetter: function sumField(params) {
        return moment(params.data.createdDate).format(
          `${getCompanyDateFormat(selectedCompany)} hh:mm a`,
        );
      },
    },
    {
      headerName: 'view file',
      headerComponentFramework: CustomHeaderviewfile,
      minWidth: 50,
      cellRenderer: function (params) {
        return (
          <div
            style={{
              cursor: 'pointer',
              display: 'flex !important',
              alignItems: 'center !important',
            }}
          >
            {params.data.path != null && (
              <InsertDriveFileIcon
                onClick={() => chipViewPageHandleClick(params.data)}
              />
            )}
          </div>
        );
      },
    },
    {
      headerName: 'Action',
      headerComponentFramework: CustomHeaderAction,
      minWidth: 300,
      cellRenderer: function (params) {
        return (
          <Stack direction='row'>
            <Stack direction='row'>
              <div
                style={buttonStyle}
                name='viewDoc'
                disabled={loading}
                onClick={() => handleRedirectViewEmail(params)}
              >
                <IntlMessages id='common.button.View' />
              </div>
            </Stack>
          </Stack>
        );
      },
    },
  ]);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  React.useEffect(() => {
    setAlignment('PENDING');
    if (!isEmptyNullUndefined(id)) {
      getAllSendMails();
    }
    return () => {
      source.cancel('Aborting fetching pending emails.');
      source2.cancel('Aborting fetching emails.');
    };
  }, [id]);

  const filterRejected = React.useCallback(() => {
    setSelectedemails([]);
    setNoDataMessage('No rejected emails to display.');
    setLoadingDataMessage('Please wait while rejected emails are loading...');
    getAllDECLINEDMails();
  }, [emailsData]);
  const filterApproved = React.useCallback(() => {
    setSelectedemails([]);
    setNoDataMessage('No approved emails to display.');
    setLoadingDataMessage('Please wait while approved emails are loading...');
    getAllFAILMails();
  }, [emailsData]);
  const filterPending = React.useCallback(() => {
    setSelectedemails([]);
    setNoDataMessage('No pending emails to display.');
    setLoadingDataMessage('Please wait while pending emails are loading...');
    getAllSendMails();
  }, [emailsData]);

  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
  };

  const handleRedirectViewEmail = (params) => {
    let titledEmail = params.data.body.replace('<head>', () => {
      return `<head><title>${params.data.subject}</title>`;
    });
    var newWindow = window.open();
    newWindow.document.write(titledEmail);
  };
  const handleApproveEmail = (email) => {
    let list = [];
    list.push(email?.data?.id);
    approveemails(list);
  };

  const handleRejectEmail = (email) => {
    let list = [];
    list.push(email?.data?.id);
    rejectEmails(list);
  };

  const onSelectionChanged = (event) => {
    let tempEmailIds = [];
    let rowData = event.api.getSelectedRows();
    tempEmailIds = rowData.map((email) => email.id);
    setSelectedemails(() => tempEmailIds);
  };

  const isFirstColumn = (params) => {
    var displayedColumns = params.api.getAllDisplayedColumns();
    var thisIsFirstColumn = displayedColumns[0] === params.column;
    return thisIsFirstColumn;
  };
  const gridRef = React.useRef();
  const defaultColDef = React.useMemo(() => ({
    resizable: true,

    headerCheckboxSelection: alignment == 'APPROVED' ? isFirstColumn : null,
    checkboxSelection: alignment == 'APPROVED' ? isFirstColumn : null,
    sortable: true,
    flex: 1,
  }));

  const approveemails = async (list) => {
    let tempList = JSON.parse(JSON.stringify(list));
    let newLiseWithId = [];
    tempList.forEach((e) => newLiseWithId.push({id: e}));

    setLoading(true);
    let tempProps = {
      isHideShow: false,
      alertType: '',
      title: '',
      message: '',
    };
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.emails}/RESEND`,
        newLiseWithId,
      );
      if (response.status == 200) {
        setLoading(false);
        dispatch(showMessage(`emails resend successfully..!`));
        setAlertProps(tempProps);
        getAllFAILMails();
      }
    } catch (e) {
      setAlertProps(tempProps);
      setLoading(false);
      dispatch(fetchError(e?.response?.data?.title));
    }
  };

  const rejectEmails = async (list) => {
    let tempList = JSON.parse(JSON.stringify(list));
    let newLiseWithId = [];
    tempList.forEach((e) => newLiseWithId.push({id: e}));

    setLoading(true);
    let tempProps = {
      isHideShow: false,
      alertType: '',
      title: '',
      message: '',
    };
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.emails}/DECLINED`,
        newLiseWithId,
      );

      if (response.status == 200) {
        setLoading(false);
        setSelectedemails([]);
        dispatch(showMessage(`emails declined successfully..!`));
        setAlertProps(tempProps);
        getAllFAILMails();
      }
    } catch (e) {
      setAlertProps(tempProps);
      setLoading(false);
      dispatch(fetchError(e?.response?.data?.title));
    }
  };

  const getAllSendMails = async () => {
    setIsLoadingGridData(true);
    setemailsGridData(null);
    try {
      const sendRes = await jwtAxios.get(
        `${API_ROUTS.emails}?status=${'SENT'}&email=${employeeEmail.email}`,
        {
          cancelToken: source.token,
        },
      );
      if (sendRes.status == 200) {
        setSelectedemails([]);
        if (sendRes.data.length == 0) {
          dispatch(showInfo(`You don't have any send emails.`));
          gridApi?.showNoRowsOverlay();
        } else {
          setemailsGridData(
            sendRes?.data.filter((doc) => {
              return doc?.status == 'SENT';
            }),
          );
        }
      } else {
        setSelectedemails([]);
        setemailsData([]);
      }
    } catch (error) {
      gridApi?.hideOverlay();
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
    }
    setIsLoadingGridData(false);
  };

  const getAllFAILMails = async () => {
    setIsLoadingGridData(true);

    gridApi?.hideOverlay();
    gridApi?.showLoadingOverlay();
    try {
      // const failRes = await jwtAxios.get(
      //   employeeEmail?.email
      //     ? `${API_ROUTS.emails}?status=${'FAILED'}&email=${
      //         employeeEmail.email
      //       }`
      //     : `${API_ROUTS.emails}?status=${'FAILED'}&companyId=${
      //         selectedCompany.id
      //       }`,
      //   {
      //     cancelToken: source.token,
      //   },
      // );
      const failRes = await jwtAxios.get(
        `${API_ROUTS.emails}?status=${'FAILED'}&email=${employeeEmail.email}`,
        {
          cancelToken: source.token,
        },
      );
      if (failRes.status == 200) {
        setSelectedemails([]);
        if (failRes.data.length == 0) {
          dispatch(showInfo(`You don't have any fail emails.`));
          gridApi?.showNoRowsOverlay();
          setemailsGridData([]);
        } else {
          setemailsGridData(
            failRes?.data?.filter((doc) => {
              return doc?.status == 'FAILED';
            }),
          );
        }
      } else {
        setemailsGridData([]);
        setSelectedemails([]);
        setemailsData([]);
        gridApi?.showNoRowsOverlay();
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setemailsGridData([]);
    }
    setIsLoadingGridData(false);
  };

  const getAllDECLINEDMails = async () => {
    setIsLoadingGridData(true);
    gridApi?.hideOverlay();
    gridApi?.showLoadingOverlay();
    try {
      // const declinedRes = await jwtAxios.get(
      //   employeeEmail?.email
      //     ? `${API_ROUTS.emails}?status=${'DECLINED'}&email=${
      //         employeeEmail.email
      //       }`
      //     : `${API_ROUTS.emails}?status=${'DECLINED'}&companyId=${
      //         selectedCompany.id
      //       }`,
      //   {
      //     cancelToken: source.token,
      //   },
      // );
      const declinedRes = await jwtAxios.get(
        `${API_ROUTS.emails}?status=${'DECLINED'}&email=${employeeEmail.email}`,
        {
          cancelToken: source.token,
        },
      );
      if (declinedRes.status == 200) {
        setSelectedemails([]);
        if (declinedRes.data.length == 0) {
          setemailsGridData([]);
          dispatch(showInfo(`You don't have any declined emails.`));
          gridApi?.showNoRowsOverlay();
        } else {
          setemailsGridData(
            declinedRes?.data?.filter((doc) => {
              return doc?.status == 'DECLINED';
            }),
          );
        }
      } else {
        setemailsGridData([]);
        setSelectedemails([]);
        setemailsData([]);
        gridApi?.showNoRowsOverlay();
      }
    } catch (error) {
      setemailsGridData([]);
      gridApi?.showNoRowsOverlay();
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
    }
    setIsLoadingGridData(false);
  };

  const handleApproveMultiple = () => {
    let tempProps = {
      isHideShow: true,
      alertType: 'Confirmation',
      title: 'Approve Multiple emails',
      message: `Are you sure want to resend the ${selectedemails.length} selected emails?`,
      type: 'approve',
    };
    setAlertProps(tempProps);
  };
  const handelRejectMultiple = () => {
    let tempProps = {
      isHideShow: true,
      alertType: 'Confirmation',
      title: 'Reject Multiple emails',
      message: `Are you sure want to decline the ${selectedemails.length} selected emails?`,
      type: 'reject',
    };
    setAlertProps(tempProps);
  };
  const handelNo = () => {
    let tempProps = {
      isHideShow: false,
      alertType: '',
      title: '',
      message: '',
    };
    setAlertProps(tempProps);
  };

  return (
    <>
      <AppAnimate animation='transition.slideUpIn' delay={500}>
        <AppPageMeta />
        <h2 style={{marginBottom: 20}}>
          <IntlMessages id='emailHistory.pageHeaderName' />
        </h2>
        <AppCard>
          <Stack
            direction='row'
            sx={{mb: 2}}
            justifyContent={'end'}
            spacing={2}
          >
            <TextField
              sx={{width: 200, mr: 2}}
              id="filter-text-box"
              onInput={onFilterTextBoxChanged}
              type={'search'}
              name='search'
              label={<IntlMessages id='common.button.Search' />}
              variant='outlined'
            />
            {alignment == 'APPROVED' && selectedemails?.length > 0 && (
              <>
                <Slide direction='up' in={selectedemails?.length > 0}>
                  <Button
                    name='addCase'
                    variant='outlined'
                    onClick={() => handleApproveMultiple()}
                    sx={{mr: 1}}
                  >
                    {loading ? (
                      <CircularProgress color='success' size={29} />
                    ) : (
                      'RESEND'
                    )}
                  </Button>
                </Slide>
                <Slide direction='up' in={selectedemails?.length > 0}>
                  <Button
                    name='addCase'
                    variant='outlined'
                    onClick={() => handelRejectMultiple()}
                    sx={{mr: 1}}
                  >
                    {loading ? (
                      <CircularProgress color='success' size={29} />
                    ) : (
                      'DECLINED'
                    )}
                  </Button>
                </Slide>
              </>
            )}
            <ToggleButtonGroup
              color='primary'
              value={alignment}
              exclusive
              onChange={handleChange}
            >
              <ToggleButton value='PENDING' onClick={() => filterPending()}>
                <IntlMessages id='emailHistory.button.SENT' />
              </ToggleButton>
              <ToggleButton value='APPROVED' onClick={() => filterApproved()}>
                <IntlMessages id='emailHistory.button.FAILED' />
              </ToggleButton>
              <ToggleButton value='REJECTED' onClick={() => filterRejected()}>
                <IntlMessages id='emailHistory.button.DECLINED' />
              </ToggleButton>
            </ToggleButtonGroup>
          </Stack>
          <Stack style={{width: '100%'}}>
            <Stack
              direction='row'
              sx={{mb: 2}}
              justifyContent={'end'}
              spacing={2}
            ></Stack>
          </Stack>
          <Stack
            className='ag-theme-alpine'
            style={{height: 325, width: '100%'}}
          >
            {isLoadingGridData ? (
              domCreactionGridSkeletonLoader()
            ) : (
              <AgGridReact
                ref={gridRef}
                rowData={emailsGridData}
                columnDefs={columnDefs}
                defaultColDef={defaultColDef}
                animateRows={true}
                paginationPageSize={10}
                pagination={emailsGridData?.length > 10 ? true : false}
                suppressRowClickSelection={true}
                rowSelection={'multiple'}
                onSelectionChanged={(event) => onSelectionChanged(event)}
                overlayLoadingTemplate={`<span className="ag-overlay-loading-center">${loadingDataMessage}</span>`}
                overlayNoRowsTemplate={`<span className="ag-overlay-loading-center">${noDataMessage}</span>`}
              />
            )}

            {alertProps?.isHideShow && (
              <AlertDialog
                alertProps={alertProps}
                handleYes={() => {
                  if (alertProps?.type == 'approve') {
                    approveemails(selectedemails);
                  }
                  if (alertProps?.type == 'reject') {
                    rejectEmails(selectedemails);
                  }
                }}
                handleNo={() => handelNo()}
              />
            )}
            <Backdrop
              sx={{color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 999}}
              open={loading}
            >
              <CircularProgress color='inherit' />
            </Backdrop>
          </Stack>
        </AppCard>
        <AppInfoView />
      </AppAnimate>
    </>
  );
};
export default EmailHistory;

EmailHistory.propTypes = {
  employeeEmail: PropTypes.object,
};
