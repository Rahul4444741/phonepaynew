import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../../@crema/core/AppAnimate';
import {AppCard, AppInfoView} from '../../../../@crema';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import AppPageMeta from '../../../../@crema/core/AppPageMeta';
import {useDispatch, useSelector} from 'react-redux';
import {showMessage, fetchError, showInfo} from '../../../../redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {Checkbox, FormControlLabel, Skeleton, Typography} from '@mui/material';
import {CircularProgress} from '@mui/material';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import CircleOutlinedIcon from '@mui/icons-material/CircleOutlined';
import {getCompanyDateFormat} from 'shared/utils/CommonUtils';
import SquareIcon from '@mui/icons-material/Square';
import {yellow, green} from '@mui/material/colors';
import moment from 'moment';
import axios from 'axios';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import IntlMessages from '@crema/utility/IntlMessages';
import PropTypes from 'prop-types';
import {useEffect} from 'react';
import {useState} from 'react';
import {
  Timeline,
  TimelineDot,
  TimelineItem,
  TimelineOppositeContent,
  TimelineSeparator,
  TimelineConnector,
  TimelineContent,
} from '@mui/lab';
import AddRoleModal from './../datePickerModal';
import {getEventLogAction} from '../../../../redux/actions/EventlogAction';

const EventLog = ({id}) => {
  const dispatch = useDispatch();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  let {logData, loading, error} = useSelector(
    ({EventLogsReducer}) => EventLogsReducer,
  );

  const [logsData, setLogsData] = useState([]);
  const [selectedEventLog, setSelectedEventLog] = React.useState([]);
  const [isLoading, setIsLoading] = React.useState(false);
  const [deleteEventLoader, setDeleteEventLoader] = useState(false);
  const [isAddRoleOpen, setIsAddRoleOpen] = React.useState(false);
  const [selectedEventExpiryDate, setSelectedEventExpiryDate] =
    React.useState(null);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();

  useEffect(()=>{
    dispatch(getEventLogAction(id));
  },[])

  useEffect(() => {
    if (!loading) {
      const sortedLogs = logData?.sort(function (a, b) {
        // Turn your strings into dates, and then subtract them
        // to get a value that is either negative, positive, or zero.
        return new Date(b.eventDate) - new Date(a.eventDate);
      });
      setLogsData(sortedLogs);
    }
  }, [loading]);

  useEffect(() => {
    logsData && updateSelectedEventLog();
  }, [logsData]);

  const openEventLog = async () => {
    if (selectedEventLog.length > 1) {
      var sorted = selectedEventLog
        .map((item) => {
          return item.eventExpiryDate;
        })
        .slice()
        .sort(function (a, b) {
          return new Date(a) - new Date(b);
        });
      setSelectedEventExpiryDate(() => sorted.pop());
    } else {
      setSelectedEventExpiryDate(() => selectedEventLog[0].eventExpiryDate);
    }
    setIsAddRoleOpen(true);
  };

  const deleteEventLog = () => {
    const ids = selectedEventLog.map((item) => {
      return {id: item.id};
    });
    setDeleteEventLoader(true);
    jwtAxios
      .put(`${API_ROUTS.deleteEventLog}`, ids)
      .then((res) => {
        res.status == 204 && dispatch(showMessage('Event deleted successfuly'));
        res.status == 204 && setSelectedEventLog([]);
        res && dispatch(getEventLogAction(id));
        setDeleteEventLoader(false);
      })
      .catch((error) => {
        dispatch(fetchError(error.message));
        setDeleteEventLoader(false);
      });
  };

  const updateSelectedEventLog = () => {
    let tempSelectedEventLog = [...selectedEventLog];
    for (let i = 0; i < logsData.length; i++) {
      for (let si = 0; si < tempSelectedEventLog.length; si++) {
        if (tempSelectedEventLog[si].id == logsData[i].id) {
          tempSelectedEventLog[si].eventExpiryDate =
            logsData[i].eventExpiryDate;
        }
      }
    }
    setSelectedEventLog(tempSelectedEventLog);
  };

  const handleSelectEvents = async (val) => {
    const pixels = document.getElementById(`containerTimeLine`).scrollTop;
    const setEvents = async () => {
      let tempSelectedEventLog = JSON.parse(JSON.stringify(selectedEventLog));
      const i = tempSelectedEventLog.findIndex((e) => e.id == val.id);
      if (i != -1) {
        tempSelectedEventLog.splice(i, 1);
      } else {
        tempSelectedEventLog.push(val);
      }
      setSelectedEventLog(tempSelectedEventLog);
    };
    await setEvents();
    await setScrollTop(pixels);
  };

  const clearSelectionEventLog = () => {
    setSelectedEventLog([]);
  };

  const isFound = (val) =>
    selectedEventLog.some((event) => {
      if (event.id === val.id) {
        return true;
      }
      return false;
    });

  const setScrollTop = async (pixels) => {
    document.getElementById(`containerTimeLine`).scrollBy(0, pixels);
  };

  const handleCloseAddRole = () => {
    setIsAddRoleOpen(false);
  };

  return (
    <>
      <AppAnimate animation='transition.slideUpIn' delay={500}>
        <AppPageMeta />
        <AppCard>
          <Stack
            direction='row'
            sx={{mb: 2}}
            justifyContent={'end'}
            spacing={2}
          ></Stack>
          <Stack style={{width: '100%'}}>
            <Stack
              direction='row'
              sx={{mb: 2}}
              justifyContent={'end'}
              spacing={2}
            ></Stack>
          </Stack>
          {isLoading ? (
            domCreactionGridSkeletonLoader()
          ) : (
            <Stack
              className='ag-theme-alpine'
              style={{height: '60vh', width: `100%`, overflow: 'scroll'}}
            >
              <div>
                <Stack
                  direction='row'
                  style={{
                    width: '35%',
                    position: 'sticky',
                    top: 0,
                  }}
                >
                  <FormControlLabel
                    control={
                      <Checkbox
                        checkedIcon={<SquareIcon />}
                        checked={true}
                        style={{color: yellow[800]}}
                      />
                    }
                    label={<IntlMessages id='common.button.Open' />}
                  />
                  <FormControlLabel
                    control={
                      <Checkbox
                        checkedIcon={<SquareIcon />}
                        checked={true}
                        style={{color: green[800]}}
                      />
                    }
                    label={<IntlMessages id='common.button.Close' />}
                  />
                </Stack>
                <Stack
                  style={{
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'flex-end',
                    position: 'sticky',
                    top: 0,
                    marginRight: 20,
                  }}
                >
                  <Button
                    disabled={selectedEventLog.length == 0 || deleteEventLoader}
                    onClick={() => deleteEventLog()}
                    size='small'
                    variant='outlined'
                  >
                    <IntlMessages id='employee.eventLog.delete' />
                  </Button>
                  <Button
                    disabled={selectedEventLog.length == 0}
                    onClick={() => openEventLog()}
                    size='small'
                    variant='outlined'
                    sx={{ml: 2}}
                  >
                    <IntlMessages id='employee.eventLog.extend' />
                  </Button>
                </Stack>

                <Stack
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: '65%',
                    marginLeft: 100,
                  }}
                >
                  <Timeline position='alternate' my={2}>
                    {deleteEventLoader ? (
                      <>
                        <CircularProgress color='success' size={29} />
                      </>
                    ) : logsData?.length > 0 ? (
                      logsData.map((val, index) => (
                        <TimelineItem key={`${val}_key_${index}`}>
                          <TimelineOppositeContent color='text.secondary'>
                            <div style={{display: 'flex'}}>
                              <p>
                                Creation Date:{' '}
                                <span>
                                  {moment(val?.eventDate).format(
                                    `${getCompanyDateFormat(
                                      selectedCompany,
                                    )} hh:mm a`,
                                  )}
                                </span>
                              </p>
                              <p>
                                Expiry Date:{' '}
                                <span>
                                  {moment(val?.eventExpiryDate).format(
                                    `${getCompanyDateFormat(
                                      selectedCompany,
                                    )} hh:mm a`,
                                  )}
                                </span>
                              </p>
                            </div>
                          </TimelineOppositeContent>
                          <TimelineSeparator>
                            <TimelineDot
                              style={{
                                background: 'transparent',
                                width: '0.75rem',
                                height: '0.75rem',
                                diplay: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                                border: 'none',
                              }}
                            >
                              <Checkbox
                                icon={
                                  <CircleOutlinedIcon
                                    style={{color: '#BDBDBD'}}
                                  />
                                }
                                checkedIcon={<CheckCircleOutlineIcon />}
                                checked={isFound(val)}
                                onClick={() => handleSelectEvents(val)}
                                style={{
                                  color: green[800],
                                }}
                              />
                            </TimelineDot>
                            <TimelineConnector />
                          </TimelineSeparator>
                          <TimelineContent>
                            <Typography
                              color={
                                val?.flag == true
                                  ? 'rgb(249, 168, 37)'
                                  : 'rgb(46, 125, 50)'
                              }
                              variant='h5'
                            >
                              {val?.event?.name}
                            </Typography>
                            <Typography variant='h6'>
                              {val?.event?.eventType}
                            </Typography>
                          </TimelineContent>
                        </TimelineItem>
                      ))
                    ) : (
                      <Typography>No logs data</Typography>
                    )}
                  </Timeline>
                </Stack>
              </div>
              {isAddRoleOpen && (
                <AddRoleModal
                  id={id}
                  selectedEventLog={selectedEventLog}
                  selectedEventExpiryDate={selectedEventExpiryDate}
                  clearSelectionEventLog={(e) => clearSelectionEventLog()}
                  handleClose={() => handleCloseAddRole()}
                ></AddRoleModal>
              )}
            </Stack>
          )}
        </AppCard>
        <AppInfoView />
      </AppAnimate>
    </>
  );
};
export default EventLog;
EventLog.propTypes = {
  id: PropTypes.oneOfType([PropTypes.string, PropTypes.node]).isRequired,
};
