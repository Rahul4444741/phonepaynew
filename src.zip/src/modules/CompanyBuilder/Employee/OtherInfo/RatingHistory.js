import React from 'react';
import PropTypes from 'prop-types';
import { useDispatch } from 'react-redux';
import jwtAxios from '@crema/services/auth/jwt-auth';
import axios from 'axios';
import { fetchError } from '../../../../redux/actions';
import {
  Typography
} from '@mui/material';
import { API_ROUTS } from 'shared/constants/ApiRouts';
import 'react-querybuilder/dist/query-builder.css';
import Stack from '@mui/material/Stack';
import {
  apiCatchErrorMessage,
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';
import RatingTable from './RatingTable';

const RatingHistory = ({empId}) => {
  const dispatch = useDispatch();

  const [data, setData] = React.useState(null);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();

  React.useEffect(() => {
    if(!isEmptyNullUndefined(empId)){
      getRatingHistory(empId);
    }
  }, [empId]);

  const getRatingHistory = async (empId) => {
    try {
      const response = await jwtAxios.get(
        `${API_ROUTS.ratingHistory}${empId}`,
        {
          cancelToken: source.token,
        },
      );
      if (response.status == 200) {
        setData(response.data);
      } 
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
    }
  };

  return (
    <div>
      {isEmptyNullUndefined(data) ? (
        <Stack alignItems='center'>
          <Typography variant='h3' fontWeight={500}> Rating history not available.</Typography>
        </Stack>
      ) : (
        <RatingTable data={data} />
      )}
    </div>
  );
};


RatingHistory.propTypes = {
  empId: PropTypes.string.isRequired,
};

export default RatingHistory;
