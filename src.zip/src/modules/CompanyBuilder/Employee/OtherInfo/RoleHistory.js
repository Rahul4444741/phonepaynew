import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  Stack,
} from '@mui/material';
import {useDispatch} from 'react-redux';
import axios from 'axios';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {
  apiCatchErrorMessage,
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';
import {fetchError} from 'redux/actions';
import {domCreactionGridSkeletonLoader} from '../domCreaction';

const RoleHistory = ({empId}) => {
  const dispatch = useDispatch();

  const [roleHistory, setRoleHistory] = React.useState([]);
  const [loading, setLoading] = React.useState(true);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();

  React.useEffect(() => {
    if (!isEmptyNullUndefined(empId)) {
      getRoleHistory(empId);
    }
  }, [empId]);

  const getRoleHistory = async (empId) => {
    setLoading(() => true);
    try {
      const response = await jwtAxios.get(
        `${API_ROUTS.roleHistory}?id=${empId}`,
        {
          cancelToken: source.token,
        },
      );
      if (response.status == 200) {
        setRoleHistory(response.data);
        setLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setRoleHistory([]);
      setLoading(() => false);
    }
  };

  return (
    <div>
      {loading ? (
        <Stack style={{maxHeight: '55vh'}}>{domCreactionGridSkeletonLoader()}</Stack>
      ) : (
        <TableContainer component={Paper} style={{maxHeight: '55vh'}}>
          <Table stickyHeader>
            <TableHead>
              <TableRow>
                <TableCell>Name</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Query Name</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {roleHistory && roleHistory.length > 0 ? (
                roleHistory.map((role, index) => (
                  <TableRow key={index}>
                    <TableCell>{role.name}</TableCell>
                    <TableCell>{role.type}</TableCell>
                    <TableCell>{role.queryName || '-'}</TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={4} align='center'>
                    No role history available
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </div>
  );
};

export default RoleHistory;
