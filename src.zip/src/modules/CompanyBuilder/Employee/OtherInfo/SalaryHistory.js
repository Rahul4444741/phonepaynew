import * as React from 'react';
import Stack from '@mui/material/Stack';
import AppAnimate from '../../../../@crema/core/AppAnimate';
import {AppCard, AppInfoView} from '../../../../@crema';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import AppPageMeta from '../../../../@crema/core/AppPageMeta';
import {useDispatch, useSelector} from 'react-redux';
import {
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  TextField,
  Divider,
  CircularProgress,
} from '@mui/material';
import {useState, useEffect, useRef} from 'react';
import axios from 'axios';
import {
  apiCatchErrorMessage,
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';
import {fetchError, showMessage} from 'redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {blue, grey} from '@mui/material/colors';
import {footerButton} from 'shared/constants/AppConst';

const currentYear = new Date().getFullYear();
const years = Array.from({length: 6}, (v, i) => currentYear - i);

const NumberFormatter = ({number}) => {
  const formattedNumber = new Intl.NumberFormat('en-IN').format(number);
  return <span>{formattedNumber}</span>;
};

const SalaryHistory = ({empId}) => {
  const dispatch = useDispatch();
  const [salYear, setSalYear] = useState(currentYear);
  const [total, setTotal] = useState(null);
  const [currency, setCurrency] = useState('');
  const [editMode, setEditMode] = useState(false);
  const [editedData, setEditedData] = useState([]);
  const [loading, setLoading] = useState(false);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();

  useEffect(() => {
    getSalaryHistory(empId, salYear);
  }, [empId, salYear]);

  const getSalaryHistory = async (empId, year) => {
    try {
      const response = await jwtAxios.get(
        `${API_ROUTS.salaryHistory}/${empId}/${year}`,
        {
          cancelToken: source.token,
        },
      );
      if (response.status === 200) {
        const findTc = response.data?.find(
          (salary) =>
            salary.isDerivedSalary == 'true' || salary.isDerivedSalary == true,
        );
        const removeTc = response.data?.filter(
          (salary) =>
            salary.isDerivedSalary == 'false' ||
            salary.isDerivedSalary == false,
        );
        removeTc?.sort((a, b) => a.srNo - b.srNo);
        setTotal(findTc);
        setEditedData(removeTc);
        if (response.data.length > 0) {
          setCurrency(response.data[0].currency);
        }
      }
    } catch (error) {
      if (axios.isCancel(error)) {
        // Handle request cancellation
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
    }
  };
  
  const handleEditToggle = () => {
    setEditMode(!editMode);
  };

  const handleAmountChange = (id, amount) => {
    setEditedData(
      editedData.map((item) =>
        item.id === id ? {...item, amount: parseFloat(amount) || 0} : item,
      ),
    );
  };

  const handleSave = async () => {
    // Add save logic here, e.g., sending editedData to the API
    setLoading(true);
    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.updateSalary}`,
        editedData,
      );
      if (response.status == 200) {
        dispatch(showMessage('Salary updated successfully..!'));
        
        editedData.sort((a, b) => b.amount - a.amount);
        setLoading(false);
        setEditMode(false);
      } else {
        setLoading(false);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
      setLoading(false);
    }
  };

  const calculateTotalAmount = () => {
    return editedData
      .filter((item) => item.isReferedInDerivedSalary)
      .reduce((sum, item) => sum + item.amount, 0);
  };

  return (
    <div style={{height: '100%', overflowY: 'auto'}}>
      <AppAnimate animation='transition.slideUpIn' delay={500}>
        <AppPageMeta />
        <Stack spacing={2}>
          {/* YEAR DROPDOWN */}
          <Stack
            direction='row'
            sx={{mb: 2, mt: 3}}
            justifyContent={'center'}
            spacing={2}
          >
            <FormControl sx={{width: '70%'}}>
              <InputLabel id='year-select-label'>Year</InputLabel>
              <Select
                labelId='year-select-label'
                id='year-select'
                label='Year'
                defaultValue={currentYear}
                size='small'
                value={salYear}
                onChange={(event) => setSalYear(event.target.value)}
              >
                {years.map((year) => (
                  <MenuItem key={year} value={year}>
                    {year}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Stack>

          {/* SALARY DATA */}
          <Stack>
            {editedData.length == 0 ? (
              <Stack
                display='flex'
                justifyContent='center'
                alignItems='center'
                marginTop='50px'
              >
                <Typography variant='h4'>
                  No salary history available.
                </Typography>
              </Stack>
            ) : (
              <Card variant='outlined' sx={{mt: 2}}>
                <CardContent>
                  <Stack
                    display='flex'
                    direction='row'
                    justifyContent='space-between'
                    alignItems='flex-start'
                  >
                    <Stack
                      display='flex'
                      direction='column'
                      justifyContent='space-between'
                      alignItems='flex-start'
                    >
                      <Typography variant='h3' component='div'>
                        Salary Slip({`in ${currency}`})
                      </Typography>
                    </Stack>
                    <Stack
                      display='flex'
                      direction='row'
                      justifyContent='end'
                      alignItems='flex-end'
                    >
                      {loading ? (
                        <CircularProgress
                          sx={{
                            width: '15px !important',
                            margin: '4px !important',
                            height: '15px !important',
                          }}
                        />
                      ) : (
                        <>
                          {editMode ? (
                            <Button
                              color={footerButton.submit.color}
                              variant={footerButton.submit.variant}
                              sx={{...footerButton.submit.sx, width: '80px'}}
                              size={footerButton.submit.size}
                              onClick={handleSave}
                            >
                              Save
                            </Button>
                          ) : (
                            <Button
                              color={footerButton.submit.color}
                              variant={footerButton.submit.variant}
                              sx={{...footerButton.submit.sx, width: '80px'}}
                              size={footerButton.submit.size}
                              onClick={handleEditToggle}
                            >
                              Edit
                            </Button>
                          )}
                        </>
                      )}
                    </Stack>
                  </Stack>
                  <Divider sx={{mt: 2, mb: 2, width: '100%'}} />
                  <span style={{color: 'red'}}>
                    Note: Components marked with an asterisk (*) are not
                    included in the Total Compensation (TC) calculation.
                  </span>
                  <TableContainer component={Paper} sx={{mt: 3}}>
                    <Table aria-label='salary table'>
                      <TableHead>
                        <TableRow>
                          <TableCell
                            sx={{
                              backgroundColor: blue[100],
                              fontWeight: 'bold',
                              fontSize: '16px',
                              width: '60%',
                            }}
                          >
                            Salary Component
                          </TableCell>
                          <TableCell
                            sx={{
                              fontWeight: 'bold',
                              width: '200px',
                              fontSize: '16px',
                              backgroundColor: blue[100],
                              width: '40%',
                            }}
                          >
                            Amount
                          </TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {editedData.map((item) => (
                          <TableRow key={item.id}>
                            <TableCell
                              sx={{
                                backgroundColor: blue[50],
                                fontSize: '14px',
                                width: '60%',
                              }}
                            >
                              {item.salaryHead}{' '}
                              <span style={{color: 'red', fontSize: '20px'}}>
                                {item.isReferedInDerivedSalary == false && '*'}
                              </span>
                            </TableCell>
                            <TableCell
                              sx={{
                                width: '200px',
                                fontSize: '14px',
                                width: '40%',
                              }}
                            >
                              {editMode ? (
                                <TextField
                                  value={
                                    editedData.find(
                                      (editedItem) => editedItem.id === item.id,
                                    ).amount
                                  }
                                  onChange={(e) =>
                                    handleAmountChange(item.id, e.target.value)
                                  }
                                  variant='outlined'
                                  size='small'
                                  fullWidth
                                />
                              ) : (
                                <NumberFormatter number={item.amount} />
                              )}
                            </TableCell>
                          </TableRow>
                        ))}

                        {!isEmptyNullUndefined(total) && (
                          <TableRow>
                            <TableCell
                              sx={{
                                backgroundColor: blue[100],
                                fontWeight: 'bold',
                                fontSize: '16px',
                                width: '60%',
                              }}
                            >
                              {/* Total */}
                              {total?.salaryHead}
                            </TableCell>
                            <TableCell
                              sx={{
                                fontWeight: 'bold',
                                width: '200px',
                                fontSize: '16px',
                                width: '40%',
                              }}
                            >
                              {/* {editedData.reduce(
                              (total, item) => total + item.amount,
                              0,
                            )} */}
                              <NumberFormatter number={total?.amount} />
                              {/* <NumberFormatter
                                number={calculateTotalAmount()}
                              /> */}
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </TableContainer>
                </CardContent>
              </Card>
            )}
          </Stack>
        </Stack>
        <AppInfoView />
      </AppAnimate>
    </div>
  );
};

export default SalaryHistory;
