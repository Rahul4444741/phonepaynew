import React, {useState, useEffect} from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Switch,
  FormControlLabel,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  CircularProgress,
  Stack,
} from '@mui/material';
import {footerButton} from 'shared/constants/AppConst';
import IntlMessages from '@crema/utility/IntlMessages';
import {
  apiCatchErrorMessage,
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';

import {useDispatch} from 'react-redux';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {fetchError, showMessage} from 'redux/actions';
import {API_ROUTS} from 'shared/constants/ApiRouts';

const PermissionsDialog = ({open, empId, handleClose, roles, currentRoles}) => {
  let adminDetails = JSON.parse(localStorage.getItem('adminDetails'));

  const dispatch = useDispatch();
  const [roleStates, setRoleStates] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // if (!isEmptyNullUndefined(roles)) {
      const defaultRoles = [
        'ROLE_USER',
        'SUPER_ADMIN',
        'ROLE_HR',
        'ROLE_ADMIN',
      ];

      const allRoles = [...new Set([...defaultRoles, ...roles])];
      const allRoleStates = allRoles.map((role) => ({
        name: role,
        enabled: role === 'ROLE_USER' || currentRoles.includes(role),
      }));
      setRoleStates(allRoleStates);
    // }
  }, [roles, currentRoles]);

  const handleToggle = (index) => {
    const updatedRoleStates = [...roleStates];

    updatedRoleStates[index].enabled = !updatedRoleStates[index].enabled;
    setRoleStates(updatedRoleStates);
  };

  const handleValidateSubmit = () => {
    const enabledRoles = roleStates
      .filter((role) => role.enabled)
      .map((role) => role.name);

    const newlyAddedRoles = enabledRoles.filter(
      (role) => !currentRoles.includes(role),
    );

    const deletedRoles = currentRoles.filter(
      (role) => !enabledRoles.includes(role),
    );

    if (!isEmptyNullUndefined(newlyAddedRoles)) {
      handleAddedRoles(newlyAddedRoles);
    }
    if (!isEmptyNullUndefined(deletedRoles)) {
      handleDeletedRoles(deletedRoles);
    }

    handleSubmit(enabledRoles);
  };

  const handleSubmit = async (enabledRoles) => {
    
    setLoading(true);
    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.updateRoles}/${empId}`,
        enabledRoles,
      );
      if (response.status === 200) {
        dispatch(showMessage('Roles updated successfully..!'));
        setLoading(false);
        handleClose();
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
      setLoading(false);
    }
  };
  
  const handleAddedRoles = async (newlyAddedRoles) => {
   
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.manualRole}/${empId}`,
        newlyAddedRoles,
      );
      if (response.status === 200) {
        // dispatch(showMessage('Roles updated successfully..!'));
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleDeletedRoles = async (deletedRoles) => {
    
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.manualRole}/delete/${empId}`,
        deletedRoles,
      );
      if (response.status === 200) {
        // dispatch(showMessage('Roles removed successfully..!'));
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const hasRequiredAuthorities = (adminDetails) => {
    const requiredAuthorities = ['SUPER_ADMIN', 'ROLE_ADMIN'];
    return requiredAuthorities.some((authority) =>
      adminDetails?.authorities?.includes(authority),
    );
  };

  const filteredRoleStates = roleStates.filter((role) => {
    const defaultRoles = ['ROLE_USER', 'SUPER_ADMIN', 'ROLE_HR', 'ROLE_ADMIN'];
    if (
      !hasRequiredAuthorities(adminDetails) &&
      defaultRoles.includes(role.name)
    ) {
      return false;
    }
    return true;
  });


  return (
    <Dialog
      open={open}
      onClose={handleClose}
      maxWidth='md'
      PaperProps={{
        style: {
          width: '40vw', // Set the fixed width of the dialog
          maxWidth: 'none', // Ensure the max width is not restricted
        },
      }}
    >
      <DialogTitle>
        <h2>Roles</h2>
      </DialogTitle>
      <DialogContent dividers>
        <TableContainer component={Paper} sx={{backgroundColor: '#f5f5f5'}}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>
                  <strong>Role Name</strong>
                </TableCell>
                <TableCell align='center'>
                  <strong>Status</strong>
                </TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {filteredRoleStates &&
                filteredRoleStates.map((role, index) => (
                  <TableRow key={role.name}>
                    <TableCell>{role.name}</TableCell>
                    <TableCell align='center'>
                      <FormControlLabel
                        control={
                          <Switch
                            checked={role.enabled}
                            onChange={() => handleToggle(index)}
                            disabled={role.name === 'ROLE_USER'}
                          />
                        }
                        label={role.enabled ? 'Enabled' : 'Disabled'}
                      />
                    </TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </TableContainer>
      </DialogContent>
      <DialogActions sx={{justifyContent: 'center'}}>
        <Button onClick={handleClose} variant='contained' color='error'>
          Close
        </Button>
        <Button
          color={footerButton.submit.color}
          variant={footerButton.submit.variant}
          sx={footerButton.submit.sx}
          size={footerButton.submit.size}
          disabled={loading}
          onClick={() => {
            // handleSubmit();
            handleValidateSubmit();
          }}
        >
          {loading ? (
            <CircularProgress
              sx={{
                margin: '0px 1rem',
                color: '#000000',
                width: '25px !important',
                height: '25px !important',
              }}
            />
          ) : (
            <Stack>
              <IntlMessages id='common.button.Update' />
            </Stack>
          )}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default PermissionsDialog;
