import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard, AppInfoView} from '../../../@crema';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import Router, {useRouter} from 'next/router';
import moment from 'moment';
import {useDispatch, useSelector} from 'react-redux';
import {fetchError, fetchStart} from '../../../redux/actions';
import axios from 'axios';
import PropTypes from 'prop-types';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';

import {
  apiCatchErrorMessage,
  buttonStyle,
  getCompanyDateFormat,
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';
import {footerButton} from 'shared/constants/AppConst';

import {domCreactionHeaderList, domCreactionHeaderTitle} from './domCreaction';
import IntlMessages from '@crema/utility/IntlMessages';
import {Divider, Tab, Tabs} from '@mui/material';
import EventLog from './OtherInfo/EventLog';
import Changes from './OtherInfo/Changes';
import EmailHistory from './OtherInfo/EmailHistory';
import RatingHistory from './OtherInfo/RatingHistory';
import SalaryHistory from './OtherInfo/SalaryHistory';
import PermissionsDialog from './PermissionsDialog';
import {getALLRolesPermissions} from 'redux/actions/RolesPermissions';
import RoleHistory from './OtherInfo/RoleHistory';
import { useState ,useEffect } from 'react';


const ViewEmployee = () => {
  const router = useRouter();
  const dispatch = useDispatch();
  const {id} = router.query;
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const {RolesAndPermissionsData} = useSelector(
    ({RolesPermissions}) => RolesPermissions,
  );

  const [employee, setEmployee] = useState(null);
  const [employeeDisplay, setEmployeeDisplay] = useState([]);
  const [value, setValue] = useState(null);

  const [open, setOpen] = useState(false);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();
  const source3 = CancelToken.source();
  const source4 = CancelToken.source();
  const source5 = CancelToken.source();
  const source6 = CancelToken.source();
  const source7 = CancelToken.source();

  useEffect(() => {
    getAllVariableNameMapping();
  }, []);

  useEffect(() => {
    dispatch(fetchStart);
    if (selectedCompany != null && selectedCompany != undefined) {
      dispatch(getALLRolesPermissions({companyId: selectedCompany.id,status:'ACTIVE'}));
    }
  }, [selectedCompany]);

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  React.useEffect(() => {
    const getEmployeeDetails = async (empId) => {
      try {
        const response = await jwtAxios.get(`${API_ROUTS.employee}${empId}`, {
          cancelToken: source4.token,
        });
        if (response.status === 200) {
          setEmployee(response.data);
        }
      } catch (error) {
        if (!axios.isCancel(error)) {
          apiCatchErrorMessage(error, dispatch, fetchError);
        }
      }
    };
  
    const handleEffect = async () => {
      const { selectedOtherInfoTab } = router.query;
  
      if (selectedOtherInfoTab) {
        if (selectedOtherInfoTab === 'employeeLetter') {
          setValue(7);
        }
      }
  
      if (open === false) {
        await getEmployeeDetails(id);
      }
    };
  
    // Call the async function
    handleEffect();
  
    // return () => {
    //   source.cancel('Aborting all previous operations.');
    //   source2.cancel('Aborting all previous operations.');
    //   source3.cancel('Aborting all previous operations.');
    //   source4.cancel('Aborting all previous operations.');
    //   source5.cancel('Aborting all previous operations.');
    //   source6.cancel('Aborting all previous operations.');
    //   source7.cancel('Aborting all previous operations.');
    //   dispatch(callCancel());
    // };
  }, [router, selectedCompany, open]);
  

  const getAllVariableNameMapping = async () => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.variable_name_mapping}/find-by-entity/Employee/${selectedCompany.id}`,
        {headers: {}},
        {
          cancelToken: source.token,
        },
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(
            showInfo('You have no Variable Name Mapping for selected company'),
          );
          setEmployeeDisplay([]);
        } else {
          setEmployeeDisplay(res.data);
        }
      }
    } catch (error) {
      setEmployeeDisplay([]);
    }
  };

  // for tabs
  function TabPanel(props) {
    const {children, value, index, ...other} = props;

    return (
      <div
        role='tabpanel'
        hidden={value !== index}
        id={`vertical-tabpanel-${index}`}
        aria-labelledby={`vertical-tab-${index}`}
        {...other}
      >
        {value === index && (
          <Box sx={{p: 3}}>
            <Typography>{children}</Typography>
          </Box>
        )}
      </div>
    );
  }

  TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.number.isRequired,
    value: PropTypes.number.isRequired,
  };

  function a11yProps(index) {
    return {
      id: `vertical-tab-${index}`,
      'aria-controls': `vertical-tabpanel-${index}`,
    };
  }

  const handleRedirectEditEmployee = (id) => {
    Router.push(`/company-builder/add-employee?id=${id}&page=viewPage`);
  };

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const getLable = (name) => {
    const field = employeeDisplay.find((item) => item.variableName == name);
    return field?.displayName;
  };

  const getIsVisible = (name) => {
    const field = employeeDisplay?.find((item) => item.variableName == name);
    if (!isEmptyNullUndefined(field)) {
      return field.isVisible;
    }
    return false;
  };

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 2}}>
        {/* Employee Details */}
        <IntlMessages id='employee.ViewEmployee.pageHeaderName' />
      </h2>
      <Stack
        direction='row'
        sx={{mb: 2, mr: 4}}
        justifyContent={'end'}
        spacing={2}
      >
        {employee && !employee?.empstatus.finalStatus && employee?.emailId && (
          <Button
            style={buttonStyle}
            name='edit'
            onClick={() => {
              jwtAxios
                .get(`${API_ROUTS.employeeLogin}${employee?.emailId}`, {
                  cancelToken: source3.token,
                })
                .then((res) => {
                  if (isEmptyNullUndefined(res?.data?.id_token)) {
                    dispatch(fetchError('Employee is not valid'));
                  } else {
                    window.open(
                      `${employee?.company?.companyUrl}/login/${res?.data?.id_token}`,
                    );
                  }
                })
                .catch((e) => {
                  if (!axios.isCancel(e)) {
                    dispatch(
                      fetchError(
                        'Something went wrong, Please try again after sometime',
                      ),
                    );
                  }
                });
            }}
          >
            <IntlMessages id='common.button.Login' />
          </Button>
        )}

        {employee && (
          <>
            <Button
              name='edit'
              variant='contained'
              onClick={() => handleRedirectEditEmployee(id)}
            >
              {/* Edit */}
              <IntlMessages id='common.button.Edit' />
            </Button>

            {employee && !employee?.empstatus.finalStatus && (
              <Button
                name='assignRole'
                variant='contained'
                color='success'
                onClick={handleOpen}
              >
                Assign Role
              </Button>
            )}
          </>
        )}
      </Stack>
      <Stack spacing={2} sx={{mb: 15}}>
        <AppCard>
          {domCreactionHeaderTitle(
            <IntlMessages id='employee.ViewEmployee.cardHeaderName.personalInformation' />,
          )}
          {employee &&
            domCreactionHeaderList(
              getLable('name'),
              getLable('dateOfBirth'),
              employee?.name,
              employee?.dateOfBirth &&
                moment(employee?.dateOfBirth).format(
                  getCompanyDateFormat(selectedCompany),
                ),
              getIsVisible('name'),
              getIsVisible('dateOfBirth'),
            )}

          {employee &&
            domCreactionHeaderList(
              getLable('emailId'),
              getLable('gender'),
              employee?.emailId,
              employee?.gender,
              getIsVisible('emailId'),
              getIsVisible('gender'),
            )}
        </AppCard>
        <AppCard>
          {domCreactionHeaderTitle(
            <IntlMessages id='employee.ViewEmployee.cardHeaderName.employeeInformation' />,
          )}

          {employee &&
            domCreactionHeaderList(
              getLable('employeeId'),
              getLable('dateOfJoining'),
              employee?.employeeId,
              employee?.dateOfJoining &&
                moment(employee?.dateOfJoining).format(
                  getCompanyDateFormat(selectedCompany),
                ),
              getIsVisible('employeeId'),
              getIsVisible('dateOfJoining'),
            )}

          {employee &&
            domCreactionHeaderList(
              getLable('empstatus'),
              getLable('employeeType'),
              employee?.empstatus?.name,
              employee?.employeeType?.name,
              getIsVisible('empstatus'),
              getIsVisible('employeeType'),
            )}
          {employee &&
            domCreactionHeaderList(
              getLable('employeeFunction'),
              getLable('employeeSubFunction'),
              employee?.employeeFunction?.name,
              employee?.employeeSubFunction?.name,
              getIsVisible('employeeFunction'),
              getIsVisible('employeeSubFunction'),
            )}

          {employee &&
            domCreactionHeaderList(
              getLable('employeeLevel'),
              getLable('employmentStatus'),
              employee?.employeeLevel?.name,
              employee?.employmentStatus?.name,
              getIsVisible('employeeLevel'),
              getIsVisible('employmentStatus'),
            )}

          {employee &&
            domCreactionHeaderList(
              getLable('isManager'),
              getLable('isFunctionalLeader'),
              employee?.isManager ? 'Yes' : 'No',
              employee?.isFunctionalLeader ? 'Yes' : 'No',
              getIsVisible('isManager'),
              getIsVisible('isFunctionalLeader'),
            )}
          {employee &&
            domCreactionHeaderList(
              // 'Designation',
              getLable('employeeDesignation'),
              getLable('employeeGrade'),
              employee?.employeeDesignation,
              employee?.employeeGrade?.name,
              getIsVisible('employeeDesignation'),
              getIsVisible('employeeGrade'),
            )}
          {employee &&
            domCreactionHeaderList(
              getLable('jobCode'),
              getLable('effectiveDate'),
              employee?.jobCode?.jobCode,
              employee?.effectiveDate &&
                moment(employee?.effectiveDate).format(
                  getCompanyDateFormat(selectedCompany),
                ),
              getIsVisible('jobCode'),
              getIsVisible('effectiveDate'),
            )}
          {employee &&
            domCreactionHeaderList(
              getLable('terminationReason'),
              getLable('effectiveStatus'),
              employee?.terminationReason,
              employee?.effectiveStatus,
              getIsVisible('terminationReason'),
              getIsVisible('effectiveStatus'),
            )}
        </AppCard>

        <AppCard>
          {domCreactionHeaderTitle(
            <IntlMessages id='employee.ViewEmployee.cardDetailName.managerInfo' />,
          )}

          {employee &&
            domCreactionHeaderList(
              // <IntlMessages id='employee.ViewEmployee.cardDetailName.managerName' />,
              // <IntlMessages id='employee.ViewEmployee.cardDetailName.managerEmail' />,
              getLable('name'),
              getLable('emailId'),
              employee?.manager?.name,
              employee?.manager?.emailId,
              getIsVisible('name'),
              getIsVisible('emailId'),
            )}
          {employee &&
            domCreactionHeaderList(
              getLable('employeeId'),
              getLable('employeeDesignation'),
              employee?.manager?.employeeId,
              employee?.manager?.employeeDesignation,
              getIsVisible('employeeId'),
              getIsVisible('employeeDesignation'),
            )}
        </AppCard>
        <AppCard>
          {domCreactionHeaderTitle(
            // <IntlMessages id='employee.ViewEmployee.cardDetailName.managerInfo' />,
            'Other variables',
          )}

          {employee &&
            domCreactionHeaderList(
              getLable('string1'),
              getLable('string2'),
              employee?.string1,
              employee?.string2,
              getIsVisible('string1'),
              getIsVisible('string2'),
            )}
          {employee &&
            domCreactionHeaderList(
              getLable('string3'),
              getLable('string4'),
              employee?.string3,
              employee?.string4,
              getIsVisible('string3'),
              getIsVisible('string4'),
            )}
          {employee &&
            domCreactionHeaderList(
              getLable('string5'),
              '',
              employee?.string5,
              '',
              getIsVisible('string5'),
              getIsVisible(''),
            )}
          <Divider sx={{mt: 2, mb: 2, width: '100%'}} />
          {employee &&
            domCreactionHeaderList(
              getLable('date1'),
              getLable('date2'),
              employee?.date1,
              employee?.date2,
              getIsVisible('date1'),
              getIsVisible('date2'),
            )}
          {employee &&
            domCreactionHeaderList(
              getLable('date3'),
              getLable('date4'),
              employee?.date3,
              employee?.date4,
              getIsVisible('date3'),
              getIsVisible('date4'),
            )}
          {employee &&
            domCreactionHeaderList(
              getLable('date5'),
              '',
              employee?.date5,
              '',
              getIsVisible('date5'),
              getIsVisible(''),
            )}
          <Divider sx={{mt: 2, mb: 2, width: '100%'}} />
          {employee &&
            domCreactionHeaderList(
              getLable('boolean1'),
              getLable('boolean2'),
              employee?.boolean1,
              employee?.boolean2,
              getIsVisible('boolean1'),
              getIsVisible('boolean2'),
            )}
          {employee &&
            domCreactionHeaderList(
              getLable('boolean3'),
              getLable('boolean4'),
              employee?.boolean3,
              employee?.boolean4,
              getIsVisible('boolean3'),
              getIsVisible('boolean4'),
            )}
          {employee &&
            domCreactionHeaderList(
              getLable('boolean5'),
              '',
              employee?.boolean5,
              '',
              getIsVisible('boolean5'),
              getIsVisible(''),
            )}
          <Divider sx={{mt: 2, mb: 2, width: '100%'}} />
          {employee &&
            domCreactionHeaderList(
              getLable('double1'),
              getLable('double2'),
              employee?.double1,
              employee?.double2,
              getIsVisible('double1'),
              getIsVisible('double2'),
            )}
          {employee &&
            domCreactionHeaderList(
              getLable('double3'),
              getLable('double4'),
              employee?.double3,
              employee?.double4,
              getIsVisible('double3'),
              getIsVisible('double4'),
            )}
          {employee &&
            domCreactionHeaderList(
              getLable('double5'),
              '',
              employee?.double5,
              '',
              getIsVisible('double5'),
              getIsVisible(''),
            )}
        </AppCard>

        <AppCard>
          <h3
            style={{
              marginBottom: 10,
              backgroundColor: '#D3D3D3',
              borderRadius: 10,
              padding: 5,
            }}
          >
            Custom Variables :
          </h3>
          <Stack>
            {employee &&
              employee.customData.map((item) => {
                return (
                  <Stack
                    width={{
                      xl: '70%',
                      lg: '80%',
                      md: '90%',
                      sm: '90%',
                      xs: '100%',
                    }}
                    sx={{
                      justifyContent: 'space-between',
                      marginLeft: '4%',
                      marginTop: {md: '10px'},
                    }}
                    direction={{xs: 'column', sm: 'row'}}
                  >
                    <Stack
                      width={{xs: '100%', lg: '50%', md: '50%', sm: '50%'}}
                      sx={{justifyContent: 'space-between'}}
                      direction='row'
                    >
                      {item.customVariables?.dataType === 'Array' ? (
                        <>
                          <Stack sx={{width: '50%'}}>
                            <b>{item.customVariables?.variableName}</b>
                          </Stack>
                          <Stack sx={{width: '50%', wordWrap: 'break-word'}}>
                            {item.options ? item.options?.join(', ') : '-'}
                          </Stack>
                        </>
                      ) : (
                        <>
                          <Stack sx={{width: '50%'}}>
                            <b>{item.customVariables?.variableName}</b>
                          </Stack>
                          <Stack sx={{width: '50%', wordWrap: 'break-word'}}>
                            {item.customVariables?.dataType === 'Boolean'
                              ? item.data === 'true'
                                ? 'Yes'
                                : 'No'
                              : item.data}
                          </Stack>
                        </>
                      )}
                    </Stack>
                  </Stack>
                );
              })}
          </Stack>
        </AppCard>

        <AppCard>
          <h3
            style={{
              marginBottom: 10,
              backgroundColor: '#D3D3D3',
              borderRadius: 10,
              padding: 5,
            }}
          >
            <IntlMessages id='employee.ViewEmployee.headerName.OtherInfo' />
          </h3>
          <Box
            sx={{
              flexGrow: 1,
              bgcolor: 'background.paper',
              display: 'flex',
              // height: '37vh',
              height: '70vh',
            }}
          >
            <Tabs
              orientation='vertical'
              variant='scrollable'
              value={value}
              onChange={handleChange}
              aria-label='Vertical tabs example'
              sx={{borderRight: 1, borderColor: 'divider'}}
            >
              <Tab
                label={
                  <IntlMessages id='sidebar.companybuilder.ratingshistory' />
                }
                {...a11yProps(0)}
              />
              <Tab label={'Salary History'} {...a11yProps(1)} />
              <Tab
                label={
                  <IntlMessages id='sidebar.companybuilder.appraisalDocuments' />
                }
                {...a11yProps(2)}
              />
              <Tab
                label={<IntlMessages id='sidebar.companybuilder.tickets' />}
                {...a11yProps(3)}
              />
              <Tab
                label={<IntlMessages id='sidebar.companybuilder.eventLog' />}
                {...a11yProps(4)}
              />
              <Tab
                label={<IntlMessages id='sidebar.companybuilder.changes' />}
                {...a11yProps(5)}
              />
              <Tab
                label={
                  <IntlMessages id='sidebar.companybuilder.emailHistory' />
                }
                {...a11yProps(6)}
              />
              <Tab label={'Role History'} {...a11yProps(7)} />
            </Tabs>

            <TabPanel value={value} index={0} style={{width: '100%'}}>
              <RatingHistory empId={id} />
            </TabPanel>

            <TabPanel value={value} index={1} style={{width: '100%'}}>
              <Stack style={{height: '70vh', width: `100%`, overflowY: 'auto'}}>
                <SalaryHistory empId={id} />
              </Stack>
            </TabPanel>

            <TabPanel value={value} index={2} style={{width: '100%'}}>
              appraisalDocuments
            </TabPanel>
            <TabPanel
              className='ag-theme-alpine'
              value={value}
              index={3}
              style={{height: '30vh', width: `100%`}}
            >
              <Stack
                className='ag-theme-alpine'
                style={{height: '50vh', width: `100%`}}
              >
                {/* <Claims id={id} claims={claims} /> */}
                tickets
              </Stack>
            </TabPanel>
            <TabPanel
              className='ag-theme-alpine'
              value={value}
              index={4}
              style={{height: '30vh', width: `100%`}}
            >
              <EventLog id={id} />
            </TabPanel>
            <TabPanel
              value={value}
              index={5}
              className='ag-theme-alpine'
              style={{height: '100%', width: `840px`}}
              id={`containerTimeLine`}
            >
              <Stack
                className='ag-theme-alpine'
                style={{height: '50vh', width: `100%`, overflowY: 'auto'}}
              >
                <Changes id={id} />
              </Stack>
            </TabPanel>
            <TabPanel
              value={value}
              index={6}
              style={{height: '100%', width: `840px`}}
            >
              <Stack
                className='ag-theme-alpine'
                style={{height: '50vh', width: `100%`}}
              >
                <EmailHistory email={employee?.emailId} />
              </Stack>
            </TabPanel>
            <TabPanel
              value={value}
              index={7}
              style={{height: '100%', width: `840px`}}
            >
                <Stack
                  className='ag-theme-alpine'
                  style={{height: '60vh', width: `100%`}}
                >
                  <Stack
                    direction='row'
                    sx={{mb: 2, mr: 4}}
                    justifyContent={'space-between'}
                    spacing={2}
                  >
                    <Typography variant='h1' gutterBottom sx={{ml:2,mt:3}}>
                    Previously Assigned Roles
                    </Typography>
                    {employee && (
                      <>
                        {employee && !employee?.empstatus.finalStatus && (
                          <Button
                            name='assignRole'
                            variant='contained'
                            color='success'
                            onClick={handleOpen}
                          >
                            Assign Role
                          </Button>
                        )}
                      </>
                    )}
                  </Stack>
                  <Stack sx={{mt: 2}}>
                    <RoleHistory empId={id} />
                  </Stack>
                </Stack>
            </TabPanel>
          </Box>

          <Stack
            sx={{
              bottom: 0,
              zIndex: 10,
              position: 'fixed',
              backdropFilter: 'blur(5px)',
              width: '100%',
              right: 0,
            }}
          >
            <Stack
              direction='row'
              justifyContent='end'
              alignItems='center'
              spacing={2}
              sx={{
                pt: 5,
                ml: 3,
                margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
              }}
            >
              <Button
                color={footerButton.back.color}
                variant={footerButton.back.variant}
                sx={footerButton.back.sx}
                size={footerButton.back.size}
                onClick={() => Router.push('/company-builder/employee')}
              >
                <IntlMessages id='common.button.Back' />
              </Button>
            </Stack>
          </Stack>
        </AppCard>
      </Stack>

      {open && (
        <PermissionsDialog
          open={open}
          handleClose={handleClose}
          empId={id}
          roles={RolesAndPermissionsData?.map((item) => item.name)}
          currentRoles={employee?.roles}
        />
      )}
      <AppInfoView />
    </AppAnimate>
  );
};
export default ViewEmployee;
