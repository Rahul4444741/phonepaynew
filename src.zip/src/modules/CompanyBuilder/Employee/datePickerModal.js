import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import Stack from '@mui/material/Stack';
import {AppCard} from '../../../@crema';
import {fetchStart, showMessage, fetchError} from '../../../redux/actions';
import TextField from '@mui/material/TextField';
import PropTypes from 'prop-types';
import AppInfoView from '../../../@crema/core/AppInfoView';
import {useDispatch} from 'react-redux';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {DesktopDatePicker} from '@mui/x-date-pickers/DesktopDatePicker';
import {LocalizationProvider} from '@mui/x-date-pickers/LocalizationProvider';
import {AdapterDateFns} from '@mui/x-date-pickers/AdapterDateFns';
import {useSelector} from 'react-redux';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {getCompanyDateFormatForInputs} from 'shared/utils/CommonUtils';
import moment from 'moment';
import {getEventLogAction} from 'redux/actions/EventlogAction';
import IntlMessages from '@crema/utility/IntlMessages';
const AddRoleModal = ({
  id,
  handleClose,
  selectedEventLog,
  selectedEventExpiryDate,
  clearSelectionEventLog,
}) => {
  const dispatch = useDispatch();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const [value, setValue] = React.useState(selectedEventExpiryDate);
  const [loading, setLoading] = React.useState(false);

  const textFieldStyled = {
    backgroundColor: 'white',
    mb: 4,
    width: {xs: '100%'},
  };

  const handleValidateRole = async () => {
    submitUpdatedDate();
  };

  const submitUpdatedDate = async () => {
    setLoading(true);
    const ids = selectedEventLog.map((item) => {
      return {id: item.id};
    });
    let date = moment(value).format('YYYY-MM-DD');
    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.getEventLog}extend?date=${date} `,
        ids,
      );
      if (response.status == 201) {
        dispatch(getEventLogAction(id));
        dispatch(showMessage('Updated successfully..!'));
        setLoading(false);
        clearSelectionEventLog()
        handleClose();
      }
    } catch (e) {
      if (e?.response?.data?.title) {
        dispatch(fetchError(e?.response?.data?.title));
      } else {
        dispatch(fetchError(e?.message));
      }
      setLoading(false);
    }
  };

  const today = new Date();

  const handleChangeLogDate = (newValue) => {
    setValue(newValue);
  };

  return (
    <Dialog maxWidth={'sm'} open={true}>
      <DialogContent>
        <Stack direction='row' justifyContent='center' sx={{mt: '7%'}}>
          <AppCard style={{width: '350px'}}>
            <h4 style={{display: 'flex'}}>
              {/* {'Extend enrollment deadline'} */}
              <IntlMessages id='employee.eventLog.extendEnrollmentDeadline'/>
            </h4>
            <Stack
              sx={{mt: 2}}
              display='flex'
              justifyContent='center'
              spacing={2}
            >
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DesktopDatePicker
                  inputFormat={getCompanyDateFormatForInputs(selectedCompany)}
                  minDate={new Date(selectedEventExpiryDate)}
                  value={value}
                  // label='Date'
                  label={<IntlMessages id='templeteConfiguration.create.date'/>}
                  name='effectiveDate'
                  onChange={handleChangeLogDate}
                  renderInput={(params) => (
                    <TextField
                      variant='outlined'
                      size='small'
                      sx={{
                        ...textFieldStyled,
                        '& fieldset': {
                          borderLeftWidth: 3,
                        },
                      }}
                      {...params}
                    />
                  )}
                />
              </LocalizationProvider>
            </Stack>
          </AppCard>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button disabled={loading} onClick={() => handleValidateRole()}>
          {/* Submit */}
          <IntlMessages id='common.button.Submit'/>
        </Button>
        <Button onClick={() => handleClose()}>
          {/* Close */}
          <IntlMessages id='common.button.Close'/>
        </Button>
      </DialogActions>
      <AppInfoView />
    </Dialog>
  );
};

export default AddRoleModal;
AddRoleModal.propTypes = {
  handleClose: PropTypes.func,
  id: PropTypes.any,
  selectedEventLog: PropTypes.array,
  selectedEventExpiryDate: PropTypes.any,
  clearSelectionEventLog: PropTypes.func
};
