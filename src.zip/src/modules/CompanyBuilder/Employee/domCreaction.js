import {Skeleton, Stack, Typography} from '@mui/material';
import {isEmptyNullUndefined} from 'shared/utils/CommonUtils';

export const domCreactionHeaderList = (
  leftHeading,
  rightHeading,
  leftValue,
  rightValue,
  isLeftVisible,
  isRightVisible,
) => {
  return (
    <Stack
      width={{xl: '70%', lg: '80%', md: '90%', sm: '90%', xs: '100%'}}
      sx={{
        justifyContent: 'space-between',
        marginLeft: '4%',
        marginTop: {md: '10px'},
      }}
      direction={{xs: 'column', sm: 'row'}}
    >
      {isLeftVisible && (
        <Stack
          width={{xs: '100%', lg: '50%', md: '50%', sm: '50%'}}
          sx={{justifyContent: 'space-between'}}
          direction='row'
        >
          <Stack sx={{width: '60%'}}>
            <b>{leftHeading}</b>
          </Stack>
          <Stack sx={{width: '40%', wordWrap: 'break-word'}}>
            {leftValue ? leftValue : '-'}
          </Stack>
        </Stack>
      )}

      {isRightVisible && (
        <Stack
          // width={{xs: '50%'}}
          width={{xs: '100%', lg: '50%', md: '50%', sm: '50%'}}
          sx={{justifyContent: 'space-between'}}
          direction='row'
        >
          <Stack sx={{width: '60%'}}>
            <b>{rightHeading}</b>
          </Stack>
          <Stack sx={{width: '40%', wordWrap: 'break-word'}}>
            {rightValue ? rightValue : '-'}
          </Stack>
        </Stack>
      )}
    </Stack>
  );
};

export const domCreactionHeaderListSingle = (leftHeading, leftValue) => {
  let listDomCreation = [];
  if (isEmptyNullUndefined(leftValue)) {
    listDomCreation = null;
  } else {
    let index = 0;

    if (typeof leftValue === 'object') {
      for (let key in leftValue) {
        // Determine the style based on the index
        const style =
          index % 2 === 0
            ? {color: '#a1a1a1', marginRight: 20}
            : {color: '#c5c566', marginRight: 20};

        // Create the div element with the determined style
        const divElement = <div style={style}>{leftValue[key]}</div>;

        // Push the div element into the listDomCreation array
        listDomCreation.push(divElement);

        index++;
      }
    } else {
      const divElement = (
        <div style={{color: '#a1a1a1', marginRight: 20}}>{leftValue}</div>
      );
      listDomCreation.push(divElement);
    }
  }

  return (
    <Stack
      width={'100%'}
      // width={{xl: '70%', lg: '80%', md: '90%', sm: '90%', xs: '100%'}}
      sx={{
        justifyContent: 'space-between',
        marginLeft: {xl: '4%', lg: '2%', md: '2%', sm: '0%', xs: '0%'},
        marginTop: {md: '10px'},
      }}
      direction={{xs: 'column', sm: 'row'}}
    >
      <Stack
        sx={{width: {xl: '80%', lg: '90%', md: '100%', sm: '100%', xs: '100%'}}}
        // width={{xs: '100%', lg: '50%', md: '50%', sm: '50%'}}
        // sx={{justifyContent: 'space-between'}}
        direction='row'
      >
        <Stack
          width={'40%'}
          // sx={{width: '50%'}}
        >
          <b>
            {' '}
            <Typography variant='h4' gutterBottom>
              {leftHeading} :
            </Typography>
          </b>
        </Stack>
        <Stack
          width={'60%'}
          // sx={{width: '50%', wordWrap: 'break-word'}}
        >
          {listDomCreation ? (
            <Typography
              display={'flex'}
              flexWrap='wrap'
              variant='subtitle2'
              gutterBottom
            >
              {listDomCreation}
            </Typography>
          ) : (
            '-'
          )}
        </Stack>
      </Stack>
    </Stack>
  );
};

export const domCreactionHeaderTitle = (headerTitle) => {
  return headerTitle ? (
    <h3
      style={{
        marginBottom: 10,
        backgroundColor: '#D3D3D3',
        borderRadius: 10,
        padding: 5,
      }}
    >
      {headerTitle} :
    </h3>
  ) : (
    <></>
  );
};

export const domCreactionGridSkeletonLoader = (SkeletonHeight) => {
  return (
    <Skeleton
      animation='wave'
      sx={{height: SkeletonHeight ? SkeletonHeight : '33rem', width: '100%'}}
    />
  );
};
