import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard, AppInfoView} from '../../../@crema';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import {AgGridReact} from 'ag-grid-react';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import Router from 'next/router';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import NativeSelect from '@mui/material/NativeSelect';
import {useDispatch, useSelector} from 'react-redux';
import {
  fetchStart,
  showMessage,
  fetchError,
  showInfo,
} from '../../../redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {
  IconButton,
  InputAdornment,
  MenuItem,
  Pagination,
  Select,
  Slide,
  TextField,
} from '@mui/material';
import {
  isEmptyNullUndefined,
  buttonStyle,
  apiCatchErrorMessage,
  isAllowedUser,
} from 'shared/utils/CommonUtils';
import axios from 'axios';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import IntlMessages from '@crema/utility/IntlMessages';
import DownloadEmployee from './DownloadEmployee';
import AlertDialog from './AlertDialog';
import SearchIcon from '@mui/icons-material/Search';
import {permissionName} from 'shared/utils/PermissionName';
import Error403 from 'modules/errorPages/Error403';

const CustomHeaderName = () => (<IntlMessages id='aggrid.tableHeader.Name' />);

const CustomHeaderEmail = () => (<IntlMessages id='aggrid.tableHeader.email' />);
const CustomHeaderEmployeeId = () => ('Employee Id');

const CustomHeaderAction = () => (
  <IntlMessages id='aggrid.tableHeader.Action' />
);
const CustomHeaderemployeeGradesLevel = () => (
  <IntlMessages id='aggrid.tableHeader.employeeGradesLevel' />
);
const CustomHeaderclassOfEmployment = () => (
  <IntlMessages id='aggrid.tableHeader.classOfEmployment' />
);
const CustomHeaderIsManager = () => (
  <IntlMessages id='aggrid.tableHeader.manager' />
);
const CustomHeaderstatus = () => (
  <IntlMessages id='aggrid.tableHeader.status' />
);
const CustomHeaderworkPermitStatus = () => (
  <IntlMessages id='aggrid.tableHeader.workPermitStatus' />
);

const Employee = () => {
  const dispatch = useDispatch();
  const [employeeData, setEmployeeData] = React.useState(null);
  const [employeeStatusData, setEmployeeStatusData] = React.useState([]);
  const [isLoading, setisLoading] = React.useState(true);
  const [selectedEmployeeData, setSelectedEmployeeData] = React.useState({
    employeeIds: [],
  });

  const [statusValue, setStatusValue] = React.useState('All');
  const [searchTerm, setSearchTerm] = React.useState(null);

  const [page, setPage] = React.useState(1);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  const [totalPages, setTotalPages] = React.useState(null);
  const [data, setData] = React.useState([]);
  const [dataLoading, setDataLoading] = React.useState(false);

  const [alertProps, setAlertProps] = React.useState({
    isHideShow: false,
    message: '',
    title: '',
    alertType: '',
    actionParams: null,
    selectedEmployeeName: null,
  });

  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);

  React.useEffect(() => {
    if (isAllowedUser(permissionName.EMPLOYEE_RELATED_EMPLOYEE_TABS)) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  const handleChange = (event, value) => {
    setPage(value);
  };

  const ActionRenderer = (params) => {
    const handleLogin = () => {
      jwtAxios
        .get(`${API_ROUTS.employeeLogin}${params?.data?.emailId}`, {
          cancelToken: source3.token,
        })
        .then((res) => {
          if (isEmptyNullUndefined(res?.data?.id_token)) {
            dispatch(fetchError('Employee is not valid'));
          } else {
            window.open(
              `${params?.data?.company?.companyUrl}/login/${res?.data?.id_token}`,
            );
          }
        })
        .catch((error) => {
          if (!axios.isCancel(error)) {
            apiCatchErrorMessage(error, dispatch, fetchError);
          }
        });
    };

    return (
      <Stack direction='row'>
        {isAllowedUser(permissionName.READ) && (
          <Button
            style={buttonStyle}
            id={`view-employee-row-${params.rowIndex}`}
            name='view'
            onClick={() => handleRedirectViewEmployee(params)}
          >
            <IntlMessages id='common.button.View' />
          </Button>
        )}
        {isAllowedUser(permissionName.UPDATE) && (
          <Button
            style={buttonStyle}
            id={`edit-employee-row-${params.rowIndex}`}
            name='edit'
            onClick={() => handleRedirectEditEmployee(params)}
          >
            <IntlMessages id='common.button.Edit' />
          </Button>
        )}

        <Button style={buttonStyle} name='login' onClick={handleLogin}>
          <IntlMessages id='common.button.Login' />
        </Button>
      </Stack>
    );
  };

  const columnDefs = [
    {
      field: 'name',
      filter: true,
      headerName: 'Name',
      headerComponentFramework: CustomHeaderName,
      minWidth: 150,
    },
    {
      field: 'emailId',
      filter: true,
      headerName: 'Email',
      headerComponentFramework: CustomHeaderEmail,
      minWidth: 150,
    },
    {
      field: 'employeeId',
      filter: true,
      headerName: 'Employee Id',
      headerComponentFramework: CustomHeaderEmployeeId,
      minWidth: 100,
    },
    // {
    //   field: 'jobCode.jobCode',
    //   filter: true,
    //   headerName: 'Job Code',
    //   headerComponentFramework: CustomHeaderJobCode,
    //   minWidth: 100,
    // },
    {
      field: 'empstatus.name',
      filter: true,
      headerName: 'Status',
      headerComponentFramework: CustomHeaderstatus,
      minWidth: 100,
    },
    {
      field: 'isManager',
      filter: true,
      headerName: 'Manager',
      headerComponentFramework: CustomHeaderIsManager,
      minWidth: 100,
      cellRenderer: (params) => (params.value ? 'Yes' : 'No'),
    },
    {
      field: 'employeeLevel.name',
      filter: true,
      headerName: 'Employee Grades/Level',
      headerComponentFramework: CustomHeaderemployeeGradesLevel,
      minWidth: 100,
    },
    {
      field: 'employeeType.name',
      filter: true,
      headerName: 'Class of Employment',
      headerComponentFramework: CustomHeaderclassOfEmployment,
      minWidth: 100,
    },
    {
      headerName: 'Action',
      headerComponentFramework: CustomHeaderAction,
      minWidth: 300,
      cellRenderer: ActionRenderer, // Use ActionRenderer component
    },
  ];

  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();
  const source3 = CancelToken.source();

  React.useEffect(() => {
    if (isAuthorized) {
      getAllEmployeesByStatusForDownload(selectedCompany.id, statusValue);
    }
  }, [isAuthorized, statusValue]);

  React.useEffect(() => {
    dispatch(fetchStart);
    if (
      isAuthorized &&
      selectedCompany != null &&
      selectedCompany != undefined
    ) {
      getAllActiveEmployeeStatus(selectedCompany.id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
    };
  }, [isAuthorized, selectedCompany]);

  React.useEffect(() => {
    dispatch(fetchStart);
    if (
      isAuthorized &&
      selectedCompany != null &&
      selectedCompany != undefined
    ) {
      if (searchTerm == null || searchTerm == '') {
        getAllEmployeesByStatus(
          selectedCompany.id,
          statusValue,
          page,
          rowsPerPage,
          null,
        );
      } else {
        getAllEmployeesByStatus(
          selectedCompany.id,
          statusValue,
          page,
          rowsPerPage,
          searchTerm,
        );
      }
    }
    return () => {
      source.cancel('Aborting all previous operations.');
    };
  }, [isAuthorized, statusValue, page, rowsPerPage]);

  const handleRedirectViewEmployee = (emp) => {
    Router.push('/company-builder/view-employee?id=' + emp.data.id);
  };

  const handleRedirectEditEmployee = (emp) => {
    Router.push('/company-builder/add-employee?id=' + emp.data.id);
  };

  const gridRef = React.useRef();

  const isFirstColumn = (params) => {
    let displayedColumns = params.api.getAllDisplayedColumns();
    let thisIsFirstColumn = displayedColumns[0] === params.column;
    return thisIsFirstColumn;
  };

  const defaultColDef = React.useMemo(() => {
    return {
      sortable: true,
      flex: 1,
      minWidth: 100,
      resizable: true,
      headerCheckboxSelection: isFirstColumn,
      checkboxSelection: isFirstColumn,
    };
  }, []);

  const handleRedirectAddEmployee = () => {
    Router.push('/company-builder/add-employee');
  };

  const requiredSelectStyled = {
    backgroundColor: 'white',
    mb: 2,
    width: {xs: '100%', xl: '60%', md: '75%'},
  };

  const getAllActiveEmployeeStatus = async (companyId) => {
    setisLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.employeestatus_companyID}${companyId}?status=ACTIVE`,
        {
          cancelToken: source.token,
        },
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(
            showInfo('You have no employee status for selected company'),
          );
          setEmployeeStatusData([]);
        } else {
          setEmployeeStatusData(res.data);
        }
        setisLoading(() => false);
      } else {
        setEmployeeStatusData([]);
        setisLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setEmployeeStatusData([]);
      setisLoading(() => false);
    }
  };

  const getAllEmployeesByStatus = async (
    companyId,
    value,
    page,
    size,
    term,
  ) => {
    let pageNum = page > 0 ? page - 1 : 0;

    setisLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.employee}companyID/${companyId}?status=${value}&page=${pageNum}&size=${size}&searchValue=${term}`,
        {
          cancelToken: source2.token,
        },
      );
      if (res.status == 200) {
        if (res.data[0].entityList.length == 0) {
          dispatch(showInfo('You have no employee for selected company'));
          setEmployeeData([]);
        } else {
          setEmployeeData(res.data[0].entityList);
          const pages = Math.ceil(
            res.data[1].totalCount / res.data[1].pageSize,
          );
          // Adjust the page value if it exceeds the total number of pages
          const adjustedPage = Math.min(page, pages);
          setTotalPages(pages);
          setPage(adjustedPage);
        }
        setisLoading(() => false);
      } else {
        setEmployeeData([]);
        setisLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setEmployeeStatusData([]);
      setisLoading(() => false);
    }
  };

  const getAllEmployeesByStatusForDownload = async (companyId, value) => {
    setDataLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.employee}companyID/getAll/${companyId}?status=${value}`,
        {
          cancelToken: source.token,
        },
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no employee for selected company'));
        } else {
          setData(res.data);
        }
        setDataLoading(() => false);
      } else {
        setData([]);
        setDataLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        setData([]);
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setDataLoading(() => false);
    }
  };

  const [gridApi, setGridApi] = React.useState(null);

  function onGridReady(params) {
    setGridApi(params.api);
  }

  const onSelectionChanged = (event) => {
    let tempEmployeeIds = [];
    const tempSelectedEmployeeData = {...selectedEmployeeData};
    let rowData = event.api.getSelectedRows();
    tempEmployeeIds = rowData.map((e) => e.id);
    tempSelectedEmployeeData.employeeIds = tempEmployeeIds;
    setSelectedEmployeeData(() => tempSelectedEmployeeData);
  };

  const handleDeleteEmployee = async (list) => {
    let tempProps = {
      isHideShow: false,
      alertType: '',
      title: '',
      message: '',
    };
    setisLoading(true);
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.employee_delete_employee}`,
        list,
      );
      if (response.status == 200) {
        let tempEmployeeData = JSON.parse(JSON.stringify(employeeData));
        const filteredEmployeeData = tempEmployeeData.filter(
          (employee) => !list.includes(employee.id),
        );
        deselectAllRows();
        setSelectedEmployeeData({
          employeeIds: [],
        });
        setEmployeeData(() => filteredEmployeeData);
        setisLoading(false);
        setAlertProps(tempProps);
        dispatch(showMessage(`Employee Deleted successfully..!`));
      } else {
        deselectAllRows();
      }
    } catch (error) {
      setAlertProps(tempProps);
      setisLoading(false);
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleSubmitConfirmation = (list) => {
    let tempEmployeeData = JSON.parse(JSON.stringify(employeeData));
    let filteredNames = tempEmployeeData
      .filter((item) => list.includes(item.id))
      .map(
        (item) =>
          `${item?.firstName ? item.firstName : ''} ${
            item?.lastName ? item.lastName : ''
          }`,
      );
    const tempAlertProps = {...alertProps};
    tempAlertProps.actionParams = list;
    tempAlertProps.selectedEmployeeName = filteredNames;
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = <IntlMessages id='employee.deleteEmployee' />;
    tempAlertProps.message = <IntlMessages id='employee.delete.areYouSure' />;
    setAlertProps(tempAlertProps);
  };

  const handleAlertYes = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;

    if (alertProps.alertType === 'Confirmation') {
      setTimeout(() => {
        handleDeleteEmployee(alertProps.actionParams);
      }, 100);
    }

    setAlertProps(tempAlertProps);
  };

  const handleAlertNo = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };

  const deselectAllRows = () => {
    if (gridApi) {
      gridApi.deselectAll();
    }
  };

  const handleSearch = () => {
    if (searchTerm === null || searchTerm.trim() === '') {
      getAllEmployeesByStatus(
        selectedCompany.id,
        statusValue,
        page,
        rowsPerPage,
        null,
      );
    } else {
      getAllEmployeesByStatus(
        selectedCompany.id,
        statusValue,
        page,
        rowsPerPage,
        searchTerm,
      );
    }
  };

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (!isAuthorized) {
    return <Error403 />;
  }

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        {/* Employee */}
        <IntlMessages id='employee.pageHeaderName' />
      </h2>
      <AppCard>
        <Stack style={{width: '100%'}}>
          <Stack
            direction='row'
            sx={{mb: 2}}
            justifyContent={'end'}
            spacing={2}
          >
            <TextField
              sx={{width: 200, mr: 2}}
              onChange={(e) => {
                setSearchTerm(e.target.value);
              }}
              type={'search'}
              name='search'
              value={searchTerm || ''}
              id='outlined-basic'
              label={<IntlMessages id='common.button.Search' />}
              variant='outlined'
              InputProps={{
                endAdornment: (
                  <InputAdornment position='end'>
                    <IconButton
                      onClick={() => {
                        setPage(1);
                        handleSearch();
                      }}
                    >
                      <SearchIcon />
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
            {isAllowedUser(permissionName.DELETE) && (
              <Slide
                direction='up'
                in={selectedEmployeeData?.employeeIds?.length > 0}
              >
                <Button
                  name='addCase'
                  variant='outlined'
                  onClick={() =>
                    handleSubmitConfirmation(
                      JSON.parse(
                        JSON.stringify(selectedEmployeeData?.employeeIds),
                      ),
                    )
                  }
                  sx={{mr: 1}}
                >
                  {/* Delete */}
                  <IntlMessages id='employee.eventLog.delete' />
                </Button>
              </Slide>
            )}
            {isAllowedUser(permissionName.CREATE) && (
              <Button
                variant='outlined'
                onClick={() => handleRedirectAddEmployee()}
              >
                {/* Add Employee */}
                <IntlMessages id='employee.addEmployeeButton' />
              </Button>
            )}
            <FormControl sx={({ml: 2}, {width: '20%'})}>
              <InputLabel size='small' id='emp-status' shrink={true}>
                {/* Status */}
                <IntlMessages id='employee.employeeStatusButton' />
              </InputLabel>
              <NativeSelect
                name='empstatus'
                value={statusValue || ''}
                defaultValue={'All'}
                labelId='emp-status'
                label='Status'
                onChange={(event) => {
                  // handleChangeEmployeeData(event, 'dropdown')
                  setStatusValue(event.target.value);
                  setPage(1);
                }}
                variant='outlined'
                size='small'
                sx={{...requiredSelectStyled}}
                style={{marginBottom: '0px'}}
              >
                <option value='All'>Select All</option>
                {employeeStatusData.map((element) => (
                  <option key={element.name} value={element.name}>
                    {element.name}
                  </option>
                ))}
              </NativeSelect>
            </FormControl>

            {isAllowedUser(permissionName.DOWNLOAD) &&
            dataLoading === false &&
            data?.length !== 0 ? (
              <DownloadEmployee data={data} />
            ) : null}
          </Stack>
        </Stack>
        {isLoading ? (
          domCreactionGridSkeletonLoader()
        ) : (
          <Stack
            className='ag-theme-alpine'
            style={{height: 525, width: '100%'}}
          >
            <AgGridReact
              ref={gridRef}
              rowData={employeeData}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              animateRows={true}
              onGridReady={onGridReady}
              suppressRowClickSelection={true}
              rowSelection={'multiple'}
              onSelectionChanged={(event) => onSelectionChanged(event)}
              alwaysShowHorizontalScroll={true}
              overlayLoadingTemplate={`<span className="ag-overlay-loading-center">Please wait while your rows are loading...</span>`}
              overlayNoRowsTemplate={`<span className="ag-overlay-loading-center"No data found to display.</span>`}
            />
            <Stack
              display='flex'
              alignItems='center'
              justifyContent='center'
              style={{
                marginTop: '20px',
              }}
            >
              {!isEmptyNullUndefined(employeeData) && (
                <Stack display='flex' direction='row'>
                  <Stack display='flex' direction='row'>
                    <FormControl sx={{m: 1, minWidth: 70}} size='small'>
                      <Select
                        labelId='demo-customized-select-label'
                        id='demo-customized-select'
                        value={rowsPerPage}
                        autoWidth
                        onChange={(event) => {
                          setRowsPerPage(event.target.value);
                          setPage(1);
                        }}
                      >
                        <MenuItem value={10}>10</MenuItem>
                        <MenuItem value={20}>20</MenuItem>
                        <MenuItem value={50}>50</MenuItem>
                        <MenuItem value={100}>100</MenuItem>
                      </Select>
                    </FormControl>
                  </Stack>
                  <Stack>
                    <Pagination
                      color='primary'
                      size='large'
                      count={totalPages}
                      page={page}
                      onChange={handleChange}
                    />
                  </Stack>
                </Stack>
              )}
            </Stack>
          </Stack>
        )}
      </AppCard>
      {alertProps.isHideShow && (
        <AlertDialog
          alertProps={alertProps}
          handleYes={() => handleAlertYes()}
          handleNo={() => handleAlertNo()}
        />
      )}
      <AppInfoView />
    </AppAnimate>
  );
};
export default Employee;
