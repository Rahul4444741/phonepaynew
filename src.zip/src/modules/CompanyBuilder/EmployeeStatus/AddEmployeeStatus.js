import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import Stack from '@mui/material/Stack';
import { AppCard } from '../../../@crema';
import { showMessage, fetchError } from '../../../redux/actions';
import TextField from '@mui/material/TextField';
import PropTypes from 'prop-types';
import AppInfoView from '../../../@crema/core/AppInfoView';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import { useDispatch } from 'react-redux';
import jwtAxios from '@crema/services/auth/jwt-auth';
import { API_ROUTS } from 'shared/constants/ApiRouts';
import {
  apiCatchErrorMessage,
  isDuplicate,
  isStrExceeds,
} from 'shared/utils/CommonUtils';
import IntlMessages from '@crema/utility/IntlMessages';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';

const AddEmployeeStatus = ({
  company,
  handleAddEmpoyeeStatus,
  handleUpdateEmployeeStatus,
  handleClose,
  isEdit,
  editEmployeeStatus,
  employeeStatusData,
}) => {
  const dispatch = useDispatch();
  const [employeeStatus, setEmployeeStatus] = React.useState({
    id: null,
    name: '',
    status: '',
    finalStatus: false,
    company: {
      id: company.id,
    },
  });
  React.useEffect(() => {
    if (isEdit) {
      setEmployeeStatus(editEmployeeStatus);
    }
  }, []);

  const [formError, setFormError] = React.useState({
    name: {isError: false, errorMessage: ''},
    status: {isError: false, errorMessage: ''},
    finalStatus: {isError: false, errorMessage: ''},
  });
  const textFieldStyled = {
    backgroundColor: 'white',
    mb: 4,
    width: {xs: '100%'},
  };

  const handleChangeEmployeeStatusData = (event) => {
    const tempEmployeeStatus = {...employeeStatus};
    const tempError = {...formError};
    tempEmployeeStatus[event.target.name] = event.target.value;
    tempError[event.target.name].isError = false;
    tempError[event.target.name].errorMessage = '';
    setEmployeeStatus(tempEmployeeStatus);
    setFormError(tempError);
  };

  const handleValidateEmployeeStatus = async () => {
    let isValid = true;
    const specialCharPattern = /[&#@^~`*+?{}!()=%<>\\$'"]/;
    const tempError = {...formError};
    const tempEmployeeStatus = {...employeeStatus};
    if (tempEmployeeStatus.name.trim() == '') {
      tempError.name.isError = true;
      tempError.name.errorMessage = <IntlMessages id='error.pleaseEnterName' />;
      isValid = false;
    } else if (specialCharPattern.test(tempEmployeeStatus.name)) {
      tempError.name.isError = true;
      tempError.name.errorMessage = 'Do not enter special character.';
      isValid = false;
    }
    if (
      !isEdit
        ? isDuplicate(tempEmployeeStatus.name, employeeStatusData)
        : isDuplicate(
            tempEmployeeStatus.name,
            employeeStatusData,
            tempEmployeeStatus.id,
          )
    ) {
      tempError.name.isError = true;
      tempError.name.errorMessage = (
        <IntlMessages id='error.duplicateEntryFound' />
      );
      isValid = false;
    }

    if (isStrExceeds(tempEmployeeStatus.name.toString(), 50)) {
      tempError.name.isError = true;
      tempError.name.errorMessage = 'should not exceed 50 characters';
      isValid = false;
    }
    if (tempEmployeeStatus.status.trim() == '') {
      tempError.status.isError = true;
      tempError.status.errorMessage = (
        <IntlMessages id='error.pleaseSelectStatus' />
      );
      isValid = false;
    }

    if (isValid) {
      if (isEdit) {
        updateEmployeeStatus();
      } else {
        submitEmployeeStatus();
      }
    } else {
      setFormError(tempError);
    }
  };

  const submitEmployeeStatus = async () => {
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.employeestatus}`,
        employeeStatus,
      );
      if (response.status == 201) {
        dispatch(
          showMessage(
            response.data.name + ' Employee Status added successfully..!',
          ),
        );
        handleAddEmpoyeeStatus(response.data);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const updateEmployeeStatus = async () => {
    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.employeestatus}${employeeStatus.id}`,
        employeeStatus,
      );
      if (response.status == 200) {
        dispatch(
          showMessage(
            response.data.name + ' Employee Status updated successfully..!',
          ),
        );
        handleUpdateEmployeeStatus(response.data);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  return (
    <Dialog maxWidth={'sm'} open={true}>
      <DialogContent>
        <Stack direction='row' justifyContent='center' sx={{mt: '7%'}}>
          <AppCard style={{width: '350px'}}>
            <h4 style={{display: 'flex'}}>
              {!isEdit ? (
                <IntlMessages id='employeeStatus.addEmployeeStatus' />
              ) : (
                <IntlMessages id='employeeStatus.updateEmployeeStatus' />
              )}
            </h4>
            <Stack
              sx={{mt: 2}}
              display='flex'
              justifyContent='center'
              spacing={2}
            >
              <TextField
                size='small'
                name='name'
                label={<IntlMessages id='configuration.dialogbox.Name' />}
                onChange={(event) => handleChangeEmployeeStatusData(event)}
                value={employeeStatus.name}
                error={formError.name.isError}
                helperText={formError.name.errorMessage}
                variant='outlined'
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              />
              <FormControl component='fieldset'>
                <IntlMessages id='configuration.dialogbox.Final.Status' />
                <RadioGroup
                  name='finalStatus'
                  value={employeeStatus.finalStatus}
                  onChange={(event) => handleChangeEmployeeStatusData(event)}
                  row
                >
                  <FormControlLabel
                    value={true}
                    control={<Radio color='primary' />}
                    label={<IntlMessages id='common.yes' />}
                  />
                  <FormControlLabel
                    value={false}
                    control={<Radio color='primary' />}
                    label={<IntlMessages id='common.no' />}
                  />
                </RadioGroup>
              </FormControl>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id='event-type'>
                  <IntlMessages id='configuration.dialogbox.Status' />
                </InputLabel>
                <Select
                  size='small'
                  name='status'
                  label='Status'
                  value={employeeStatus.status}
                  error={formError.status.isError}
                  helperText={formError.status.errorMessage}
                  onChange={(event) => handleChangeEmployeeStatusData(event)}
                  variant='outlined'
                  sx={{...textFieldStyled}}
                >
                  <MenuItem key='Active' value='ACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Active' />
                  </MenuItem>
                  <MenuItem key='Inactive' value='INACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                  </MenuItem>
                </Select>
                <FormHelperText style={{color: '#d32f2f'}}>
                  {formError.status.errorMessage}
                </FormHelperText>
              </FormControl>
            </Stack>
          </AppCard>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={() => handleValidateEmployeeStatus()}>
          <IntlMessages id='common.button.Submit' />
        </Button>
        <Button onClick={() => handleClose()}>
          <IntlMessages id='common.button.Close' />
        </Button>
      </DialogActions>
      <AppInfoView />
    </Dialog>
  );
};

export default AddEmployeeStatus;
AddEmployeeStatus.propTypes = {
  company: PropTypes.object,
  handleAddEmpoyeeStatus: PropTypes.func,
  handleUpdateEmployeeStatus: PropTypes.func,
  handleClose: PropTypes.func,
  isEdit: PropTypes.bool,
  editEmployeeStatus: PropTypes.object,
  employeeStatusData: PropTypes.array,
};
