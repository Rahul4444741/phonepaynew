import React from 'react';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {RiDragMove2Fill} from 'react-icons/ri';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {useDispatch, useSelector} from 'react-redux';
import {blue, green, grey, purple, red, yellow} from '@mui/material/colors';
import {footerButton} from 'shared/constants/AppConst';
import {DragDropContext, Droppable, Draggable} from '@hello-pangea/dnd';
import {
  fetchStart,
  fetchSuccess,
  showMessage,
  fetchError,
  showInfo,
} from '../../../../redux/actions';
import axios from 'axios';
import Paper from '@mui/material/Paper';
import {AppCard} from '../../../../@crema';
import AppPageMeta from '../../../../@crema/core/AppPageMeta';
import {AppAnimate, AppInfoView} from '@crema';
import AlertDialog from '../../../Common/AlertDialog';
import {
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  Divider,
  FormControl,
  FormControlLabel,
  FormHelperText,
  InputLabel,
  MenuItem,
  Modal,
  Select,
  Skeleton,
  Slide,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from '@mui/material';
import Grow from '@mui/material/Grow';
import {ImCross, ImBin} from 'react-icons/im';
import {Box} from '@mui/system';
import {
  apiCatchErrorMessage,
  buttonStyle,
  getCompanyDateFormat,
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';

import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import IntlMessages from '@crema/utility/IntlMessages';
import Router, {useRouter} from 'next/router';
import {useState} from 'react';
import GenericSelectWithSearch from 'modules/Common/GenericSelectWithSearch';

// function createData(entity, header, unmapped, name, isRequired, defaultValue) {
//   return {entity, header, unmapped, name, isRequired, defaultValue};
// }
function createData(header, unmapped, name, defaultValue) {
  return {header, unmapped, name, defaultValue};
}

const getItemStyle = (isDragging, draggableStyle) => ({
  background: isDragging ? '#C8E6C9' : 'white',
  boxShadow: isDragging ? '0 0 .4rem #666' : 'none',
  ...draggableStyle,
  userSelect: 'none',
});

const textFieldStyled = {
  backgroundColor: 'white',
  width: {xs: '100%'},
};
const formHelperTextStyle = {
  color: '#d32f2f',
  marginBottom: '16.5px',
};

const AddFeedbackReport = () => {
  const router = useRouter();
  const {id} = router.query;
  const dispatch = useDispatch();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  // const {email} = JSON.parse(localStorage.getItem('userDetails'));
  const [loading, setLoading] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(false);
  const [isLoadingUpload, setIsLoadingUpload] = React.useState(false);
  const [isLoadingDel, setIsLoadingDel] = React.useState(false);
  const [providerSelectModal, setProviderSelectModal] = React.useState(false);

  const [loadingCnfg, setLoadingCnfg] = React.useState(false);

  const [isDisabled, setIsDisabled] = React.useState(false);
  const [resData, setResData] = React.useState(null);
  const [alertProps, setAlertProps] = React.useState({});
  const [selectedData, setSelectedData] = React.useState({});
  const [entities, setEntities] = React.useState([]);
  const [openAddRowModal, setOpenAddRowModal] = React.useState(false);
  const initialEmptyEntityFields = {
    entityDetails: [],
    headersDetails: {
      headers: [],
      headerIndex: [],
      headersMappedWith: [],
    },
    previousProviderMappings: {
      mappedHeaders: [],
      headersWithIndex: [],
      entityWithIndex: [],
      oldEntity: [],
      oldHeaders: [],
      // entityDropdown: [],
      // isRequired: [],
      defaultValue: [],
    },
  };
  const [entityFields, setEntityFields] = React.useState(
    initialEmptyEntityFields,
  );

  const [mappingsRow, setMappingsRow] = React.useState([]);

  const intialNewRowFields = {
    // entityDropdown: '',
    headerName: '',
    entityName: '',
    defaultValue: '',
    // isRequired: false,
  };
  const intialNewRowFieldsError = {
    // entityDropdown: {isError: false, errorMessage: ''},
    headerName: {isError: false, errorMessage: ''},
    entityName: {isError: false, errorMessage: ''},
    defaultValue: {isError: false, errorMessage: ''},
  };
  const [newRowFields, setNewRowFields] = React.useState(intialNewRowFields);
  const [newRowFieldsError, setNewRowFieldsError] = React.useState(
    intialNewRowFieldsError,
  );

  const [headerError, setHeaderError] = React.useState([]);
  const [entityError, setEntityError] = React.useState([]);
  const [defaultValueError, setDefaultValueError] = React.useState([]);

  const [emailSend, setEmailSend] = React.useState(false);
  const [email, setEmail] = React.useState('');
  const [emailError, setEmailError] = React.useState({
    isError: false,
    errorMessage: '',
  });
  const [showEmail, setShowEmail] = React.useState(false);

  const [reportName, setReportName] = React.useState('');
  const [reportNameError, setReportNameError] = React.useState(false);
  const [status, setStatus] = React.useState('');
  const [statusError, setStatusError] = React.useState(false);
  const [reportType, setReportType] = React.useState('');
  const [reportTypeError, setReportTypeError] = React.useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const [isEdit, setIsEdit] = React.useState(false);

  const [queryList, setQueryList] = React.useState(null);
  const [annualCycle, setAnnualCycle] = React.useState(null);

  const [queryId, setQueryId] = React.useState(null);
  const [cycleId, setCycleId] = React.useState(null);

  const [queryIdError, setQueryIdError] = React.useState(false);
  const [cycleIdError, setCycleIdError] = React.useState(false);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();

  const swapKeysAndValues = (obj) => {
    const swapped = Object.entries(obj).map(([key, value]) => [value, key]);
    return Object.fromEntries(swapped);
  };

  React.useEffect(() => {
    const fetchData = async () => {
      if (selectedCompany != null && selectedCompany != undefined && !isEmptyNullUndefined(reportType)) {
        await getAllCsventity(selectedCompany.id);
      }
    };
  
    fetchData();
  
    return () => {
      source.cancel('Abort fetching CSV entities');
    };
  }, [selectedCompany, reportType]);
  
  React.useEffect(() => {
    const fetchData = async () => {
      if (!isEmptyNullUndefined(id)) {
        await getProviderReportingHeaders(id);
        setIsEdit(true);
      }
    };
    fetchData();
  }, [entities]);
  

  React.useEffect(() => {
    if (id && selectedCompany.id) {
      getAllActiveQuery(selectedCompany.id);
      getAllActiveAnnualCycle(selectedCompany.id);
    }
  }, []);

  React.useEffect(() => {
    let emptyEntityMappings = [];
    for (const entity of entities) {
      emptyEntityMappings.push({
        dbName: entity,
        csvName: '',
        defaultValue: '',
      });
    }
    handleMapBlankAndDeleteAllMappingRows(emptyEntityMappings);
  }, [entities]);

  const getAllActiveQuery = async (companyId) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.customquery}?companyId=${companyId}&relationTable=Employee&status=ACTIVE`,
        {
          cancelToken: source.token,
        },
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no record'));
          setQueryList([]);
        } else {
          setQueryList(res.data.reverse());
        }
      } else {
        setQueryList([]);
      }
    } catch (e) {
      if (axios.isCancel(e)) {
      } else {
        apiCatchErrorMessage(e, dispatch, fetchError);
      }
      setQueryList([]);
    }
  };

  const getAllActiveAnnualCycle = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.annualCycle}/${companyId}/ACTIVE`,
        {cancelToken: source.token},
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no annual cycle for selected company'));
          setAnnualCycle([]);
        } else {
          const reversed = res.data.reverse();
          setAnnualCycle(reversed);
        }
        setIsLoading(() => false);
      } else {
        setAnnualCycle([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setAnnualCycle([]);
    }
    setIsLoading(() => false);
  };

  const getAllCsventity = async (id) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.csventity_getCSVEntityFields}/Employee/${id}?type=${reportType}`,
        {
          cancelToken: source.token,
        },
      );
      if (res.status == 200) {
        setEntities([
          // 'Manager ID',
          // 'Manager Name',
          // 'Manager Email ID',
          // 'Self Feedback',
          // 'Peer Feedback',
          // 'Manager Feedback',
          // 'Trending Rating',
          // 'Rating',
          // 'Promotion',
          // 'Self Feedback Status',
          // 'Self Feedback Submitted Date',
          // 'Manager Feedback Status',
          // 'Manager Feedback Submitted Date',
          // `lastIncrementDate`,
          // `lastYearNoOfHikes`,
          // `lastYearTotalHikePercent`,
          // `lastYearFixedSalary`,
          // `currentFixedCompaRatio`,
          // `recomendedFixedSalaryIncrementPercent`,
          // `managerRecomandationPercent`,
          // `finalIncrementAmount`,
          // `newFixedSalary`,
          // `newFixedCompaRatio`,
          // `lastYearVariablePayEligiblity`,
          // `newRecomendedVariablePayTarget`,
          // `managerRecomendedVariablePayTarget`,
          // `lastYearValueOfVestedESOPs`,
          // `newVestedESOPs`,
          // `lastYearTotalCompensation`,
          // `currentTcCompaRatio`,
          // `newTolatCompensation`,
          // `newTCCompaRatio`,
          // `lastYearVariablePayAmount`,
          // `lastYearRating`,
          // `ratingsThreeYearsAgo`,
          // `ratingsTwoYearsAgo`,
          // `lastYearEarnedInsentives`,
          // `lastYearJoiningBonus`,
          // `lastYearRetentionBonus`,
          // `lastYearVestedESOPUnits`,
          // `lastYearLongTermContributioBonus`,
          // `lastYearBenifits`,
          // `lastYearOneTimeBonus`,
          // `newIncentives`,
          // `newJoiningBonus`,
          // `newRetentionBonus`,
          // `newVestedESOPUnits`,
          // `newLongTermContributionBonus`,
          // `newBenifits`,
          // `newOneTimeBonus`,
          // `lastYearVariablePayEligiblityTarget`,
          // `lastYearVariablePayEligiblityProrated`,
          // `currentRating`,
          // `Job Family`,
          // `Role Type`,
          // `Job Type/ Career Level`,
          // `Fixed Salary Min`,
          // `Fixed Salary Mid`,
          // `Fixed Salary Max`,
          // `TC Min`,
          // `TC Mid`,
          // `TC Max`,
          // `TC Amount for calc`,
          // `valueOfVestedESOP (nextYear)`,
          // `valueOfVestedESOP (nextYear + 1)`,
          // `valueOfVestedESOP (nextYear + 2)`,
          // `lbpPayOut`,
          ...res.data,
        ]);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
    }
  };

  function capitalize(s) {
    return s[0].toUpperCase() + s.slice(1);
  }

  function separateCamelCaseWords(camelCaseString) {
    var words = camelCaseString.split(/(?=[A-Z])/);
    return capitalize(words.join(' '));
  }

  // function separateCamelCaseWords(camelCaseString) {
  //   if (employeeFields.includes(camelCaseString)) {
  //     var words = camelCaseString.split(/(?=[A-Z])/);
  //     return capitalize(words.join(' '));
  //   }
  //   return camelCaseString;
  // }

  const handleCreateBlankMaps = async () => {
    setIsLoading(() => true);
    let emptyEntityMappings = {};
    let orderedObj = {};
    let orderedUnmappedObj = {};
    let mappedEntities = entityFields.entityDetails
      .filter((item) => {
        if (!item.isVisible && !item.isDeleted) {
          return item;
        }
      })
      .map((item) => item.entityName);
    let reversed = entityFields.headersDetails.headersMappedWith.map((item) =>
      swapKeysAndValues(item),
    );
    for (let i = 0; i < entities.length; i++) {
      let entity = entities[i];
      emptyEntityMappings[entity] = separateCamelCaseWords(entities[i]);
    }
    for (let key in emptyEntityMappings) {
      if (mappingsRow.length > 0 && mappedEntities.includes(key)) {
        let entIndex = reversed.findIndex((item) => item.hasOwnProperty(key));
        if (entIndex != -1) {
          emptyEntityMappings[key] =
            entityFields.headersDetails.headers[entIndex].header;
        }
      }
    }
    for (let key in emptyEntityMappings) {
      let entIndex = reversed.findIndex((item) => item.hasOwnProperty(key));
      if (
        mappedEntities.includes(key) &&
        entIndex != -1 &&
        entityFields.headersDetails.headers[entIndex].header.trim() != ''
      ) {
        orderedObj[key] = emptyEntityMappings[key];
      } else {
        orderedUnmappedObj[key] = emptyEntityMappings[key];
      }
    }

    let newObj = {...orderedObj, ...orderedUnmappedObj};
    const resultArray = [];
    for (const dbName in newObj) {
      if (newObj.hasOwnProperty(dbName)) {
        const csvName = newObj[dbName];
        resultArray.push({
          // entity: 'Employee',
          fieldName: dbName,
          reportHeader: csvName,
          // required: true,
          defaultValue: 'N.A',
        });
      }
    }
    handleReset(resultArray);
  };

  const indexOfAll = (arr, val) =>
    arr.reduce((acc, el, i) => (el === val ? [...acc, i] : acc), []);

  const handleMapBlankAndDeleteAllMappingRows = (mappedData) => {
    let tempEntityFields = JSON.parse(JSON.stringify(initialEmptyEntityFields));

    const getMappedHeadersData = async () => {
      let tempMappedHeadersDataTwo = [];
      mappedData.forEach((e, index) => {
        tempMappedHeadersDataTwo.push({[e.dbName]: e.csvName});
      });
      tempEntityFields.previousProviderMappings.mappedHeaders =
        tempMappedHeadersDataTwo;
      tempEntityFields.headersDetails.headersMappedWith = [];
    };

    const getHeadersWithIndex = async () => {
      let tempHeadersWithIndexTwo = [];
      mappedData.forEach((e, index) => {
        tempHeadersWithIndexTwo.push({
          headersName: e.csvName,
          index: index,
        });
      });
      tempEntityFields.headersDetails.headerIndex = tempHeadersWithIndexTwo;
    };

    const getEntitiesWithIndex = async () => {
      let tempEntityWithIndexTwo = [];
      mappedData.forEach((e, index) => {
        tempEntityWithIndexTwo.push({entityName: e.dbName, index: index});
      });
      tempEntityFields.previousProviderMappings.entityWithIndex =
        tempEntityWithIndexTwo;
      tempEntityFields.entityDetails = tempEntityWithIndexTwo;
    };

    const getDefaultValueWithIndex = async () => {
      let tempDefaultValueTwo = [];
      mappedData.forEach((e, index) => {
        tempDefaultValueTwo.push({defaultValue: e.defaultValue, index: index});
      });
      tempEntityFields.previousProviderMappings.defaultValue =
        tempDefaultValueTwo;
    };

    const getOldEntity = async () => {
      let tempOldEntityTwo = [];
      mappedData.forEach((e, index) => {
        tempOldEntityTwo.push(e.dbName);
      });
      tempEntityFields.previousProviderMappings.oldEntity = tempOldEntityTwo;
    };

    const getOldHeaders = async () => {
      let tempOldHeadersTwo = [];
      tempEntityFields.previousProviderMappings.oldHeaders = tempOldHeadersTwo;
      tempEntityFields.headersDetails.headers = tempOldHeadersTwo;

      setMappingsRow(
        tempOldHeadersTwo.map((e) => {
          return createData(
            // e.entity,
            e.header,
            e.header,
            'map',
            // e.isRequired,
            e.defaultValue,
          );
        }),
      );

      setHeaderError(
        new Array(tempOldHeadersTwo?.length).fill({
          isError: false,
          errorMessage: '',
        }),
      );

      // setEntityError(
      //   new Array(tempOldHeadersTwo?.length).fill({
      //     isError: false,
      //     errorMessage: '',
      //   }),
      // );
      setDefaultValueError(
        new Array(tempOldHeadersTwo?.length).fill({
          isError: false,
          errorMessage: '',
        }),
      );
    };

    const syncisVisible = async () => {
      tempEntityFields.entityDetails.forEach((ent, index) => {
        ent.isVisible = false;
        ent.isDeleted = true;
      });
    };

    getMappedHeadersData();
    getHeadersWithIndex();
    getEntitiesWithIndex();
    getOldEntity();
    getOldHeaders();
    // getEntityDropdownWithIndex();
    getDefaultValueWithIndex();
    // getIsRequiredWithIndex();

    syncisVisible();
    let tempProps = {
      isHideShow: false,
    };
    setAlertProps(() => tempProps);
    setEntityFields(() => tempEntityFields);
  };

  const shouldBeDisabled = () => {
    let bool;
    let values = {};
    for (let i = 0; i < entityFields.headersDetails.headers.length; i++) {
      var header = entityFields.headersDetails.headers[i].header;
      var mappedEntity =
        entityFields.headersDetails.headersMappedWith[i][
          entityFields.headersDetails.headers[i].header
        ];
      if (!isEmptyNullUndefined(mappedEntity)) {
        values[mappedEntity] = header;
      }
    }
    if (Object.keys(values).length) {
      bool = false;
    } else {
      bool = true;
    }

    return bool;
  };

  const getProviderReportingHeaders = async (Id) => {
    setIsLoading(() => true);
    let tempEntityFields = JSON.parse(JSON.stringify(entityFields));
    try {
      const res = await jwtAxios.get(`${API_ROUTS.feedbackReport}/${Id}`, {
        cancelToken: source.token,
      });

      if (res.status == 200) {
        // setIsConfigured(() => true);
        setResData(res.data.feedbackReportHeader);
        setReportName(res.data.reportName);
        setReportType(res.data.reportType);
        setStatus(res.data.status);

        const getMappedHeadersData = async () => {
          let tempMappedHeadersDataTwo = [];
          res.data.feedbackReportHeader.forEach((e, index) => {
            tempMappedHeadersDataTwo.push({[e.fieldName]: e.reportHeader});
          });

          tempEntityFields.previousProviderMappings.mappedHeaders =
            tempMappedHeadersDataTwo;

          tempEntityFields.headersDetails.headersMappedWith =
            tempMappedHeadersDataTwo.map((item) => swapKeysAndValues(item));
        };

        const getHeadersWithIndex = async () => {
          let tempHeadersWithIndexTwo = [];

          res.data.feedbackReportHeader.forEach((e, index) => {
            tempHeadersWithIndexTwo.push({
              headersName: e.reportHeader,
              index: index,
            });
          });

          tempEntityFields.previousProviderMappings.headersWithIndex =
            tempHeadersWithIndexTwo;

          tempEntityFields.headersDetails.headerIndex = tempHeadersWithIndexTwo;
        };

        const getEntitiesWithIndex = async () => {
          let tempEntityWithIndexTwo = [];

          res.data.feedbackReportHeader.forEach((e, index) => {
            tempEntityWithIndexTwo.push({
              entityName: e.fieldName,
              index: index,
            });
          });

          tempEntityFields.previousProviderMappings.entityWithIndex =
            tempEntityWithIndexTwo;

          let tempCSVEntityWithIndex = [];
          for (let i = 0; i < entities.length; i++) {
            tempCSVEntityWithIndex.push({entityName: entities[i], index: i});
          }
          tempEntityFields.entityDetails = tempCSVEntityWithIndex;
        };

        const getOldEntity = async () => {
          let tempOldEntityTwo = [];
          res.data.feedbackReportHeader.forEach((e, index) => {
            tempOldEntityTwo.push(e.fieldName);
          });

          tempEntityFields.previousProviderMappings.oldEntity =
            tempOldEntityTwo;
        };

        const getOldHeaders = async () => {
          let tempOldHeadersTwo = [];

          res.data.feedbackReportHeader.forEach((e, index) => {
            tempOldHeadersTwo.push({
              header: e.reportHeader,
              // entity: e.entity,
              // isRequired: e.required,
              defaultValue: e.defaultValue,
            });
          });

          tempEntityFields.previousProviderMappings.oldHeaders =
            tempOldHeadersTwo;

          tempEntityFields.headersDetails.headers = tempOldHeadersTwo;

          setMappingsRow(
            tempOldHeadersTwo.map((e) => {
              return createData(
                // e.entity,
                e.header,
                e.header,
                'map',
                // e.isRequired,
                e.defaultValue,
              );
            }),
          );
        };

        const getDefaultValueWithIndex = async () => {
          let tempDefaultValue = [];

          res.data.feedbackReportHeader.forEach((e, index) => {
            tempDefaultValue.push({defaultValue: e.defaultValue, index: index});
          });

          tempEntityFields.previousProviderMappings.defaultValue =
            tempDefaultValue;
        };

        const syncisVisible = async () => {
          let currentEntities =
            tempEntityFields.previousProviderMappings.entityWithIndex.map(
              (i) => i.entityName,
            );

          tempEntityFields.entityDetails.forEach((ent, index) => {
            ent.isVisible = currentEntities.includes(ent.entityName)
              ? false
              : true;
            ent.isDeleted = false;
          });
        };

        if (Object.keys(res.data).length) {
          getMappedHeadersData();
          getHeadersWithIndex();
          getEntitiesWithIndex();
          getOldEntity();
          getOldHeaders();
          getDefaultValueWithIndex();
          syncisVisible();
          setEntityFields(() => tempEntityFields);
          setIsLoading(() => false);
          setEntityError(
            new Array(tempEntityFields.headersDetails.headers?.length).fill({
              isError: false,
              errorMessage: '',
            }),
          );
          setHeaderError(
            new Array(tempEntityFields.headersDetails.headers?.length).fill({
              isError: false,
              errorMessage: '',
            }),
          );
          setDefaultValueError(
            new Array(tempEntityFields.headersDetails.headers?.length).fill({
              isError: false,
              errorMessage: '',
            }),
          );
        } else {
          let emptyEntityMappings = [];
          for (let i = 0; i < entities.length; i++) {
            let entity = entities[i];
            emptyEntityMappings.push({
              // entity: '',
              dbName: entity,
              csvName: '',
              // required: false,
              defaultValue: '',
            });
          }
          handleMapBlankAndDeleteAllMappingRows(emptyEntityMappings);
          setIsLoading(() => false);
          setHeaderError(
            new Array(entities.length).fill({
              isError: false,
              errorMessage: '',
            }),
          );
          setDefaultValueError(
            new Array(entities.length).fill({
              isError: false,
              errorMessage: '',
            }),
          );
        }
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setIsLoading(() => false);
      // setProviderSelectModal(false);
    }
  };

  const handleChange = (event, index, row) => {
    let tempEntityFields = JSON.parse(JSON.stringify(entityFields));
    tempEntityFields.entityDetails.find((ent) => {
      return ent?.entityName == event.target.value;
    }).isDeleted = false;
    tempEntityFields.entityDetails.find((ent) => {
      return ent?.entityName == event.target.value;
    }).isVisible = false;
    setEntityError(
      new Array(mappingsRow?.length).fill({
        isError: false,
        errorMessage: '',
      }),
    );
    if (
      !isEmptyNullUndefined(
        tempEntityFields.headersDetails.headersMappedWith[index][
          tempEntityFields.headersDetails.headers[index].header
        ],
      )
    ) {
      for (let key in tempEntityFields.entityDetails) {
        if (
          tempEntityFields.entityDetails[key].entityName ==
          tempEntityFields.headersDetails.headersMappedWith[index][
            tempEntityFields.headersDetails.headers[index].header
          ]
        ) {
          tempEntityFields.entityDetails[key].isVisible = true;
          setEntityFields(() => tempEntityFields);
        }
      }

      for (let key in tempEntityFields.entityDetails) {
        if (
          tempEntityFields.entityDetails[key].entityName == event.target.value
        ) {
          tempEntityFields.entityDetails[key].isVisible = false;
          tempEntityFields.headersDetails.headersMappedWith[index][
            tempEntityFields.headersDetails.headers[index].header
          ] = event.target.value;
          setEntityFields(() => tempEntityFields);
        }
      }
    } else {
      for (let key in tempEntityFields.entityDetails) {
        if (
          tempEntityFields.entityDetails[key].entityName == event.target.value
        ) {
          tempEntityFields.entityDetails[key].isVisible = false;
          tempEntityFields.headersDetails.headersMappedWith[index][
            tempEntityFields.headersDetails.headers[index].header
          ] = event.target.value;
          setEntityFields(() => tempEntityFields);
        }
      }
    }
    setEntityFields(() => tempEntityFields);
  };

  const handleChangeHeader = (e, index) => {
    let tempEntityFields = JSON.parse(JSON.stringify(entityFields));
    let tempHeaderError = JSON.parse(JSON.stringify(headerError));
    let tempEntityError = JSON.parse(JSON.stringify(entityError));
    let tempDefaultValueError = JSON.parse(JSON.stringify(defaultValueError));
    let value = e.target.value;

    let oldKey = entityFields.headersDetails.headers[index].header;
    let oldEntity =
      tempEntityFields?.headersDetails?.headersMappedWith[index][
        tempEntityFields?.headersDetails?.headers[index].header
      ];

    tempEntityFields.headersDetails.headers[index].header = value;
    tempEntityFields.headersDetails.headerIndex[index].headersName = value;
    tempEntityFields.headersDetails.headersMappedWith[index] = renameProp(
      `${oldKey}`,
      `${value}`,
      tempEntityFields.headersDetails.headersMappedWith[index],
    );
    tempEntityFields.headersDetails.headersMappedWith[index][value] = oldEntity;

    setEntityFields(() => tempEntityFields);

    let tempRows = [...mappingsRow];
    tempRows[index].unmapped = value;
    tempRows[index].header = value;
    tempHeaderError[index].isError = false;
    tempHeaderError[index].errorMessage = '';
    tempEntityError[index].isError = false;
    tempEntityError[index].errorMessage = '';
    tempDefaultValueError[index].isError = false;
    tempDefaultValueError[index].errorMessage = '';
    setMappingsRow(() => tempRows);
    setHeaderError(tempHeaderError);
    setEntityError(tempEntityError);
    setDefaultValueError(tempDefaultValueError);
  };

  const handleChangeForNewFields = (e, index, type) => {
    let tempEntityFields = JSON.parse(JSON.stringify(entityFields));
    let value = e.target.value;
    let tempDefaultValueError = JSON.parse(JSON.stringify(defaultValueError));
    let selectedIndexDefaultValueError = tempDefaultValueError[index];

    if (type == 'dropdown') {
      tempEntityFields.headersDetails.headers[index].entity = value;
      tempEntityFields.previousProviderMappings.entityDropdown[
        index
      ].entityDropdown = value;
      tempEntityFields.previousProviderMappings.entityDropdown[index].index =
        index;
    }
    if (type == 'checkbox') {
      tempEntityFields.headersDetails.headers[index].isRequired =
        e.target.checked;
      tempEntityFields.previousProviderMappings.isRequired[index].isRequired =
        e.target.checked;
      tempEntityFields.previousProviderMappings.isRequired[index].index = index;
    }
    if (type == 'textfield') {
      tempEntityFields.headersDetails.headers[index].defaultValue = value;
      tempEntityFields.previousProviderMappings.defaultValue[
        index
      ].defaultValue = value;
      tempEntityFields.previousProviderMappings.defaultValue[index].index =
        index;
      selectedIndexDefaultValueError = {isError: false, errorMessage: ''};
      tempDefaultValueError[index] = selectedIndexDefaultValueError;
      setDefaultValueError(() => tempDefaultValueError);
    }

    setEntityFields(() => tempEntityFields);

    let tempRows = [...mappingsRow];

    if (type === 'dropdown') {
      tempRows[index].entity = value;
    } else if (type === 'checkbox') {
      tempRows[index].isRequired = e.target.checked;
    } else {
      tempRows[index].defaultValue = value;
    }

    setMappingsRow(() => tempRows);
  };

  const mapToNewFormat = (originalObject) => {
    return {
      fieldName: originalObject.dbName,
      reportHeader: originalObject.csvName,
      isActive: true,
      defaultValue: originalObject.defaultValue,
    };
  };

  const reportProviderHeaders = async (companyId, email, payload) => {
    setIsLoadingUpload(() => true);
    const newPayload = payload.map(mapToNewFormat);

    let tempPayloadCreate = {
      companyId: selectedCompany && selectedCompany.id,
      reportName: reportName,
      status: status,
      reportType: reportType,
      feedbackReportHeader: newPayload,
    };
    let tempPayloadUpdate = {
      id: id,
      companyId: selectedCompany && selectedCompany.id,
      reportName: reportName,
      status: status,
      reportType: reportType,
      feedbackReportHeader: newPayload,
    };

    try {
      const res = await jwtAxios.post(
        `${API_ROUTS.saveFeedbackReport}`,
        isEdit ? tempPayloadUpdate : tempPayloadCreate,
      );
      if (res.status == 200) {
        dispatch(showMessage(`Report mappings updated successfully..!`));
        Router.push('/company-builder/feedback-report');
        setIsLoadingUpload(false);
        // getProviderReportingHeaders();
      }
    } catch (e) {
      if (e?.response?.data?.detail) {
        dispatch(fetchError(e?.response?.data?.detail));
      } else if (e?.response?.data?.title) {
        dispatch(fetchError(e?.response?.data?.title));
      } else {
        dispatch(fetchError(e?.message));
      }

      setIsLoadingUpload(() => false);
    }
  };

  const emailProviderHeaders = async (payload) => {
    setEmailSend(() => true);
    // const newPayload = payload.map(mapToNewFormat);
    try {
      const res = await jwtAxios.post(
        `${API_ROUTS.sendFeedbackReport}?email=${selectedCompany.primaryEmail}&companyId=${selectedCompany.id}&queryId=${queryId}&cycleId=${cycleId}&reportId=${id}&managerId =NULL`,
        // payload,
      );
      if (res.status == 200) {
        setEmailSend(() => false);
        dispatch(showMessage(`Sample report e-mailed successfully..!`));
        setShowEmail(false);
        setEmail('');
        setCycleId(null);
        setQueryId(null);
      }
    } catch (e) {
      if (e?.response?.data?.detail) {
        dispatch(fetchError(e?.response?.data?.detail));
      } else if (e?.response?.data?.title) {
        dispatch(fetchError(e?.response?.data?.title));
      } else {
        // dispatch(fetchError(e?.message));
      }
      setShowEmail(false);
      setEmailSend(() => false);
    }
  };

  const menuItems = () => {
    let dom = [];

    const sortedEntityDetails = [...entityFields.entityDetails].sort((a, b) => {
      if (a.entityName < b.entityName) return -1;
      if (a.entityName > b.entityName) return 1;
      return 0;
    });

    sortedEntityDetails.forEach((element) => {
      dom.push(
        <MenuItem
          value={element.entityName}
          disabled={!element.isVisible && !element.isDeleted}
        >
          {element.entityName}
        </MenuItem>,
      );
    });
    return dom;
  };

  const renameProp = (oldProp, newProp, {[oldProp]: old, ...others}) => {
    return {
      [newProp]: old,
      ...others,
    };
  };

  const reorder = (list, startIndex, endIndex) => {
    const result = Array.from(list);
    const [removed] = result.splice(startIndex, 1);
    result.splice(endIndex, 0, removed);
    return result;
  };

  const onDragEnd = (result) => {
    if (!result.destination) {
      return;
    }
    let tempEntityFields = JSON.parse(JSON.stringify(entityFields));

    let movedItems = reorder(
      mappingsRow,
      result.source.index,
      result.destination.index,
    );

    let tempEntityDetails = reorder(
      tempEntityFields.entityDetails,
      result.source.index,
      result.destination.index,
    );

    if (result.source.index < result.destination.index) {
      for (let i = result.source.index; i <= result.destination.index; i++) {
        tempEntityDetails[i].index = i;
      }
    } else if (result.destination.index < result.source.index) {
      for (let i = result.destination.index; i <= result.source.index; i++) {
        tempEntityDetails[i].index = i;
      }
    }

    let tempHeaders = reorder(
      tempEntityFields.headersDetails.headers,
      result.source.index,
      result.destination.index,
    );
    let tempHeadersIndex = reorder(
      tempEntityFields.headersDetails.headerIndex,
      result.source.index,
      result.destination.index,
    );

    if (result.source.index < result.destination.index) {
      for (let i = result.source.index; i <= result.destination.index; i++) {
        tempHeadersIndex[i].index = i;
      }
    } else if (result.destination.index < result.source.index) {
      for (let i = result.destination.index; i <= result.source.index; i++) {
        tempHeadersIndex[i].index = i;
      }
    }

    let tempHeadersMappedWith = reorder(
      tempEntityFields.headersDetails.headersMappedWith,
      result.source.index,
      result.destination.index,
    );
    let tempHeaderError = reorder(
      headerError,
      result.source.index,
      result.destination.index,
    );

    let tempEntityError = reorder(
      entityError,
      result.source.index,
      result.destination.index,
    );
    let tempDefaultValueError = reorder(
      defaultValueError,
      result.source.index,
      result.destination.index,
    );
    tempEntityFields.entityDetails = tempEntityDetails;
    tempEntityFields.headersDetails.headers = tempHeaders;
    tempEntityFields.headersDetails.headerIndex = tempHeadersIndex;
    tempEntityFields.headersDetails.headersMappedWith = tempHeadersMappedWith;
    setEntityFields(() => tempEntityFields);
    setMappingsRow(() => movedItems);
    setHeaderError(() => tempHeaderError);
    setEntityError(() => tempEntityError);
    setDefaultValueError(() => tempDefaultValueError);
  };

  const handleUnMapMapping = (row, index, e) => {
    let tempEntityFields = JSON.parse(JSON.stringify(entityFields));

    tempEntityFields.entityDetails.find((ent) => {
      return (
        ent?.entityName ==
        tempEntityFields?.headersDetails?.headersMappedWith[index][
          tempEntityFields?.headersDetails?.headers[index].header
        ]
      );
    }).isVisible = true;

    tempEntityFields.headersDetails.headersMappedWith[index][
      tempEntityFields.headersDetails.headers[index].header
    ] = '';

    setEntityFields(() => tempEntityFields);
  };

  const handleDeleteMapping = (row, index) => {
    setIsLoadingDel(true);
    let tempEntityFields = JSON.parse(JSON.stringify(entityFields));

    if (
      !isEmptyNullUndefined(
        entityFields?.headersDetails?.headersMappedWith[index][
          entityFields?.headersDetails?.headers[index].header
        ],
      )
    ) {
      tempEntityFields.entityDetails.find((ent) => {
        return (
          ent?.entityName ==
          entityFields?.headersDetails?.headersMappedWith[index][
            entityFields?.headersDetails?.headers[index].header
          ]
        );
      }).isDeleted = true;
    }

    tempEntityFields.headersDetails.headersMappedWith.splice(index, 1);
    tempEntityFields.headersDetails.headerIndex[index].headersName = '';
    tempEntityFields.headersDetails.headerIndex.splice(index, 1);
    tempEntityFields.headersDetails.headerIndex.forEach(
      (item, i) => (item.index = i),
    );
    tempEntityFields.headersDetails.headers.splice(index, 1);
    setEntityFields(() => tempEntityFields);

    setMappingsRow(
      tempEntityFields.headersDetails.headers.map((e) => {
        return createData(
          // e.entity,
          e.header,
          e.header,
          'map',
          // e.isRequired,
          e.defaultValue,
        );
      }),
    );
    // setEntityError(
    //   new Array(tempEntityFields.headersDetails.headers?.length).fill({
    //     isError: false,
    //     errorMessage: '',
    //   }),
    // );
    setHeaderError(
      new Array(tempEntityFields.headersDetails.headers?.length).fill({
        isError: false,
        errorMessage: '',
      }),
    );
    setDefaultValueError(
      new Array(tempEntityFields.headersDetails.headers?.length).fill({
        isError: false,
        errorMessage: '',
      }),
    );

    setIsLoadingDel(false);
  };
  const handleResetAlert = () => {
    let tempProps = {
      isHideShow: true,
      alertType: 'Confirmation',
      useFor: 'Reset All Mappings',
      title: <IntlMessages id='feedbackReport.resetAllMappings' />,
      message: <IntlMessages id='feedbackReport.resetAllMappingsMessage' />,
    };
    setAlertProps(() => tempProps);
  };
  const handleCreateAllAlert = () => {
    let tempProps = {
      isHideShow: true,
      alertType: 'Confirmation',
      useFor: 'Create All Mappings',
      title: <IntlMessages id='feedbackReport.createAllMappings' />,
      message: <IntlMessages id='feedbackReport.createAllMappingsMessage' />,
    };
    setAlertProps(() => tempProps);
  };

  const handleChangeNewRowFields = async (e, fieldName) => {
    let tempNewRowFields = JSON.parse(JSON.stringify(newRowFields));
    // let tempNewRowFieldsError = JSON.parse(JSON.stringify(newRowFieldsError));
    let tempNewRowFieldsError = {...newRowFieldsError};
    if (fieldName == 'hName') {
      tempNewRowFieldsError.headerName.isError = false;
      tempNewRowFieldsError.headerName.errorMessage = '';
      tempNewRowFields.headerName = e.target.value;
    }
    if (fieldName == 'eName') {
      tempNewRowFieldsError.entityName.isError = false;
      tempNewRowFieldsError.entityName.errorMessage = '';
      tempNewRowFields.entityName = e.target.value;
    }
    if (fieldName == 'entityDropdown') {
      tempNewRowFieldsError.entityDropdown.isError = false;
      tempNewRowFieldsError.entityDropdown.errorMessage = '';
      tempNewRowFields.entityDropdown = e.target.value;
    }
    if (fieldName == 'dvalue') {
      tempNewRowFieldsError.defaultValue.isError = false;
      tempNewRowFieldsError.defaultValue.errorMessage = '';
      tempNewRowFields.defaultValue = e.target.value;
    }
    if (fieldName == 'checkbox') {
      tempNewRowFields.isRequired = e.target.checked;
    }
    setNewRowFields(tempNewRowFields);
    setNewRowFieldsError(tempNewRowFieldsError);
  };

  const handleValidateNewRowFields = async () => {
    let isValid = true;
    let tempNewRowFields = JSON.parse(JSON.stringify(newRowFields));

    let tempNewRowFieldsError = {...newRowFieldsError};
    if (isEmptyNullUndefined(tempNewRowFields.headerName)) {
      tempNewRowFieldsError.headerName.isError = true;

      tempNewRowFieldsError.headerName.errorMessage = (
        <IntlMessages id='error.pleaseEnterCSVHeader' />
      );
      isValid = false;
    }
    if (isEmptyNullUndefined(tempNewRowFields.entityName)) {
      tempNewRowFieldsError.entityName.isError = true;

      tempNewRowFieldsError.entityName.errorMessage = (
        <IntlMessages id='error.pleaseSelectTableHeader' />
      );

      isValid = false;
    }

    if (isEmptyNullUndefined(tempNewRowFields.defaultValue)) {
      tempNewRowFieldsError.defaultValue.isError = true;

      tempNewRowFieldsError.defaultValue.errorMessage = (
        <IntlMessages id='error.pleaseEnterDefaultValue' />
      );
      isValid = false;
    }
    if (isValid) {
      addNewRow();
    } else {
      setNewRowFieldsError(tempNewRowFieldsError);
    }
  };

  const addNewRow = () => {
    let tempSelectedData = JSON.parse(JSON.stringify(selectedData));
    let tempEntityFields = JSON.parse(JSON.stringify(entityFields));

    if (mappingsRow.length > 0) {
      tempEntityFields.entityDetails.find(
        (item) => item.entityName == newRowFields.entityName,
      ).isVisible = false;
      tempEntityFields.entityDetails.find(
        (item) => item.entityName == newRowFields.entityName,
      ).isDeleted = false;
      tempEntityFields.headersDetails.headersMappedWith.unshift({
        [newRowFields.headerName]: newRowFields.entityName,
      });
      tempEntityFields.headersDetails.headerIndex.forEach(
        (item) => (item.index += 1),
      );
      tempEntityFields.headersDetails.headerIndex.unshift({
        headersName: newRowFields.headerName,
        index: 0,
      });

      tempEntityFields.headersDetails.headers.unshift({
        header: newRowFields.headerName,
        // entity: newRowFields.entityDropdown,
        defaultValue: newRowFields.defaultValue,
        // isRequired: newRowFields.isRequired,
      });

      tempEntityFields.headersDetails.headersMappedWith.forEach((e, index) => {
        if (
          !isEmptyNullUndefined(
            tempEntityFields.headersDetails.headerIndex[index],
          ) &&
          tempEntityFields.headersDetails.headerIndex[index].headersName != ''
        ) {
          if (
            e[tempEntityFields.headersDetails.headerIndex[index].headersName]
          ) {
            tempSelectedData[
              tempEntityFields.headersDetails.headerIndex[index].headersName
            ] =
              e[tempEntityFields.headersDetails.headerIndex[index].headersName];
          }
        }
      });

      setMappingsRow(
        tempEntityFields.headersDetails.headers.map((e) => {
          return createData(
            // e.entity,
            e.header,
            e.header,
            'map',
            // e.isRequired,
            e.defaultValue,
          );
        }),
      );
      setSelectedData(() => tempSelectedData);
      setEntityFields(() => tempEntityFields);
      handleCloseAddNewRowFields();
    } else {
      tempEntityFields.entityDetails.find(
        (item) => item.entityName == newRowFields.entityName,
      ).isVisible = false;
      tempEntityFields.entityDetails.find(
        (item) => item.entityName == newRowFields.entityName,
      ).isDeleted = false;
      tempEntityFields.headersDetails.headersMappedWith.push({
        [newRowFields.headerName]: newRowFields.entityName,
      });

      tempEntityFields.headersDetails.headerIndex[0].headersName = {
        header: newRowFields.headerName,
        defaultValue: newRowFields.defaultValue,
      };

      tempEntityFields.headersDetails.headers.push({
        header: newRowFields.headerName,
        defaultValue: newRowFields.defaultValue,
      });

      tempEntityFields.headersDetails.headersMappedWith.forEach((e, index) => {
        if (
          tempEntityFields.headersDetails.headerIndex[index].headersName != ''
        ) {
          if (
            e[tempEntityFields.headersDetails.headerIndex[index].headersName]
          ) {
            tempSelectedData[
              tempEntityFields.headersDetails.headerIndex[index].headersName
            ] =
              e[tempEntityFields.headersDetails.headerIndex[index].headersName];
          }
        }
      });
      setMappingsRow(
        tempEntityFields.headersDetails.headers.map((e) => {
          return createData(e.header, e.header, 'map', e.defaultValue);
        }),
      );

      setHeaderError(
        new Array(tempEntityFields.headersDetails.headers.length).fill({
          isError: false,
          errorMessage: '',
        }),
      );

      setDefaultValueError(
        new Array(tempEntityFields.headersDetails.headers.length).fill({
          isError: false,
          errorMessage: '',
        }),
      );

      setSelectedData(() => tempSelectedData);
      setEntityFields(() => tempEntityFields);
      handleCloseAddNewRowFields();
    }
    dispatch(showMessage(`${newRowFields.entityName} added successfully..!`));
  };

  const handleAddRow = () => {
    setOpenAddRowModal(true);
  };

  const handleCloseAddNewRowFields = () => {
    setOpenAddRowModal(false);
    setNewRowFields(intialNewRowFields);
    setNewRowFieldsError(intialNewRowFieldsError);
  };

  const handleCloseResetAlert = () => {
    let tempProps = {
      isHideShow: false,
    };
    setAlertProps(() => tempProps);
  };

  const handleReset = (mappedData) => {
    setIsLoading(() => true);
    let tempEntityFields = JSON.parse(JSON.stringify(initialEmptyEntityFields));

    const getMappedHeadersData = async () => {
      let tempMappedHeadersDataTwo = [];
      mappedData.forEach((e, index) => {
        tempMappedHeadersDataTwo.push({[e.fieldName]: e.reportHeader});
      });

      tempEntityFields.previousProviderMappings.mappedHeaders =
        tempMappedHeadersDataTwo;

      tempEntityFields.headersDetails.headersMappedWith =
        tempMappedHeadersDataTwo.map((item) => swapKeysAndValues(item));
    };

    const getHeadersWithIndex = async () => {
      let tempHeadersWithIndexTwo = [];
      mappedData.forEach((e, index) => {
        tempHeadersWithIndexTwo.push({
          headersName: e.reportHeader,
          index: index,
        });
      });

      tempEntityFields.previousProviderMappings.headersWithIndex =
        tempHeadersWithIndexTwo;

      tempEntityFields.headersDetails.headerIndex = tempHeadersWithIndexTwo;
    };

    const getEntitiesWithIndex = async () => {
      let tempEntityWithIndexTwo = [];
      mappedData.forEach((e, index) => {
        tempEntityWithIndexTwo.push({entityName: e.fieldName, index: index});
      });

      tempEntityFields.previousProviderMappings.entityWithIndex =
        tempEntityWithIndexTwo;

      let tempCSVEntityWithIndex = [];
      for (let i = 0; i < entities.length; i++) {
        tempCSVEntityWithIndex.push({entityName: entities[i], index: i});
      }
      tempEntityFields.entityDetails = tempCSVEntityWithIndex;
    };

    const getDefaultValueWithIndex = async () => {
      let tempDefaultValueTwo = [];
      mappedData.forEach((e, index) => {
        tempDefaultValueTwo.push({defaultValue: e.defaultValue, index: index});
      });
      tempEntityFields.previousProviderMappings.defaultValue =
        tempDefaultValueTwo;
    };

    const getOldEntity = async () => {
      let tempOldEntityTwo = [];
      mappedData.forEach((e, index) => {
        tempOldEntityTwo.push(e.fieldName);
      });
      tempEntityFields.previousProviderMappings.oldEntity = tempOldEntityTwo;
    };

    const getOldHeaders = async () => {
      let tempOldHeadersTwo = [];
      mappedData.forEach((e, index) => {
        tempOldHeadersTwo.push({
          header: e.reportHeader,
          // entity: e.entity,
          // isRequired: e.required,
          defaultValue: e.defaultValue,
        });
      });

      tempEntityFields.previousProviderMappings.oldHeaders = tempOldHeadersTwo;

      tempEntityFields.headersDetails.headers = tempOldHeadersTwo;

      setMappingsRow(
        tempOldHeadersTwo.map((e) => {
          return createData(
            // e.entity,
            e.header,
            e.header,
            'map',
            // e.isRequired,
            e.defaultValue,
          );
        }),
      );

      setHeaderError(
        new Array(tempOldHeadersTwo?.length).fill({
          isError: false,
          errorMessage: '',
        }),
      );

      setDefaultValueError(
        new Array(tempOldHeadersTwo?.length).fill({
          isError: false,
          errorMessage: '',
        }),
      );
    };

    const syncisVisible = async () => {
      let currentEntities =
        tempEntityFields.previousProviderMappings.entityWithIndex.map(
          (i) => i.entityName,
        );

      tempEntityFields.entityDetails.forEach((ent, index) => {
        ent.isVisible = currentEntities.includes(ent.entityName) ? false : true;
        ent.isDeleted = false;
      });
    };

    getMappedHeadersData();
    getHeadersWithIndex();
    getEntitiesWithIndex();
    getOldEntity();
    getOldHeaders();
    getDefaultValueWithIndex();
    syncisVisible();
    let tempProps = {
      isHideShow: false,
    };
    setAlertProps(() => tempProps);
    setEntityFields(() => tempEntityFields);
    setIsLoading(() => false);
  };

  const handleValidateMappings = (typeOfReq) => {
    let isValid = true;
    let tempHeaders = JSON.parse(
      JSON.stringify(entityFields.headersDetails.headers),
    );
    let tempDefaultValue = JSON.parse(
      JSON.stringify(entityFields.previousProviderMappings.defaultValue),
    );
    // let tempIsRequired = JSON.parse(
    //   JSON.stringify(entityFields.previousProviderMappings.isRequired),
    // );
    let tempMappings = JSON.parse(JSON.stringify(mappingsRow));
    let tempHeaderError = [];
    let tempEntityError = [];
    let tempDefaultValueError = [];
    let repeatedHeadersArray = tempHeaders.filter(
      (item, index) => tempHeaders.indexOf(item) !== index,
    );

    tempHeaders.forEach((h) => {
      if (h.header?.trim() != '') {
        tempHeaderError.push({isError: false, errorMessage: ''});
      } else {
        tempHeaderError.push({
          isError: true,
          errorMessage: 'Please enter header',
        });
        isValid = false;
      }
    });

    if (repeatedHeadersArray.length > 0) {
      repeatedHeadersArray.forEach((item) => {
        var indices = indexOfAll(tempHeaders, item);
        for (let i = 0; i < indices.length; i++) {
          var errorIndex = indices[i];
          tempHeaderError[errorIndex].isError = true;
          tempHeaderError[errorIndex].errorMessage =
            item.trim() == '' ? 'Please enter header' : 'Header name repeated';
        }
      });
      isValid = false;
    }

    tempMappings.forEach((field, index) => {
      if (field.isRequired) {
        const defaultValue = field.defaultValue;
        if (defaultValue.trim() !== '') {
          tempDefaultValueError.push({isError: false, errorMessage: ''});
        } else {
          tempDefaultValueError.push({
            isError: true,
            errorMessage: 'Please enter default value',
          });
          isValid = false;
        }
      } else {
        tempDefaultValueError.push({isError: false, errorMessage: ''});
      }
    });

    if (isEmptyNullUndefined(reportName)) {
      setReportNameError(() => true);
      isValid = false;
    }
    if (isEmptyNullUndefined(status)) {
      setStatusError(() => true);
      isValid = false;
    }
    if (isEmptyNullUndefined(reportType)) {
      setReportTypeError(() => true);
      isValid = false;
    }

    if (isValid) {
      // let values = {};
      let values = [];
      for (let i = 0; i < entityFields.headersDetails.headers.length; i++) {
        var header = entityFields.headersDetails.headers[i];
        var mappedEntity =
          entityFields.headersDetails.headersMappedWith[i][
            entityFields.headersDetails.headers[i].header
          ];

        if (!isEmptyNullUndefined(mappedEntity)) {
          // values[mappedEntity] = header;
          values.push({
            // entity: header.entity,
            dbName: mappedEntity,
            csvName: header.header,
            // required: header.isRequired,
            defaultValue: header.defaultValue,
          });
        }
      }
      if (typeOfReq == 'submit') {
        reportProviderHeaders(selectedCompany.id, email, values);
      }
      if (typeOfReq == 'report') {
        setShowEmail(true);
      }
    } else {
      setHeaderError(tempHeaderError);
      setEntityError(tempEntityError);
      setDefaultValueError(tempDefaultValueError);
    }
  };

  const isAddRowVisible = () => {
    let visible = false;
    if (
      entityFields.entityDetails
        .map((ent) => {
          return ent.isDeleted;
        })
        .includes(true)
    ) {
      visible = true;
    } else if (
      entityFields.entityDetails
        .map((ent) => {
          return ent.isVisible;
        })
        .includes(true)
    ) {
      visible = true;
    }
    return visible;
  };
  const isCreateAllVisible = () => {
    let visible = false;
    if (
      entityFields.entityDetails
        .map((ent) => {
          return ent.isDeleted;
        })
        .includes(true)
    ) {
      visible = true;
    } else if (
      entityFields.entityDetails
        .map((ent) => {
          return ent.isVisible;
        })
        .includes(true)
    ) {
      visible = true;
    }
    return visible;
  };

  const handleChangeQuery = (event, fieldType) => {
    setQueryId(event.target.value);
    setQueryIdError(false);
  };

  return (
    <>
      <AppAnimate animation='transition.slideUpIn' delay={500}>
        <>
          <AppPageMeta />

          <h2 style={{marginBottom: 20}}>
            <IntlMessages id='feedbackReport.addFeedbackReport' />
          </h2>
          {isLoading ? (
            <AppCard>{domCreactionGridSkeletonLoader()}</AppCard>
          ) : (
            <AppCard
            // style={{display: resData && 'none'}}
            >
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%'}}>
                  <Stack fontWeight={500}>
                    <IntlMessages id='feedbackReport.Enter_report_Name' /> :
                  </Stack>
                </Stack>

                <Stack sx={{width: '60%'}}>
                  <TextField
                    name='reportName'
                    size='small'
                    label={<IntlMessages id='feedbackReport.reportName' />}
                    variant='outlined'
                    sx={{
                      backgroundColor: 'white',
                      mb: 2,
                      borderRadius: 2,
                      width: 400,
                      mr: '200px',
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                    }}
                    value={reportName || ''}
                    onChange={(event) => {
                      setReportName(() => event.target.value);
                      setReportNameError(() => false);
                    }}
                    error={reportNameError}
                  />
                  {reportNameError && (
                    <FormHelperText className='Mui-error'>
                      <IntlMessages id='error.Please_enter_report_name' />
                    </FormHelperText>
                  )}
                </Stack>
              </Stack>

              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%'}}>
                  <Stack fontWeight={500}>Status:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <FormControl
                    sx={{
                      backgroundColor: 'white',
                      mb: 2,
                      borderRadius: 2,
                      width: 400,
                      mr: '200px',
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                    }}
                  >
                    <InputLabel size='small' id='status'>
                      <IntlMessages id='configuration.dialogbox.Status' />
                    </InputLabel>
                    <Select
                      size='small'
                      name='status'
                      label={
                        <IntlMessages id='configuration.dialogbox.Status' />
                      }
                      labelId='status'
                      value={status || ''}
                      error={statusError}
                      onChange={(event) => {
                        setStatus(event.target.value);
                        setStatusError(() => false);
                      }}
                      variant='outlined'
                    >
                      <MenuItem key='Active' value='ACTIVE'>
                        <IntlMessages id='configuration.dialogbox.Status.Active' />
                      </MenuItem>
                      <MenuItem key='Inactive' value='INACTIVE'>
                        <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                      </MenuItem>
                    </Select>
                    {statusError && (
                      <FormHelperText style={{color: '#d32f2f'}}>
                        {'Please select status'}
                      </FormHelperText>
                    )}
                  </FormControl>
                </Stack>
              </Stack>

              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%'}}>
                  <Stack fontWeight={500}>Select Report Type:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <FormControl
                    sx={{
                      backgroundColor: 'white',
                      mb: 2,
                      borderRadius: 2,
                      width: 400,
                      mr: '200px',
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                    }}
                  >
                    <InputLabel size='small' id='reportType'>
                      Report Type
                    </InputLabel>
                    <Select
                      size='small'
                      name='reportType'
                      label={'Report Type'}
                      labelId='reportType'
                      value={reportType || ''}
                      error={reportTypeError}
                      onChange={(event) => {
                        setReportType(event.target.value);
                        setReportTypeError(false);
                      }}
                      variant='outlined'
                    >
                      <MenuItem key='Feedback' value='Feedback'>
                        Feedback
                      </MenuItem>
                      <MenuItem key='Compensation' value='Compensation'>
                        Compensation
                      </MenuItem>
                    </Select>
                    {reportTypeError && (
                      <FormHelperText style={{color: '#d32f2f'}}>
                        {'Please select report type'}
                      </FormHelperText>
                    )}
                  </FormControl>
                </Stack>
              </Stack>

              <Divider sx={{mt: 2, mb: 2}} />

              <Stack
                style={{
                  maxWidth: 750,
                  marginTop: '10px',
                }}
              >
                <Typography variant='h4' sx={{ml: 3}}>
                  <IntlMessages id='feedbackReport.existingProviderMappings' />
                </Typography>
              </Stack>

              <Stack
                sx={{
                  mb: 2,
                }}
                style={{maxWidth: 750}}
              >
                <Stack>
                  <Stack
                    style={{minWidth: '70%'}}
                    direction='row'
                    justifyContent='start'
                  ></Stack>
                </Stack>
              </Stack>
              <Stack
                style={{
                  maxWidth: 750,
                  marginTop: 20,
                  marginBottom: 20,
                }}
                sx={{ml: 3}}
              >
                {!isEmptyNullUndefined(resData) && !isCreateAllVisible() ? (
                  <Stack>
                    <IntlMessages id='feedbackReport.yourFileHasBeenAutoMapped' />
                  </Stack>
                ) : isCreateAllVisible ? (
                  <Stack>
                    <IntlMessages id='feedbackReport.clickOnAddRow' />
                  </Stack>
                ) : (
                  <Stack>
                    <IntlMessages id='feedbackReport.notMappings' />
                  </Stack>
                )}
              </Stack>

              <Stack sx={{mb: 10}}>
                {mappingsRow.length != 0 && (
                  <Stack style={{maxWidth: 1050}}>
                    <div className='ag-theme-alpine' style={{width: '100%'}}>
                      <TableContainer component={Paper}>
                        <Table sx={{minWidth: 600}} aria-label='simple table'>
                          <TableHead>
                            <TableRow>
                              <TableCell
                                sx={{backgroundColor: purple['100']}}
                                align='center'
                                style={{width: 180}}
                              >
                                <IntlMessages id='feedbackReport.csvHeader' />
                              </TableCell>

                              <TableCell
                                sx={{backgroundColor: purple['100']}}
                                align='center'
                                style={{width: 150}}
                              >
                                <IntlMessages id='feedbackReport.mappingStatus' />
                              </TableCell>
                              <TableCell
                                sx={{backgroundColor: purple['100']}}
                                align='center'
                                style={{width: 100}}
                              >
                                <IntlMessages id='feedbackReport.tableHeader' />
                              </TableCell>
                              <TableCell
                                sx={{backgroundColor: purple['100']}}
                                align='center'
                                style={{width: 110}}
                              >
                                {/* Default Value */}
                                <IntlMessages id='feedbackReport.defaultValue' />
                              </TableCell>
                              <TableCell
                                sx={{backgroundColor: purple['100']}}
                                align='center'
                                style={{width: 150}}
                              >
                                <IntlMessages id='feedbackReport.deselect' />
                              </TableCell>
                            </TableRow>
                          </TableHead>
                          <DragDropContext onDragEnd={onDragEnd}>
                            <Droppable
                              style={{transform: 'none'}}
                              droppableId='droppable'
                            >
                              {(provided, snapshot) => (
                                <TableBody
                                  {...provided.droppableProps}
                                  ref={provided.innerRef}
                                >
                                  {mappingsRow.map((row, index) => (
                                    <Draggable
                                      key={'key' + index}
                                      draggableId={'r-' + index}
                                      index={index}
                                    >
                                      {(provided, snapshot) => (
                                        <TableRow
                                          key={`${row.name}_${index}`}
                                          sx={{
                                            '&:last-child td, &:last-child th':
                                              {
                                                border: 0,
                                              },
                                          }}
                                          ref={provided.innerRef}
                                          {...provided.draggableProps}
                                          {...provided.dragHandleProps}
                                          style={getItemStyle(
                                            snapshot.isDragging,
                                            provided.draggableProps.style,
                                          )}
                                        >
                                          <TableCell
                                            sx={{
                                              backgroundColor: green['100'],
                                            }}
                                            scope='row'
                                            align='center'
                                          >
                                            <FormControl fullWidth>
                                              <TextField
                                                id={`${row.header}_${index}_id`}
                                                name='totalLiveMaxLimit'
                                                label={row.header}
                                                variant='outlined'
                                                InputProps={{
                                                  inputProps: {min: 0},
                                                }}
                                                placeholder='Header Name'
                                                sx={{
                                                  backgroundColor: 'white',
                                                  mb: 2,
                                                  borderRadius: 2,
                                                }}
                                                onChange={(e) => {
                                                  handleChangeHeader(e, index);
                                                }}
                                                value={row.header}
                                                error={
                                                  headerError[index]?.isError
                                                    ? headerError[index]
                                                        ?.isError
                                                    : false
                                                }
                                                helperText={
                                                  headerError[index]
                                                    ?.errorMessage
                                                    ? headerError[index]
                                                        ?.errorMessage
                                                    : ''
                                                }
                                              />
                                            </FormControl>
                                          </TableCell>
                                          <TableCell
                                            sx={{backgroundColor: red['50']}}
                                            align='center'
                                          >
                                            {entityFields?.headersDetails
                                              ?.headersMappedWith?.length > 0 &&
                                            !isEmptyNullUndefined(
                                              entityFields.headersDetails
                                                .headerIndex[index]
                                                ?.headersName,
                                            ) &&
                                            !isEmptyNullUndefined(
                                              entityFields?.headersDetails
                                                ?.headersMappedWith[index][
                                                entityFields?.headersDetails
                                                  ?.headers[index].header
                                              ],
                                            ) &&
                                            !entityFields?.entityDetails.find(
                                              (item) => {
                                                return (
                                                  item?.entityName ==
                                                  entityFields?.headersDetails
                                                    ?.headersMappedWith[index][
                                                    entityFields?.headersDetails
                                                      ?.headers[index].header
                                                  ]
                                                );
                                              },
                                            )?.isVisible
                                              ? 'mapped'
                                              : 'unmapped'}
                                          </TableCell>
                                          <TableCell
                                            sx={{backgroundColor: red['50']}}
                                            scope='row'
                                          >
                                            <FormControl fullWidth>
                                              <InputLabel id='demo-simple-select-label'>
                                                Map
                                              </InputLabel>
                                              {isLoading && (
                                                <Skeleton
                                                  variant='rounded'
                                                  width={200}
                                                  height={55}
                                                />
                                              )}
                                              {!isLoading && (
                                                <Select
                                                  labelId='demo-simple-select-label'
                                                  id={`${index}${row.header}`}
                                                  name={`${index}${row.header}_select_input_field`}
                                                  key={`${row.name}_${index}_select_dropdown`}
                                                  value={
                                                    entityFields.headersDetails
                                                      .headersMappedWith
                                                      .length > 0
                                                      ? entityFields
                                                          .headersDetails
                                                          .headersMappedWith[
                                                          index
                                                        ][
                                                          entityFields
                                                            .headersDetails
                                                            .headers[index]
                                                            .header
                                                        ]
                                                      : ''
                                                  }
                                                  label='Map'
                                                  onChange={(event) =>
                                                    handleChange(
                                                      event,
                                                      index,
                                                      row,
                                                    )
                                                  }
                                                >
                                                  {menuItems()}
                                                </Select>
                                              )}
                                              {entityError[index]?.isError && (
                                                <FormHelperText className='Mui-error'>
                                                  {
                                                    entityError[index]
                                                      ?.errorMessage
                                                  }
                                                </FormHelperText>
                                              )}
                                            </FormControl>
                                          </TableCell>

                                          <TableCell
                                            sx={{
                                              backgroundColor: red['50'],
                                            }}
                                          >
                                            <FormControl fullWidth>
                                              <TextField
                                                name='defaultValue'
                                                label={
                                                  <IntlMessages id='feedbackReport.defaultValue' />
                                                }
                                                variant='outlined'
                                                InputProps={{
                                                  inputProps: {min: 0},
                                                }}
                                                sx={{
                                                  backgroundColor: 'white',
                                                  mb: 2,
                                                  borderRadius: 2,
                                                  width: 100,
                                                }}
                                                value={row.defaultValue}
                                                onChange={(event) =>
                                                  handleChangeForNewFields(
                                                    event,
                                                    index,
                                                    'textfield',
                                                  )
                                                }
                                                error={
                                                  defaultValueError[index]
                                                    ?.isError
                                                    ? defaultValueError[index]
                                                        ?.isError
                                                    : false
                                                }
                                                helperText={
                                                  defaultValueError[index]
                                                    ?.errorMessage
                                                    ? defaultValueError[index]
                                                        ?.errorMessage
                                                    : ''
                                                }
                                              />
                                            </FormControl>
                                          </TableCell>

                                          <TableCell
                                            scope='row'
                                            sx={{
                                              backgroundColor: green['100'],
                                            }}
                                            align='center'
                                          >
                                            {entityFields?.headersDetails
                                              ?.headersMappedWith?.length > 0 &&
                                            !isEmptyNullUndefined(
                                              entityFields.headersDetails
                                                .headerIndex[index]
                                                ?.headersName,
                                            ) &&
                                            !isEmptyNullUndefined(
                                              entityFields?.headersDetails
                                                ?.headersMappedWith[index][
                                                entityFields?.headersDetails
                                                  ?.headers[index].header
                                              ],
                                            ) &&
                                            !entityFields?.entityDetails.find(
                                              (item) => {
                                                return (
                                                  item?.entityName ==
                                                  entityFields?.headersDetails
                                                    ?.headersMappedWith[index][
                                                    entityFields?.headersDetails
                                                      ?.headers[index].header
                                                  ]
                                                );
                                              },
                                            )?.isVisible ? (
                                              // <ImCross
                                              //   onClick={(e) =>
                                              //     handleUnMapMapping(
                                              //       row,
                                              //       index,
                                              //       e,
                                              //     )
                                              //   }
                                              //   style={{
                                              //     cursor: 'pointer',
                                              //     color: 'red',
                                              //   }}
                                              // />
                                              <Button
                                                onClick={(e) =>
                                                  handleUnMapMapping(
                                                    row,
                                                    index,
                                                    e,
                                                  )
                                                }
                                                sx={{
                                                  minWidth: 0,
                                                  padding: '1rem',
                                                  background: 'transparent',
                                                }}
                                              >
                                                <ImCross
                                                  style={{color: 'red'}}
                                                />
                                              </Button>
                                            ) : (
                                              // <ImCross
                                              //   style={{
                                              //     color: 'transparent',
                                              //   }}
                                              // />
                                              <Button
                                                sx={{
                                                  minWidth: 0,
                                                  padding: '1rem',
                                                  background: 'transparent',
                                                }}
                                              >
                                                <ImCross
                                                  style={{color: 'transparent'}}
                                                />
                                              </Button>
                                            )}
                                            {/* <ImBin
                                              onClick={(e) => {
                                                handleDeleteMapping(row, index);
                                              }}
                                              style={{
                                                cursor: 'pointer',
                                                color: 'red',
                                                marginLeft: '2rem',
                                              }}
                                            /> */}
                                            <Button
                                              onClick={(e) =>
                                                handleDeleteMapping(row, index)
                                              }
                                              sx={{
                                                minWidth: 0,
                                                padding: '1rem',
                                                background: 'transparent',
                                                marginLeft: '2rem',
                                              }}
                                            >
                                              <ImBin style={{color: 'red'}} />
                                            </Button>
                                          </TableCell>
                                        </TableRow>
                                      )}
                                    </Draggable>
                                  ))}
                                  {provided.placeholder}
                                </TableBody>
                              )}
                            </Droppable>
                          </DragDropContext>
                        </Table>
                      </TableContainer>
                    </div>
                  </Stack>
                )}
              </Stack>

              <Stack
                sx={{
                  width: '100%',
                  marginTop: 8,
                  background: 'red',
                }}
                direction='row'
                justifyContent={'flex-end'}
                spacing={4}
              >
                <Dialog maxWidth={'sm'} open={openAddRowModal}>
                  <DialogContent>
                    <Stack
                      direction='row'
                      justifyContent='center'
                      sx={{mt: '7%'}}
                    >
                      <AppCard style={{width: '350px'}}>
                        <h4 style={{display: 'flex'}}>
                          <IntlMessages id='feedbackReport.addNewField-EntityMapping' />
                        </h4>
                        <Stack sx={{mt: 2}}>
                          <FormControl>
                            <TextField
                              id='add_new_row_header_name'
                              name='add_new_row_header_name'
                              // label='Header'
                              label={
                                <IntlMessages id='providerReporting.edit.CSVHeader' />
                              }
                              variant='outlined'
                              InputProps={{inputProps: {min: 0}}}
                              placeholder='Header Name'
                              sx={{
                                ...textFieldStyled,
                                '& fieldset': {
                                  borderLeftColor: 'red',
                                  borderLeftWidth: 3,
                                },
                              }}
                              onChange={(e) => {
                                handleChangeNewRowFields(e, 'hName');
                              }}
                              value={
                                newRowFields.headerName
                                  ? newRowFields.headerName
                                  : ''
                              }
                              error={newRowFieldsError.headerName.isError}
                              helperText={
                                newRowFieldsError.headerName.errorMessage
                              }
                            />
                          </FormControl>
                          <FormControl fullWidth style={{marginTop: '15px'}}>
                            <InputLabel id='demo-simple-select-label'>
                              {/* Entity Field */}
                              <IntlMessages id='providerReporting.edit.tableHeader' />
                            </InputLabel>
                            {isLoading && (
                              <Skeleton
                                variant='rounded'
                                width={200}
                                height={55}
                              />
                            )}
                            {!isLoading && (
                              <Select
                                sx={{
                                  ...textFieldStyled,
                                  width: '100%',
                                  borderRadius: '8px',
                                  '& fieldset': {
                                    borderLeftColor: 'red',
                                    borderLeftWidth: 3,
                                  },
                                }}
                                labelId='add_new_row_entity_name_label'
                                id='add_new_row_entity_name_select_id'
                                name='add_new_row_entity_name_select_name'
                                value={
                                  newRowFields.entityName
                                    ? newRowFields.entityName
                                    : ''
                                }
                                error={newRowFieldsError.entityName.isError}
                                // label='Entity'
                                label={
                                  <IntlMessages id='providerReporting.edit.tableHeader' />
                                }
                                onChange={(e) => {
                                  handleChangeNewRowFields(e, 'eName');
                                }}
                              >
                                {menuItems()}
                              </Select>
                            )}
                            <FormHelperText style={formHelperTextStyle}>
                              {newRowFieldsError.entityName.errorMessage}
                            </FormHelperText>
                          </FormControl>

                          <FormControl>
                            <TextField
                              name='defaultValue'
                              // label='Default Value'
                              label={
                                <IntlMessages id='feedbackReport.defaultValue' />
                              }
                              variant='outlined'
                              InputProps={{inputProps: {min: 0}}}
                              placeholder='Default Value'
                              sx={{
                                ...textFieldStyled,
                                '& fieldset': {
                                  borderLeftColor: 'red',
                                  borderLeftWidth: 3,
                                },
                              }}
                              onChange={(e) => {
                                handleChangeNewRowFields(e, 'dvalue');
                              }}
                              value={
                                newRowFields.defaultValue
                                  ? newRowFields.defaultValue
                                  : ''
                              }
                              error={newRowFieldsError.defaultValue.isError}
                              helperText={
                                newRowFieldsError.defaultValue.errorMessage
                              }
                            />
                          </FormControl>
                        </Stack>
                      </AppCard>
                    </Stack>
                  </DialogContent>
                  <DialogActions>
                    <Button
                      color='success'
                      name='add_new_header_entity-row_btn'
                      onClick={() => handleValidateNewRowFields()}
                    >
                      {/* Proceed */}
                      <IntlMessages id='common.button.Proceed' />
                    </Button>
                    <Button
                      color='error'
                      name='cancel_add_new_header_entity-row_btn'
                      onClick={() => handleCloseAddNewRowFields()}
                    >
                      {/* Cancel */}
                      <IntlMessages id='common.button.Cancel' />
                    </Button>
                  </DialogActions>
                  <AppInfoView />
                </Dialog>
                <Dialog maxWidth={'sm'} open={showEmail}>
                  <DialogContent>
                    <Stack
                      direction='row'
                      justifyContent='center'
                      sx={{mt: '7%'}}
                    >
                      <AppCard style={{width: '350px'}}>
                        <Stack>
                          <TextField
                            name='email'
                            label={
                              <IntlMessages id='feedbackReport.sendEmailTo' />
                            }
                            variant='outlined'
                            sx={{
                              backgroundColor: 'white',
                              mb: 2,
                              borderRadius: 2,
                              '& fieldset': {
                                borderLeftColor: 'red',
                                borderLeftWidth: 3,
                              },
                            }}
                            value={email || ''}
                            onChange={(event) => {
                              setEmail(() => event.target.value);

                              let tempError = {...emailError};
                              tempError.isError = false;
                              tempError.errorMessage = '';
                              setEmailError(() => tempError);
                            }}
                            error={emailError.isError}
                          />
                          {emailError.isError && (
                            <FormHelperText className='Mui-error'>
                              {emailError.errorMessage}
                            </FormHelperText>
                          )}
                        </Stack>

                        <Stack>
                          <Stack sx={{mt: 10}}>
                            {/* <FormControl
                              sx={{
                                ...textFieldStyled,
                                '& .MuiOutlinedInput-root': {
                                  '& fieldset': {
                                    borderLeftColor: 'red',
                                    borderLeftWidth: 3,
                                  },
                                },
                              }}
                            >
                              <InputLabel
                                sx={{
                                  backgroundColor: '#ffffff',
                                  padding: '0px 0.5rem',
                                }}
                                size='small'
                                id='Type-'
                              >
                                <IntlMessages id='feedbackReport.selectQuery' />
                              </InputLabel>
                              <Select
                                value={queryId || ''}
                                id={'queryId'}
                                name='queryId'
                                error={queryIdError}
                                onChange={(event) => {
                                  setQueryId(event.target.value);
                                  setQueryIdError(false);
                                }}
                                variant='outlined'
                                size='small'
                              >
                                {queryList &&
                                  queryList?.map((t, i) => {
                                    return (
                                      <MenuItem
                                        value={t.id}
                                        id={t.id}
                                        name={t.query}
                                        size='small'
                                        key={i}
                                      >
                                        {t.variableName}
                                      </MenuItem>
                                    );
                                  })}
                              </Select>
                              {queryIdError && (
                                <FormHelperText className='Mui-error'>
                                  <IntlMessages id='error.Please_select_query' />
                                </FormHelperText>
                              )}
                            </FormControl> */}
                            <GenericSelectWithSearch
                              label={
                                <IntlMessages id='feedbackReport.selectQuery' />
                              }
                              name={'queryId'}
                              value={queryId || ''}
                              error={queryIdError}
                              helperText={
                                queryIdError ? (
                                  <IntlMessages id='error.Please_select_query' />
                                ) : null
                              }
                              handleChange={handleChangeQuery}
                              optionList={queryList}
                              labelName={'variableName'}
                              customStyles={{
                                ...textFieldStyled,
                                '& .MuiOutlinedInput-root': {
                                  '& fieldset': {
                                    borderLeftColor: 'red',
                                    borderLeftWidth: 3,
                                  },
                                },
                              }}
                            />
                          </Stack>
                          <Stack sx={{mt: 10}}>
                            <FormControl
                              sx={{
                                ...textFieldStyled,
                                '& .MuiOutlinedInput-root': {
                                  '& fieldset': {
                                    borderLeftColor: 'red',
                                    borderLeftWidth: 3,
                                  },
                                },
                              }}
                            >
                              <InputLabel
                                sx={{
                                  backgroundColor: '#ffffff',
                                  padding: '0px 0.5rem',
                                }}
                                size='small'
                                id='Type-'
                              >
                                <IntlMessages id='feedbackReport.selectCycle' />
                              </InputLabel>
                              <Select
                                value={cycleId || ''}
                                id={'cycleId'}
                                name='cycleId'
                                error={cycleIdError}
                                onChange={(event) => {
                                  setCycleId(event.target.value);
                                  setCycleIdError(false);
                                }}
                                variant='outlined'
                                size='small'
                              >
                                {annualCycle &&
                                  annualCycle?.map((t, i) => {
                                    return (
                                      <MenuItem
                                        value={t.id}
                                        id={t.id}
                                        name={t.cycleName}
                                        size='small'
                                        key={i}
                                      >
                                        {t.cycleName}
                                      </MenuItem>
                                    );
                                  })}
                              </Select>
                              {cycleIdError && (
                                <FormHelperText className='Mui-error'>
                                  <IntlMessages id='error.Please_select_cycle' />
                                </FormHelperText>
                              )}
                            </FormControl>
                          </Stack>
                        </Stack>
                      </AppCard>
                    </Stack>
                  </DialogContent>
                  <DialogActions>
                    <Button
                      color='success'
                      name='emailProviderReport_btn'
                      disabled={emailSend}
                      onClick={() => {
                        let isValid = true;
                        let tempError = {...emailError};
                        if (isEmptyNullUndefined(email)) {
                          tempError.isError = true;
                          // tempError.errorMessage = 'Enter email to send report';
                          tempError.errorMessage = (
                            <IntlMessages id='error.Enter_email_to_send_report' />
                          );
                          isValid = false;
                        } else if (
                          !isEmptyNullUndefined(email) &&
                          !email.match(
                            /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
                          )
                        ) {
                          tempError.isError = true;
                          // tempError.errorMessage =
                          //   'Incorrect email entered.';
                          tempError.errorMessage = (
                            <IntlMessages id='error.Incorrect_email_entered' />
                          );
                          isValid = false;
                        }
                        if (isEmptyNullUndefined(queryId)) {
                          setQueryIdError(true);
                          isValid = false;
                        }
                        if (isEmptyNullUndefined(cycleId)) {
                          setCycleIdError(true);
                          isValid = false;
                        }
                        if (isValid) {
                          let values = [];
                          for (
                            let i = 0;
                            i < entityFields.headersDetails.headers.length;
                            i++
                          ) {
                            var header = entityFields.headersDetails.headers[i];
                            var mappedEntity =
                              entityFields.headersDetails.headersMappedWith[i][
                                entityFields.headersDetails.headers[i].header
                              ];
                            if (!isEmptyNullUndefined(mappedEntity)) {
                              values.push({
                                // entity: header.entity,
                                dbName: mappedEntity,
                                csvName: header.header,
                                // required: header.isRequired,
                                defaultValue: header.defaultValue,
                              });
                            }
                          }

                          emailProviderHeaders(values);
                        } else {
                          setEmailError(tempError);
                        }
                      }}
                    >
                      <IntlMessages id='common.button.Proceed' />
                    </Button>
                    <Button
                      color='error'
                      name='cancel_add_new_header_entity-row_btn'
                      onClick={() => {
                        setShowEmail(false);
                      }}
                    >
                      <IntlMessages id='common.button.Cancel' />
                    </Button>
                  </DialogActions>
                  <AppInfoView />
                </Dialog>
                {/* ////////add Stack for fixed////// */}
                {/* {!isEmptyNullUndefined(resData) && ( */}
                <Stack
                  sx={{
                    bottom: 0,
                    zIndex: 10,
                    position: 'fixed',
                    backdropFilter: 'blur(5px)',
                    width: '100%',
                    right: 0,
                  }}
                >
                  <Stack
                    direction='row'
                    justifyContent='end'
                    alignItems='center'
                    spacing={2}
                    sx={{
                      pt: 5,
                      ml: 3,
                      //// add marging for fixed stack///
                      margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
                    }}
                  >
                    {(isAddRowVisible() ||
                      isEmptyNullUndefined(mappingsRow)) && (
                      <Button
                        name='addRow'
                        variant='outlined'
                        onClick={() => handleAddRow()}
                        sx={{mr: 1}}
                        disabled={isEmptyNullUndefined(reportType)}
                        // disabled={isLoading || !isDisabled}
                      >
                        <IntlMessages id='feedbackReport.addRow' />
                      </Button>
                    )}
                    {(isCreateAllVisible() ||
                      isEmptyNullUndefined(mappingsRow)) && (
                      <Button
                        name='createAllBtn'
                        variant='outlined'
                        onClick={() => handleCreateAllAlert()}
                        sx={{mr: 1}}
                        disabled={isEmptyNullUndefined(reportType)}
                      >
                        <IntlMessages id='feedbackReport.mapAll' />
                      </Button>
                    )}
                    {!isEmptyNullUndefined(mappingsRow) && (
                      <Button
                        name='addRow'
                        color='error'
                        variant='contained'
                        onClick={() => handleResetAlert()}
                        // disabled={isLoadingDel}
                        // disabled={isLoadingDel || isLoading}
                        sx={{mr: 1}}
                      >
                        <IntlMessages id='common.button.Reset' />
                      </Button>
                    )}
                    <Button
                      color='success'
                      variant='contained'
                      sx={footerButton.back.sx}
                      size={footerButton.back.size}
                      disabled={
                        isLoading || isLoadingUpload || shouldBeDisabled()
                      }
                      onClick={() => handleValidateMappings('submit')}
                    >
                      {!isEdit ? (
                        <IntlMessages id='common.button.Submit' />
                      ) : (
                        <IntlMessages id='common.button.Update' />
                      )}
                    </Button>
                    {isEdit && (
                      <Button
                        color={footerButton.back.color}
                        variant={footerButton.back.variant}
                        sx={footerButton.back.sx}
                        size={footerButton.back.size}
                        // disabled={
                        //   shouldBeDisabled() ||
                        //   isLoading ||
                        //   !isDisabled ||
                        //   isEmptyNullUndefined(selectedCompany?.primaryEmail)
                        // }
                        onClick={() => {
                          // let isValid = true;
                          // if (isEmptyNullUndefined(queryId)) {
                          //   setQueryIdError(true);
                          //   isValid = false;
                          // }
                          // if (isEmptyNullUndefined(cycleId)) {
                          //   setCycleIdError(true);
                          //   isValid = false;
                          // }
                          // if (isValid) {
                          handleValidateMappings('report');
                          // }
                        }}
                      >
                        <IntlMessages id='feedbackReport.sendSampleReport' />
                      </Button>
                    )}
                    <Button
                      color={footerButton.back.color}
                      variant={footerButton.back.variant}
                      sx={footerButton.back.sx}
                      size={footerButton.back.size}
                      onClick={() =>
                        Router.push('/company-builder/feedback-report')
                      }
                    >
                      <IntlMessages id='common.button.Back' />
                    </Button>
                  </Stack>
                </Stack>
                {/* )} */}
                {alertProps?.isHideShow && (
                  <AlertDialog
                    alertProps={alertProps}
                    handleYes={() => {
                      if (alertProps.useFor == 'Create All Mappings') {
                        handleCreateBlankMaps();
                      } else {
                        if (resData && Object.keys(resData).length) {
                          handleReset(resData);
                        } else {
                          let emptyEntityMappings = [];
                          for (let i = 0; i < entities.length; i++) {
                            let entity = entities[i];
                            emptyEntityMappings.push({
                              // entity: '',
                              dbName: entity,
                              csvName: '',
                              // required: false,
                              defaultValue: '',
                            });
                          }

                          handleMapBlankAndDeleteAllMappingRows(
                            emptyEntityMappings,
                          );
                        }
                      }
                    }}
                    handleNo={() => handleCloseResetAlert()}
                  />
                )}
              </Stack>
            </AppCard>
          )}
        </>
      </AppAnimate>
      <AppInfoView />
    </>
  );
};

export default AddFeedbackReport;
