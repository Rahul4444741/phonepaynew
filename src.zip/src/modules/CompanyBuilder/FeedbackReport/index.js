import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard} from '../../../@crema';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import {AgGridReact} from 'ag-grid-react';
import {useDispatch, useSelector} from 'react-redux';
import AppInfoView from '../../../@crema/core/AppInfoView';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import {
  fetchStart,
  showMessage,
  fetchError,
  showInfo,
} from '../../../redux/actions';
import axios from 'axios';
import AlertDialog from '../../Common/AlertDialog';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  FormControl,
  FormHelperText,
  InputLabel,
  MenuItem,
  Select,
  TextField,
} from '@mui/material';
import {
  isEmptyNullUndefined,
  buttonStyle,
  apiCatchErrorMessage,
  isAllowedUser,
} from 'shared/utils/CommonUtils';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import IntlMessages from '@crema/utility/IntlMessages';
import Router from 'next/router';
import {saveAs} from 'file-saver';
import GenericSelectWithSearch from 'modules/Common/GenericSelectWithSearch';
import {permissionName} from 'shared/utils/PermissionName';
import Error403 from 'modules/errorPages/Error403';
import {useCallback} from 'react';

const textFieldStyled = {
  backgroundColor: 'white',
  width: {xs: '100%'},
};

const CustomHeaderName = () => <IntlMessages id='aggrid.tableHeader.Name' />;
const CustomHeaderType = () => <IntlMessages id='aggrid.tableHeader.Type' />;
const CustomHeaderStatus = () => (
  <IntlMessages id='aggrid.tableHeader.Status' />
);
const CustomHeaderAction = () => (
  <IntlMessages id='aggrid.tableHeader.Action' />
);

const FeedbackReport = () => {
  const dispatch = useDispatch();
  const employeeDetails = JSON.parse(localStorage.getItem('userDetails'));
  const token = localStorage.getItem('token');
  const [feedBackReport, setFeedBackReport] = React.useState(null);
  const [overlayMessage, setOverlayMessage] = React.useState('No Rows To Show');
  const [isLoading, setIsLoading] = React.useState(true);
  const [alertProps, setAlertProps] = React.useState({
    isHideShow: false,
    message: '',
    title: '',
    alertType: '',
    actionParams: null,
  });

  const [queryList, setQueryList] = React.useState(null);
  const [annualCycle, setAnnualCycle] = React.useState(null);

  const [queryId, setQueryId] = React.useState(null);
  const [cycleId, setCycleId] = React.useState(null);
  const [reportId, setReportId] = React.useState(null);

  const [queryIdError, setQueryIdError] = React.useState(false);
  const [cycleIdError, setCycleIdError] = React.useState(false);

  const [emailSend, setEmailSend] = React.useState(false);
  const [email, setEmail] = React.useState('');
  const [emailError, setEmailError] = React.useState({
    isError: false,
    errorMessage: '',
  });
  const [showEmail, setShowEmail] = React.useState(false);
  const [isDownload, setIsDownload] = React.useState(false);
  const [downloadLoading, setDownloadLoading] = React.useState(false);
  const [reportName, setReportName] = React.useState('');

  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);

  React.useEffect(() => {
    if (isAllowedUser(permissionName.DEFINE_REPORT)) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  const statusCellRenderer = (params) => (
    <Stack direction="row">
      {params.data.status === 'ACTIVE' ? (
        <div style={{ color: '#11C15B' }}>{params.data.status}</div>
      ) : (
        <div style={{ color: '#D32F2F' }}>{params.data.status}</div>
      )}
    </Stack>
  );
  
  const actionCellRenderer = (params) => (
    <Stack direction="row">
      {(isAllowedUser(permissionName.UPDATE) || isAllowedUser(permissionName.READ)) && (
        <Button onClick={() => handleRedirectEditFeedbackReport(params)} style={buttonStyle}>
          <IntlMessages id="common.button.Edit/View" />
        </Button>
      )}
      {isAllowedUser(permissionName.SEND_REPORT) && (
        <Button
          onClick={() => {
            setShowEmail(true);
            setReportId(params.data.id);
            setIsDownload(false);
          }}
          style={buttonStyle}
        >
          <IntlMessages id="common.button.SendReport" />
        </Button>
      )}
      {isAllowedUser(permissionName.DOWNLOAD) && (
        <Button
          onClick={() => {
            setShowEmail(true);
            setReportId(params.data.id);
            setReportName(params.data.reportName);
            setIsDownload(true);
          }}
          style={buttonStyle}
        >
          <IntlMessages id="common.button.Download" />
        </Button>
      )}
      {isAllowedUser(permissionName.DEACTIVATE) && params.data.status === 'ACTIVE' && (
        <Button onClick={() => handleDeactivateConfirmation(params)} style={buttonStyle}>
          <IntlMessages id="common.button.Deactivate" />
        </Button>
      )}
      {isAllowedUser(permissionName.ACTIVATE) && params.data.status === 'INACTIVE' && (
        <Button onClick={() => handleActivateConfirmation(params)} style={buttonStyle}>
          <IntlMessages id="common.button.Activate" />
        </Button>
      )}
    </Stack>
  );
  
  const columnDefs =[
    {
      field: 'reportName',
      filter: true,
      headerName: 'Name',
      minWidth: 250,
      headerComponentFramework: CustomHeaderName,
    },
    {
      field: 'reportType',
      filter: true,
      headerName: 'Type',
      minWidth: 250,
      headerComponentFramework: CustomHeaderType,
    },
    {
      field: 'status',
      filter: true,
      headerName: 'Status',
      headerComponentFramework: CustomHeaderStatus,
      minWidth: 200,
      cellRenderer: statusCellRenderer,
    },
    {
      headerName: 'Action',
      headerComponentFramework: CustomHeaderAction,
      minWidth: 450,
      cellRenderer: actionCellRenderer,
    },
  ];

  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  React.useEffect(() => {
    dispatch(fetchStart);
    if (
      isAuthorized &&
      selectedCompany != null &&
      selectedCompany != undefined
    ) {
      getAllActiveFeedbackReport(selectedCompany.id);
      getAllActiveQuery(selectedCompany.id);
      getAllActiveAnnualCycle(selectedCompany.id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, [isAuthorized, selectedCompany]);

  const gridRef = React.useRef();
  const defaultColDef = React.useMemo(() => ({
    sortable: true,
  }));

  const getAllActiveQuery = async (companyId) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.customquery}?companyId=${companyId}&relationTable=Employee&status=ACTIVE`,
        {
          cancelToken: source.token,
        },
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no record'));
          setQueryList([]);
        } else {
          setQueryList(res.data.reverse());
        }
      } else {
        setQueryList([]);
      }
    } catch (e) {
      if (!axios.isCancel(e)) {
        apiCatchErrorMessage(e, dispatch, fetchError);
      }
      setQueryList([]);
    }
  };

  const getAllActiveAnnualCycle = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.annualCycle}/${companyId}/ACTIVE`,
        {cancelToken: source.token},
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no annual cycle for selected company'));
          setAnnualCycle([]);
        } else {
          const reversed = res.data.reverse();
          setAnnualCycle(reversed);
        }
        setIsLoading(() => false);
      } else {
        setAnnualCycle([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setAnnualCycle([]);
    }
    setIsLoading(() => false);
  };

  const getAllActiveFeedbackReport = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.getFeedbackReport}/company/${companyId}?status=ACTIVE`,
        {cancelToken: source.token},
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no report for selected company'));
          setFeedBackReport([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setFeedBackReport(reversed);
        }
        setIsLoading(() => false);
      } else {
        setFeedBackReport([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setFeedBackReport([]);
    }
    setIsLoading(() => false);
  };
  const getAllInactiveFeedbackReport = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.getFeedbackReport}/company/${companyId}?status=INACTIVE`,
        {cancelToken: source2.token},
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no report for selected company'));
          setFeedBackReport([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setFeedBackReport(reversed);
        }
        setIsLoading(() => false);
      } else {
        setFeedBackReport([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setFeedBackReport([]);
      setIsLoading(() => false);
    }
  };

  const handleRedirectAddFeedbackReport = () => {
    Router.push(`/company-builder/add-feedback-report`);
  };

  const handleRedirectEditFeedbackReport = (params) => {
    Router.push(`/company-builder/add-feedback-report?id=${params.data?.id}`);
  };

  const isValidEmail = (email) => {
    const emailRegex = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/;
    return emailRegex.test(email);
  };
  
  const validateEmailData = async () => {
    let isValid = true;
    let tempError = {...emailError};
    if (!isDownload && isEmptyNullUndefined(email)) {
      tempError.isError = true;
      tempError.errorMessage = (
        <IntlMessages id='error.Enter_email_to_send_report' />
      );
      isValid = false;
    } else if (!isEmptyNullUndefined(email) && !isValidEmail(email)) {
      tempError.isError = true;
      tempError.errorMessage = (
        <IntlMessages id='error.Incorrect_email_entered' />
      );
      isValid = false;
    }
    if (isEmptyNullUndefined(queryId)) {
      setQueryIdError(true);
      isValid = false;
    }
    if (isEmptyNullUndefined(cycleId)) {
      setCycleIdError(true);
      isValid = false;
    }
    if (isValid) {
      if (!isDownload) {
        await emailSendHandler();
      } else {
        await downloadReport();
      }
    } else {
      setEmailError(tempError);
    }
  };

  const emailSendHandler = async () => {
    setEmailSend(() => true);
    try {
      const res = await jwtAxios.post(
        `${API_ROUTS.sendFeedbackReport}?email=${email}&companyId=${selectedCompany.id}&queryId=${queryId}&cycleId=${cycleId}&reportId=${reportId}&managerId =NULL`,
        // payload,
      );
      if (res.status == 200) {
        setEmailSend(() => false);
        dispatch(showMessage(`Sample report e-mailed successfully..!`));
        setShowEmail(false);
        handleReset();
      }
    } catch (e) {
      if (e?.response?.data?.detail) {
        dispatch(fetchError(e?.response?.data?.detail));
      } else if (e?.response?.data?.title) {
        dispatch(fetchError(e?.response?.data?.title));
      }
      handleReset();
      setShowEmail(false);
      setEmailSend(() => false);
    }
  };

  const downloadReport = async () => {
    setDownloadLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.downloadFeedbackReport}?email=${employeeDetails.emailId}&companyId=${selectedCompany.id}&queryId=${queryId}&cycleId=${cycleId}&reportId=${reportId}&managerId=${employeeDetails.id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          responseType: 'arraybuffer',
        },
      );
      if (res.status == 200) {
        setEmailSend(() => false);
        const blob = new Blob([res?.data], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });

        saveAs(blob, `${reportName}.xlsx`);
        dispatch(showMessage(`Report downloaded successfully..!`));
        setShowEmail(false);
        handleReset();
        setIsDownload(() => false);
        setDownloadLoading(() => false);
      }
    } catch (e) {
      if (e?.response?.data?.detail) {
        dispatch(fetchError(e?.response?.data?.detail));
      } else if (e?.response?.data?.title) {
        dispatch(fetchError(e?.response?.data?.title));
      }
      setShowEmail(false);
      handleReset();
      setDownloadLoading(() => false);
    }
  };

  const handleReset = () => {
    setEmail(null);
    setCycleId(null);
    setQueryId(null);
  };

  const handleDeactivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = (
      <IntlMessages id='warning.deactivateFeedbackReport' />
    );

    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureDeactivate' /> {params.data.name} ?
      </span>
    );

    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleAlertYes = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.actionParams.data.status == 'ACTIVE' &&
      handleDeactivateFeedbackReport(tempAlertProps.actionParams);
    tempAlertProps.actionParams.data.status == 'INACTIVE' &&
      handleActivateFeedbackReport(tempAlertProps.actionParams);
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };

  const handleAlertNo = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };
  const handleDeactivateFeedbackReport = async (params) => {
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));

      let payload = {
        id: params.data.id,
        status: 'INACTIVE',
      };
      const response = await jwtAxios.put(
        `${API_ROUTS.feedbackReport}/update/status`,
        payload,
      );
      if (response.status == 200) {
        dispatch(showMessage('Report deactivate successfully..!'));

        const roleIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );

        if (roleIndex != -1) {
          rowData[roleIndex].status = 'INACTIVE';
        }
        getAllInactiveFeedbackReport(selectedCompany.id);
        setAlignment('INACTIVE');
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleActivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = <IntlMessages id='warning.activateFeedbackReport' />;
    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureActivate' /> {params.data.name} ?
      </span>
    );
    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleActivateFeedbackReport = async (params) => {
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));
      let payload = {
        id: params.data.id,
        status: 'ACTIVE',
      };
      const response = await jwtAxios.put(
        `${API_ROUTS.feedbackReport}/update/status`,
        payload,
      );
      if (response.status == 200) {
        dispatch(showMessage('Report activate successfully..!'));
        const roleIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );
        if (roleIndex != -1) {
          rowData[roleIndex].status = 'ACTIVE';
        }
        getAllActiveFeedbackReport(selectedCompany.id);
        setAlignment('ACTIVE');
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const [alignment, setAlignment] = React.useState('ACTIVE');

  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
  };

  const onFilterTextBoxChanged = useCallback(() => {
    const filterText = document.getElementById('filter-text-box').value;
    gridRef.current.api.setGridOption('quickFilterText', filterText);
    const totalResults = gridRef.current.api.getDisplayedRowCount();
    if (!isEmptyNullUndefined(feedBackReport) && feedBackReport.length > 0) {
      if (totalResults === 0 && !isEmptyNullUndefined(filterText)) {
        setOverlayMessage('No Record Found');
        gridRef.current.api.showNoRowsOverlay();
      } else if (totalResults !== 0) {
        setOverlayMessage('No Rows To Show');
        gridRef.current.api.hideOverlay();
      }
    }
  }, []);

  const handleChangeQuery = (event, fieldType) => {
    setQueryId(event.target.value);
    setQueryIdError(false);
  };

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (!isAuthorized) {
    return <Error403 />;
  }

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        <IntlMessages id='feedbackReport.pageHeaderName' />
      </h2>
      <AppCard>
        <Stack style={{width: '100%'}}>
          <Stack direction='row' sx={{mb: 2}} justifyContent={'end'}>
            <TextField
              //size='small'
              sx={{width: 200, mr: 2}}
              id='filter-text-box'
              onInput={onFilterTextBoxChanged}
              type={'search'}
              name='search'
              label={<IntlMessages id='common.button.Search' />}
              variant='outlined'
            />
            {isAllowedUser(permissionName.CREATE) && (
              <Button
                sx={{mr: 2}}
                variant='outlined'
                onClick={() => handleRedirectAddFeedbackReport()}
              >
                <IntlMessages id='feedbackReport.addFeedbackReport' />
              </Button>
            )}
            <ToggleButtonGroup
              color='primary'
              value={alignment}
              exclusive
              onChange={handleChange}
            >
              <ToggleButton
                value='ACTIVE'
                onClick={() => getAllActiveFeedbackReport(selectedCompany.id)}
              >
                <IntlMessages id='common.button.Active' />
              </ToggleButton>
              <ToggleButton
                value='INACTIVE'
                onClick={() => getAllInactiveFeedbackReport(selectedCompany.id)}
              >
                <IntlMessages id='common.button.Inactive' />
              </ToggleButton>
            </ToggleButtonGroup>
          </Stack>
          {isLoading ? (
            domCreactionGridSkeletonLoader()
          ) : (
            <Stack
              className='ag-theme-alpine'
              style={{height: 525, width: '100%'}}
            >
              <AgGridReact
                ref={gridRef}
                rowData={feedBackReport}
                columnDefs={columnDefs}
                defaultColDef={defaultColDef}
                animateRows={true}
                pagination={true}
                paginationPageSize={10}
                overlayLoadingTemplate={
                  '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'
                }
                overlayNoRowsTemplate={`<span class="ag-overlay-loading-center">${overlayMessage}</span>`}
              />
            </Stack>
          )}
        </Stack>

        {alertProps.isHideShow && (
          <AlertDialog
            alertProps={alertProps}
            handleYes={() => handleAlertYes()}
            handleNo={() => handleAlertNo()}
          />
        )}
      </AppCard>
      <Dialog maxWidth={'sm'} open={showEmail}>
        <DialogContent>
          <Stack direction='row' justifyContent='center' sx={{mt: '7%'}}>
            <AppCard style={{width: '350px'}}>
              <Stack>
                <TextField
                  name='email'
                  label={<IntlMessages id='feedbackReport.sendEmailTo' />}
                  variant='outlined'
                  sx={{
                    backgroundColor: 'white',
                    mb: 2,
                    borderRadius: 2,
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  }}
                  value={isDownload ? employeeDetails.emailId : email || ''}
                  onChange={(event) => {
                    setEmail(() => event.target.value);

                    let tempError = {...emailError};
                    tempError.isError = false;
                    tempError.errorMessage = '';
                    setEmailError(() => tempError);
                  }}
                  error={emailError.isError}
                  disabled={isDownload}
                />
                {emailError.isError && (
                  <FormHelperText className='Mui-error'>
                    {emailError.errorMessage}
                  </FormHelperText>
                )}
              </Stack>

              <Stack>
                <Stack sx={{mt: 10}}>
                  <GenericSelectWithSearch
                    label={<IntlMessages id='feedbackReport.selectQuery' />}
                    name={'queryId'}
                    value={queryId || ''}
                    error={queryIdError}
                    helperText={
                      queryIdError ? (
                        <IntlMessages id='error.Please_select_query' />
                      ) : null
                    }
                    handleChange={handleChangeQuery}
                    optionList={queryList}
                    labelName={'variableName'}
                    customStyles={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'red',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
                <Stack sx={{mt: 10}}>
                  <FormControl
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'red',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  >
                    <InputLabel
                      sx={{
                        backgroundColor: '#ffffff',
                        padding: '0px 0.5rem',
                      }}
                      size='small'
                      id='Type-'
                    >
                      <IntlMessages id='feedbackReport.selectCycle' />
                    </InputLabel>
                    <Select
                      value={cycleId || ''}
                      id={'cycleId'}
                      name='cycleId'
                      error={cycleIdError}
                      onChange={(event) => {
                        setCycleId(event.target.value);
                        setCycleIdError(false);
                      }}
                      variant='outlined'
                      size='small'
                    >
                      {annualCycle?.map((t, i) => {
                          return (
                            <MenuItem
                              value={t.id}
                              id={t.id}
                              name={t.cycleName}
                              size='small'
                              key={t.id}
                            >
                              {t.cycleName}
                            </MenuItem>
                          );
                        })}
                    </Select>
                    {cycleIdError && (
                      <FormHelperText className='Mui-error'>
                        <IntlMessages id='error.Please_select_cycle' />
                      </FormHelperText>
                    )}
                  </FormControl>
                </Stack>
              </Stack>
            </AppCard>
          </Stack>
        </DialogContent>
        <DialogActions>
          {isDownload &&
            (downloadLoading ? (
              <CircularProgress
                color='success'
                size={25}
                sx={{marginRight: '20px', marginBottom: '10px'}}
              />
            ) : (
              <>
                <Button
                  color='success'
                  name='emailProviderReport_btn'
                  disabled={emailSend}
                  onClick={() => validateEmailData()}
                >
                  <IntlMessages id='common.button.Proceed' />
                </Button>
                <Button
                  color='error'
                  name='cancel_add_new_header_entity-row_btn'
                  onClick={() => {
                    setShowEmail(false);
                  }}
                >
                  <IntlMessages id='common.button.Cancel' />
                </Button>
              </>
            ))}

          {!isDownload && (
            <>
              <Button
                color='success'
                name='emailProviderReport_btn'
                disabled={emailSend}
                onClick={() => validateEmailData()}
              >
                <IntlMessages id='common.button.Proceed' />
              </Button>
              <Button
                color='error'
                name='cancel_add_new_header_entity-row_btn'
                onClick={() => {
                  setShowEmail(false);
                }}
              >
                <IntlMessages id='common.button.Cancel' />
              </Button>
            </>
          )}
        </DialogActions>
        <AppInfoView />
      </Dialog>
      <AppInfoView />
    </AppAnimate>
  );
};

export default FeedbackReport;
