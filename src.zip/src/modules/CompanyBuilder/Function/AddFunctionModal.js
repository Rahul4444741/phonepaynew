import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import Stack from '@mui/material/Stack';
import { AppCard } from '../../../@crema';
import { showMessage, fetchError } from '../../../redux/actions';
import TextField from '@mui/material/TextField';
import PropTypes from 'prop-types';
import AppInfoView from '../../../@crema/core/AppInfoView';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import { useDispatch } from 'react-redux';
import jwtAxios from '@crema/services/auth/jwt-auth';
import { API_ROUTS } from 'shared/constants/ApiRouts';
import {
  apiCatchErrorMessage,
  isDuplicate,
  isStrExceeds,
} from 'shared/utils/CommonUtils';
import IntlMessages from '@crema/utility/IntlMessages';
const AddFunctionModal = ({
  company,
  handleAddFunction,
  handleUpdateFunction,
  handleClose,
  isEdit,
  editFunction,
  functionData,
}) => {
  const dispatch = useDispatch();
  const [functions, setFunctions] = React.useState({
    id: null,
    name: '',
    status: '',
    company: {
      id: company.id,
    },
  });
  React.useEffect(() => {
    if (isEdit) {
      setFunctions(editFunction);
    }
  }, []);
  const [formError, setFormError] = React.useState({
    name: {isError: false, errorMessage: ''},
    status: {isError: false, errorMessage: ''},
  });
  const textFieldStyled = {
    backgroundColor: 'white',
    mb: 4,
    width: {xs: '100%'},
  };

  const handleValidateFunction = async () => {
    let isValid = true;
    const tempError = {...formError};
    const tempFunction = {...functions};
    if (tempFunction.name.trim() == '') {
      tempError.name.isError = true;
      tempError.name.errorMessage = <IntlMessages id='error.pleaseEnterName' />;
      isValid = false;
    }
    if (isStrExceeds(tempFunction.name.toString(), 50)) {
      tempError.name.isError = true;
      tempError.name.errorMessage = 'should not exceed 50 characters';
      isValid = false;
    }
    if (
      !isEdit
        ? isDuplicate(tempFunction.name, functionData)
        : isDuplicate(tempFunction.name, functionData, tempFunction.id)
    ) {
      tempError.name.isError = true;
      tempError.name.errorMessage = (
        <IntlMessages id='error.duplicateEntryFound' />
      );
      isValid = false;
    }

    if (tempFunction.status.trim() == '') {
      tempError.status.isError = true;
      tempError.status.errorMessage = (
        <IntlMessages id='error.pleaseSelectStatus' />
      );
      isValid = false;
    }
    if (isValid) {
      if (isEdit) {
        updateFunction();
      } else {
        submitFunction();
      }
    } else {
      setFormError(tempError);
    }
  };

  const submitFunction = async () => {
    let tempFunction={...functions , name:functions.name.trim()}
    try {
      const response = await jwtAxios.post(`${API_ROUTS.create_function}`, tempFunction);
      if (response.status == 201) {
        dispatch(
          showMessage(response.data.name + ' Function added successfully..!'),
        );
        handleAddFunction(response.data);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const updateFunction = async () => {
    let tempFunction={...functions , name:functions.name.trim()}
    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.create_function}/${functions.id}`,
        tempFunction,
      );
      if (response.status == 200) {
        dispatch(
          showMessage(response.data.name + ' Function updated successfully..!'),
        );
        handleUpdateFunction(response.data);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleChangeFunctionData = (event) => {
    const tempFunction = {...functions};
    const tempError = {...formError};
    tempFunction[event.target.name] = event.target.value;
    tempError[event.target.name].isError = false;
    tempError[event.target.name].errorMessage = '';
    setFunctions(tempFunction);
    setFormError(tempError);
  };

  return (
    <Dialog maxWidth={'sm'} open={true}>
      <DialogContent>
        <Stack direction='row' justifyContent='center' sx={{mt: '7%'}}>
          <AppCard style={{width: '350px'}}>
            <h4 style={{display: 'flex'}}>
              {!isEdit ? (
                // <IntlMessages id='roles.addGradesLevel' />
                'Add Function'
              ) : (
                // <IntlMessages id='roles.updateGradesLevel' />
                'Update Function'
              )}
            </h4>
            <Stack
              sx={{mt: 2}}
              display='flex'
              justifyContent='center'
              spacing={2}
            >
              <TextField
                size='small'
                name='name'
                label={<IntlMessages id='configuration.dialogbox.Name' />}
                onChange={(event) => handleChangeFunctionData(event)}
                value={functions?.name}
                error={formError.name.isError}
                helperText={formError.name.errorMessage}
                variant='outlined'
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              />
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id='event-type'>
                  <IntlMessages id='configuration.dialogbox.Status' />
                </InputLabel>
                <Select
                  size='small'
                  name='status'
                  label='Status'
                  value={functions?.status}
                  error={formError.status.isError}
                  helperText={formError.status.errorMessage}
                  onChange={(event) => handleChangeFunctionData(event)}
                  variant='outlined'
                  sx={{...textFieldStyled}}
                >
                  <MenuItem key='Active' value='ACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Active' />
                  </MenuItem>
                  <MenuItem key='Inactive' value='INACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                  </MenuItem>
                </Select>
                <FormHelperText style={{color: '#d32f2f'}}>
                  {formError.status.errorMessage}
                </FormHelperText>
              </FormControl>
            </Stack>
          </AppCard>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={() => handleValidateFunction()}>
          <IntlMessages id='common.button.Submit' />
        </Button>
        <Button onClick={() => handleClose()}>
          <IntlMessages id='common.button.Close' />
        </Button>
      </DialogActions>
      <AppInfoView />
    </Dialog>
  );
};

export default AddFunctionModal;
AddFunctionModal.propTypes = {
  company: PropTypes.object,
  handleAddFunction: PropTypes.func,
  handleUpdateFunction: PropTypes.func,
  handleClose: PropTypes.func,
  isEdit: PropTypes.bool,
  editFunction: PropTypes.object,
  functionData: PropTypes.array,
};
