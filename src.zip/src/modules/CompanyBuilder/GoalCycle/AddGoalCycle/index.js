import React from 'react';
import {useDispatch, useSelector} from 'react-redux';
import AppAnimate from '../../../../@crema/core/AppAnimate';
import AppPageMeta from '../../../../@crema/core/AppPageMeta';
import {AppCard, AppInfoView} from '../../../../@crema';
import Stack from '@mui/material/Stack';
import {DesktopDatePicker, LocalizationProvider} from '@mui/x-date-pickers';
import {AdapterDateFns} from '@mui/x-date-pickers/AdapterDateFns';
import TextField from '@mui/material/TextField';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import {
  getCompanyDateFormatForInputs,
  isEmptyNullUndefined,
  apiCatchErrorMessage,
} from '../../../../shared/utils/CommonUtils';
import Button from '@mui/material/Button';
import Router, {useRouter} from 'next/router';
import {showMessage, fetchError, showInfo} from '../../../../redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import FormHelperText from '@mui/material/FormHelperText';
import {footerButton} from 'shared/constants/AppConst';
import IntlMessages from '@crema/utility/IntlMessages';
import {
  Autocomplete,
  Checkbox,
  CircularProgress,
  FormControlLabel,
  Radio,
  RadioGroup,
} from '@mui/material';
import axios from 'axios';
import {domCreactionHeaderTitle} from 'shared/utils/domCreaction';
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import CheckBoxIcon from '@mui/icons-material/CheckBox';

const icon = <CheckBoxOutlineBlankIcon fontSize='small' />;
const checkedIcon = <CheckBoxIcon fontSize='small' />;

const textFieldStyled = {
  backgroundColor: 'white',
  mb: 2,
  width: {xs: '100%', xl: '60%', md: '75%'},
};

const AddGoalCycle = () => {
  const router = useRouter();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const {id, view} = router.query;
  const dispatch = useDispatch();

  const initialCalibrationCycle = {
    name: null,
    status: null,
    startDate: null,
    endDate: null,
    goalFormId: null,
    goalCycleCustomQuery: null,
    isWorkflow: false,
    workflowId: null,
    isEditEmployeeGoal: false,
    isEmployeeAcknowledgement: false,
    stakeHolderEdit: false,
    isGoalLockedDown: false,
  };

  const initialgoalCycleError = {
    name: {isError: false, errorMessage: ''},
    status: {isError: false, errorMessage: ''},
    startDate: {isError: false, errorMessage: ''},
    endDate: {isError: false, errorMessage: ''},
    goalFormId: {isError: false, errorMessage: ''},
    goalCycleCustomQuery: {isError: false, errorMessage: ''},
    isWorkflow: {isError: false, errorMessage: ''},
    workflowId: {isError: false, errorMessage: ''},
    isEditEmployeeGoal: {isError: false, errorMessage: ''},
    isEmployeeAcknowledgement: {isError: false, errorMessage: ''},
    stakeHolderEdit: {isError: false, errorMessage: ''},
    isGoalLockedDown: {isError: false, errorMessage: ''},
  };

  const [goalCycle, setGoalCycle] = React.useState(initialCalibrationCycle);
  const [goalCycleError, setGoalCycleError] = React.useState(
    initialgoalCycleError,
  );
  const [loading, setLoading] = React.useState(false);
  const [isEdit, setIsEdit] = React.useState(false);
  const [isView, setIsView] = React.useState(false);

  const [goalForms, setGoalForms] = React.useState([]);
  const [queryList, setQueryList] = React.useState([]);
  const [workflowList, setWorkflowList] = React.useState(null);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  React.useEffect(() => {
    if (!isEmptyNullUndefined(selectedCompany.id)) {
      getAllActiveGoalForms(selectedCompany.id);
      getAllActiveQuery(selectedCompany.id);
      getAllActiveWorkflows(selectedCompany.id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
    };
  }, []);

  React.useEffect(() => {
    if (!isEmptyNullUndefined(id)) {
      getGoalCycleDetails(id);
      if (view == 'true' || view == true) {
        setIsView(true);
      } else {
        setIsEdit(true);
      }
    }

    return () => {
      source2.cancel('Aborting all previous operations.');
    };
  }, []);

  const getGoalCycleDetails = async (id) => {
    try {
      const response = await jwtAxios.get(`${API_ROUTS.goalCycle}/${id}`, {
        cancelToken: source2.token,
      });
      if (response.status == 200) {
        setGoalCycle(response.data);
      }
    } catch (e) {
      dispatch(fetchError(e.response?.data?.detail));
    }
  };

  const getAllActiveGoalForms = async (companyId) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.goalForm_company}/${companyId}/ACTIVE`,
        {cancelToken: source.token},
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have not ratings for selected company'));
          setGoalForms([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setGoalForms(reversed);
        }
      } else {
        setGoalForms([]);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setGoalForms([]);
    }
  };

  const getAllActiveWorkflows = async (companyId) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.get_all_workflow}/${companyId}/ACTIVE`,
        {cancelToken: source.token},
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no workflow for selected company'));
          setWorkflowList([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setWorkflowList(reversed);
        }
      } else {
        setWorkflowList([]);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setWorkflowList([]);
    }
  };

  const getAllActiveQuery = async (companyId) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.customquery}?companyId=${companyId}&relationTable=Employee&status=ACTIVE`,
        {
          cancelToken: source.token,
        },
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no record'));
          setQueryList([]);
        } else {
          setQueryList(res.data.reverse());
        }
      } else {
        setQueryList([]);
      }
    } catch (e) {
      if (!axios.isCancel(e)) {
        apiCatchErrorMessage(e, dispatch, fetchError);
      }
      setQueryList([]);
    }
  };

  const handleChangeGoalCycleData = (event, fieldType, name) => {
    const tempGoalCycle = {...goalCycle};

    const tempError = {...goalCycleError};

    if (fieldType == 'textfield' || fieldType == 'dropdown') {
      tempGoalCycle[event.target.name] = event.target.value;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
    } else if (fieldType == 'date') {
      tempGoalCycle[name] = event;
      tempError[name].isError = false;
      tempError[name].errorMessage = '';
    } else if (fieldType == 'radio') {
      tempGoalCycle[event.target.name] = event.target.value;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
      if (
        event.target.name == 'isWorkflow' &&
        (event.target.value == false || event.target.value == 'false')
      ) {
        tempGoalCycle.workflowId = null;
        tempError.workflowId.isError = false;
        tempError.workflowId.errorMessage = '';
      }
      if (
        event.target.name == 'isEditEmployeeGoal' &&
        (event.target.value == false || event.target.value == 'false')
      ) {
        tempGoalCycle.isEmployeeAcknowledgement = false;
        tempError.isEmployeeAcknowledgement.isError = false;
        tempError.isEmployeeAcknowledgement.errorMessage = '';
      }
    } else if (fieldType == 'multiselect') {
      const selectedIds = event.map((option) => ({
        customQueryId: option.id,
      }));
      tempGoalCycle[name] = selectedIds;
      tempError[name].isError = false;
      tempError[name].errorMessage = '';
    }

    setGoalCycle(tempGoalCycle);
    setGoalCycleError(tempError);
  };

  const validateCalibrationCycleData = () => {
    const tempError = {...goalCycleError};
    let isValid = true;

    if (isEmptyNullUndefined(goalCycle.name)) {
      tempError.name.isError = true;
      tempError.name.errorMessage = (
        <IntlMessages id='error.PleaseEnterCalibrationCycleName' />
      );
      isValid = false;
    }

    if (isEmptyNullUndefined(goalCycle.status)) {
      tempError.status.isError = true;
      tempError.status.errorMessage = (
        <IntlMessages id='error.PleaseSelectStatus' />
      );
      isValid = false;
    }

    if (isEmptyNullUndefined(goalCycle.startDate)) {
      tempError.startDate.isError = true;
      tempError.startDate.errorMessage = (
        <IntlMessages id='error.Please_enter_start_date' />
      );
      isValid = false;
    }

    if (isEmptyNullUndefined(goalCycle.endDate)) {
      tempError.endDate.isError = true;
      tempError.endDate.errorMessage = (
        <IntlMessages id='error.Please_enter_end_date' />
      );
      isValid = false;
    }
    if (!dateValidation(goalCycle.startDate, goalCycle.endDate)) {
      tempError.endDate.isError = true;
      tempError.endDate.errorMessage = (
        <IntlMessages id='error.greater_end_date' />
      );
      isValid = false;
    }

    if (isEmptyNullUndefined(goalCycle.goalFormId)) {
      tempError.goalFormId.isError = true;
      tempError.goalFormId.errorMessage = 'Please select goal form';
      isValid = false;
    }

    if (isEmptyNullUndefined(goalCycle.goalCycleCustomQuery)) {
      tempError.goalCycleCustomQuery.isError = true;
      tempError.goalCycleCustomQuery.errorMessage =
        'Please select goal custom queries';
      isValid = false;
    }
    if (
      (goalCycle.isWorkflow == true || goalCycle.isWorkflow == 'true') &&
      isEmptyNullUndefined(goalCycle.workflowId)
    ) {
      tempError.workflowId.isError = true;
      tempError.workflowId.errorMessage = (
        <IntlMessages id='error.PleaseSelectWorkflow' />
      );
      isValid = false;
    }

    if (isValid) {
      if (!isEdit) {
        SubmitGoalCycle();
      } else {
        UpdateGoalCycle();
      }
    } else {
      setGoalCycleError(tempError);
    }
  };

  const dateValidation = (startDate, endDate) => {
    let isValid = true;
    if (new Date(startDate) > new Date(endDate)) {
      isValid = false;
    }

    return isValid;
  };

  const SubmitGoalCycle = async () => {
    let tempGoalCycle = {
      ...goalCycle,
      company: {id: selectedCompany?.id},
    };
    const submit = async () => {
      setLoading(true);
      try {
        const response = await jwtAxios.post(
          `${API_ROUTS.goalCycle}/save`,
          tempGoalCycle,
        );
        if (response.status == 200) {
          dispatch(showMessage('Goal Cycle added successfully..!'));
          Router.push('/company-builder/goal-cycle');
        } else {
          setLoading(false);
        }
      } catch (error) {
        apiCatchErrorMessage(error, dispatch, fetchError);
        setLoading(false);
      }
    };
    await submit();
  };

  const UpdateGoalCycle = async () => {
    let tempGoalCycle = {
      ...goalCycle,
      company: {id: selectedCompany?.id},
      id: id,
    };
    const update = async () => {
      setLoading(true);
      try {
        const response = await jwtAxios.post(
          `${API_ROUTS.goalCycle}/save`,
          tempGoalCycle,
        );
        if (response.status == 200) {
          dispatch(showMessage('Goal Cycle updated successfully..!'));
          Router.push('/company-builder/goal-cycle');
        } else {
          setLoading(false);
        }
      } catch (error) {
        apiCatchErrorMessage(error, dispatch, fetchError);
        setLoading(false);
      }
    };
    await update();
  };

  const getHeadingText = () => {
    if (isView) return 'View Goal Cycle';
    if (!isEdit) return <IntlMessages id='goalCycle.AddGoalCycle' />;
    return <IntlMessages id='goalCycle.EditGoalCycle' />;
  };

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>{getHeadingText()}</h2>

      <AppCard>
        <Stack sx={{mb: 10}}>
          {/* <h3 style={{marginTop: '5px', marginLeft: '10px'}}>
            <IntlMessages id='calibration.BasicInfo' />:
          </h3> */}
          <Stack>
            {domCreactionHeaderTitle(
              <IntlMessages id='calibration.BasicInfo' />,
            )}
          </Stack>
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>Name :</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <TextField
                size='small'
                name='name'
                disabled={isView}
                label={<IntlMessages id='calibration.Name' />}
                onChange={(event) =>
                  handleChangeGoalCycleData(event, 'textfield')
                }
                variant='outlined'
                error={goalCycleError.name.isError}
                helperText={goalCycleError.name.errorMessage}
                value={goalCycle.name ? goalCycle.name : ''}
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              />
            </Stack>
          </Stack>

          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>Status :</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id='status'>
                  <IntlMessages id='configuration.dialogbox.Status' />
                </InputLabel>
                <Select
                  size='small'
                  name='status'
                  disabled={isView}
                  label={<IntlMessages id='configuration.dialogbox.Status' />}
                  labelId='status'
                  value={goalCycle?.status || ''}
                  error={goalCycleError.status?.isError}
                  helperText={goalCycleError.status?.errorMessage}
                  onChange={(event) =>
                    handleChangeGoalCycleData(event, 'dropdown')
                  }
                  variant='outlined'
                  sx={{...textFieldStyled, width: '100%'}}
                >
                  <MenuItem key='Active' value='ACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Active' />
                  </MenuItem>
                  <MenuItem key='Inactive' value='INACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                  </MenuItem>
                </Select>
                <FormHelperText style={{color: '#d32f2f'}}>
                  {goalCycleError.status.errorMessage}
                </FormHelperText>
              </FormControl>
            </Stack>
          </Stack>

          {/* -------------Goal Cycle Period------------------------------------------------------------------------- */}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>Goal Cycle Period :</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <Stack direction={'column'} sx={{width: '42%'}}>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DesktopDatePicker
                    //minDate={new Date()}
                    inputFormat={getCompanyDateFormatForInputs(selectedCompany)}
                    value={goalCycle.startDate}
                    label={
                      <IntlMessages id='calibration.Calibration_Start_Dates' />
                    }
                    name='startDate'
                    disabled={isView}
                    onChange={(event) =>
                      handleChangeGoalCycleData(event, 'date', 'startDate')
                    }
                    renderInput={(params) => (
                      <TextField
                        id='startdate-textField'
                        variant='outlined'
                        size='small'
                        sx={{
                          ...textFieldStyled,
                          '& .MuiOutlinedInput-root': {
                            '& fieldset': {
                              borderLeftColor: 'red',
                              borderLeftWidth: 3,
                            },
                          },
                        }}
                        {...params}
                      />
                    )}
                  />
                </LocalizationProvider>
                {goalCycleError.startDate?.isError && (
                  <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                    {goalCycleError.startDate?.errorMessage}
                  </FormHelperText>
                )}
              </Stack>
              <Stack direction={'column'} sx={{width: '42%'}}>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DesktopDatePicker
                    //minDate={new Date()}
                    inputFormat={getCompanyDateFormatForInputs(selectedCompany)}
                    value={goalCycle.endDate}
                    label={
                      <IntlMessages id='calibration.Calibration_End_Dates' />
                    }
                    name='endDate'
                    onChange={(event) =>
                      handleChangeGoalCycleData(event, 'date', 'endDate')
                    }
                    disabled={isView}
                    renderInput={(params) => (
                      <TextField
                        id='endDate-textField'
                        variant='outlined'
                        size='small'
                        sx={{
                          ...textFieldStyled,
                          '& .MuiOutlinedInput-root': {
                            '& fieldset': {
                              borderLeftColor: 'red',
                              borderLeftWidth: 3,
                            },
                          },
                        }}
                        {...params}
                      />
                    )}
                  />
                </LocalizationProvider>
                {goalCycleError.endDate?.isError && (
                  <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                    {goalCycleError.endDate?.errorMessage}
                  </FormHelperText>
                )}
              </Stack>
            </Stack>
          </Stack>

          <Stack sx={{mt: 3, mb: 3}}>
            {domCreactionHeaderTitle('Other Info')}
          </Stack>

          {/* -------------Select goal form------------------------------------------------------------------------- */}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>Select Goal Form :</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id={'goalFormId'}>
                  Goal Form
                </InputLabel>
                <Select
                  value={goalCycle.goalFormId || ''}
                  labelId='goalFormId'
                  name='goalFormId'
                  variant='outlined'
                  label={'Goal Form'}
                  size='small'
                  disabled={isView}
                  onChange={(event) =>
                    handleChangeGoalCycleData(event, 'dropdown')
                  }
                  sx={{
                    ...textFieldStyled,
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                    },
                    width: '460px',
                  }}
                >
                  {goalForms?.map((form, index) => (
                    <MenuItem
                      id={`employeeSubFunction-MenuItem-${index}`}
                      key={form.id}
                      value={form.id}
                    >
                      {form.name}
                    </MenuItem>
                  ))}
                </Select>
                {goalCycleError.goalFormId.isError && (
                  <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                    {goalCycleError.goalFormId.errorMessage}
                  </FormHelperText>
                )}
              </FormControl>
            </Stack>
          </Stack>

          {/* -------------Select custom query------------------------------------------------------------------------- */}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>Select query :</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: isView ? 'gray' : 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <Autocomplete
                  multiple
                  id='checkboxes-tags-demo'
                  limitTags={2}
                  size='small'
                  value={
                    goalCycle.goalCycleCustomQuery?.map((item) =>
                      queryList.find(
                        (option) => option.id === item.customQueryId,
                      ),
                    ) || []
                  }
                  onChange={(event, newValue) =>
                    handleChangeGoalCycleData(
                      newValue,
                      'multiselect',
                      'goalCycleCustomQuery',
                    )
                  }
                  options={queryList}
                  disableCloseOnSelect
                  getOptionLabel={(option) => option?.variableName}
                  renderOption={(props, option, {selected}) => {
                    const {key, ...optionProps} = props;
                    return (
                      <li key={key} {...optionProps}>
                        <Checkbox
                          icon={icon}
                          checkedIcon={checkedIcon}
                          style={{marginRight: 8}}
                          checked={selected}
                        />
                        {option.variableName}
                      </li>
                    );
                  }}
                  style={{width: '450px'}}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label='Queries'
                      placeholder='Select queries'
                    />
                  )}
                />
                {goalCycleError.goalCycleCustomQuery.isError && (
                  <FormHelperText sx={{color: '#d32f2f', mt: 2}}>
                    {goalCycleError.goalCycleCustomQuery.errorMessage}
                  </FormHelperText>
                )}
              </FormControl>
            </Stack>
          </Stack>

          {/* -------------isWorkflow------------------------------------------------------------------------- */}
          <Stack>
            <Stack
              id='addEnrollmentStack'
              direction='row'
              sx={{mt: 5, ml: 3}}
              justifyContent='space-between'
              alignItems='flex-start'
              spacing={2}
            >
              <Stack sx={{width: '40%'}}>
                <Stack fontWeight={500}>Is Workflow required ?</Stack>
              </Stack>

              <Stack direction={'row'} sx={{width: '60%'}}>
                <RadioGroup
                  value={goalCycle.isWorkflow}
                  row
                  aria-labelledby='demo-row-radio-buttons-group-label'
                  name='isWorkflow'
                  onChange={(event) =>
                    handleChangeGoalCycleData(event, 'radio')
                  }
                >
                  <FormControlLabel
                    value={true}
                    disabled={isView}
                    control={<Radio />}
                    label={<IntlMessages id='common.button.Yes' />}
                  />
                  <FormControlLabel
                    value={false}
                    disabled={isView}
                    control={<Radio />}
                    label={<IntlMessages id='common.button.No' />}
                  />
                </RadioGroup>
              </Stack>
            </Stack>

            {(goalCycle.isWorkflow == 'true' ||
              goalCycle.isWorkflow == true) && (
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%'}}>
                  <Stack fontWeight={500}>Select Workflow : </Stack>
                </Stack>
                <Stack direction={'row'} sx={{width: '60%'}}>
                  <FormControl
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'red',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  >
                    <InputLabel size='small' id='workflowId '>
                      Select Workflow
                    </InputLabel>
                    <Select
                      size='small'
                      name='workflowId'
                      label='Select Workflow'
                      labelId='workflowId '
                      disabled={isView}
                      value={goalCycle?.workflowId || ''}
                      error={goalCycleError.workflowId?.isError}
                      helperText={goalCycleError.workflowId?.errorMessage}
                      onChange={(event) =>
                        handleChangeGoalCycleData(event, 'dropdown')
                      }
                      variant='outlined'
                      sx={{...textFieldStyled, width: '100%'}}
                    >
                      {workflowList?.map((work, index) => (
                        <MenuItem key={work.id} value={work.id}>
                          {work.name}
                        </MenuItem>
                      ))}
                    </Select>
                    {goalCycleError.workflowId?.isError && (
                      <FormHelperText style={{color: '#d32f2f'}}>
                        {goalCycleError.workflowId.errorMessage}
                      </FormHelperText>
                    )}
                  </FormControl>
                </Stack>
              </Stack>
            )}
          </Stack>
          {/* ------------------isEditEmployeeGoal----------------------------------------------------- */}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>
                Does Organization allow managers to Edit Employee Goals ?
              </Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <RadioGroup
                value={goalCycle.isEditEmployeeGoal}
                row
                aria-labelledby='demo-row-radio-buttons-group-label'
                name='isEditEmployeeGoal'
                onChange={(event) => handleChangeGoalCycleData(event, 'radio')}
              >
                <FormControlLabel
                  value={true}
                  disabled={isView}
                  control={<Radio />}
                  label={<IntlMessages id='common.button.Yes' />}
                />
                <FormControlLabel
                  value={false}
                  disabled={isView}
                  control={<Radio />}
                  label={<IntlMessages id='common.button.No' />}
                />
              </RadioGroup>
            </Stack>
          </Stack>
          {/* -------------------isEmployeeAcknowledgement---------------------------------------------------- */}
          {(goalCycle.isEditEmployeeGoal == 'true' ||
            goalCycle.isEditEmployeeGoal == true) && (
            <Stack
              id='addEnrollmentStack'
              direction='row'
              sx={{mt: 5, ml: 3}}
              justifyContent='space-between'
              alignItems='flex-start'
              spacing={2}
            >
              <Stack sx={{width: '40%'}}>
                <Stack fontWeight={500}>
                  Are employee acknowledgments needed (in case Manager edits) ?
                </Stack>
              </Stack>

              <Stack direction={'row'} sx={{width: '60%'}}>
                <RadioGroup
                  value={goalCycle.isEmployeeAcknowledgement}
                  row
                  aria-labelledby='demo-row-radio-buttons-group-label'
                  name='isEmployeeAcknowledgement'
                  onChange={(event) =>
                    handleChangeGoalCycleData(event, 'radio')
                  }
                >
                  <FormControlLabel
                    value={true}
                    disabled={isView}
                    control={<Radio />}
                    label={<IntlMessages id='common.button.Yes' />}
                  />
                  <FormControlLabel
                    value={false}
                    disabled={isView}
                    control={<Radio />}
                    label={<IntlMessages id='common.button.No' />}
                  />
                </RadioGroup>
              </Stack>
            </Stack>
            )}

          {/* -------------------Can stake holder edit goal ---------------------------------------------------- */}
          <Stack
              id='addEnrollmentStack'
              direction='row'
              sx={{mt: 5, ml: 3}}
              justifyContent='space-between'
              alignItems='flex-start'
              spacing={2}
            >
              <Stack sx={{width: '40%'}}>
                <Stack fontWeight={500}>
                   Can Stake holder edit goals ?
                </Stack>
              </Stack>

              <Stack direction={'row'} sx={{width: '60%'}}>
                <RadioGroup
                  value={goalCycle.stakeHolderEdit}
                  row
                  aria-labelledby='demo-row-radio-buttons-group-label'
                  name='stakeHolderEdit'
                  onChange={(event) =>
                    handleChangeGoalCycleData(event, 'radio')
                  }
                >
                  <FormControlLabel
                    value={true}
                    disabled={isView}
                    control={<Radio />}
                    label={<IntlMessages id='common.button.Yes' />}
                  />
                  <FormControlLabel
                    value={false}
                    disabled={isView}
                    control={<Radio />}
                    label={<IntlMessages id='common.button.No' />}
                  />
                </RadioGroup>
              </Stack>
            </Stack>


          {/* -------------------isGoalLockedDown---------------------------------------------------- */}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>
                Are goals locked down after End date or Approval ?
              </Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <RadioGroup
                value={goalCycle.isGoalLockedDown}
                row
                aria-labelledby='demo-row-radio-buttons-group-label'
                name='isGoalLockedDown'
                onChange={(event) => handleChangeGoalCycleData(event, 'radio')}
              >
                <FormControlLabel
                  value={true}
                  disabled={isView}
                  control={<Radio />}
                  label={<IntlMessages id='common.button.Yes' />}
                />
                <FormControlLabel
                  value={false}
                  disabled={isView}
                  control={<Radio />}
                  label={<IntlMessages id='common.button.No' />}
                />
              </RadioGroup>
            </Stack>
          </Stack>
        </Stack>
        {/* ////////add Stack for fixed////// */}
        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0,
          }}
        >
          <Stack
            direction='row'
            justifyContent='end'
            alignItems='center'
            spacing={2}
            sx={{
              pt: 5,
              ml: 3,
              //// add marging for fixed stack///
              margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
            }}
          >
            <Button
              color={footerButton.back.color}
              variant={footerButton.back.variant}
              sx={footerButton.back.sx}
              size={footerButton.back.size}
              onClick={() => Router.push('/company-builder/goal-cycle')}
            >
              <IntlMessages id='common.button.Back' />
            </Button>
            {!isView && (
              <Button
                color={footerButton.submit.color}
                variant={footerButton.submit.variant}
                sx={footerButton.submit.sx}
                size={footerButton.submit.size}
                disabled={loading}
                onClick={() => {
                  validateCalibrationCycleData();
                }}
              >
                {loading ? (
                  <CircularProgress
                    sx={{
                      margin: '0px 1rem',
                      color: '#000000',
                      width: '25px !important',
                      height: '25px !important',
                    }}
                  />
                ) : (
                  <Stack>
                    {isEdit ? (
                      <IntlMessages id='common.button.Update' />
                    ) : (
                      <IntlMessages id='common.button.Submit' />
                    )}
                  </Stack>
                )}
              </Button>
            )}
          </Stack>
        </Stack>
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default AddGoalCycle;
