import React from 'react';
import {useDispatch, useSelector} from 'react-redux';
import AppAnimate from '../../../@crema/core/AppAnimate';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import {AppCard, AppInfoView} from '../../../@crema';
import Stack from '@mui/material/Stack';
import {
  isEmptyNullUndefined,
  apiCatchErrorMessage,
  getCompanyDateFormat,
} from '../../../shared/utils/CommonUtils';
import Button from '@mui/material/Button';
import Router, {useRouter} from 'next/router';
import {fetchError, showInfo} from '../../../redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {footerButton} from 'shared/constants/AppConst';
import IntlMessages from '@crema/utility/IntlMessages';
import axios from 'axios';
import {domCreactionHeaderTitle} from 'shared/utils/domCreaction';
import moment from 'moment';
import ExtendGoalCycleDialog from './ExtendGoalCycleDialog';
import { useState } from 'react';

const ViewGoalCycle = () => {
  const router = useRouter();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const {id, view} = router.query;
  const dispatch = useDispatch();

  const [goalCycle, setGoalCycle] = React.useState(null);
  
  const [goalForms, setGoalForms] = React.useState([]);
  const [queryList, setQueryList] = React.useState([]);
  const [workflowList, setWorkflowList] = React.useState(null);

  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  React.useEffect(() => {
    if (!isEmptyNullUndefined(selectedCompany.id)) {
      getAllActiveGoalForms(selectedCompany.id);
      getAllActiveQuery(selectedCompany.id);
      getAllActiveWorkflows(selectedCompany.id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
    };
  }, []);

  React.useEffect(() => {
    if (!isEmptyNullUndefined(id) && (view == 'true' || view == true)) {
      getGoalCycleDetails(id);
    }

    return () => {
      source2.cancel('Aborting all previous operations.');
    };
  }, []);

  const getGoalCycleDetails = async (id) => {
    try {
      const response = await jwtAxios.get(`${API_ROUTS.goalCycle}/${id}`, {
        cancelToken: source2.token,
      });
      if (response.status == 200) {
        setGoalCycle(response.data);
      }
    } catch (e) {
      dispatch(fetchError(e.response?.data?.detail));
    }
  };

  const getAllActiveGoalForms = async (companyId) => {
    try {
      const res = await jwtAxios.get(
       `${API_ROUTS.goalForm_company}/${companyId}/ACTIVE`,
        {cancelToken: source.token},
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have not ratings for selected company'));
          setGoalForms([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setGoalForms(reversed);
        }
      } else {
        setGoalForms([]);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setGoalForms([]);
    }
  };

  const getAllActiveWorkflows = async (companyId) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.get_all_workflow}/${companyId}/ACTIVE`,
        {cancelToken: source.token},
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no workflow for selected company'));
          setWorkflowList([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setWorkflowList(reversed);
        }
      } else {
        setWorkflowList([]);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setWorkflowList([]);
    }
  };

  const getAllActiveQuery = async (companyId) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.customquery}?companyId=${companyId}&relationTable=Employee&status=ACTIVE`,
        {
          cancelToken: source.token,
        },
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no record'));
          setQueryList([]);
        } else {
          setQueryList(res.data.reverse());
        }
      } else {
        setQueryList([]);
      }
    } catch (e) {
      if (axios.isCancel(e)) {
      } else {
        apiCatchErrorMessage(e, dispatch, fetchError);
      }
      setQueryList([]);
    }
  };

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>View Goal Cycle</h2>

      <Stack
        direction='row'
        sx={{m: 2, width: '100%'}}
        display={'flex'}
        justifyContent={'flex-end'}
        spacing={2}
        // width={'50%'}
      >
        <Button
          // disabled={isLoading}
          name='extendCalibration'
          variant='contained'
          color='success'
          onClick={() => handleClickOpen()}
          style={{marginRight: '30px'}}
        >
          Extend cycle
        </Button>
      </Stack>

      <AppCard>
        <Stack sx={{mb: 10}}>
          <Stack>
            {domCreactionHeaderTitle(
              <IntlMessages id='calibration.BasicInfo' />,
            )}
          </Stack>
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>Name :</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '50%'}} fontWeight={800}>
              {goalCycle?.name ? goalCycle.name : ''}
            </Stack>
          </Stack>

          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>Status :</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '50%'}} fontWeight={800}>
              {goalCycle?.status || ''}
            </Stack>
          </Stack>

          {/* -------------Goal Cycle Period------------------------------------------------------------------------- */}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>Goal Cycle Start Date :</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '50%'}} fontWeight={800}>
              {goalCycle?.startDate
                ? moment(goalCycle?.startDate).format(
                    getCompanyDateFormat(selectedCompany),
                  )
                : '-'}
            </Stack>
          </Stack>
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>Goal Cycle End Date :</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '50%'}} fontWeight={800}>
              {goalCycle?.endDate
                ? moment(goalCycle?.endDate).format(
                    getCompanyDateFormat(selectedCompany),
                  )
                : '-'}
            </Stack>
          </Stack>

          <Stack sx={{mt: 3, mb: 3}}>
            {domCreactionHeaderTitle('Other Info')}
          </Stack>

          {/* -------------Select goal form------------------------------------------------------------------------- */}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>Goal Form :</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '50%'}} fontWeight={500}>
              {goalForms?.find((form) => form.id === goalCycle?.goalFormId)?.name || ''}
            </Stack>
          </Stack>

          {/* -------------Select custom query------------------------------------------------------------------------- */}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>Custom queries :</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '50%'}} fontWeight={800}>
              {goalCycle?.goalCycleCustomQuery
                ?.map(
                  (item) =>
                    queryList.find((option) => option.id === item.customQueryId)
                      ?.variableName,
                )
                .filter(Boolean)
                .join(', ') || ''}
            </Stack>
          </Stack>

          {/* -------------isWorkflow------------------------------------------------------------------------- */}
          <Stack>
            <Stack
              id='addEnrollmentStack'
              direction='row'
              sx={{mt: 5, ml: 3}}
              justifyContent='space-between'
              alignItems='flex-start'
              spacing={2}
            >
              <Stack sx={{width: '50%'}}>
                <Stack fontWeight={500}>Is Workflow required ?</Stack>
              </Stack>

              <Stack direction={'row'} sx={{width: '50%'}} fontWeight={800}>
                {goalCycle?.isWorkflow ? 'Yes' : 'No'}
              </Stack>
            </Stack>

            <Stack
              id='addEnrollmentStack'
              direction='row'
              sx={{mt: 5, ml: 3}}
              justifyContent='space-between'
              alignItems='flex-start'
              spacing={2}
            >
              <Stack sx={{width: '50%'}}>
                <Stack fontWeight={500}>Workflow : </Stack>
              </Stack>
              <Stack direction={'row'} sx={{width: '50%'}} fontWeight={800}>
                {workflowList?.find(
                  (workflow) => workflow.id === goalCycle?.workflowId,
                )?.name || ''}
              </Stack>
            </Stack>
          </Stack>
          {/* ------------------isEditEmployeeGoal----------------------------------------------------- */}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>
                Does Organization allow managers to Edit Employee Goals ?
              </Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '50%'}} fontWeight={800}>
              {goalCycle?.isEditEmployeeGoal ? 'Yes' : 'No'}
            </Stack>
          </Stack>
          {/* -------------------isEmployeeAcknowledgement---------------------------------------------------- */}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>
                Is employee acknowledgements needed (in case Manager edits)?
              </Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '50%'}} fontWeight={800}>
              {goalCycle?.isEmployeeAcknowledgement ? 'Yes' : 'No'}
            </Stack>
          </Stack>
          {/* -------------------are stakeholder edit---------------------------------------------------- */}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>
                Are Shared Goals Editable by Stakeholders?
              </Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '50%'}} fontWeight={800}>
              {goalCycle?.stakeHolderEdit ? 'Yes' : 'No'}
            </Stack>
          </Stack>
          {/* -------------------isGoalLockedDown---------------------------------------------------- */}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>
                Are goals locked down after End date or Approval ?
              </Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '50%'}} fontWeight={800}>
              {goalCycle?.isGoalLockedDown ? 'Yes' : 'No'}
            </Stack>
          </Stack>
        </Stack>
        {/* ////////add Stack for fixed////// */}
        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0,
          }}
        >
          <Stack
            direction='row'
            justifyContent='end'
            alignItems='center'
            spacing={2}
            sx={{
              pt: 5,
              ml: 3,
              //// add marging for fixed stack///
              margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
            }}
          >
            <Button
              color={footerButton.back.color}
              variant={footerButton.back.variant}
              sx={footerButton.back.sx}
              size={footerButton.back.size}
              onClick={() => Router.push('/company-builder/goal-cycle')}
            >
              <IntlMessages id='common.button.Back' />
            </Button>
          </Stack>
        </Stack>
        <Stack>
          {open && (
            <ExtendGoalCycleDialog
              open={open}
              handleClose={handleClose}
              id={id}
              getGoalCycleDetails={getGoalCycleDetails}
            />
          )}
        </Stack>
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default ViewGoalCycle;
