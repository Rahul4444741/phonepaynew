import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import Stack from '@mui/material/Stack';
import { AppCard } from '../../../@crema';
import { showMessage, fetchError } from '../../../redux/actions';
import TextField from '@mui/material/TextField';
import PropTypes from 'prop-types';
import AppInfoView from '../../../@crema/core/AppInfoView';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import { useDispatch } from 'react-redux';
import jwtAxios from '@crema/services/auth/jwt-auth';
import { API_ROUTS } from 'shared/constants/ApiRouts';
import {
  apiCatchErrorMessage,
  isDuplicate,
  isStrExceeds,
} from 'shared/utils/CommonUtils';
import IntlMessages from '@crema/utility/IntlMessages';
const AddGridModal = ({
  company,
  isEdit,
  editGrid,
  handleAddGrid,
  handleUpdateGrid,
  handleClose,
  gridData,
}) => {
  const dispatch = useDispatch();
  const [grid, setGrid] = React.useState({
    id: null,
    name: '',
    status: '',
    company: {
      id: company.id,
    },
  });
  React.useEffect(() => {
    if (isEdit) {
      setGrid(editGrid);
    }
  }, []);
  const [formError, setFormError] = React.useState({
    name: {isError: false, errorMessage: ''},
    status: {isError: false, errorMessage: ''},
  });
  const textFieldStyled = {
    backgroundColor: 'white',
    mb: 4,
    width: {xs: '100%'},
  };

  const handleValidateGrid = async () => {
    let isValid = true;
    const tempError = {...formError};
    const tempGrid = {...grid};
    if (tempGrid.name.trim() == '') {
      tempError.name.isError = true;
      tempError.name.errorMessage = <IntlMessages id='error.pleaseEnterName' />;
      isValid = false;
    }
    if (isStrExceeds(tempGrid.name.toString(), 50)) {
      tempError.name.isError = true;
      tempError.name.errorMessage = 'should not exceed 50 characters';
      isValid = false;
    }
    if (
      !isEdit
        ? isDuplicate(tempGrid.name, gridData)
        : isDuplicate(tempGrid.name, gridData, tempGrid.id)
    ) {
      tempError.name.isError = true;
      tempError.name.errorMessage = (
        <IntlMessages id='error.duplicateEntryFound' />
      );
      isValid = false;
    }

    if (tempGrid.status.trim() == '') {
      tempError.status.isError = true;
      tempError.status.errorMessage = (
        <IntlMessages id='error.pleaseSelectStatus' />
      );
      isValid = false;
    }
    if (isValid) {
      if (isEdit) {
        updateGrid();
      } else {
        submitGrid();
      }
    } else {
      setFormError(tempError);
    }
  };

  const submitGrid = async () => {
    try {
      const response = await jwtAxios.post(`${API_ROUTS.employeegrade}`, grid);
      if (response.status == 201) {
        dispatch(
          showMessage(response.data.name + ' grade added successfully..!'),
        );
        handleAddGrid(response.data);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const updateGrid = async () => {
    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.employeegrade}${grid.id}`,
        grid,
      );
      if (response.status == 200) {
        dispatch(
          showMessage(response.data.name + ' grade updated successfully..!'),
        );
        handleUpdateGrid(response.data);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleChangeGridData = (event) => {
    const tempGrid = {...grid};
    const tempError = {...formError};
    tempGrid[event.target.name] = event.target.value;
    tempError[event.target.name].isError = false;
    tempError[event.target.name].errorMessage = '';
    setGrid(tempGrid);
    setFormError(tempError);
  };

  return (
    <Dialog maxWidth={'sm'} open={true}>
      <DialogContent>
        <Stack direction='row' justifyContent='center' sx={{mt: '7%'}}>
          <AppCard style={{width: '350px'}}>
            <h4 style={{display: 'flex'}}>
            {!isEdit ? (
                <IntlMessages id='grades.addGrades' />
              ) : (
                <IntlMessages id='grades.updateGrades' />
              )}
            </h4>
            <Stack
              sx={{mt: 2}}
              display='flex'
              justifyContent='center'
              spacing={2}
            >
              <TextField
                size='small'
                name='name'
                label={<IntlMessages id='configuration.dialogbox.Name' />}
                onChange={(event) => handleChangeGridData(event)}
                value={grid?.name}
                error={formError.name.isError}
                helperText={formError.name.errorMessage}
                variant='outlined'
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              />
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id='event-type'>
                  <IntlMessages id='configuration.dialogbox.Status' />
                </InputLabel>
                <Select
                  size='small'
                  name='status'
                  label='Status'
                  value={grid?.status}
                  error={formError.status.isError}
                  helperText={formError.status.errorMessage}
                  onChange={(event) => handleChangeGridData(event)}
                  variant='outlined'
                  sx={{...textFieldStyled}}
                >
                  <MenuItem key='Active' value='ACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Active' />
                  </MenuItem>
                  <MenuItem key='Inactive' value='INACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                  </MenuItem>
                </Select>
                <FormHelperText style={{color: '#d32f2f'}}>
                  {formError.status.errorMessage}
                </FormHelperText>
              </FormControl>
            </Stack>
          </AppCard>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={() => handleValidateGrid()}>
          <IntlMessages id='common.button.Submit' />
        </Button>
        <Button onClick={() => handleClose()}>
          <IntlMessages id='common.button.Close' />
        </Button>
      </DialogActions>
      <AppInfoView />
    </Dialog>
  );
};

export default AddGridModal;
AddGridModal.propTypes = {
  company: PropTypes.object,
  handleAddGrid: PropTypes.func,
  handleUpdateGrid: PropTypes.func,
  handleClose: PropTypes.func,
  isEdit: PropTypes.bool,
  editGrid: PropTypes.object,
  gridData: PropTypes.array,
};
