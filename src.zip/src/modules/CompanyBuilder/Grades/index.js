import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard} from '../../../@crema';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import {AgGridReact} from 'ag-grid-react';
import {useDispatch, useSelector} from 'react-redux';
import AppInfoView from '../../../@crema/core/AppInfoView';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import {
  fetchStart,
  showMessage,
  fetchError,
  showInfo,
} from '../../../redux/actions';
import axios from 'axios';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {TextField} from '@mui/material';
import {
  isEmptyNullUndefined,
  buttonStyle,
  apiCatchErrorMessage,
  isAllowedUser,
} from 'shared/utils/CommonUtils';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import IntlMessages from '@crema/utility/IntlMessages';
import AddGridModal from './AddGridModal';
import AlertDialog from 'modules/Common/AlertDialog';
import {permissionName} from 'shared/utils/PermissionName';
import Error403 from 'modules/errorPages/Error403';
import { useCallback } from 'react';

const CustomHeaderName = () => <IntlMessages id='aggrid.tableHeader.Name' />;
const CustomHeaderStatus = () => (
  <IntlMessages id='aggrid.tableHeader.Status' />
);
const CustomHeaderAction = () => (
  <IntlMessages id='aggrid.tableHeader.Action' />
);

const Grades = () => {
  const dispatch = useDispatch();
  const [gridData, setGridData] = React.useState(null);
  const [isAddGridOpen, setIsAddGridOpen] = React.useState(false);
  const [isEdit, setIsEdit] = React.useState(false);
  const [editGrid, setEditGrid] = React.useState(undefined);
  const [overlayMessage, setOverlayMessage] = React.useState('No Rows To Show');
  const [isLoading, setIsLoading] = React.useState(true);
  const [alertProps, setAlertProps] = React.useState({
    isHideShow: false,
    message: '',
    title: '',
    alertType: '',
    actionParams: null,
  });

  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);

  React.useEffect(() => {
    if (isAllowedUser(permissionName.COMPANY_VARIABLES_EMPLOYEE_GRADES)) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  const StatusRenderer = (params) => (
    <Stack direction='row'>
      {params.data.status === 'ACTIVE' ? (
        <div style={{color: '#11C15B'}}>{params.data.status}</div>
      ) : (
        <div style={{color: '#D32F2F'}}>{params.data.status}</div>
      )}
    </Stack>
  );
  const ActionRenderer = (params) => (
    <Stack direction='row'>
      {isAllowedUser(permissionName.UPDATE) && (
        <Button onClick={() => handleOpenEditModel(params)} style={buttonStyle}>
          <IntlMessages id='common.button.Edit' />
        </Button>
      )}
      {isAllowedUser(permissionName.DEACTIVATE) &&
        params.data.status === 'ACTIVE' && (
          <Button
            onClick={() => handleDeactivateConfirmation(params)}
            style={buttonStyle}
          >
            <IntlMessages id='common.button.Deactivate' />
          </Button>
        )}
      {isAllowedUser(permissionName.ACTIVATE) &&
        params.data.status === 'INACTIVE' && (
          <Button
            onClick={() => handleActivateConfirmation(params)}
            style={buttonStyle}
          >
            <IntlMessages id='common.button.Activate' />
          </Button>
        )}
    </Stack>
  );
  const columnDefs = [
    {
      field: 'name',
      filter: true,
      headerName: 'Name',
      minWidth: 350,
      headerComponentFramework: CustomHeaderName,
    },
    {
      field: 'status',
      filter: true,
      headerName: 'Status',
      headerComponentFramework: CustomHeaderStatus,
      minWidth: 350,
      cellRenderer: StatusRenderer, // Use StatusRenderer component
    },
    {
      headerName: 'Action',
      headerComponentFramework: CustomHeaderAction,
      minWidth: 300,
      cellRenderer: ActionRenderer, // Use ActionRenderer component
    },
  ];

  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();
  React.useEffect(() => {
    dispatch(fetchStart);
    if (
      isAuthorized &&
      selectedCompany != null &&
      selectedCompany != undefined
    ) {
      getAllActiveGridData(selectedCompany.id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, [isAuthorized, selectedCompany]);

  const gridRef = React.useRef();
  const defaultColDef = React.useMemo(() => ({
    sortable: true,
  }));

  const getAllActiveGridData = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        //chage required here
        `${API_ROUTS.employeegrade_companyID}${companyId}?status=ACTIVE`,
        {cancelToken: source.token},
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no grades for selected company'));
          setGridData([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setGridData(reversed);
        }
        setIsLoading(() => false);
      } else {
        setGridData([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setGridData([]);
    }
    setIsLoading(() => false);
  };
  const getAllInactiveGridData = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        //chage required here
        `${API_ROUTS.employeegrade_companyID}${companyId}?status=INACTIVE`,
        {cancelToken: source2.token},
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no grades for selected company'));
          setGridData([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setGridData(reversed);
        }
        setIsLoading(() => false);
      } else {
        setGridData([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setGridData([]);
      setIsLoading(() => false);
    }
  };

  const handleOpenEditModel = (params) => {
    let rowData = [];
    params.api.forEachNode((node) => rowData.push(node.data));
    const gridIndex = rowData.findIndex((item) => item.id == params.data.id);

    if (gridIndex != -1) setEditGrid(rowData[gridIndex]);
    setIsEdit(true);
    setIsAddGridOpen(true);
  };

  const handleDeactivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    //chagne required here
    tempAlertProps.title = <IntlMessages id='warning.deactivateGrade' />;

    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureDeactivate' /> {params.data.name} ?
      </span>
    );

    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleAlertYes = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.actionParams.data.status == 'ACTIVE' &&
      handleDeactivateGrid(tempAlertProps.actionParams);
    tempAlertProps.actionParams.data.status == 'INACTIVE' &&
      handleActivateGrid(tempAlertProps.actionParams);
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };

  const handleAlertNo = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };
  const handleDeactivateGrid = async (params) => {
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));
      const response = await jwtAxios.put(
        //chage required here
        `${API_ROUTS.employeegrade_inactivate}${params.data.id}`,
      );
      if (response.status == 200) {
        //chage required here
        dispatch(showMessage('Grade deactivate successfully..!'));

        const gridIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );

        if (gridIndex != -1) {
          rowData[gridIndex].status = 'INACTIVE';
        }
        getAllInactiveGridData(selectedCompany.id);
        setAlignment('INACTIVE');
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleActivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    //chagne required here
    tempAlertProps.title = <IntlMessages id='warning.activateGrade' />;
    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureActivate' /> {params.data.name} ?
      </span>
    );
    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleActivateGrid = async (params) => {
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));
      const response = await jwtAxios.put(
        //chage required here
        `${API_ROUTS.employeegrade_activate}${params.data.id}`,
      );
      if (response.status == 200) {
        //chagne required here
        dispatch(showMessage('Grade activate successfully..!'));
        const gridIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );
        if (gridIndex != -1) {
          rowData[gridIndex].status = 'ACTIVE';
        }
        getAllActiveGridData(selectedCompany.id);
        setAlignment('ACTIVE');
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleUpdateGrid = (grid) => {
    const isActive = grid.status === 'ACTIVE';
    const isInactive = grid.status === 'INACTIVE';

    // Update grid data if the status and alignment match
    if (
      (isActive && alignment === 'ACTIVE') ||
      (isInactive && alignment === 'INACTIVE')
    ) {
      const tempGrid = [...gridData];
      const gridIndex = tempGrid.findIndex((item) => item.id === grid.id);

      if (gridIndex !== -1) {
        tempGrid[gridIndex] = grid;
        setGridData(tempGrid);
      }
    }

    // Handle alignment changes and fetch data if needed
    if (
      (isActive && alignment === 'INACTIVE') ||
      (isInactive && alignment === 'ACTIVE')
    ) {
      setAlignment(isActive ? 'ACTIVE' : 'INACTIVE');
      isActive
        ? getAllActiveGridData(selectedCompany.id)
        : getAllInactiveGridData(selectedCompany.id);
    }

    // Cleanup
    setEditGrid(null);
    setIsEdit(false);
    setIsAddGridOpen(false);
  };

  const handleAddGridToList = (grid) => {
    const {status} = grid;

    if (status === alignment) {
      setGridData((prevData) => [grid, ...prevData]);
    }

    if (status !== alignment) {
      setAlignment(status);
      if (status === 'ACTIVE') {
        getAllActiveGridData(selectedCompany.id);
      } else if (status === 'INACTIVE') {
        getAllInactiveGridData(selectedCompany.id);
      }
    }

    setIsAddGridOpen(false);
  };

  const handleCloseAddGrid = () => {
    setIsAddGridOpen(false);
  };
  const handleOpenAddGrid = () => {
    setIsAddGridOpen(true);
    setIsEdit(false);
  };

  const [alignment, setAlignment] = React.useState('ACTIVE');

  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
  };

  const onFilterTextBoxChanged = useCallback(() => {
    const filterText = document.getElementById("filter-text-box").value;
    gridRef.current.api.setGridOption("quickFilterText", filterText);
    const totalResults = gridRef.current.api.getDisplayedRowCount();
    if (!isEmptyNullUndefined(gridData) && gridData.length > 0) {
      if (totalResults === 0 && !isEmptyNullUndefined(filterText)) {
        setOverlayMessage('No Record Found');
        gridRef.current.api.showNoRowsOverlay();
      } else if (totalResults !== 0) {
        setOverlayMessage('No Rows To Show');
        gridRef.current.api.hideOverlay();
      }
    }
  }, []);
  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (!isAuthorized) {
    return <Error403 />;
  }

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        <IntlMessages id='grades.pageHeaderName' />
      </h2>
      <AppCard>
        <Stack style={{width: '100%'}}>
          <Stack direction='row' sx={{mb: 2}} justifyContent={'end'}>
            <TextField
              //size='small'
              sx={{width: 200, mr: 2}}
              id="filter-text-box"
              onInput={onFilterTextBoxChanged}
              type={'search'}
              name='search'
              label={<IntlMessages id='common.button.Search' />}
              variant='outlined'
            />
            {isAllowedUser(permissionName.CREATE) && (
              <Button
                sx={{mr: 2}}
                variant='outlined'
                onClick={() => handleOpenAddGrid()}
              >
                <IntlMessages id='grades.addGrades' />
              </Button>
            )}
            <ToggleButtonGroup
              color='primary'
              value={alignment}
              exclusive
              onChange={handleChange}
            >
              <ToggleButton
                value='ACTIVE'
                onClick={() => getAllActiveGridData(selectedCompany.id)}
              >
                <IntlMessages id='common.button.Active' />
              </ToggleButton>
              <ToggleButton
                value='INACTIVE'
                onClick={() => getAllInactiveGridData(selectedCompany.id)}
              >
                <IntlMessages id='common.button.Inactive' />
              </ToggleButton>
            </ToggleButtonGroup>
          </Stack>
          {isLoading ? (
            domCreactionGridSkeletonLoader()
          ) : (
            <Stack
              className='ag-theme-alpine'
              style={{height: 525, width: '100%'}}
            >
              <AgGridReact
                ref={gridRef}
                rowData={gridData}
                columnDefs={columnDefs}
                defaultColDef={defaultColDef}
                animateRows={true}
                pagination={true}
                paginationPageSize={10}
                overlayLoadingTemplate={
                  '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'
                }
                overlayNoRowsTemplate={`<span class="ag-overlay-loading-center">${overlayMessage}</span>`}
              />
            </Stack>
          )}
        </Stack>
        {isAddGridOpen && (
          <AddGridModal
            company={selectedCompany}
            isEdit={isEdit}
            editGrid={editGrid}
            handleAddGrid={(grid) => handleAddGridToList(grid)}
            handleUpdateGrid={(grid) => handleUpdateGrid(grid)}
            handleClose={() => handleCloseAddGrid()}
            gridData={gridData}
          ></AddGridModal>
        )}
        {alertProps.isHideShow && (
          <AlertDialog
            alertProps={alertProps}
            handleYes={() => handleAlertYes()}
            handleNo={() => handleAlertNo()}
          />
        )}
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default Grades;
