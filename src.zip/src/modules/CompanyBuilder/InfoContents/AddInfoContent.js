import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import AppAnimate from '../../../@crema/core/AppAnimate';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import { AppCard, AppInfoView } from '../../../@crema';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import {
  isEmptyNullUndefined,
  apiCatchErrorMessage,
} from '../../../shared/utils/CommonUtils';
import Button from '@mui/material/Button';
import Router, { useRouter } from 'next/router';
import {
  showMessage,
  fetchError
} from '../../../redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import { API_ROUTS } from 'shared/constants/ApiRouts';
import { footerButton } from 'shared/constants/AppConst';
import IntlMessages from '@crema/utility/IntlMessages';
import axios from 'axios';

import {
  align,
  font,
  fontColor,
  fontSize,
  formatBlock,
  hiliteColor,
  horizontalRule,
  image,
  lineHeight,
  link,
  list,
  paragraphStyle,
  table,
  template,
  textStyle,
} from '../../../../node_modules/suneditor/src/plugins';
import 'suneditor/dist/css/suneditor.min.css';
import mergeTag from './merge_tag_plugin';
import dynamic from 'next/dynamic';
import {
  FormControl,
  FormHelperText,
  InputLabel,
  MenuItem,
  Select,
} from '@mui/material';

const SunEditor = dynamic(() => import('suneditor-react'), {
  ssr: false,
});

const textFieldStyled = {
  backgroundColor: 'white',
  mb: 2,
  width: {xs: '100%', xl: '60%', md: '75%'},
};

const pageNameArray = [
  {
    key: 'request-feedback',
    name: 'request-feedback',
    value: 'request-feedback',
    view: 'Request Feedback',
  },
  {
    key: 'aprove',
    name: 'aprove',
    value: 'aprove',
    view: 'Approve',
  },
  {
    key: 'give-peer-feedback',
    name: 'give-peer-feedback',
    value: 'give-peer-feedback',
    view: 'Give Feedback',
  },
  {
    key: 'rating-calibration',
    name: 'rating-calibration',
    value: 'rating-calibration',
    view: 'Rating Calibration',
  },
  {
    key: 'functional-leader',
    name: 'functional-leader',
    value: 'functional-leader',
    view: 'Functional Leader',
  },
  {
    key: 'create-employee-cohort',
    name: 'create-employee-cohort',
    value: 'create-employee-cohort',
    view: 'Create Employee Cohort',
  },
  {
    key: 'add-panelist',
    name: 'add-panelist',
    value: 'add-panelist',
    view: 'Add Panelist',
  },
];

const AddInfoContent = () => {
  const router = useRouter();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const {id} = router.query;
  const dispatch = useDispatch();

  const initialInfoContent = {
    title: null,
    pageName: null,
    description: null,
    companyId: selectedCompany?.id,
  };
  const initialInfoContentError = {
    title: {isError: false, errorMessage: ''},
    pageName: {isError: false, errorMessage: ''},
  };

  const [infoContent, setInfoContent] = React.useState(initialInfoContent);
  const [infoContentError, setInfoContentError] = React.useState(
    initialInfoContentError,
  );

  const [editorData, setEditorData] = React.useState('<p><br></p>');
  const [editorDataError, setEditorDataError] = React.useState({
    isError: false,
    errorMessage: '',
  });

  const [isEditorEditActive, setIsEditorEditActive] = React.useState(false);

  const [isEdit, setIsEdit] = React.useState(false);
  const [loading, setLoading] = React.useState(false);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  React.useEffect(() => {
    if (!isEmptyNullUndefined(id)) {
      getInfoContent(id);
      setIsEdit(true);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, []);

  const getInfoContent = async (id) => {
    try {
      const response = await jwtAxios.get(`${API_ROUTS.infoContents}/${id}`, {
        cancelToken: source2.token,
      });
      if (response.status == 200) {
        setInfoContent(response.data);
        setEditorData(response?.data?.description);
      }
    } catch (e) {
      dispatch(fetchError(e.response?.data?.detail));
    }
  };

  const handleChangeInfoContent = (event, type) => {
    let tempInfoContent = {...infoContent};
    let tempInfoContentError = {...infoContentError};

    if (type == 'editor') {
      tempInfoContent.description = event;
      tempInfoContentError.description.isError = false;
      tempInfoContentError.description.errorMessage = '';
    } else {
      tempInfoContent[event.target.name] = event.target.value;
      tempInfoContentError[event.target.name].isError = false;
      tempInfoContentError[event.target.name].errorMessage = '';
    }

    setInfoContent(() => tempInfoContent);
    setInfoContentError(() => tempInfoContentError);
  };

  const validateInfoContent = () => {
    let tempInfoContentError = {...infoContentError};
    let tempEditorDataError = editorDataError;

    let isValid = true;

    if (isEmptyNullUndefined(infoContent.title)) {
      tempInfoContentError.title.isError = true;
      tempInfoContentError.title.errorMessage = (
        <IntlMessages id='error.please_enter_info_title' />
      );
      isValid = false;
    }
    if (isEmptyNullUndefined(infoContent.pageName)) {
      tempInfoContentError.pageName.isError = true;
      tempInfoContentError.pageName.errorMessage = (
        <IntlMessages id='error.please_enter_page_name' />
      );
      isValid = false;
    }
    if (editorData == '<p><br></p>') {
      tempEditorDataError.isError = true;
      tempEditorDataError.errorMessage = (
        <IntlMessages id='error.pleaseEnterDiscription' />
      );
      isValid = false;
    }

    if (isValid) {
      if (isEdit) {
        UpdateInfo();
      } else {
        SubmitInfo();
      }
    } else {
      setInfoContentError(() => tempInfoContentError);
      setEditorDataError(() => tempEditorDataError);
    }
  };

  const SubmitInfo = async () => {
    let tempInfo = {
      ...infoContent,
      description: editorData,
    };
    const submit = async () => {
      setLoading(true);
      try {
        const response = await jwtAxios.post(
          `${API_ROUTS.infoContents}`,
          tempInfo,
        );
        if (response.status == 201) {
          dispatch(showMessage('Info Content added successfully..!'));
          Router.push('/company-builder/info-contents');
        } else {
          setLoading(false);
        }
      } catch (error) {
        apiCatchErrorMessage(error, dispatch, fetchError);
        setLoading(false);
      }
    };
    await submit();
  };
  const UpdateInfo = async () => {
    let tempInfo = {
      ...infoContent,
      id: id,
      description: editorData,
    };
    const update = async () => {
      setLoading(true);
      try {
        const response = await jwtAxios.put(
          `${API_ROUTS.infoContents}`,
          tempInfo,
        );
        if (response.status == 200) {
          dispatch(showMessage('Info Content updated successfully..!'));
          Router.push('/company-builder/info-contents');
        } else {
          setLoading(false);
        }
      } catch (error) {
        apiCatchErrorMessage(error, dispatch, fetchError);
        setLoading(false);
      }
    };
    await update();
  };

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        {!isEdit ? (
          <h3>
            <IntlMessages id='info.addInfoContent' />
          </h3>
        ) : (
          <h3>
            <IntlMessages id='info.editInfoContent' />
          </h3>
        )}
      </h2>

      <AppCard>
        <Stack
          id='addEnrollmentStack'
          direction='row'
          sx={{mt: 5, ml: 3}}
          justifyContent='space-between'
          alignItems='flex-start'
          spacing={2}
        >
          <Stack sx={{width: '40%'}}>
            <Stack fontWeight={500}>
              <IntlMessages id='info.enterPageName' />:{' '}
            </Stack>
          </Stack>

          <Stack direction={'row'} sx={{width: '60%'}}>
            <FormControl
              sx={{
                ...textFieldStyled,
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {
                    borderLeftColor: 'red',
                    borderLeftWidth: 3,
                  },
                  width: '100%',
                },
              }}
            >
              <InputLabel size='small' id='event-type'>
                <IntlMessages id='info.pageName' />
              </InputLabel>
              <Select
                size='small'
                name='pageName'
                label={<IntlMessages id='info.pageName' />}
                value={infoContent.pageName ? infoContent.pageName : ''}
                error={infoContentError.pageName?.isError}
                helperText={infoContentError.pageName?.errorMessage}
                onChange={(event) => handleChangeInfoContent(event, 'dropdown')}
                variant='outlined'
                sx={{...textFieldStyled}}
              >
                {pageNameArray.map((page) => (
                  <MenuItem key={page.key} value={page.value}>
                    {page.view}
                  </MenuItem>
                ))}
              </Select>
              <FormHelperText style={{color: '#d32f2f'}}>
                {infoContentError.pageName?.errorMessage}
              </FormHelperText>
            </FormControl>
          </Stack>
        </Stack>

        <Stack
          id='addEnrollmentStack'
          direction='row'
          sx={{mt: 5, ml: 3}}
          justifyContent='space-between'
          alignItems='flex-start'
          spacing={2}
        >
          <Stack sx={{width: '40%'}}>
            <Stack fontWeight={500}>
              <IntlMessages id='info.enterNameForInfo' /> :
            </Stack>
          </Stack>

          <Stack direction={'row'} sx={{width: '60%'}}>
            <TextField
              size='small'
              name='title'
              label={<IntlMessages id='info.title' />}
              onChange={(event) => {
                handleChangeInfoContent(event, 'textfield');
              }}
              variant='outlined'
              error={infoContentError.title?.isError}
              helperText={infoContentError.title?.errorMessage}
              value={infoContent.title ? infoContent.title : ''}
              sx={{
                ...textFieldStyled,
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {
                    borderLeftColor: 'red',
                    borderLeftWidth: 3,
                  },
                },
              }}
            />
          </Stack>
        </Stack>

        <Stack
          direction='column'
          sx={{mt: 5, ml: 3}}
          justifyContent='space-between'
          alignItems='flex-start'
          spacing={2}
          style={{marginBottom: '20px'}}
        >
          <Stack
            direction='row'
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
            sx={{mt: 5, ml: 3, width: '100%'}}
          >
            <Stack fontWeight={500}>
              <IntlMessages id='info.enterDescription' /> :
            </Stack>
            <Stack>
              {editorDataError.isError && (
                <Stack direction='row' justifyContent='end'>
                  <Stack
                    style={{
                      marginRight: '120px',
                      marginBottom: 15,
                      color: 'red',
                    }}
                  >
                    <i>
                      <IntlMessages id='error.pleaseEnterDescription' />
                    </i>
                  </Stack>
                </Stack>
              )}
            </Stack>
          </Stack>

          <Stack
            direction={'column'}
            sx={{width: '100%', mt: 10}}
            style={{marginTop: '20px', marginBottom: '20px'}}
          >
            {!isEditorEditActive ? (
              <Stack className='description-modal-style-popup'>
                <div dangerouslySetInnerHTML={{__html: editorData}}></div>
              </Stack>
            ) : (
              <SunEditor
                setOptions={{
                  showPathLabel: false,
                  minHeight: '41vh',
                  placeholder: 'Enter your text here!!!',

                  mode: 'classic',
                  rtl: false,
                  katex: 'window.katex',
                  imageGalleryUrl:
                    'https://etyswjpn79.execute-api.ap-northeast-1.amazonaws.com/suneditor-demo',
                  videoFileInput: false,
                  tableCellControllerPosition: '',
                  tabDisable: false,

                  plugins: [
                    align,
                    font,
                    fontColor,
                    fontSize,
                    formatBlock,
                    hiliteColor,
                    horizontalRule,
                    lineHeight,
                    list,
                    paragraphStyle,
                    table,
                    template,
                    textStyle,
                    image,
                    link,
                    mergeTag,
                  ],
                  buttonList: [
                    ['undo', 'redo'],
                    [
                      'font',
                      'fontSize',
                      'formatBlock',
                      {
                        name: 'merge_tag',
                        dataCommand: 'merge_tag',
                        buttonClass: '',
                        title: 'Variable',
                        dataDisplay: 'submenu',
                        innerHTML:
                          '<span style="font-size: 20px;"><strong>P</strong></span>',
                      },
                    ],
                    ['paragraphStyle'],
                    [
                      'bold',
                      'underline',
                      'italic',
                      'strike',
                      'subscript',
                      'superscript',
                    ],
                    ['fontColor', 'hiliteColor'],
                    ['removeFormat'],
                    '/', // Line break
                    ['outdent', 'indent'],
                    ['align', 'horizontalRule', 'list', 'lineHeight'],
                    ['table', 'link', 'image'],
                    [
                      'textStyle',
                      'math',
                      'imageGallery',
                      'fullScreen',
                      'showBlocks',
                      'codeView',
                      'preview',
                      'print',
                      'save',
                      'template',
                    ],
                  ],

                  formats: ['p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'],
                  font: [
                    'Arial',
                    'Calibri',
                    'Comic Sans',
                    'Courier',
                    'Garamond',
                    'Georgia',
                    'Impact',
                    'Lucida Console',
                    'Palatino Linotype',
                    'Segoe UI',
                    'Tahoma',
                    'Times New Roman',
                    'Trebuchet MS',
                  ],
                }}
                onChange={(event) => {
                  setEditorData(event);
                  setEditorDataError({isError: false, errorMessage: ''});
                }}
                setContents={editorData}
              />
            )}
            <Button
              id={`edit-submit-description`}
              variant='outlined'
              onClick={() => {
                if (isEditorEditActive) {
                  setIsEditorEditActive(false);
                } else {
                  setIsEditorEditActive(true);
                }
              }}
            >
              {isEditorEditActive ? (
                <IntlMessages id='info.SubmitDescription' />
              ) : (
                <IntlMessages id='info.EditDescription' />
              )}
            </Button>
          </Stack>
        </Stack>

        {/* ////////add Stack for fixed////// */}
        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0,
          }}
        >
          <Stack
            direction='row'
            justifyContent='end'
            alignItems='center'
            spacing={2}
            sx={{
              pt: 5,
              ml: 3,
              //// add marging for fixed stack///
              margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
            }}
          >
            <Button
              color={footerButton.back.color}
              variant={footerButton.back.variant}
              sx={footerButton.back.sx}
              size={footerButton.back.size}
              onClick={() => Router.push('/company-builder/info-contents')}
            >
              <IntlMessages id='common.button.Back' />
            </Button>

            <Button
              color={footerButton.submit.color}
              variant={footerButton.submit.variant}
              sx={footerButton.submit.sx}
              size={footerButton.submit.size}
              disabled={loading || isEditorEditActive}
              onClick={() => {
                validateInfoContent();
              }}
            >
              {isEdit ? (
                <IntlMessages id='common.button.Update' />
              ) : (
                <IntlMessages id='common.button.Submit' />
              )}
            </Button>
          </Stack>
        </Stack>
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default AddInfoContent;
