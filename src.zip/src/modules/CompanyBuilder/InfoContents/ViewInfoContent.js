import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import { AppCard, AppInfoView } from '../../../@crema';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import Router, { useRouter } from 'next/router';
import { useDispatch } from 'react-redux';
import {
  fetchError
} from '../../../redux/actions';
import axios from 'axios';
import {
  isEmptyNullUndefined
} from 'shared/utils/CommonUtils';
import IntlMessages from '@crema/utility/IntlMessages';
import { footerButton } from 'shared/constants/AppConst';
import jwtAxios from '@crema/services/auth/jwt-auth';
import { API_ROUTS } from 'shared/constants/ApiRouts';

const ViewInfoContent = () => {
  const router = useRouter();
  const {id} = router.query;
  const dispatch = useDispatch();

  const [info, setInfo] = React.useState({});

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  React.useEffect(() => {
    if (!isEmptyNullUndefined(id)) {
        getInfoContent(id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, []);

  const getInfoContent = async (id) => {
    try {
      const response = await jwtAxios.get(`${API_ROUTS.infoContents}/${id}`, {
        cancelToken: source2.token,
      });
      if (response.status == 200) {
        setInfo(response.data);
      }
    } catch (e) {
      dispatch(fetchError(e.response?.data?.detail));
    }
  };
 

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h1 style={{marginBottom: 5}}><IntlMessages id="info.infoContents"/></h1>

      <Stack spacing={2} sx={{mb: 10}}>
        <AppCard>
          <Stack
            direction='row'
            sx={{mt: 5, ml: 10}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <div>
                <b>
                  <IntlMessages id='info.InfoContentTitle' /> :
                </b>
              </div>
            </Stack>
            <Stack sx={{width: '50%'}}>
              <div>
                <span style={{marginLeft: 75}}>
                  {info.title}
                </span>
              </div>
            </Stack>
          </Stack>
          <Stack
            direction='row'
            sx={{mt: 5, ml: 10}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <div>
                <b>
                  <IntlMessages id='info.InfoContentPageName' />:
                </b>
              </div>
            </Stack>
            <Stack sx={{width: '50%'}}>
              <div>
                <span style={{marginLeft: 75}}>
                  {info.pageName}
                </span>
              </div>
            </Stack>
          </Stack>

          <Stack
            direction='column'
            sx={{mt: 5, ml: 10}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <div>
                <b>
                  <IntlMessages id='info.InfoContentDescription' />:
                </b>
              </div>
            </Stack>
            <Stack sx={{width: '100%'}}>
            <div>
                <span style={{ marginLeft: 75 }} className="custom-html-content">
                  <div dangerouslySetInnerHTML={{ __html: info.description }} />
                </span>
              </div>
            </Stack>
          </Stack>
        </AppCard>

        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0,
          }}
        >
          <Stack
            direction='row'
            justifyContent='end'
            alignItems='center'
            spacing={2}
            sx={{
              pt: 5,
              ml: 3,
              margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
            }}
          ></Stack>
        </Stack>
      </Stack>
      <AppInfoView />

      {/* ////////add Stack for fixed////// */}
      <Stack
        sx={{
          bottom: 0,
          zIndex: 10,
          position: 'fixed',
          backdropFilter: 'blur(5px)',
          width: '100%',
          right: 0,
        }}
      >
        <Stack
          direction='row'
          justifyContent='end'
          alignItems='center'
          spacing={2}
          sx={{
            pt: 5,
            ml: 3,
            //// add marging for fixed stack///
            margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
          }}
        >
          <Button
            color={footerButton.back.color}
            variant={footerButton.back.variant}
            sx={footerButton.back.sx}
            size={footerButton.back.size}
            onClick={() => Router.push('/company-builder/info-contents')}
          >
            <IntlMessages id='common.button.Back' />
          </Button>
        </Stack>
      </Stack>
    </AppAnimate>
  );
};

export default ViewInfoContent;
