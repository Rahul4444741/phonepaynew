import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard} from '../../../@crema';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import {AgGridReact} from 'ag-grid-react';
import {useDispatch, useSelector} from 'react-redux';
import AppInfoView from '../../../@crema/core/AppInfoView';
import {fetchError, showInfo} from '../../../redux/actions';
import axios from 'axios';
import AlertDialog from '../../Common/AlertDialog';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {TextField} from '@mui/material';
import {
  isEmptyNullUndefined,
  buttonStyle,
  apiCatchErrorMessage,
  isAllowedUser,
} from 'shared/utils/CommonUtils';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import IntlMessages from '@crema/utility/IntlMessages';
import Router from 'next/router';
import {permissionName} from 'shared/utils/PermissionName';
import Error403 from 'modules/errorPages/Error403';
import { useCallback } from 'react';

const CustomHeaderName = () => (<IntlMessages id='info.title' />)
const CustomHeaderPageName = () => (<IntlMessages id='info.pageName' />)
const CustomHeaderAction = () => (
  <IntlMessages id='aggrid.tableHeader.Action' />
);

const alertProps={
  isHideShow: false,
  message: '',
  title: '',
  alertType: '',
  actionParams: null,
}

const InfoContents = () => {
  const dispatch = useDispatch();
  const [infoContent, setInfoContent] = React.useState(null);
  const [overlayMessage, setOverlayMessage] = React.useState('No Rows To Show');
  const [isLoading, setIsLoading] = React.useState(true);
  
  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);

  React.useEffect(() => {
    if (isAllowedUser(permissionName.SET_UP_INFO_CONTENT)) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  const ActionRenderer = (params) => {
    return (
      <Stack direction="row">
        {isAllowedUser(permissionName.UPDATE) && (
          <Button
            onClick={() => handleRedirectEditInfoContent(params)}
            style={buttonStyle}
          >
            <IntlMessages id="common.button.Edit" />
          </Button>
        )}
        {isAllowedUser(permissionName.READ) && (
          <Button
            onClick={() => handleRedirectViewInfoContent(params)}
            style={buttonStyle}
          >
            <IntlMessages id="common.button.View" />
          </Button>
        )}
      </Stack>
    );
  };
  
  const columnDefs = [
    {
      field: 'pageName',
      filter: true,
      headerName: 'Page Name',
      minWidth: 350,
      headerComponentFramework: CustomHeaderPageName,
    },
    {
      field: 'title',
      filter: true,
      headerName: 'Title',
      minWidth: 350,
      headerComponentFramework: CustomHeaderName,
    },
    {
      headerName: 'Action',
      headerComponentFramework: CustomHeaderAction,
      minWidth: 300,
      cellRenderer: ActionRenderer,  // Use ActionRenderer component
    },
  ];
  
  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();

  const gridRef = React.useRef();

  const defaultColDef = React.useMemo(() => ({
    sortable: true,
  }));

  React.useEffect(() => {
    if (isAuthorized) {
      getAllInfoContents(selectedCompany.id);
    }

    return () => {
      source.cancel('Aborting all previous operations.');
    };
  }, [isAuthorized, selectedCompany]);

  const getAllInfoContents = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.infoContents}/company/${companyId}`,
        {
          //const res = await jwtAxios.get(`${API_ROUTS.infoContents}`, {
          cancelToken: source.token,
        },
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no info contents'));
          setInfoContent([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setInfoContent(reversed);
        }
        setIsLoading(() => false);
      } else {
        setInfoContent([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setInfoContent([]);
    }
    setIsLoading(() => false);
  };

  const handleRedirectAddInfoContent = () => {
    Router.push('/company-builder/add-info-content');
  };

  const handleRedirectEditInfoContent = (params) => {
    Router.push(`/company-builder/add-info-content?id=${params.data?.id}`);
  };

  const handleRedirectViewInfoContent = (params) => {
    Router.push(`/company-builder/view-info-content?id=${params.data?.id}`);
  };

  const onFilterTextBoxChanged = useCallback(() => {
    const filterText = document.getElementById("filter-text-box").value;
    gridRef.current.api.setGridOption("quickFilterText", filterText);
    const totalResults = gridRef.current.api.getDisplayedRowCount();
    if (!isEmptyNullUndefined(infoContent) && infoContent.length > 0) {
      if (totalResults === 0 && !isEmptyNullUndefined(filterText)) {
        setOverlayMessage('No Record Found');
        gridRef.current.api.showNoRowsOverlay();
      } else if (totalResults !== 0) {
        setOverlayMessage('No Rows To Show');
        gridRef.current.api.hideOverlay();
      }
    }
  }, []);

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (!isAuthorized) {
    return <Error403 />;
  }

  return (
      <AppAnimate animation='transition.slideUpIn' delay={500}>
        <AppPageMeta />
        <h2 style={{marginBottom: 20}}>
          <IntlMessages id='info.infoContents' />
        </h2>
        <AppCard>
          <Stack style={{width: '100%'}}>
            <Stack direction='row' sx={{mb: 2}} justifyContent={'end'}>
              <TextField
                //size='small'
                sx={{width: 200, mr: 2}}
                id="filter-text-box"
                onInput={onFilterTextBoxChanged}
                type={'search'}
                name='search'
                label={<IntlMessages id='common.button.Search' />}
                variant='outlined'
              />
              {isAllowedUser(permissionName.CREATE) && (
                <Button
                  sx={{mr: 2}}
                  variant='outlined'
                  onClick={() => handleRedirectAddInfoContent()}
                >
                  <IntlMessages id='info.addInfoContent' />
                </Button>
              )}
            </Stack>
            {isLoading ? (
              domCreactionGridSkeletonLoader()
            ) : (
              <Stack
                className='ag-theme-alpine'
                style={{height: 525, width: '100%'}}
              >
                <AgGridReact
                  ref={gridRef}
                  rowData={infoContent}
                  columnDefs={columnDefs}
                  defaultColDef={defaultColDef}
                  animateRows={true}
                  pagination={true}
                  paginationPageSize={10}
                  overlayLoadingTemplate={
                    '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'
                  }
                  overlayNoRowsTemplate={`<span class="ag-overlay-loading-center">${overlayMessage}</span>`}
                />
              </Stack>
            )}
          </Stack>

          {alertProps.isHideShow && (
            <AlertDialog
              alertProps={alertProps}
              handleYes={() => handleAlertYes()}
              handleNo={() => handleAlertNo()}
            />
          )}
        </AppCard>
        <AppInfoView />
      </AppAnimate>
  );
};

export default InfoContents;
