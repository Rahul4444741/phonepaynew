import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import AppAnimate from '../../../../@crema/core/AppAnimate';
import AppPageMeta from '../../../../@crema/core/AppPageMeta';
import { AppCard, AppInfoView } from '../../../../@crema';
import Stack from '@mui/material/Stack';
import { DesktopDatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import TextField from '@mui/material/TextField';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import {
  getCompanyDateFormatForInputs,
  apiCatchErrorMessage,
  isEmptyNullUndefined,
} from '../../../../shared/utils/CommonUtils';
import Button from '@mui/material/Button';
import Router, { useRouter } from 'next/router';
import { fetchError, showMessage } from '../../../../redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import { API_ROUTS } from 'shared/constants/ApiRouts';
import FormHelperText from '@mui/material/FormHelperText';
import { footerButton } from 'shared/constants/AppConst';
import Card from '@mui/material/Card';
import IntlMessages from '@crema/utility/IntlMessages';
import { CircularProgress } from '@mui/material';
import axios from 'axios';

const textFieldStyled = {
  backgroundColor: 'white',
  mb: 2,
  width: {xs: '100%', xl: '60%', md: '75%'},
};

const AddJobCode = () => {
  const router = useRouter();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const {id, view} = router.query;
  const dispatch = useDispatch();

  const initialJobCode = {
    id: null,
    status: null,
    // name: null,
    jobTitle:null,
    companyId: null,
    effectiveDate: null,
    breakoutName: null,
    peerGroupName: null,
    monetaryUnit: null,
    jobModule: null,
    jobFunction: null,
    jobArea: null,
    jobFocus: null,
    jobCategory: null,
    jobFamily: null,
    jobLevel: null,
    jobCode: null,
    techOrNonTech: null,
    roleType: null,
  };

  const initialJobCodeError = {
    status: {isError: false, errorMessage: ''},
    // name: {isError: false, errorMessage: ''},
    jobTitle: {isError: false, errorMessage: ''},
    companyId: {isError: false, errorMessage: ''},
    effectiveDate: {isError: false, errorMessage: ''},
    breakoutName: {isError: false, errorMessage: ''},
    peerGroupName: {isError: false, errorMessage: ''},
    monetaryUnit: {isError: false, errorMessage: ''},
    jobModule: {isError: false, errorMessage: ''},
    jobFunction: {isError: false, errorMessage: ''},
    jobArea: {isError: false, errorMessage: ''},
    jobFocus: {isError: false, errorMessage: ''},
    jobCategory: {isError: false, errorMessage: ''},
    jobFamily: {isError: false, errorMessage: ''},
    jobLevel: {isError: false, errorMessage: ''},
    jobCode: {isError: false, errorMessage: ''},
    techOrNonTech: {isError: false, errorMessage: ''},
    roleType: {isError: false, errorMessage: ''},
  };

  const [jobCode, setJobCode] = React.useState(initialJobCode);
  const [jobCodeError, setJobCodeError] = React.useState(initialJobCodeError);
  const [loading, setLoading] = React.useState(false);
  const [isEdit, setIsEdit] = React.useState(false);

  const [isView, setIsView] = React.useState(false);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  React.useEffect(() => {
    if (!isEmptyNullUndefined(id)) {
      if (view || view == 'true') {
        getJobCodeDetails(id);
        setIsView(true);
      } else {
        getJobCodeDetails(id);
        setIsEdit(true);
      }
    }
    return () => {
      source2.cancel('Aborting all previous operations.');
    };
  }, []);

  const getJobCodeDetails = async (Id) => {
    try {
      const res = await jwtAxios.get(`${API_ROUTS.JobCode}?id=${Id}`, {
        cancelToken: source.token,
      });

      if (res.status == 200) {
        setJobCode(res.data);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
    }
  };

  const handleChangeJobCode = (event, fieldType, name) => {
    const tempJobCode = {...jobCode};
    const tempError = {...jobCodeError};

    if (fieldType == 'textfield' || fieldType == 'dropdown' || fieldType == 'radio') {
      tempJobCode[event.target.name] = event.target.value;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
    } else if (fieldType == 'date') {
      tempJobCode[name] = event;
      tempError[name].isError = false;
      tempError[name].errorMessage = '';
    }

    setJobCode(tempJobCode);
    setJobCodeError(tempError);
  };

  const validateJobCode = () => {
    let isValid = true;
    const tempError = {...jobCodeError};

    if (isEmptyNullUndefined(jobCode.status)) {
      tempError.status.isError = true;
      tempError.status.errorMessage = 'Please select status';
      isValid = false;
    }

    if (isEmptyNullUndefined(jobCode.jobCode)) {
      tempError.jobCode.isError = true;
      tempError.jobCode.errorMessage = 'Please enter code';
      isValid = false;
    }

    if (isValid) {
      if (isEdit) {
        updateForm();
      } else {
        submitForm();
      }
    } else {
      setJobCodeError(() => tempError);
    }
  };

  const submitForm = async () => {
    setLoading(() => true);

    let payload = {
      ...jobCode,
      companyId: selectedCompany?.id,
    };

    try {
      const response = await jwtAxios.post(`${API_ROUTS.JobCode}`, payload);
      if (response.status == 200) {
        dispatch(showMessage('Job code submitted successfully..!'));
        Router.push(`/company-builder/job-code`);
        setLoading(() => false);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
      setLoading(() => false);
    }
  };

  const updateForm = async () => {
    setLoading(() => true);

    let payload = {
      ...jobCode,
      companyId: selectedCompany?.id,
    };

    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.JobCode}/${jobCode.id}`,
        payload,
      );
      if (response.status == 200 || response.status == 201) {
        dispatch(showMessage('Job code updated successfully..!'));
        Router.push(`/company-builder/job-code`);
        setLoading(() => false);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
      setLoading(() => false);
    }
  };

  const getTitle = () => {
    if (isView) {
      return "View Job Code";
    } else if (!isEdit) {
      return "Add Job Code";
    } else {
      return "Edit Job Code";
    }
  };


  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        {getTitle()}
      </h2>

      <AppCard>
        <Stack
          sx={{display: 'flex', justifyContent: 'center', alignItems: 'center'}}
        >
          <Card
            variant='outlined'
            sx={{width: '80%', boxShadow: 1, p: 2, mb: 10}}
          >
            <Stack>
              {/* NAME*********************************************************************************** */}
              {/* <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Job Title:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <TextField
                    size='small'
                    name='name'
                    disabled={isView}
                    label={'Title'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.name?.isError}
                    helperText={jobCodeError.name?.errorMessage}
                    value={jobCode.name ? jobCode.name : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'red',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack> */}
              {/* jobCode*********************************************************************************** */}
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Job Code:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <TextField
                    size='small'
                    name='jobCode'
                    disabled={isView}
                    label={'Code'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.jobCode?.isError}
                    helperText={jobCodeError.jobCode?.errorMessage}
                    value={jobCode.jobCode ? jobCode.jobCode : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'red',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack>
              {/* STATUS *********************************************************************************** */}
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Job Code Status:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <FormControl
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'red',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  >
                    <InputLabel size='small' id='status'>
                      <IntlMessages id='configuration.dialogbox.Status' />
                    </InputLabel>
                    <Select
                      size='small'
                      name='status'
                      disabled={isView}
                      label={
                        <IntlMessages id='configuration.dialogbox.Status' />
                      }
                      labelId='status'
                      value={jobCode?.status || ''}
                      error={jobCodeError.status?.isError}
                      helperText={jobCodeError.status?.errorMessage}
                      onChange={(event) =>
                        handleChangeJobCode(event, 'dropdown')
                      }
                      variant='outlined'
                      sx={{...textFieldStyled, width: '100%'}}
                    >
                      <MenuItem key='Active' value='ACTIVE'>
                        <IntlMessages id='configuration.dialogbox.Status.Active' />
                      </MenuItem>
                      <MenuItem key='Inactive' value='INACTIVE'>
                        <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                      </MenuItem>
                    </Select>
                    <FormHelperText style={{color: '#d32f2f'}}>
                      {jobCodeError.status.errorMessage}
                    </FormHelperText>
                  </FormControl>
                </Stack>
              </Stack>
               {/*JOB TITLE*********************************************************************************** */}
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Job Title:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <TextField
                    size='small'
                    name='jobTitle'
                    disabled={isView}
                    label={'Job Title'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.jobTitle?.isError}
                    helperText={jobCodeError.jobTitle?.errorMessage}
                    value={jobCode.jobTitle ? jobCode.jobTitle : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack>
              {/* EFFECTIVE DATE*********************************************************************************** */}
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>
                    {/* <IntlMessages id='calibration.CalibrationPeriod' />: */}
                    Data Effective Date:
                  </Stack>
                </Stack>

                <Stack direction={'column'} sx={{width: '60%'}}>
                  {/* <Stack direction={'column'}> */}
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DesktopDatePicker
                      //minDate={new Date()}
                      inputFormat={getCompanyDateFormatForInputs(
                        selectedCompany,
                      )}
                      value={jobCode.effectiveDate}
                      label={'Date'}
                      name='effectiveDate'
                      disabled={isView}
                      onChange={(event) =>
                        handleChangeJobCode(event, 'date', 'effectiveDate')
                      }
                      renderInput={(params) => (
                        <TextField
                          id='startdate-textField'
                          variant='outlined'
                          size='small'
                          sx={{
                            ...textFieldStyled,
                            '& .MuiOutlinedInput-root': {
                              '& fieldset': {
                                borderLeftColor: 'gray',
                                borderLeftWidth: 3,
                              },
                            },
                          }}
                          {...params}
                        />
                      )}
                    />
                  </LocalizationProvider>
                  {jobCodeError.effectiveDate?.isError && (
                    <FormHelperText sx={{color: '#d32f2f', ml: 2}}>
                      {jobCodeError.effectiveDate?.errorMessage}
                    </FormHelperText>
                  )}
                  {/* </Stack> */}
                </Stack>
              </Stack>
              {/* BREAKOUTNAME*********************************************************************************** */}
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Breakout Name:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <TextField
                    size='small'
                    name='breakoutName'
                    disabled={isView}
                    label={'Breakout Name'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.breakoutName?.isError}
                    helperText={jobCodeError.breakoutName?.errorMessage}
                    value={jobCode.breakoutName ? jobCode.breakoutName : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack>
              {/* PEERGROUPNAME*********************************************************************************** */}
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Peer Group Name:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <TextField
                    size='small'
                    name='peerGroupName'
                    disabled={isView}
                    label={'Peer Group Name'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.peerGroupName?.isError}
                    helperText={jobCodeError.peerGroupName?.errorMessage}
                    value={jobCode.peerGroupName ? jobCode.peerGroupName : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack>
              {/* MONETARYUNIT*********************************************************************************** */}
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Monetary Unit:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <TextField
                    size='small'
                    name='monetaryUnit'
                    disabled={isView}
                    label={'Unit'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.monetaryUnit?.isError}
                    helperText={jobCodeError.monetaryUnit?.errorMessage}
                    value={jobCode.monetaryUnit ? jobCode.monetaryUnit : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack>
              {/* JOBMODULE*********************************************************************************** */}
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Job Module:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <TextField
                    size='small'
                    name='jobModule'
                    disabled={isView}
                    label={'Module'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.jobModule?.isError}
                    helperText={jobCodeError.jobModule?.errorMessage}
                    value={jobCode.jobModule ? jobCode.jobModule : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack>
              {/* JOBFUNCTION*********************************************************************************** */}
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Job Function:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <TextField
                    size='small'
                    name='jobFunction'
                    disabled={isView}
                    label={'Function'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.jobFunction?.isError}
                    helperText={jobCodeError.jobFunction?.errorMessage}
                    value={jobCode.jobFunction ? jobCode.jobFunction : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack>
              {/* JOBAREA*********************************************************************************** */}
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Job Area:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <TextField
                    size='small'
                    name='jobArea'
                    disabled={isView}
                    label={'Area'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.jobArea?.isError}
                    helperText={jobCodeError.jobArea?.errorMessage}
                    value={jobCode.jobArea ? jobCode.jobArea : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack>
              {/* JOBFOCUS*********************************************************************************** */}
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Job Focus:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <TextField
                    size='small'
                    name='jobFocus'
                    disabled={isView}
                    label={'Focus'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.jobFocus?.isError}
                    helperText={jobCodeError.jobFocus?.errorMessage}
                    value={jobCode.jobFocus ? jobCode.jobFocus : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack>
              {/* JOBCATEGORY*********************************************************************************** */}
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Job Category:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <TextField
                    size='small'
                    name='jobCategory'
                    disabled={isView}
                    label={'Category'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.jobCategory?.isError}
                    helperText={jobCodeError.jobCategory?.errorMessage}
                    value={jobCode.jobCategory ? jobCode.jobCategory : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack>
              {/* JOBLEVEL*********************************************************************************** */}
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Job Level:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <TextField
                    size='small'
                    name='jobLevel'
                    disabled={isView}
                    label={'Level'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.jobLevel?.isError}
                    helperText={jobCodeError.jobLevel?.errorMessage}
                    value={jobCode.jobLevel ? jobCode.jobLevel : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack>
              {/* JOBFAMILY*********************************************************************************** */}
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Job Family:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <TextField
                    size='small'
                    name='jobFamily'
                    disabled={isView}
                    label={'Family'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.jobFamily?.isError}
                    helperText={jobCodeError.jobFamily?.errorMessage}
                    value={jobCode.jobFamily ? jobCode.jobFamily : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack>
              {/* TECH/NONTECH*********************************************************************************** */}
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>Select Tech/Non-Tech:</Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  <FormControl
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  >
                    <InputLabel size='small' id='tech'>
                      Tech/Non-Tech
                    </InputLabel>
                    <Select
                      size='small'
                      name='techOrNonTech'
                      disabled={isView}
                      label='Tech/Non-Tech'
                      labelId='tech'
                      value={jobCode?.techOrNonTech || ''}
                      error={jobCodeError.techOrNonTech?.isError}
                      helperText={jobCodeError.techOrNonTech?.errorMessage}
                      onChange={(event) =>
                        handleChangeJobCode(event, 'dropdown')
                      }
                      variant='outlined'
                      sx={{...textFieldStyled, width: '100%'}}
                    >
                      <MenuItem key='TECH' value='TECH'>
                        TECH
                      </MenuItem>
                      <MenuItem key='NONTECH' value='NONTECH'>
                        NON-TECH
                      </MenuItem>
                    </Select>
                    <FormHelperText style={{color: '#d32f2f'}}>
                      {jobCodeError.techOrNonTech.errorMessage}
                    </FormHelperText>
                  </FormControl>
                </Stack>
              </Stack>
              {/* ROLETYPE*********************************************************************************** */}
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '40%', marginLeft: '50px'}}>
                  <Stack fontWeight={500}>
                    {/* Select Role Type(IC/M): */}
                    Role Type
                  </Stack>
                </Stack>

                <Stack direction={'row'} sx={{width: '60%'}}>
                  {/* <FormControl
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'red',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  >
                    <InputLabel size='small' id='status'>
                      Role Type
                    </InputLabel>
                    <Select
                      size='small'
                      name='status'
                      disabled={isView}
                      label={'Role Type'}
                      labelId='status'
                      value={jobCode?.status || ''}
                      error={jobCodeError.status?.isError}
                      helperText={jobCodeError.status?.errorMessage}
                      onChange={(event) =>
                        handleChangeJobCode(event, 'dropdown')
                      }
                      variant='outlined'
                      sx={{...textFieldStyled, width: '100%'}}
                    >
                      <MenuItem key='Active' value='ACTIVE'>
                        <IntlMessages id='configuration.dialogbox.Status.Active' />
                      </MenuItem>
                      <MenuItem key='Inactive' value='INACTIVE'>
                        <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                      </MenuItem>
                    </Select>
                    <FormHelperText style={{color: '#d32f2f'}}>
                      {jobCodeError.status.errorMessage}
                    </FormHelperText>
                  </FormControl> */}
                  <TextField
                    size='small'
                    name='roleType'
                    disabled={isView}
                    label={'Role Type'}
                    onChange={(event) =>
                      handleChangeJobCode(event, 'textfield')
                    }
                    variant='outlined'
                    error={jobCodeError.roleType?.isError}
                    helperText={jobCodeError.roleType?.errorMessage}
                    value={jobCode.roleType ? jobCode.roleType : ''}
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'gray',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  />
                </Stack>
              </Stack>
              {/* *********************************************************************************** */}
            </Stack>
          </Card>
        </Stack>
        {/* ////////add Stack for fixed////// */}
        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0,
          }}
        >
          <Stack
            direction='row'
            justifyContent='end'
            alignItems='center'
            spacing={2}
            sx={{
              pt: 5,
              ml: 3,
              //// add marging for fixed stack///
              margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
            }}
          >
            <Button
              color={footerButton.back.color}
              variant={footerButton.back.variant}
              sx={footerButton.back.sx}
              size={footerButton.back.size}
              onClick={() => Router.push('/company-builder/job-code')}
            >
              <IntlMessages id='common.button.Back' />
            </Button>
            {!isView && (
              <Button
                color={footerButton.submit.color}
                variant={footerButton.submit.variant}
                sx={footerButton.submit.sx}
                size={footerButton.submit.size}
                disabled={loading}
                onClick={() => {
                  validateJobCode();
                }}
              >
                {loading ? (
                  <CircularProgress
                    sx={{
                      margin: '0px 1rem',
                      color: '#000000',
                      width: '25px !important',
                      height: '25px !important',
                    }}
                  />
                ) : (
                  <Stack>
                    {isEdit ? (
                      <IntlMessages id='common.button.Update' />
                    ) : (
                      <IntlMessages id='common.button.Submit' />
                    )}
                  </Stack>
                )}
              </Button>
            )}
          </Stack>
        </Stack>
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default AddJobCode;
