export const pageNameSequence = [
  'Home',
  'My Profile',
  'Self Assessment',
  'My Assessment',
  'Request Feedback',
  'Approve Feedback',
  'Give Feedback',
  'Manager Feedback',
  'My Team',
  'Rating Calibration',
  'Functional Leader',
  'Miscellaneous',
];
// Function to sort grouped data based on sequence
export const sortGroupedData = (groupedData, sequence) => {
  const sortedGroupedData = {};
  sequence.forEach((groupName) => {
    if (groupedData[groupName]) {
      sortedGroupedData[groupName] = groupedData[groupName];
      delete groupedData[groupName]; // Remove already added group
    }
  });

  // Append remaining groups to the end
  for (const groupName in groupedData) {
    sortedGroupedData[groupName] = groupedData[groupName];
  }

  return sortedGroupedData;
};