import React, {useEffect, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import AppAnimate from '../../../../@crema/core/AppAnimate';
import AppPageMeta from '../../../../@crema/core/AppPageMeta';
import {AppCard, AppInfoView} from '../../../../@crema';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import FormControl from '@mui/material/FormControl';
import Typography from '@mui/material/Typography';
import {
  isEmptyNullUndefined,
  apiCatchErrorMessage,
} from '../../../../shared/utils/CommonUtils';
import Button from '@mui/material/Button';
import ListItemText from '@mui/material/ListItemText';
import Router, {useRouter} from 'next/router';
import {showMessage, fetchError, showInfo} from '../../../../redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {footerButton} from 'shared/constants/AppConst';
import Card from '@mui/material/Card';
import IntlMessages from '@crema/utility/IntlMessages';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import {
  CardContent,
  Checkbox,
  CircularProgress,
  FormControlLabel,
  FormHelperText,
  Grid,
  InputLabel,
  ListItem,
  MenuItem,
  Select,
  Tooltip,
} from '@mui/material';
import axios from 'axios';

import {pageNameSequence, sortGroupedData} from './Util';
import GenericSelectWithSearch from 'modules/Common/GenericSelectWithSearch';
import {domCreactionHeaderTitle} from 'shared/utils/domCreaction';
import {getALLRolesPermissions} from 'redux/actions/RolesPermissions';

const iconButtonStyled = {padding: '2px 10px'};

const textFieldStyled = {
  backgroundColor: 'white',
  mb: 2,
  width: {xs: '100%', xl: '60%', md: '75%'},
};

const AddRolePermission = () => {
  const router = useRouter();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const {RolesAndPermissionsData} = useSelector(
    ({RolesPermissions}) => RolesPermissions,
  );

  const {name, status} = router.query;
  const dispatch = useDispatch();

  const intialForm = {
    name: '',
    status: '',
    companyId: selectedCompany?.id,
    customQueryId: null,
    dataQueryId: null,
    permissions: null,
  };
  const initialFormError = {
    name: {isError: false, errorMessage: ''},
    status: {isError: false, errorMessage: ''},
    customQueryId: {isError: false, errorMessage: ''},
    dataQueryId: {isError: false, errorMessage: ''},
    permissions: {isError: false, errorMessage: ''},
  };
  const [formData, setFormData] = useState(intialForm);
  const [formError, setFormError] = useState(initialFormError);

  const [queryList, setQueryList] = useState(null);
  const [isEdit, setIsEdit] = useState(false);
  const [permissions, setPermissions] = useState([]);
  const [isLoading, setIsLoading] = React.useState(true);
  const [groupedPermissions, setGroupedPermissions] = useState(null);
  const [selectedPermissions, setSelectedPermissions] = useState([]);
  const [submitLoader, setSubmitLoader] = useState(false);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();

  useEffect(() => {
    getAllActiveQuery(selectedCompany.id);
    getAllActivePermissions(selectedCompany.id);
    if (!isEmptyNullUndefined(name) && !isEmptyNullUndefined(status)) {
      dispatch(
        getALLRolesPermissions({
          companyId: selectedCompany.id,
          status: status,
        }),
      );
    }
  }, []);

  useEffect(() => {
    const groupedData = permissions?.reduce((acc, item) => {
      const {pageName, ...rest} = item;
      if (!acc[pageName]) {
        acc[pageName] = [rest];
      } else {
        acc[pageName].push(rest);
      }
      return acc;
    }, {});

    // Sort and concatenate the groups according to the desired sequence
    const sortedArray = sortGroupedData(groupedData, pageNameSequence);

    setGroupedPermissions(sortedArray);
  }, [permissions]);

  React.useEffect(() => {
    if (
      !isEmptyNullUndefined(name) &&
      !isEmptyNullUndefined(RolesAndPermissionsData)
    ) {
      let editRole = RolesAndPermissionsData.find(
        (role) => role.name.trim() == name.trim(),
      );

      if (!isEmptyNullUndefined(editRole)) {
        setFormData(editRole);
        setSelectedPermissions(editRole.permissions);
        setIsEdit(() => true);
      } else {
        dispatch(showInfo(`Role not found with name - ${name}`));
        Router.push(`/company-builder/manage-roles-permissions`);
      }
    }
  }, [RolesAndPermissionsData]);

  const getValueById = (queryList, id) => {
    if (!isEmptyNullUndefined(queryList) && !isEmptyNullUndefined(id)) {
      let index = queryList.findIndex((element) => element.id === id);
      if (index !== -1) {
        return queryList[index].query;
      } else {
        return null;
      }
    }
  };

  const getAllActiveQuery = async (companyId) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.customquery}?companyId=${companyId}&relationTable=Employee&status=ACTIVE`,
        {
          cancelToken: source.token,
        },
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no record'));
          setQueryList([]);
        } else {
          setQueryList(res.data.reverse());
        }
      } else {
        setQueryList([]);
      }
    } catch (e) {
      if (!axios.isCancel(e)) {
        apiCatchErrorMessage(e, dispatch, fetchError);
      }
      setQueryList([]);
    }
  };
  const getAllActivePermissions = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(`${API_ROUTS.get_permissions}`, {
        cancelToken: source.token,
      });

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no permissions for selected company'));
          setPermissions([]);
        } else {
          let filterdArray = res.data?.filter(
            (item) => item.type == 'Employee',
          );
          setPermissions(filterdArray);
        }
        setIsLoading(() => false);
      } else {
        setPermissions([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setPermissions([]);
    }
    setIsLoading(() => false);
  };

  const handleChange = (event, fieldType) => {
    const tempFormData = {...formData};
    const tempError = {...formError};

    if (fieldType == 'textfield' || fieldType == 'dropdown') {
      tempFormData[event.target.name] = event.target.value;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
    }
    setFormData(() => tempFormData);
    setFormError(() => tempError);
  };

  const handleSelectAllPages = (event) => {
    const {checked} = event.target;

    if (checked) {
      // Select all permissions across all groups
      const allPermissions = Object.values(groupedPermissions).flatMap(
        (items) => items.map((item) => item.name),
      );
      setSelectedPermissions(allPermissions);
    } else {
      // Deselect all permissions
      setSelectedPermissions([]);
    }
  };

  const handleSelectAll = (pageName) => {
    const permissions = groupedPermissions[pageName].map((item) => item.name);
    let updatedSelectedPermissions = new Set(selectedPermissions);

    if (
      permissions.every((permission) =>
        updatedSelectedPermissions.has(permission),
      )
    ) {
      // If all permissions in this group are already selected, deselect them
      permissions.forEach((permission) =>
        updatedSelectedPermissions.delete(permission),
      );
    } else {
      // If not all are selected, select all in this group
      permissions.forEach((permission) =>
        updatedSelectedPermissions.add(permission),
      );
    }

    setSelectedPermissions([...updatedSelectedPermissions]);
  };

  const handleCheckboxChange = (name) => {
    let updatedPermissions = new Set(selectedPermissions);

    if (updatedPermissions.has(name)) {
      updatedPermissions.delete(name);
    } else {
      updatedPermissions.add(name);
    }

    setSelectedPermissions([...updatedPermissions]);
  };

  const isGroupSelectAllChecked = (pageName) => {
    const permissions = groupedPermissions[pageName].map((item) => item.name);
    return permissions.every((permission) =>
      selectedPermissions.includes(permission),
    );
  };

  const isSelectAllChecked = () => {
    if (!groupedPermissions || !selectedPermissions) {
      return false;
    }

    return Object.values(groupedPermissions).every((items) =>
      items.every((item) => selectedPermissions.includes(item.name)),
    );
  };

  const validateFormData = () => {
    let tempFormError = {...formError};
    let isValid = true;

    if (isEmptyNullUndefined(formData.name)) {
      tempFormError.name.isError = true;
      tempFormError.name.errorMessage = (
        <IntlMessages id='error.pleaseEnterName' />
      );
      isValid = false;
    }
    if (isEmptyNullUndefined(formData.status)) {
      tempFormError.status.isError = true;
      tempFormError.status.errorMessage = (
        <IntlMessages id='error.PleaseSelectStatus' />
      );
      isValid = false;
    }
    if (isEmptyNullUndefined(formData.customQueryId)) {
      tempFormError.customQueryId.isError = true;
      tempFormError.customQueryId.errorMessage = (
        <IntlMessages id='error.pleaseSelectCustomEligibilityQuery' />
      );
      isValid = false;
    }
    if (isEmptyNullUndefined(formData.dataQueryId)) {
      tempFormError.dataQueryId.isError = true;
      tempFormError.dataQueryId.errorMessage = (
        <IntlMessages id='error.pleaseSelectCustomDataQuery' />
      );
      isValid = false;
    }
    if (isValid) {
      submitForm();
    } else {
      setFormError(() => tempFormError);
    }
  };

  const submitForm = async () => {
    setSubmitLoader(true);
    let payload = {
      ...formData,
      permissions: selectedPermissions,
    };

    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.add_authority}`,
        payload,
      );
      if (response.status == 200) {
        Router.push(`/company-builder/manage-roles-permissions`);
        dispatch(showMessage('Role and Permissions added successfully..!'));
        setSubmitLoader(false);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
      setSubmitLoader(false);
    }
  };

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        {!isEdit ? (
          <h3>
            <IntlMessages id='roles.addRolesAndPermission' />
          </h3>
        ) : (
          <h3>
            <IntlMessages id='roles.editRolesAndPermission' />
          </h3>
        )}
      </h2>

      <AppCard sxStyle={{marginBottom: '20px'}}>
        <Stack sx={{mb: 10}}>
          <Stack justifyContent='flex-start' sx={{width: '100%'}}>
            {domCreactionHeaderTitle('Basic Info')}
          </Stack>
          <Stack
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
            style={{marginLeft: '50px'}}
          >
            <Stack fontWeight={500} width='40%'>
              {/* Enter Role Name : */}
              <IntlMessages id='roles.enterRoleName' /> :
            </Stack>
            <Stack width='60%'>
              <TextField
                id='outlined-basic'
                label={<IntlMessages id='roles.role' />}
                name='name'
                disabled={isEdit}
                variant='outlined'
                size='small'
                value={formData.name || ''}
                error={formError?.name?.isError}
                helperText={formError?.name?.errorMessage}
                onChange={(e) => handleChange(e, 'textfield')}
                sx={{
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                  width: '80%',
                }}
              />
            </Stack>
          </Stack>

          <Stack
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
            style={{marginLeft: '50px'}}
          >
            <Stack sx={{width: '40%'}}>
              <Stack fontWeight={500}>Status :</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '60%'}}>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                  width: '80%',
                }}
              >
                <InputLabel size='small' id='status'>
                  <IntlMessages id='configuration.dialogbox.Status' />
                </InputLabel>
                <Select
                  size='small'
                  name='status'
                  // disabled={isView}
                  label={<IntlMessages id='configuration.dialogbox.Status' />}
                  labelId='status'
                  value={formData?.status || ''}
                  error={formError.status?.isError}
                  helperText={formError.status?.errorMessage}
                  onChange={(event) => handleChange(event, 'dropdown')}
                  variant='outlined'
                  sx={{...textFieldStyled, width: '100%'}}
                >
                  <MenuItem key='Active' value='ACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Active' />
                  </MenuItem>
                  <MenuItem key='Inactive' value='INACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                  </MenuItem>
                </Select>
                <FormHelperText style={{color: '#d32f2f'}}>
                  {formError.status.errorMessage}
                </FormHelperText>
              </FormControl>
            </Stack>
          </Stack>

          {/* eligibility query */}
          <Stack
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='flex-start'
            alignItems='flex-start'
            spacing={2}
            style={{marginLeft: '50px'}}
          >
            <Stack fontWeight={500} width='40%'>
              <IntlMessages id='roles.selectCustomQueryForEligibilty' /> :
            </Stack>
            <Stack width='60%'>
              <GenericSelectWithSearch
                label={<IntlMessages id='roles.eligibilityQuery' />}
                name={'customQueryId'}
                value={formData.customQueryId || ''}
                error={formError.customQueryId.isError}
                helperText={formError.customQueryId.errorMessage}
                handleChange={handleChange}
                optionList={queryList}
                labelName={'variableName'}
                customStyles={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                  width: '80%',
                }}
              />

              {formData.customQueryId && (
                <FormControl
                  sx={{mt: 5, mb: 2, width: '80%', minWidth: '10rem'}}
                >
                  <TextField
                    disabled
                    size='small'
                    value={getValueById(queryList, formData.customQueryId)}
                    id='outlined-basic'
                    variant='outlined'
                    multiline
                    rows={2}
                  />
                </FormControl>
              )}
            </Stack>
          </Stack>
          {/* data query */}
          <Stack
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='flex-start'
            alignItems='flex-start'
            spacing={2}
            style={{marginLeft: '50px'}}
          >
            <Stack fontWeight={500} width='40%'>
              <IntlMessages id='roles.selectCustomQueryForDataAccess' /> :
            </Stack>
            <Stack width='60%'>
              <GenericSelectWithSearch
                label={<IntlMessages id='roles.dataQuery' />}
                name={'dataQueryId'}
                value={formData.dataQueryId || ''}
                error={formError.dataQueryId.isError}
                helperText={formError.dataQueryId.errorMessage}
                handleChange={handleChange}
                optionList={queryList}
                labelName={'variableName'}
                customStyles={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                  width: '80%',
                }}
              />
              {formData.dataQueryId && (
                <FormControl
                  sx={{mt: 5, mb: 2, width: '80%', minWidth: '10rem'}}
                >
                  <TextField
                    disabled
                    size='small'
                    value={getValueById(queryList, formData.dataQueryId)}
                    id='outlined-basic'
                    variant='outlined'
                    multiline
                    rows={2}
                  />
                </FormControl>
              )}
            </Stack>
          </Stack>
        </Stack>
      </AppCard>
      <AppCard>
        <Stack sx={{mb: 10}}>
          <Stack justifyContent='flex-start' sx={{width: '100%'}}>
            {/* <Typography fontWeight={500} variant='h4'>
                <IntlMessages id='roles.selectPermissionsForRole' /> :
              </Typography> */}
            {domCreactionHeaderTitle(
              <IntlMessages id='roles.selectPermissionsForRole' />,
            )}
          </Stack>
          <Stack
            width='90%'
            justifyContent='center'
            style={{margin: 'auto', marginTop: '50px'}}
          >
            <Stack justifyContent='flex-end' sx={{width: '100%'}}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={isSelectAllChecked()}
                    onChange={(e) => handleSelectAllPages(e)}
                    color='primary'
                  />
                }
                // label='Select All Permissions'
                label={<IntlMessages id='roles.selectAllPermissions' />}
                sx={{alignSelf: 'flex-end'}}
              />
            </Stack>

            {groupedPermissions &&
              Object.entries(groupedPermissions).map(([pageName, items]) => (
                <Card
                  key={pageName}
                  // style={{marginBottom: '20px', backgroundColor: '#fafafa'}}
                  sx={{
                    boxShadow: 2,
                    marginBottom: '20px',
                    backgroundColor: '#f0f0f0',
                    transition: 'box-shadow 0.3s ease-in-out',
                    '&:hover': {
                      boxShadow: 4, // Elevation on hover
                      backgroundColor: '#f0f0f0',
                      border: '1px solid gray',
                    },
                  }}
                >
                  <Stack
                    justifyContent='flex-start'
                    sx={{marginTop: '10px', width: '100%'}}
                  >
                    <Typography sx={{ml: 10}} fontWeight={500} variant='h4'>
                      {pageName}
                    </Typography>
                  </Stack>
                  <Stack justifyContent='flex-end' sx={{width: '100%'}}>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={isGroupSelectAllChecked(pageName)}
                          onChange={() => handleSelectAll(pageName)}
                        />
                      }
                      // label='Select All'
                      label={<IntlMessages id='roles.selectAll' />}
                      sx={{alignSelf: 'flex-end'}}
                    />
                  </Stack>
                  <CardContent>
                    <Grid container spacing={2}>
                      {items.map((item, index) => (
                        <Grid item xs={6} key={item.name}>
                          <ListItem>
                            <Checkbox
                              checked={selectedPermissions.includes(item.name)}
                              onChange={() => handleCheckboxChange(item.name)}
                            />
                            <ListItemText primary={item.name} />
                            <Tooltip title={item.descripition}>
                              <InfoOutlinedIcon
                                color='secondary'
                                fontSize='small'
                              />
                            </Tooltip>
                          </ListItem>
                        </Grid>
                      ))}
                    </Grid>
                  </CardContent>
                </Card>
              ))}
          </Stack>
        </Stack>
        {/* ////////add Stack for fixed////// */}
        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0,
          }}
        >
          <Stack
            direction='row'
            justifyContent='end'
            alignItems='center'
            spacing={2}
            sx={{
              pt: 5,
              ml: 3,
              //// add marging for fixed stack///
              margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
            }}
          >
            <Button
              color={footerButton.back.color}
              variant={footerButton.back.variant}
              sx={footerButton.back.sx}
              size={footerButton.back.size}
              onClick={() =>
                Router.push('/company-builder/manage-roles-permissions')
              }
            >
              <IntlMessages id='common.button.Back' />
            </Button>

            <Button
              color={footerButton.submit.color}
              variant={footerButton.submit.variant}
              sx={footerButton.submit.sx}
              size={footerButton.submit.size}
              disabled={submitLoader || isLoading}
              onClick={() => {
                validateFormData();
              }}
            >
              {submitLoader ? (
                <CircularProgress
                  sx={{
                    margin: '0px 1rem',
                    color: '#000000',
                    width: '25px !important',
                    height: '25px !important',
                  }}
                />
              ) : (
                <>
                  {isEdit ? (
                    <IntlMessages id='common.button.Update' />
                  ) : (
                    <IntlMessages id='common.button.Submit' />
                  )}
                </>
              )}
            </Button>
          </Stack>
        </Stack>
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default AddRolePermission;
