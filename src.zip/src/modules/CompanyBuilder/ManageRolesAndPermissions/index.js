import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard} from '../../../@crema';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import {AgGridReact} from 'ag-grid-react';
import {useDispatch, useSelector} from 'react-redux';
import AppInfoView from '../../../@crema/core/AppInfoView';
import {fetchStart, showMessage, fetchError, showInfo} from '../../../redux/actions';

import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {
  CircularProgress,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
} from '@mui/material';
import {
  isEmptyNullUndefined,
  buttonStyle,
  apiCatchErrorMessage,
  isAllowedUser,
} from 'shared/utils/CommonUtils';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import IntlMessages from '@crema/utility/IntlMessages';
import Router from 'next/router';
// import {getALLRolesPermissions} from 'redux/actions/RolesPermissions';
import AlertDialog from 'modules/Common/AlertDialog';
import {getALLCustomQueries} from 'redux/actions/CustomQuery';
import {useState} from 'react';
import {permissionName} from 'shared/utils/PermissionName';
import Error403 from 'modules/errorPages/Error403';
import {useCallback} from 'react';
import axios from 'axios';

const CustomHeaderName = () => <IntlMessages id='aggrid.tableHeader.Name' />;
const CustomHeaderStatus = () => (
  <IntlMessages id='aggrid.tableHeader.Status' />
);
const CustomHeaderCustomQueryEligibility = () => (
  <IntlMessages id='aggrid.tableHeader.EligibilityCustomQueries' />
);
const CustomHeaderCustomQueryDataAccess = () => (
  <IntlMessages id='aggrid.tableHeader.DataCustomQueries' />
);
const CustomHeaderAction = () => (
  <IntlMessages id='aggrid.tableHeader.Action' />
);

const ManageRolesAndPermissions = () => {
  const dispatch = useDispatch();

  let selectedCompany = useSelector(({company}) => company.selectedCompany);
 
  const {CustomQueries} = useSelector(({CustomQueries}) => CustomQueries);

  const [gridData, setGridData] = React.useState(null);
  const [isLoading, setIsLoading] = React.useState(null);
  const [overlayMessage, setOverlayMessage] = React.useState('No Rows To Show');
  const [submitLoader, setSubmitLoader] = useState(false);
  const [alertProps, setAlertProps] = React.useState({
    isHideShow: false,
    message: '',
    title: '',
    alertType: '',
    actionParams: null,
  });

  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);

  const [alignment, setAlignment] = React.useState('ACTIVE');

  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
  };

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  React.useEffect(() => {
    if (isAllowedUser(permissionName.MANAGE_ROLES_AND_PERMISSIONS)) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  const ActionRenderer = (params) => (
    <Stack direction='row'>
      {isAllowedUser(permissionName.UPDATE) && (
        <Button
          onClick={() => handleRedirectEditRolesPermissions(params)}
          style={buttonStyle}
        >
          <IntlMessages id='common.button.Edit' />
        </Button>
      )}

      {isAllowedUser(permissionName.DEACTIVATE) &&
        params.data.status === 'ACTIVE' && (
          <Button
            onClick={() => handleDeactivateConfirmation(params)}
            style={buttonStyle}
          >
            <IntlMessages id='common.button.Deactivate' />
          </Button>
        )}

      {isAllowedUser(permissionName.ACTIVATE) &&
        params.data.status === 'INACTIVE' && (
          <Button
            onClick={() => handleActivateConfirmation(params)}
            style={buttonStyle}
          >
            <IntlMessages id='common.button.Activate' />
          </Button>
        )}
      {/* {isAllowedUser(permissionName.DELETE) && (
        <Button
          onClick={() => handleDeleteConfirmation(params)}
          style={buttonStyle}
        >
          <IntlMessages id='common.button.Delete' />
        </Button>
      )} */}
    </Stack>
  );

  const columnDefs = [
    {
      field: 'name',
      filter: true,
      headerName: 'Name',
      minWidth: 200,
      headerComponentFramework: CustomHeaderName,
    },
    {
      field: 'customQueryId',
      filter: true,
      headerName: 'CustomQueryId',
      minWidth: 200,
      headerComponentFramework: CustomHeaderCustomQueryEligibility,
      cellRenderer: function (params) {
        return (
          <Stack direction='row'>
              {/* <div>{params.data.customQueryId}</div> */}
              <div>{getQueryNameById(params.data.customQueryId,CustomQueries)}</div>
          </Stack>
        );
      },
    },
    {
      field: 'dataQueryId',
      filter: true,
      headerName: 'DataQueryId',
      minWidth: 200,
      headerComponentFramework: CustomHeaderCustomQueryDataAccess,
      cellRenderer: function (params) {
        return (
          <Stack direction='row'>
              {/* <div>{params.data.dataQueryId}</div> */}
              <div>{getQueryNameById(params.data.dataQueryId,CustomQueries)}</div>
          </Stack>
        );
      },
    },
    {
      field: 'status',
      filter: true,
      headerName: 'Status',
      minWidth: 100,
      headerComponentFramework: CustomHeaderStatus,
      cellRenderer: function (params) {
        return (
          <Stack direction='row'>
            {params.data.status === 'ACTIVE' ? (
              <div style={{color: '#11C15B'}}>{params.data.status}</div>
            ) : (
              <div style={{color: '#D32F2F'}}>{params.data.status}</div>
            )}
          </Stack>
        );
      },
    },
    {
      headerName: 'Action',
      headerComponentFramework: CustomHeaderAction,
      minWidth: 240,
      cellRenderer: ActionRenderer, // Use ActionRenderer component
    },
  ];

  const handleRedirectAddRolesPermissions = () => {
    Router.push(`/company-builder/add-role-permissions`);
  };
  const handleRedirectEditRolesPermissions = (params) => {
    Router.push(
      `/company-builder/add-role-permissions?name=${params.data?.name}&status=${params.data.status}`,
    );
  };

  React.useEffect(() => {
    dispatch(fetchStart);
    if (
      isAuthorized &&
      selectedCompany != null &&
      selectedCompany != undefined
    ) {
      dispatch(getALLCustomQueries(selectedCompany.id));
      getAllActiveRole(selectedCompany.id);
    }
  }, [isAuthorized, selectedCompany]);

  const getQueryNameById = (queryId, list) => {
    const query = list.find((q) => q.id == queryId);
    return query?.variableName ? query?.variableName : null;
  };

  const gridRef = React.useRef();
  const defaultColDef = React.useMemo(() => ({
    sortable: true,
  }));

  const getAllActiveRole = async (companyId) => {
  
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.authPermissions}/${companyId}?status=ACTIVE`,
        {cancelToken: source.token},
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no roles for selected company'));
          setGridData([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setGridData(reversed);
        }
        setIsLoading(() => false);
      } else {
        setGridData([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setGridData([]);
    }
    setIsLoading(() => false);
  };
  const getAllInactiveRole = async (companyId) => {
   
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.authPermissions}/${companyId}?status=INACTIVE`,
        {cancelToken: source2.token},
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no roles for selected company'));
          setGridData([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setGridData(reversed);
        }
        setIsLoading(() => false);
      } else {
        setGridData([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setGridData([]);
    }
    setIsLoading(() => false);
  };

  const handleDeactivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = <IntlMessages id='warning.deactivateRole' />;

    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureDeactivate' /> {params.data.name} ?
      </span>
    );

    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleAlertYes = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.actionParams.data.status == 'ACTIVE' &&
      handleDeactivateRole(tempAlertProps.actionParams);
    tempAlertProps.actionParams.data.status == 'INACTIVE' &&
      handleActivateRole(tempAlertProps.actionParams);
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };

  const handleAlertNo = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };
  const handleDeactivateRole = async (params) => {
    let payload = {
      name: params.data.name,
      companyId: selectedCompany?.id,
      status: 'INACTIVE',
    };

    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.createPermissions}/update-status`,
        payload,
      );
      if (response.status == 200) {
        dispatch(showMessage('Role deactivate successfully..!'));
        getAllInactiveRole(selectedCompany.id);
        setAlignment('INACTIVE');
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleActivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = <IntlMessages id='warning.activateRole' />;
    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureActivate' /> {params.data.name} ?
      </span>
    );
    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleActivateRole = async (params) => {
    let payload = {
      name: params.data.name,
      companyId: selectedCompany?.id,
      status: 'ACTIVE',
    };
    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.createPermissions}/update-status`,
        payload,
      );
      if (response.status == 200) {
        dispatch(showMessage('Role activate successfully..!'));
        getAllActiveRole(selectedCompany.id);
        setAlignment('ACTIVE');
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  // DELETE CONFIRMATION
  // const handleDeleteConfirmation = (params) => {
  //   const tempAlertProps = {...alertProps};
  //   tempAlertProps.isHideShow = true;
  //   tempAlertProps.alertType = 'Confirmation';
  //   tempAlertProps.title = <IntlMessages id='warning.deleteRolePermissions' />;

  //   tempAlertProps.message = (
  //     <span>
  //       <IntlMessages id='warning.areYouSureDelete' /> {params.data.name} ?
  //     </span>
  //   );
  //   tempAlertProps.actionParams = params;
  //   setAlertProps(tempAlertProps);
  // };

  // const handleAlertYes = () => {
  //   const tempAlertProps = {...alertProps};
  //   deletePermission(tempAlertProps.actionParams);
  //   tempAlertProps.isHideShow = false;
  //   tempAlertProps.alertType = '';
  //   tempAlertProps.title = '';
  //   tempAlertProps.message = '';
  //   tempAlertProps.actionParams = null;
  //   setAlertProps(tempAlertProps);
  // };
  // const handleAlertNo = () => {
  //   const tempAlertProps = {...alertProps};
  //   tempAlertProps.isHideShow = false;
  //   tempAlertProps.alertType = '';
  //   tempAlertProps.title = '';
  //   tempAlertProps.message = '';
  //   tempAlertProps.actionParams = null;
  //   setAlertProps(tempAlertProps);
  // };

  // const deletePermission = async (params) => {
  //   try {
  //     const response = await jwtAxios.delete(
  //       `${API_ROUTS.createPermissions}/${selectedCompany?.id}?authorityName=${params?.data?.name}`,
  //       params?.data,
  //     );
  //     if (response.status == 200) {
  //       dispatch(showMessage(' Permissions delete successfully..!'));
  //       dispatch(getALLRolesPermissions({companyId: selectedCompany.id}));
  //     }
  //   } catch (error) {
  //     apiCatchErrorMessage(error, dispatch, fetchError);
  //   }
  // };

  const onFilterTextBoxChanged = useCallback(() => {
    const filterText = document.getElementById('filter-text-box').value;
    gridRef.current.api.setGridOption('quickFilterText', filterText);
    const totalResults = gridRef.current.api.getDisplayedRowCount();
    if (!isEmptyNullUndefined(gridData) && gridData.length > 0) {
      if (totalResults === 0 && !isEmptyNullUndefined(filterText)) {
        setOverlayMessage('No Record Found');
        gridRef.current.api.showNoRowsOverlay();
      } else if (totalResults !== 0) {
        setOverlayMessage('No Rows To Show');
        gridRef.current.api.hideOverlay();
      }
    }
  }, []);

  const handleRoleScheduler = async (companyId) => {
    setSubmitLoader(true);
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.roleScheduler}/${companyId}`,
      );
      if (response.status == 200) {
        dispatch(showMessage('Role scheduler activated successfully...!'));
        setSubmitLoader(false);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
      setSubmitLoader(false);
    }
  };

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (!isAuthorized) {
    return <Error403 />;
  }

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        <IntlMessages id='sidebar.RolesAndPermissions' />
      </h2>
      <AppCard>
        <Stack style={{width: '100%'}}>
          <Stack direction='row' sx={{mb: 2}} justifyContent={'end'}>
            <TextField
              //size='small'
              sx={{width: 200, mr: 2}}
              id='filter-text-box'
              onInput={onFilterTextBoxChanged}
              type={'search'}
              name='search'
              label={<IntlMessages id='common.button.Search' />}
              variant='outlined'
            />
             {isAllowedUser(permissionName.RUN_ROLE_SCHEDULER) && (
              <Button
                disabled={isEmptyNullUndefined(gridData) || submitLoader}
                color='success'
                variant='contained'
                sx={{mr: 2}}
                onClick={() => handleRoleScheduler(selectedCompany.id)}
              >
                {submitLoader ? (
                  <CircularProgress
                    sx={{
                      margin: '0px 1rem',
                      color: '#000000',
                      width: '25px !important',
                      height: '25px !important',
                    }}
                  />
                ) : (
                  <IntlMessages id='common.button.Run_Role_Schedular' />
                )}
              </Button>
            )} 
            {isAllowedUser(permissionName.CREATE) && (
              <Button
                sx={{mr: 2}}
                variant='outlined'
                onClick={() => handleRedirectAddRolesPermissions()}
              >
                <IntlMessages id='roles.addRolesAndPermission' />
              </Button>
            )}
            <ToggleButtonGroup
              color='primary'
              value={alignment}
              exclusive
              onChange={handleChange}
            >
              <ToggleButton
                value='ACTIVE'
                onClick={() => getAllActiveRole(selectedCompany.id)}
              >
                <IntlMessages id='common.button.Active' />
              </ToggleButton>
              <ToggleButton
                value='INACTIVE'
                onClick={() => getAllInactiveRole(selectedCompany.id)}
              >
                <IntlMessages id='common.button.Inactive' />
              </ToggleButton>
            </ToggleButtonGroup>
          </Stack>

          <Stack
            className='ag-theme-alpine'
            style={{height: 525, width: '100%'}}
          >
            {isLoading ? (
              domCreactionGridSkeletonLoader()
            ) : (
              <AgGridReact
                ref={gridRef}
                rowData={gridData}
                columnDefs={columnDefs}
                defaultColDef={defaultColDef}
                animateRows={true}
                pagination={true}
                paginationPageSize={10}
                overlayLoadingTemplate={
                  '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'
                }
                overlayNoRowsTemplate={`<span class="ag-overlay-loading-center">${overlayMessage}</span>`}
              />
            )}
          </Stack>
        </Stack>
        {alertProps.isHideShow && (
          <AlertDialog
            alertProps={alertProps}
            handleYes={() => handleAlertYes()}
            handleNo={() => handleAlertNo()}
          />
        )}
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default ManageRolesAndPermissions;
