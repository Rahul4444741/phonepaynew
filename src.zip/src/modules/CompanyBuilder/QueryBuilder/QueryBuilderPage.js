import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import jwtAxios from '@crema/services/auth/jwt-auth';
import axios from 'axios';
import { fetchError, showInfo, showMessage } from '../../../redux/actions';
import { QueryBuilder, formatQuery, defaultOperators } from 'react-querybuilder';
import {
  Paper,
  Box,
  Button,
  TextField,
  Divider,
  FormControl,
  InputLabel,
  Select,
  FormHelperText,
  MenuItem,
} from '@mui/material';
import { API_ROUTS } from 'shared/constants/ApiRouts';
import 'react-querybuilder/dist/query-builder.css';
import { footerButton } from 'shared/constants/AppConst';
import Stack from '@mui/material/Stack';
import IntlMessages from '@crema/utility/IntlMessages';
import Router from 'next/router';
import AppAnimate from '../../../@crema/core/AppAnimate';
import { AppCard, AppInfoView } from '../../../@crema';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import { AgGridReact } from 'ag-grid-react';
import { isEmptyNullUndefined } from 'shared/utils/CommonUtils';
import DownloadEmployee from 'modules/Common/DownloadEmployee';

const CustomHeaderEmployeeName = () => (
  <IntlMessages id='aggrid.tableHeader.employeeName' />
);
const CustomHeaderEmail = () => (
  <IntlMessages id='aggrid.tableHeader.Email' />
);
const CustomHeaderEmployeeId = () => (
  <IntlMessages id='aggrid.tableHeader.employeeId' />
);

const QueryBuilderPage = () => {
  const gridRef = React.useRef();
  const dispatch = useDispatch();
  const [query, setQuery] = useState(null);
  const [responseFields, setResponseFields] = useState([]);
  const [apiResponse, setApiResponse] = useState([]);
  const selectedCompany = useSelector(({company}) => company.selectedCompany);
  const [variableName, setVariableName] = useState('');
  const [employeeListData, setEmployeeListData] = React.useState([]);
  const [gridApi, setGridApi] = React.useState(null);
  const [queryFor, setQueryFor] = React.useState(null);
  const [dataLoading, setDataLoading] = React.useState(false);
  const [queryForError, setQueryForError] = React.useState({
    isError: false,
    errorMessage: '',
  });

  const queryForList = [
    {name: 'Roles and Permissions', value: 'ROLES_AND_PERMISSIONS'},
    {name: 'Calibration Cycle', value: 'CALIBRATION_CYCLE'},
    {name: 'PMS Cycle', value: 'PMS_CYCLE'},
    {name: 'Compensation Cycle', value: 'COMPENSATION_CYCLE'},
  ];

   const columnDefs =[
    {
      field: 'fullName',
      headerName: 'Employee Name',
      headerComponentFramework: CustomHeaderEmployeeName,
      valueGetter(params) {
        return params.data.name;
      },
      suppressMenu: true,
      minWidth: 250,
      filter: true,
    },
    {
      field: 'emailId',
      filter: true,
      headerName: 'emailId',
      headerComponentFramework: CustomHeaderEmail,
      minWidth: 100,
    },
    {
      field: 'employeeId',
      filter: true,
      headerName: 'Employee Id',
      headerComponentFramework: CustomHeaderEmployeeId,
      minWidth: 100,
    },
  ];
  const defaultColDef = React.useMemo(() => {
    return {
      flex: 1,
      minWidth: 100,
      resizable: true,
    };
  }, []);
  function onGridReady(params) {
    setGridApi(params.api);
  }

  const initialFormErrorList = {
    variableName: {isError: false, errorMessage: ''},
  };
  const [formError, setFormError] = React.useState(initialFormErrorList);

  useEffect(() => {
    getFields();
    getCompanyPlan();
  }, []);

  const getFields = async () => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.variablesDropdown}?companyId=${selectedCompany.id}`,
        {
          headers: {},
        },
      );

      if (res.status === 200) {
        setResponseFields(res.data);
      } 
    } catch (error) {
      if (!axios.isCancel(error)) {
        dispatch(fetchError(error.message));
      }
    }
  };

  const getCompanyPlan = async () => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.serviceprovider_plan}/${selectedCompany.id}`,
      );

      if (res.status === 200) {
        setApiResponse(res.data);
      } 
    } catch (error) {
      if (!axios.isCancel(error)) {
        dispatch(fetchError(error.message));
      }
    }
  };

  const submitQuery = async () => {
    if (!variableName) {
      setFormError({
        ...formError,
        variableName: {
          isError: true,
          errorMessage: <IntlMessages id='error.queryNameIsRequired' />,
        },
      });
      return;
    }
    if (isEmptyNullUndefined(queryFor)) {
      let tempQueryForError = {...queryForError};
      tempQueryForError.isError = true;
      tempQueryForError.errorMessage = (
        <IntlMessages id='error.pleaseSelectQueryUsedFor' />
      );
      setQueryForError(() => tempQueryForError);
      return;
    }
    try {
      const payload = {
        relationTable: 'Employee',
        variableName: variableName,
        status: 'ACTIVE',
        queryFor: queryFor,
        query: formatQuery(query, 'sql'), // formatQuery() converts the query object to SQL string
        company: {
          id: selectedCompany.id,
        },
      };

      const response = await jwtAxios.post(`${API_ROUTS.customquery}`, payload);
      if (response.status === 200) {
        if (response.status === 200) {
          dispatch(showMessage('Query Added Successfully'));
          Router.push(`/company-builder/query-builder`);
        }
      } 
    } catch (error) {
      if (!axios.isCancel(error)) {
        dispatch(fetchError(error.message));
      }
    }
  };
  const handleQueryChange = (query) => {
    setQuery(query);
  };

  let transformedFields = responseFields.map((field) => {
    let fieldObj = {
      // name: field,
      // label: field.charAt(0).toUpperCase() + field.slice(1),
      name: field.value,
      label: field.name,
    };

    if (field.value === 'name') {
      fieldObj.inputType = 'string';
      fieldObj.operators = defaultOperators.filter((op) =>
        [
          'contains',
          'beginsWith',
          'endsWith',
          'doesNotContain',
          'doesNotBeginWith',
          'doesNotEndWith',
          'null',
          '=',
          '!=',
          'notNull',
          'in',
          'notIn',
        ].includes(op.name),
      );
    }
    if (field.value === 'employeeId') {
      fieldObj.inputType = 'string';
      fieldObj.operators = defaultOperators.filter((op) =>
        [
          'contains',
          'beginsWith',
          'endsWith',
          'doesNotContain',
          'doesNotBeginWith',
          'doesNotEndWith',
          'null',
          '=',
          '!=',
          'notNull',
          'in',
          'notIn',
        ].includes(op.name),
      );
    }

    if (field.value === 'emailId') {
      fieldObj.inputType = 'string';
      fieldObj.operators = defaultOperators.filter((op) =>
        [
          'contains',
          'beginsWith',
          'endsWith',
          'doesNotContain',
          'doesNotBeginWith',
          'doesNotEndWith',
          'null',
          '=',
          '!=',
          'notNull',
          'in',
          'notIn',
        ].includes(op.name),
      );
    }

    if (field.value === 'dateOfJoining') {
      fieldObj.inputType = 'date';
    }
    
    if (field.value === 'dateOfBirth') {
      fieldObj.inputType = 'date';
    }

    if (
      field.value === 'date1' ||
      field.value === 'date2' ||
      field.value === 'date3' ||
      field.value === 'date4' ||
      field.value === 'date5'
    ) {
      fieldObj.inputType = 'date';
    }

    if (
      field.value === 'boolean1' ||
      field.value === 'boolean2' ||
      field.value === 'boolean3' ||
      field.value === 'boolean4' ||
      field.value === 'boolean5'
    ) {
      fieldObj.valueEditorType = 'select';
      fieldObj.values = [
        {
          name: 'true',
          label: 'True',
        },
        {
          name: 'false',
          label: 'False',
        },
      ];
    }
    if (field.value === 'gender') {
      fieldObj.valueEditorType = 'select';
      fieldObj.values = [
        {
          name: 'Male',
          label: 'Male',
        },
        {
          name: 'Female',
          label: 'Female',
        },
        {
          name: 'Others',
          label: 'Others',
        },
        {
          name: 'Do not wish to disclose',
          label: 'Do not wish to disclose',
        },
      ];
      fieldObj.operators = defaultOperators.filter(
        (op) =>
          ![
            'contains',
            'beginsWith',
            'endsWith',
            'doesNotContain',
            'doesNotBeginWith',
            'doesNotEndWith',
            '>',
            '<',
            '<=',
            '>=',
            'in',
            'notIn',
            'between',
            'notBetween',
          ].includes(op.name),
      );
    }

    if (field.value === 'employeeType') {
      fieldObj.valueEditorType = 'multiselect';
      fieldObj.values = apiResponse?.employeeType?.map((item) => ({
        name: item.name,
        label: item.name,
      }));
      fieldObj.operators = defaultOperators.filter(
        (op) =>
          ![
            'contains',
            'beginsWith',
            'endsWith',
            'doesNotContain',
            'doesNotBeginWith',
            'doesNotEndWith',
            '>',
            '<',
            '<=',
            '>=',
            'in',
            'notIn',
            'between',
            'notBetween',
          ].includes(op.name),
      );
    }

    if (field.value === 'employeeLevel') {
      fieldObj.valueEditorType = 'multiselect';
      fieldObj.values = apiResponse?.employeeLevel?.map((item) => ({
        name: item.name,
        label: item.name,
      }));
      fieldObj.operators = defaultOperators.filter(
        (op) =>
          ![
            'contains',
            'beginsWith',
            'endsWith',
            'doesNotContain',
            'doesNotBeginWith',
            'doesNotEndWith',
            '>',
            '<',
            '<=',
            '>=',
            'in',
            'notIn',
            'between',
            'notBetween',
          ].includes(op.name),
      );
    }
    if (field.value === 'employeeGrade') {
      fieldObj.valueEditorType = 'multiselect';
      fieldObj.values = apiResponse?.employeeGrade?.map((item) => ({
        name: item.name,
        label: item.name,
      }));
      fieldObj.operators = defaultOperators.filter(
        (op) =>
          ![
            'contains',
            'beginsWith',
            'endsWith',
            'doesNotContain',
            'doesNotBeginWith',
            'doesNotEndWith',
            '>',
            '<',
            '<=',
            '>=',
            'in',
            'notIn',
            'between',
            'notBetween',
          ].includes(op.name),
      );
    }
    if (field.value === 'manager') {
      fieldObj.valueEditorType = 'multiselect';
      fieldObj.values = apiResponse?.manager?.map((item) => ({
        name: item.name,
        label: item.name,
      }));
      fieldObj.operators = defaultOperators.filter(
        (op) =>
          ![
            'contains',
            'beginsWith',
            'endsWith',
            'doesNotContain',
            'doesNotBeginWith',
            'doesNotEndWith',
            '>',
            '<',
            '<=',
            '>=',
            'in',
            'notIn',
            'between',
            'notBetween',
          ].includes(op.name),
      );
    }

    if (field.value === 'empstatus') {
      fieldObj.valueEditorType = 'multiselect';
      fieldObj.values = apiResponse?.employeeStatus?.map((item) => ({
        name: item.name,
        label: item.name,
      }));
      fieldObj.operators = defaultOperators.filter(
        (op) =>
          ![
            'contains',
            'beginsWith',
            'endsWith',
            'doesNotContain',
            'doesNotBeginWith',
            'doesNotEndWith',
            '>',
            '<',
            '<=',
            '>=',
            'in',
            'notIn',
            'between',
            'notBetween',
          ].includes(op.name),
      );
    }
    if (field.value === 'employmentStatus') {
      fieldObj.valueEditorType = 'multiselect';
      fieldObj.values = apiResponse?.employementStatus?.map((item) => ({
        name: item.name,
        label: item.name,
      }));
      fieldObj.operators = defaultOperators.filter(
        (op) =>
          ![
            'contains',
            'beginsWith',
            'endsWith',
            'doesNotContain',
            'doesNotBeginWith',
            'doesNotEndWith',
            '>',
            '<',
            '<=',
            '>=',
            'in',
            'notIn',
            'between',
            'notBetween',
          ].includes(op.name),
      );
    }

    if (field.value === 'employeeFunction') {
      fieldObj.valueEditorType = 'multiselect';
      fieldObj.values = apiResponse?.employeeFunction?.map((item) => ({
        name: item.name,
        label: item.name,
      }));
      fieldObj.operators = defaultOperators.filter(
        (op) =>
          ![
            'contains',
            'beginsWith',
            'endsWith',
            'doesNotContain',
            'doesNotBeginWith',
            'doesNotEndWith',
            '>',
            '<',
            '<=',
            '>=',
            'in',
            'notIn',
            'between',
            'notBetween',
          ].includes(op.name),
      );
    }

    if (field.value === 'employeeSubFunction') {
      fieldObj.valueEditorType = 'multiselect';
      fieldObj.values = apiResponse?.employeeSubfunction?.map((item) => ({
        name: item.name,
        label: item.name,
      }));
      fieldObj.operators = defaultOperators.filter(
        (op) =>
          ![
            'contains',
            'beginsWith',
            'endsWith',
            'doesNotContain',
            'doesNotBeginWith',
            'doesNotEndWith',
            '>',
            '<',
            '<=',
            '>=',
            'in',
            'notIn',
            'between',
            'notBetween',
          ].includes(op.name),
      );
    }

    if (field.value === 'isManager') {
      fieldObj.inputType = 'boolean';
    }
    if (field.value === 'isFunctionalLeader') {
      fieldObj.inputType = 'boolean';
    }

    if (field.value === 'managerCode') {
      fieldObj.inputType = 'string';
      fieldObj.operators = defaultOperators.filter((op) =>
        [
          'contains',
          'beginsWith',
          'endsWith',
          'doesNotContain',
          'doesNotBeginWith',
          'doesNotEndWith',
          'null',
          '=',
          '!=',
          'notNull',
          'in',
          'notIn',
        ].includes(op.name),
      );
    }

    if (field.value === 'dateOfJoining') {
      fieldObj.inputType = 'date';
    }

    return fieldObj;
  });
  const handleResetForm = () => {
    const tempInitError = JSON.parse(JSON.stringify(initialFormErrorList));
    setFormError(tempInitError);
    setVariableName('');
    setQueryFor('');
    setEmployeeListData([]);
    setQuery(null);
  };
  const textFieldStyled = {
    backgroundColor: 'white',
    mb: 4,
    width: {xs: '100%', xl: '50%', md: '75%'},
  };
  const submitForm = async () => {
    setDataLoading(() => true);
    gridApi.hideOverlay();
    gridApi.showLoadingOverlay();

    const payload = {
      relationTable: 'Employee',
      variableName: variableName,
      status: 'ACTIVE',
      query: formatQuery(query, 'sql'), // formatQuery() converts the query object to SQL string
      company: {
        id: selectedCompany.id,
      },
    };

    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.customquery}/find`,
        payload,
        // `${API_ROUTS.customquery}/${serviceProvider?.id}`,
      );
      if (response.status == 200) {
        if (response?.data.length > 0) {
          setEmployeeListData(() => response.data);
          gridApi.hideOverlay();
          setDataLoading(() => false);
        } else {
          dispatch(showInfo('You have no employee for selected company'));
          gridApi.showNoRowsOverlay();
          setEmployeeListData(() => []);
          setDataLoading(() => false);
        }
      }
    } catch (error) {
      gridApi.showNoRowsOverlay();
      setEmployeeListData(() => []);
      dispatch(fetchError(error.message));
      setDataLoading(() => false);
    }
  };
  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        <IntlMessages id='queryBuilder.pageHeaderName' />
      </h2>
      <AppCard>
        <Stack style={{width: '100%'}}>
          <Stack
            direction='row'
            sx={{mt: 2}}
            justifycontent='space-between'
            alignitems='flex-start'
            spacing={2}
          >
            <Stack style={{width: '50%'}}>
              <TextField
                size='small'
                name='variableName'
                InputLabelProps={{shrink: true}}
                label={<IntlMessages id='queryBuilder.queryName' />}
                onChange={(e) => {
                  setVariableName(e.target.value);

                  let tempFormError = {...formError};
                  tempFormError.variableName.isError = false;
                  tempFormError.variableName.errorMessage = '';

                  setFormError(() => tempFormError);
                }}
                variant='outlined'
                value={variableName}
                error={formError.variableName.isError}
                helperText={formError.variableName.errorMessage}
                sx={{
                  ...textFieldStyled,
                  '& fieldset': {
                    borderLeftColor: 'red',
                    borderLeftWidth: 3,
                    // width: 200,
                  },
                }}
              />
            </Stack>
            <Stack style={{width: '50%'}}>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id='queryFor'>
                  Query For
                </InputLabel>
                <Select
                  size='small'
                  name='queryFor'
                  label='Query For'
                  labelId='queryFor'
                  value={queryFor || ''}
                  error={queryForError.isError}
                  helperText={queryForError.errorMessage}
                  onChange={(event) => {
                    setQueryFor(event.target.value);
                    let tempQueryForError = {...queryForError};
                    tempQueryForError.isError = false;
                    tempQueryForError.errorMessage = '';
                    setQueryForError(() => tempQueryForError);
                  }}
                  variant='outlined'
                  sx={{...textFieldStyled, width: '100%'}}
                >
                  {queryForList?.map((item, index) => {
                      return (
                        <MenuItem key='index' value={item.value}>
                          {item.name}
                        </MenuItem>
                      );
                    })}
                </Select>
                {queryForError.isError && (
                  <FormHelperText style={{color: '#d32f2f'}}>
                    {queryForError.errorMessage}
                  </FormHelperText>
                )}
              </FormControl>
            </Stack>
          </Stack>
          <Paper sx={{width: '100%', overflow: 'hidden', marginBottom: '50px'}}>
            <Box
              sx={{
                backgroundColor: 'lightgrey',
                padding: '16px',
                borderRadius: '4px',
              }}
            >
              <QueryBuilder
                controlClassnames={{
                  queryBuilder: 'queryBuilder-branches',
                }}
                fields={transformedFields}
                query={query}
                onQueryChange={handleQueryChange}
              />
            </Box>
            <Box sx={{padding: '16px', borderRadius: '4px'}}>
              <h2>
                {/* Query */}
                <IntlMessages id='queryBuilder.query' />
              </h2>
              <pre>
                {query &&
                  formatQuery(query, 'sql') !== '(1 = 1)' &&
                  formatQuery(query, 'sql')}
              </pre>
            </Box>
          </Paper>
          <Divider color='grey' sx={{my: 3}} varint='fullWidth' />
          <Stack
            direction='row'
            sx={{mt: 2}}
            justifycontent='space-between'
            alignitems='flex-start'
            marginTop='50px'
          >
            <Stack sx={{mb: 5, width: '50%'}}>
              <Button
                color={footerButton.back.color}
                variant={footerButton.back.variant}
                sx={{
                  ...textFieldStyled,
                }}
                size={footerButton.back.size}
                onClick={() => submitForm()}
              >
                <IntlMessages id='queryBuilder.query.testQuery' />
              </Button>
            </Stack>
            <Stack
              sx={{
                mb: 5,
                mr: 10,
                width: '50%',
                alignItems: 'flex-end',
                justifyContent: 'flex-end',
              }}
            >
              {dataLoading === false && employeeListData?.length !== 0 ? (
                <DownloadEmployee data={employeeListData} employeeDisplay={responseFields}/>
              ) : null}
            </Stack>
          </Stack>
          <Stack
            id='ag-grid-table'
            className='ag-theme-alpine'
            style={{height: 520, width: '98%', marginBottom: '50px'}}
          >
            <AgGridReact
              ref={gridRef}
              rowData={employeeListData}
              columnDefs={columnDefs}
              defaultColDef={defaultColDef}
              pagination={true}
              paginationPageSize={10}
              overlayLoadingTemplate={
                '<span className="ag-overlay-loading-center">Please wait while your rows are loading...</span>'
              }
              overlayNoRowsTemplate={
                '<span className="ag-overlay-loading-center">No data found to display.</span>'
              }
              onGridReady={onGridReady}
            />
          </Stack>
          <Stack
            direction='row'
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
            sx={{mt: 10, width: {xs: '100%', xl: '75%', md: '90%'}}}
          >
            <Stack
              sx={{
                bottom: 0,
                zIndex: 10,
                position: 'fixed',
                backdropFilter: 'blur(5px)',
                width: '100%',
                right: 0,
              }}
            >
              <Stack
                direction='row'
                justifyContent='end'
                alignItems='center'
                spacing={2}
                sx={{
                  pt: 5,
                  ml: 3,
                  margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
                }}
              >
                <Button
                  color={footerButton.back.color}
                  variant={footerButton.back.variant}
                  sx={footerButton.back.sx}
                  size={footerButton.back.size}
                  onClick={() => Router.push(`/company-builder/query-builder`)}
                >
                  <IntlMessages id='common.button.Back' />
                </Button>
                <Button
                  color={footerButton.reset.color}
                  variant={footerButton.reset.variant}
                  sx={footerButton.reset.sx}
                  size={footerButton.reset.size}
                  onClick={() => handleResetForm()}
                >
                  <IntlMessages id='common.button.Reset' />
                </Button>
                <Button
                  color={footerButton.reset.color}
                  variant={footerButton.reset.variant}
                  sx={footerButton.reset.sx}
                  size={footerButton.reset.size}
                  onClick={() => ''}
                >
                  <IntlMessages id='common.save' />
                  {' As '}
                  <IntlMessages id='common.button.Draft' />
                </Button>
                <Button
                  color={footerButton.submit.color}
                  variant={footerButton.submit.variant}
                  sx={footerButton.submit.sx}
                  size={footerButton.submit.size}
                  onClick={() => submitQuery()}
                >
                  <IntlMessages id='common.button.Submit' />
                </Button>
              </Stack>
            </Stack>
          </Stack>
        </Stack>
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default QueryBuilderPage;
