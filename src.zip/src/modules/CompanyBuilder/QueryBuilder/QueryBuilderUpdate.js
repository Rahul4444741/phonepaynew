import * as React from 'react';
import { Box, Divider } from '@mui/material';
import TextField from '@mui/material/TextField';
import Select from '@mui/material/Select';
import Stack from '@mui/material/Stack';
import MenuItem from '@mui/material/MenuItem';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import { AppCard } from '../../../@crema';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import FormHelperText from '@mui/material/FormHelperText';
import AppInfoView from '../../../@crema/core/AppInfoView';
import { showMessage, fetchError, showInfo } from '../../../redux/actions';
import axios from 'axios';
import { useDispatch, useSelector } from 'react-redux';
import Router, { useRouter } from 'next/router';
import jwtAxios from '@crema/services/auth/jwt-auth';
import { API_ROUTS } from 'shared/constants/ApiRouts';
import { footerButton } from 'shared/constants/AppConst';
import IntlMessages from '@crema/utility/IntlMessages';
import {
  QueryBuilder,
  formatQuery,
  defaultOperators,
  parseSQL,
} from 'react-querybuilder';
import 'react-querybuilder/dist/query-builder.css';
import { AgGridReact } from 'ag-grid-react';
import { isEmptyNullUndefined } from 'shared/utils/CommonUtils';
import DownloadEmployee from 'modules/Common/DownloadEmployee';

const CustomHeaderEmployeeName = () => (
  <IntlMessages id='aggrid.tableHeader.employeeName' />
);
const CustomHeaderEmail = () => (
  <IntlMessages id='aggrid.tableHeader.Email' />
);
const CustomHeaderEmployeeId = () => (
  <IntlMessages id='aggrid.tableHeader.employeeId' />
);

const QueryBuilderUpdate = () => {
  const gridRef = React.useRef();
  const dispatch = useDispatch();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const [isEdit, setIsEdit] = React.useState(false);
  const router = useRouter();
  const {id} = router.query;
  const [employeeListData, setEmployeeListData] = React.useState([]);
  const [queryFor, setQueryFor] = React.useState(null);
  const [dataLoading, setDataLoading] = React.useState(false);
  const [queryForError, setQueryForError] = React.useState({
    isError: false,
    errorMessage: '',
  });
  const [gridApi, setGridApi] = React.useState(null);
  const [responseFields, setResponseFields] = React.useState([]);
  const [apiResponse, setApiResponse] = React.useState([]);
 
  const columnDefs =[
    {
      field: 'fullName',
      headerName: 'Employee Name',
      headerComponentFramework: CustomHeaderEmployeeName,
      valueGetter(params) {
        return params.data.name;
      },
      suppressMenu: true,
      minWidth: 250,
      filter: true,
    },
    {
      field: 'emailId',
      filter: true,
      headerName: 'emailId',
      headerComponentFramework: CustomHeaderEmail,
      minWidth: 100,
    },
    {
      field: 'employeeId',
      filter: true,
      headerName: 'Employee Id',
      headerComponentFramework: CustomHeaderEmployeeId,
      minWidth: 100,
    },
  ];
  const defaultColDef = React.useMemo(() => {
    return {
      flex: 1,
      minWidth: 100,
      resizable: true,
    };
  }, []);
  function onGridReady(params) {
    setGridApi(params.api);
  }
  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();
  React.useEffect(() => {
    const {id} = router.query;
    if (id != undefined) {
      handleResetForm();
      setIsEdit(true);
      getQuerDetails(id);
    } else {
      handleResetForm();
      setIsEdit(false);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, [router]);

  React.useEffect(() => {
    getFields();
    getCompanyPlan();
  }, []);

  const initialEmptyServiceProviderList = {
    id: null,
    relationTable: null,
    variableName: null,
    status: null,
    query: null,
  };
  const [serviceProvider, setServiceProvider] = React.useState(
    initialEmptyServiceProviderList,
  );
  const parsedQuery = parseSQL(serviceProvider?.query);
  const [query, setQuery] = React.useState();
  const [serviceQueryDetails, setQueryDetails] = React.useState(
    initialEmptyServiceProviderList,
  );
  React.useEffect(() => {
    setQuery(parseSQL(serviceProvider?.query));
  }, [serviceProvider?.query]);

  const queryForList = [
    {name: 'Roles and Permissions', value: 'ROLES_AND_PERMISSIONS'},
    {name: 'Calibration Cycle', value: 'CALIBRATION_CYCLE'},
    {name: 'PMS Cycle', value: 'PMS_CYCLE'},
    {name: 'Compensation Cycle', value: 'COMPENSATION_CYCLE'},
  ];

  const textFieldStyled = {
    backgroundColor: 'white',
    mb: 4,
    width: {xs: '100%', xl: '50%', md: '75%'},
  };

  const formHelperTextStyle = {
    color: '#d32f2f',
    marginTop: '-12px',
    marginBottom: '16.5px',
    marginLeft: '15px',
  };

  const formHelperTextForIconStyle = {
    color: '#d32f2f',
    fontSize: '0.75rem',
    textAlign: 'start',
  };
  const initialFormErrorList = {
    relationTable: {isError: false, errorMessage: ''},
    variableName: {isError: false, errorMessage: ''},
    status: {isError: false, errorMessage: ''},
    query: {isError: false, errorMessage: ''},
  };
  const [formError, setFormError] = React.useState(initialFormErrorList);

  const handleResetForm = () => {
    const tempInitServiceProvider = JSON.parse(
      JSON.stringify(serviceQueryDetails),
    );

    const tempInitError = JSON.parse(JSON.stringify(initialFormErrorList));
    setServiceProvider(tempInitServiceProvider);
    setFormError(tempInitError);
    setQueryFor('');
    setEmployeeListData([]);
    setQuery(parsedQuery);
  };

  const getQuerDetails = async (serviceProviderID) => {
    try {
      const res = await jwtAxios.get(
        // `${baseURL}${API}/customquery?companyId=${selectedCompany.id}&relationTable=Employee&status=ACTIVE`,
        // `${API_ROUTS.customquery}?companyId=${selectedCompany.id}&relationTable=Employee&status=ACTIVE`,
        `${API_ROUTS.customquery}/query/${serviceProviderID}`,
        {
          cancelToken: source.token,
        },
      );
      if (res.status == 200) {
        setServiceProvider(res.data);
        setQueryDetails(res.data);
        setQueryFor(res.data.queryFor);
      } else {
        console.log(response);
      }
    } catch (e) {
      if (!axios.isCancel(e)) {
        dispatch(fetchError(e.response));
      }
    }
  };
  const getCompanyPlan = async () => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.serviceprovider_plan}/${selectedCompany.id}`,
      );

      if (res.status === 200) {
        setApiResponse(res.data);
      } 
    } catch (error) {
      if (!axios.isCancel(error)) {
        dispatch(fetchError(error.message));
      }
    }
  };

  const handleChangeServiceProviderData = (event, fieldType) => {
    const tempServiceProvider = JSON.parse(JSON.stringify(serviceProvider));
    const tempError = JSON.parse(JSON.stringify(formError));
    if (fieldType == 'textfield' || fieldType == 'dropdown') {
      if (event.target.name == 'primaryPhoneCountryCode') {
        tempServiceProvider[event.target.name] = event.target.value.replace(
          /[^+0-9]/g,
          '',
        );
        tempError[event.target.name].isError = false;
        tempError[event.target.name].errorMessage = '';
      } else if (
        event.target.name == 'primaryPhone' ||
        event.target.name == 'mobileNumber'
      ) {
        tempServiceProvider[event.target.name] = event.target.value.replace(
          /\D/g,
          ''
        );
        tempError[event.target.name].isError = false;
        tempError[event.target.name].errorMessage = '';
      } else {
        tempServiceProvider[event.target.name] = event.target.value;
        tempError[event.target.name].isError = false;
        tempError[event.target.name].errorMessage = '';
      }
    } else if (fieldType == 'streetLineOne') {
      tempServiceProvider.address.streetLineOne = event.target.value;
    } else if (fieldType == 'streetLineTwo') {
      tempServiceProvider.address.streetLineTwo = event.target.value;
    } else if (fieldType == 'city') {
      tempServiceProvider.address.city = event.target.value;
    } else if (fieldType == 'state') {
      tempServiceProvider.address.state = event.target.value;
    } else if (fieldType == 'country') {
      tempServiceProvider.address.country = event.target.value;
    } else if (fieldType == 'postalCode') {
      tempServiceProvider.address.postalCode = event.target.value.replace(
        /[^a-zA-Z0-9]/g,
        '',
      );
    }

    setServiceProvider(tempServiceProvider);
    setFormError(tempError);
  };
  const handleValidateQuery = async () => {
    let isValid = true;
    const tempError = {...formError};
    const tempServiceProvider = {...serviceProvider};

    // Check if the relationTable field is not empty
    if (
      !tempServiceProvider.relationTable ||
      tempServiceProvider.relationTable.trim() === ''
    ) {
      tempError.relationTable.isError = true;
      tempError.relationTable.errorMessage = 'Please enter Relation Table';
      isValid = false;
    }

    // Check if the variableName field is not empty
    if (
      !tempServiceProvider.variableName ||
      tempServiceProvider.variableName.trim() === ''
    ) {
      tempError.variableName.isError = true;
      tempError.variableName.errorMessage = 'Please enter Variable Name';
      isValid = false;
    }

    // Check if the query field is not empty
    if (!tempServiceProvider.query || tempServiceProvider.query.trim() === '') {
      tempError.query.isError = true;
      tempError.query.errorMessage = 'Please enter Query';
      isValid = false;
    }

    if (isEmptyNullUndefined(queryFor)) {
      let tempQueryForError = {...queryForError};
      tempQueryForError.isError = true;
      tempQueryForError.errorMessage = (
        <IntlMessages id='error.pleaseSelectQueryUsedFor' />
      );
      setQueryForError(() => tempQueryForError);
      isValid = false;
    }

    if (isValid) {
      setIsDisable(true);
      const data = {
        company: {id: selectedCompany.id},
        relationTable: serviceProvider.relationTable,
        variableName: serviceProvider.variableName,
        queryFor: queryFor,
        query:
          query && formatQuery(query, 'sql') !== '(1 = 1)'
            ? formatQuery(query, 'sql')
            : serviceProvider.query,
        status: serviceProvider.status,
        id: id,
      };
      try {
        const response = await jwtAxios.put(
          `${API_ROUTS.customquery}/${id}`,
          data,
        );
        if (response.status === 200) {
          dispatch(showMessage('Query Updated Successfully'));
          Router.push(`/company-builder/query-builder`);
        }
      } catch (e) {
        setIsDisable(false);
        dispatch(fetchError(e?.response?.data?.title));
      }
    } else {
      setFormError(tempError);
    }
  };

  const [isDisable, setIsDisable] = React.useState(false);

  let transformedFields = responseFields.map((field) => {
    let fieldObj = {
      // name: field,
      // label: field.charAt(0).toUpperCase() + field.slice(1),
      name: field.value,
      label: field.name,
    };

    if (field.value === 'name') {
      fieldObj.inputType = 'string';
      fieldObj.operators = defaultOperators.filter((op) =>
        [
          'contains',
          'beginsWith',
          'endsWith',
          'doesNotContain',
          'doesNotBeginWith',
          'doesNotEndWith',
          'null',
          '=',
          '!=',
          'notNull',
          'in',
          'notIn',
        ].includes(op.name),
      );
    }
    if (field.value === 'employeeId') {
      fieldObj.inputType = 'string';
      fieldObj.operators = defaultOperators.filter((op) =>
        [
          'contains',
          'beginsWith',
          'endsWith',
          'doesNotContain',
          'doesNotBeginWith',
          'doesNotEndWith',
          'null',
          '=',
          '!=',
          'notNull',
          'in',
          'notIn',
        ].includes(op.name),
      );
    }

    if (field.value === 'emailId') {
      fieldObj.inputType = 'string';
      fieldObj.operators = defaultOperators.filter((op) =>
        [
          'contains',
          'beginsWith',
          'endsWith',
          'doesNotContain',
          'doesNotBeginWith',
          'doesNotEndWith',
          'null',
          '=',
          '!=',
          'notNull',
          'in',
          'notIn',
        ].includes(op.name),
      );
    }

    if (field.value === 'dateOfJoining') {
      fieldObj.inputType = 'date';
    }
    if (field.value === 'dateOfBirth') {
      fieldObj.inputType = 'date';
    }

    if (
      field.value === 'date1' ||
      field.value === 'date2' ||
      field.value === 'date3' ||
      field.value === 'date4' ||
      field.value === 'date5'
    ) {
      fieldObj.inputType = 'date';
    }

    if (
      field.value === 'boolean1' ||
      field.value === 'boolean2' ||
      field.value === 'boolean3' ||
      field.value === 'boolean4' ||
      field.value === 'boolean5'
    ) {
      fieldObj.valueEditorType = 'select';
      fieldObj.values = [
        {
          name: 'true',
          label: 'True',
        },
        {
          name: 'false',
          label: 'False',
        },
      ];
    }


    if (field.value === 'gender') {
      fieldObj.valueEditorType = 'select';
      fieldObj.values = [
        {
          name: 'Male',
          label: 'Male',
        },
        {
          name: 'Female',
          label: 'Female',
        },
        {
          name: 'Others',
          label: 'Others',
        },
        {
          name: 'Do not wish to disclose',
          label: 'Do not wish to disclose',
        },
      ];
      fieldObj.operators = defaultOperators.filter(
        (op) =>
          ![
            'contains',
            'beginsWith',
            'endsWith',
            'doesNotContain',
            'doesNotBeginWith',
            'doesNotEndWith',
            '>',
            '<',
            '<=',
            '>=',
            'in',
            'notIn',
            'between',
            'notBetween',
          ].includes(op.name),
      );
    }

    if (field.value === 'employeeType') {
      fieldObj.valueEditorType = 'multiselect';
      fieldObj.values = apiResponse?.employeeType?.map((item) => ({
        name: item.name,
        label: item.name,
      }));
      fieldObj.operators = defaultOperators.filter(
        (op) =>
          ![
            'contains',
            'beginsWith',
            'endsWith',
            'doesNotContain',
            'doesNotBeginWith',
            'doesNotEndWith',
            '>',
            '<',
            '<=',
            '>=',
            'in',
            'notIn',
            'between',
            'notBetween',
          ].includes(op.name),
      );
    }

    if (field.value === 'employeeLevel') {
      fieldObj.valueEditorType = 'multiselect';
      fieldObj.values = apiResponse?.employeeLevel?.map((item) => ({
        name: item.name,
        label: item.name,
      }));
      fieldObj.operators = defaultOperators.filter(
        (op) =>
          ![
            'contains',
            'beginsWith',
            'endsWith',
            'doesNotContain',
            'doesNotBeginWith',
            'doesNotEndWith',
            '>',
            '<',
            '<=',
            '>=',
            'in',
            'notIn',
            'between',
            'notBetween',
          ].includes(op.name),
      );
    }
    if (field.value === 'employeeGrade') {
      fieldObj.valueEditorType = 'multiselect';
      fieldObj.values = apiResponse?.employeeGrade?.map((item) => ({
        name: item.name,
        label: item.name,
      }));
      fieldObj.operators = defaultOperators.filter(
        (op) =>
          ![
            'contains',
            'beginsWith',
            'endsWith',
            'doesNotContain',
            'doesNotBeginWith',
            'doesNotEndWith',
            '>',
            '<',
            '<=',
            '>=',
            'in',
            'notIn',
            'between',
            'notBetween',
          ].includes(op.name),
      );
    }
    if (field.value === 'manager') {
      fieldObj.valueEditorType = 'multiselect';
      fieldObj.values = apiResponse?.manager?.map((item) => ({
        name: item.name,
        label: item.name,
      }));
      fieldObj.operators = defaultOperators.filter(
        (op) =>
          ![
            'contains',
            'beginsWith',
            'endsWith',
            'doesNotContain',
            'doesNotBeginWith',
            'doesNotEndWith',
            '>',
            '<',
            '<=',
            '>=',
            'in',
            'notIn',
            'between',
            'notBetween',
          ].includes(op.name),
      );
    }

    if (field.value === 'empstatus') {
      fieldObj.valueEditorType = 'multiselect';
      fieldObj.values = apiResponse?.employeeStatus?.map((item) => ({
        name: item.name,
        label: item.name,
      }));
      fieldObj.operators = defaultOperators.filter(
        (op) =>
          ![
            'contains',
            'beginsWith',
            'endsWith',
            'doesNotContain',
            'doesNotBeginWith',
            'doesNotEndWith',
            '>',
            '<',
            '<=',
            '>=',
            'in',
            'notIn',
            'between',
            'notBetween',
          ].includes(op.name),
      );
    }

    if (field.value === 'employmentStatus') {
      fieldObj.valueEditorType = 'multiselect';
      fieldObj.values = apiResponse?.employementStatus?.map((item) => ({
        name: item.name,
        label: item.name,
      }));
      fieldObj.operators = defaultOperators.filter(
        (op) =>
          ![
            'contains',
            'beginsWith',
            'endsWith',
            'doesNotContain',
            'doesNotBeginWith',
            'doesNotEndWith',
            '>',
            '<',
            '<=',
            '>=',
            'in',
            'notIn',
            'between',
            'notBetween',
          ].includes(op.name),
      );
    }

    if (field.value === 'employeeFunction') {
      fieldObj.valueEditorType = 'multiselect';
      fieldObj.values = apiResponse?.employeeFunction?.map((item) => ({
        name: item.name.trim(),
        label: item.name,
      }));
      fieldObj.operators = defaultOperators.filter(
        (op) =>
          ![
            'contains',
            'beginsWith',
            'endsWith',
            'doesNotContain',
            'doesNotBeginWith',
            'doesNotEndWith',
            '>',
            '<',
            '<=',
            '>=',
            'in',
            'notIn',
            'between',
            'notBetween',
          ].includes(op.name),
      );
    }

    if (field.value === 'employeeSubFunction') {
      fieldObj.valueEditorType = 'multiselect';
      fieldObj.values = apiResponse?.employeeSubfunction?.map((item) => ({
        name: item.name,
        label: item.name,
      }));
      fieldObj.operators = defaultOperators.filter(
        (op) =>
          ![
            'contains',
            'beginsWith',
            'endsWith',
            'doesNotContain',
            'doesNotBeginWith',
            'doesNotEndWith',
            '>',
            '<',
            '<=',
            '>=',
            'in',
            'notIn',
            'between',
            'notBetween',
          ].includes(op.name),
      );
    }

    if (field.value === 'isManager') {
      fieldObj.inputType = 'boolean';
    }
    if (field.value === 'isFunctionalLeader') {
      fieldObj.inputType = 'boolean';
    }

    if (field.value === 'managerCode') {
      fieldObj.inputType = 'string';
      fieldObj.operators = defaultOperators.filter((op) =>
        [
          'contains',
          'beginsWith',
          'endsWith',
          'doesNotContain',
          'doesNotBeginWith',
          'doesNotEndWith',
          'null',
          '=',
          '!=',
          'notNull',
          'in',
          'notIn',
        ].includes(op.name),
      );
    }

    if (field === 'dateOfJoining') {
      fieldObj.inputType = 'date';
    }
    return fieldObj;
  });

  const handleQueryChange = (query) => {
    setQuery(query);
  };

  const getFields = async () => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.variablesDropdown}?companyId=${selectedCompany.id}`,
        {
          headers: {},
        },
      );

      if (res.status === 200) {
        setResponseFields(res.data);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        dispatch(fetchError(error.message));
      }
    }
  };

  const submitForm = async () => {
    setDataLoading(() => true);
    gridApi.hideOverlay();
    gridApi.showLoadingOverlay();

    const data = {
      company: {id: selectedCompany.id},
      relationTable: serviceProvider.relationTable,
      variableName: serviceProvider.variableName,
      query:
        query && formatQuery(query, 'sql') !== '(1 = 1)'
          ? formatQuery(query, 'sql')
          : serviceProvider.query,
      status: serviceProvider.status,
    };

    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.customquery}/find`,
        data,
      );
      if (response.status == 200) {
        if (response?.data.length > 0) {
          setEmployeeListData(() => response.data);
          gridApi.hideOverlay();
          setDataLoading(() => false);
        } else {
          dispatch(showInfo('You have no employee for selected company'));
          gridApi.showNoRowsOverlay();
          setEmployeeListData(() => []);
          setDataLoading(() => false);
        }
      }
    } catch (error) {
      gridApi.showNoRowsOverlay();
      setEmployeeListData(() => []);
      dispatch(fetchError(error.message));
      setDataLoading(() => false);
    }
  };
  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{display: 'flex'}}>
        {!isEdit ? (
          <IntlMessages id='queryBuilder.query.viewQuery' />
        ) : (
          <IntlMessages id='queryBuilder.query.editQuery' />
        )}
      </h2>
      <AppCard>
        <Stack sx={{mx: {xs: 0, xl: 10, md: 5}}}>
          <Box sx={{my: 2}}>
            <Stack
              direction='row'
              sx={{mt: 2}}
              justifycontent='space-between'
              alignitems='flex-start'
              spacing={2}
            >
              <Stack sx={{mb: 5, width: '50%'}}>
                <TextField
                  size='small'
                  name='relationTable'
                  InputLabelProps={{shrink: true}}
                  label={<IntlMessages id='queryBuilder.query.relationTable' />}
                  disabled
                  onChange={(event) =>
                    handleChangeServiceProviderData(event, 'textfield')
                  }
                  variant='outlined'
                  value={serviceProvider?.relationTable || ''}
                  error={formError.relationTable.isError}
                  helperText={formError.relationTable.errorMessage}
                  sx={{
                    ...textFieldStyled,
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  }}
                />
                <TextField
                  size='small'
                  name='variableName'
                  InputLabelProps={{shrink: true}}
                  label={<IntlMessages id='queryBuilder.query.variableName' />}
                  onChange={(event) =>
                    handleChangeServiceProviderData(event, 'textfield')
                  }
                  variant='outlined'
                  value={serviceProvider?.variableName || ''}
                  error={formError.variableName.isError}
                  helperText={formError.variableName.errorMessage}
                  sx={{
                    ...textFieldStyled,
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  }}
                />
              </Stack>
              <Stack style={{width: '50%'}}>
                <FormControl
                  sx={{
                    ...textFieldStyled,
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                    },
                  }}
                >
                  <InputLabel size='small' id='queryFor'>
                    Query For
                  </InputLabel>
                  <Select
                    size='small'
                    name='queryFor'
                    label='Query For'
                    labelId='queryFor'
                    value={queryFor || ''}
                    error={queryForError.isError}
                    helperText={queryForError.errorMessage}
                    onChange={(event) => {
                      setQueryFor(event.target.value);
                      let tempQueryForError = {...queryForError};
                      tempQueryForError.isError = false;
                      tempQueryForError.errorMessage = '';
                      setQueryForError(() => tempQueryForError);
                    }}
                    variant='outlined'
                    sx={{...textFieldStyled, width: '100%'}}
                  >
                    {queryForList?.map((item, index) => { 
                        return (
                          <MenuItem key='index' value={item.value}>
                            {item.name}
                          </MenuItem>
                        );
                      })}
                  </Select>
                  {queryForError.isError && (
                    <FormHelperText style={{color: '#d32f2f'}}>
                      {queryForError.errorMessage}
                    </FormHelperText>
                  )}
                </FormControl>
              </Stack>
            </Stack>
            <Stack
              direction='row'
              sx={{mt: 2}}
              justifycontent='space-between'
              alignitems='flex-start'
              spacing={2}
            >
              <Stack sx={{mb: 5, width: '50%'}}>
                <FormControl>
                  <InputLabel size='small' id='event-type' shrink={true}>
                    <IntlMessages id='serviceProvider.addServiceProvider.status' />
                  </InputLabel>
                  <Select
                    size='small'
                    name='status'
                    label={
                      <IntlMessages id='serviceProvider.addServiceProvider.status' />
                    }
                    notched
                    value={serviceProvider?.status || ''}
                    error={formError.status.isError}
                    onChange={(event) =>
                      handleChangeServiceProviderData(event, 'dropdown')
                    }
                    variant='outlined'
                    sx={{
                      backgroundColor: 'white',
                      mb: 3,
                      width: {xs: '100%', xl: '50%', md: '75%'},
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                    }}
                  >
                    <MenuItem key='Active' value='ACTIVE'>
                      <IntlMessages id='serviceProvider.addServiceProvider.status.Active' />
                    </MenuItem>
                    <MenuItem key='Inactive' value='INACTIVE'>
                      <IntlMessages id='serviceProvider.addServiceProvider.status.Inactive' />
                    </MenuItem>
                  </Select>
                  <FormHelperText style={formHelperTextStyle}>
                    {formError.status?.errorMessage}
                  </FormHelperText>
                </FormControl>
                {formError.brandIcon?.isError && (
                  <FormHelperText
                    className='Mui-error'
                    style={formHelperTextForIconStyle}
                  >
                    {formError.brandIcon.errorMessage}
                  </FormHelperText>
                )}
              </Stack>
            </Stack>
            <Stack
              direction='row'
              justifyContent='space-between'
              alignItems='flex-start'
              spacing={2}
            >
              <Stack
                sx={{
                  width: {
                    xs: '100%',
                    xl: 'calc(80% - 6px)',
                    md: 'calc(85% + 12px)',
                  },
                }}
              >
                <FormControl>
                  <TextField
                    size='small'
                    name='query'
                    InputLabelProps={{shrink: true}}
                    label={<IntlMessages id='queryBuilder.query' />}
                    onChange={(event) =>
                      handleChangeServiceProviderData(event, 'textfield')
                    }
                    variant='outlined'
                    value={
                      (query &&
                        formatQuery(query, 'sql') !== '(1 = 1)' &&
                        formatQuery(query, 'sql')) ||
                      serviceProvider?.query ||
                      ''
                    }
                    error={formError.query.isError}
                    helperText={formError.query.errorMessage}
                    sx={{
                      ...textFieldStyled,
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                    }}
                    disabled
                    multiline
                    rows={3}
                  />
                </FormControl>
              </Stack>
            </Stack>
            <Stack
              direction='row'
              sx={{mt: 2}}
              justifycontent='space-between'
              alignitems='flex-start'
              spacing={2}
            >
              <Stack sx={{mb: 5, width: '50%'}}>
                <Box
                  sx={{
                    backgroundColor: 'lightgrey',
                    padding: '16px',
                    borderRadius: '4px',
                    mb: 5,
                    width: '120%',
                  }}
                >
                  <QueryBuilder
                    controlClassnames={{
                      queryBuilder: 'queryBuilder-branches',
                    }}
                    fields={transformedFields}
                    query={query}
                    onQueryChange={handleQueryChange}
                  />
                </Box>
              </Stack>
            </Stack>
            <Divider color='grey' sx={{my: 3}} varint='fullWidth' />
            <Stack
              direction='row'
              sx={{mt: 2}}
              justifycontent='space-between'
              alignitems='flex-start'
            >
              <Stack sx={{mb: 5, width: '50%'}}>
                <Button
                  color={footerButton.back.color}
                  variant={footerButton.back.variant}
                  sx={{
                    ...textFieldStyled,
                  }}
                  size={footerButton.back.size}
                  onClick={() => submitForm()}
                >
                  {/* Test Query */}
                  <IntlMessages id='queryBuilder.query.testQuery' />
                </Button>
              </Stack>
              <Stack
                sx={{
                  mb: 5,
                  mr: 10,
                  width: '50%',
                  alignItems: 'flex-end',
                  justifyContent: 'flex-end',
                }}
              >
                {dataLoading === false && employeeListData?.length !== 0 ? (
                  <DownloadEmployee data={employeeListData} employeeDisplay={responseFields}/>
                ) : null}
              </Stack>
            </Stack>

            <Stack
              id='ag-grid-table'
              className='ag-theme-alpine'
              style={{height: 520, width: '98%', marginBottom: '50px'}}
            >
              <AgGridReact
                ref={gridRef}
                rowData={employeeListData}
                columnDefs={columnDefs}
                defaultColDef={defaultColDef}
                pagination={true}
                paginationPageSize={10}
                overlayLoadingTemplate={
                  '<span className="ag-overlay-loading-center">Please wait while your rows are loading...</span>'
                }
                overlayNoRowsTemplate={
                  '<span className="ag-overlay-loading-center">No data found to display.</span>'
                }
                onGridReady={onGridReady}
              />
            </Stack>

            <Stack
              direction='row'
              justifyContent='space-between'
              alignItems='center'
              spacing={2}
              sx={{mt: 10, width: {xs: '100%', xl: '75%', md: '90%'}}}
            >
              <Stack
                sx={{
                  bottom: 0,
                  zIndex: 10,
                  position: 'fixed',
                  backdropFilter: 'blur(5px)',
                  width: '100%',
                  right: 0,
                }}
              >
                <Stack
                  direction='row'
                  justifyContent='end'
                  alignItems='center'
                  spacing={2}
                  sx={{
                    pt: 5,
                    ml: 3,
                    margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
                  }}
                >
                  <Button
                    color={footerButton.back.color}
                    variant={footerButton.back.variant}
                    sx={footerButton.back.sx}
                    size={footerButton.back.size}
                    onClick={() =>
                      Router.push(`/company-builder/query-builder`)
                    }
                  >
                    <IntlMessages id='common.button.Back' />
                  </Button>
                  <Button
                    color={footerButton.reset.color}
                    variant={footerButton.reset.variant}
                    sx={footerButton.reset.sx}
                    size={footerButton.reset.size}
                    onClick={() => handleResetForm()}
                  >
                    <IntlMessages id='common.button.Reset' />
                  </Button>
                  {!isDisable ? (
                    <Button
                      color={footerButton.submit.color}
                      variant={footerButton.submit.variant}
                      sx={footerButton.submit.sx}
                      size={footerButton.submit.size}
                      onClick={() => handleValidateQuery()}
                    >
                      <IntlMessages id='common.button.Submit' />
                    </Button>
                  ) : (
                    <Button
                      color={footerButton.submit.color}
                      variant={footerButton.submit.variant}
                      sx={footerButton.submit.sx}
                      size={footerButton.submit.size}
                      disabled
                      onClick={() => handleValidateQuery()}
                    >
                      <IntlMessages id='common.button.Submit' />
                    </Button>
                  )}
                </Stack>
              </Stack>
            </Stack>
          </Box>
        </Stack>
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default QueryBuilderUpdate;
