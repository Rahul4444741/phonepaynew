import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import { AppCard } from '../../../@crema';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import { AgGridReact } from 'ag-grid-react';
import { useDispatch, useSelector } from 'react-redux';
import {
  fetchStart, fetchError,
  showMessage,
  showInfo,
  closeCompanyModel
} from '../../../redux/actions';
import axios from 'axios';
import Router from 'next/router';
import AppInfoView from '../../../@crema/core/AppInfoView';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import AlertDialog from '../../Common/AlertDialog';
import jwtAxios from '@crema/services/auth/jwt-auth';
import { API_ROUTS } from 'shared/constants/ApiRouts';
import { TextField } from '@mui/material';
import {
  isEmptyNullUndefined,
  buttonStyle,
  apiCatchErrorMessage,
  isAllowedUser,
} from 'shared/utils/CommonUtils';
import { domCreactionGridSkeletonLoader } from 'shared/utils/domCreaction';
import IntlMessages from '@crema/utility/IntlMessages';
import { permissionName } from 'shared/utils/PermissionName';
import Error403 from 'modules/errorPages/Error403';
import { useCallback } from 'react';

const CustomHeaderName = () => (
  <IntlMessages id='aggrid.tableHeader.Name' />
);
const CustomHeaderAction = () => (
  <IntlMessages id='aggrid.tableHeader.Action' />
);
const CustomHeaderQuery = () => (
  <IntlMessages id='aggrid.tableHeader.Query' />
);

const QueryBuilderUpdate = () => {
  const dispatch = useDispatch();
  const [serviceProvidersData, setServiceProvidersData] = React.useState(null);
  const [isLoading, setIsLoading] = React.useState(true);
  const [alertProps, setAlertProps] = React.useState({
    isHideShow: false,
    message: '',
    title: '',
    alertType: '',
    actionParams: null,
  });

  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);

  React.useEffect(() => {
    if (isAllowedUser(permissionName.COMPANY_VARIABLES_QUERY_BUILDER)) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();
  React.useEffect(() => {
    dispatch(fetchStart);
    if (
      isAuthorized &&
      selectedCompany != null &&
      selectedCompany != undefined
    ) {
      getAllActiveQuery(selectedCompany.id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, [isAuthorized, selectedCompany]);

  const gridRef = React.useRef();
  const defaultColDef = React.useMemo(() => ({
    sortable: true,
  }));

  const ActionRenderer = (params) => (
    <Stack direction='row'>
      {isAllowedUser(permissionName.READ) && (
        <Button
          style={buttonStyle}
          id={`${params.data.name}_viewBtn`}
          name={`${params.data.name}_viewBtnName`}
          onClick={() => handleRedirectViewServiceProvider(params.data.id)}
        >
          <IntlMessages id='common.button.View' />
        </Button>
      )}
      {isAllowedUser(permissionName.UPDATE) && (
        <Button
          style={buttonStyle}
          id={`${params.data.name}_editBtn`}
          name={`${params.data.name}_editBtnName`}
          onClick={() => handleRedirectEditServiceProvider(params.data.id)}
        >
          <IntlMessages id='common.button.Edit' />
        </Button>
      )}
      {isAllowedUser(permissionName.DEACTIVATE) && params.data.status === 'ACTIVE' && (
        <Button
          style={buttonStyle}
          id={`${params.data.name}_deactivateBtn`}
          name={`${params.data.name}_deactivateBtnName`}
          onClick={() => handleDeactivateConfirmation(params)}
        >
          <IntlMessages id='common.button.Deactivate' />
        </Button>
      )}
      {isAllowedUser(permissionName.ACTIVATE) && params.data.status === 'INACTIVE' && (
        <Button
          style={buttonStyle}
          id={`${params.data.name}_activateBtn`}
          name={`${params.data.name}_activateBtnName`}
          onClick={() => handleActivateConfirmation(params)}
        >
          <IntlMessages id='common.button.Activate' />
        </Button>
      )}
    </Stack>
  );
  const columnDefs = [
    {
      field: 'variableName',
      filter: true,
      headerName: 'variableName',
      headerComponentFramework: CustomHeaderName,
      minWidth: 200,
    },
    {
      field: 'query',
      filter: true,
      headerName: 'query',
      headerComponentFramework: CustomHeaderQuery,
      minWidth: 350,
    },
    {
      field: 'queryFor',
      headerName: 'Query For',
      headerComponentFramework: 'Query For',
      minWidth: 200,
    },
    {
      headerName: 'Action',
      headerComponentFramework: CustomHeaderAction,
      minWidth: 500,
      cellRenderer: ActionRenderer, // Use the custom action renderer
    },
  ];
  
  const [overlayMessage, setOverlayMessage] = React.useState('No Rows To Show');
  const handleAddQuery = () => {
    Router.push('/company-builder/query-builder-page');
  };
  const getAllActiveQuery = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        // `${baseURL}${API}/customquery?companyId=${selectedCompany.id}&relationTable=Employee&status=ACTIVE`,
        `${API_ROUTS.customquery}?companyId=${selectedCompany.id}&relationTable=Employee&status=ACTIVE`,
        {
          cancelToken: source.token,
        },
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no record'));
          setServiceProvidersData([]);
        } else {
          setServiceProvidersData(res.data.reverse());
        }
        setIsLoading(() => false);
      } else {
        setServiceProvidersData([]);
        setIsLoading(() => false);
      }
    } catch (e) {
      if (!axios.isCancel(e)) {
        apiCatchErrorMessage(e, dispatch, fetchError);
      }
      setServiceProvidersData([]);
    }
    setIsLoading(() => false);
  };

  const getAllInactiveServiceProviders = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        // `${baseURL}${API}/customquery?companyId=${selectedCompany.id}&relationTable=Employee&status=INACTIVE`,
        `${API_ROUTS.customquery}?companyId=${selectedCompany.id}&relationTable=Employee&status=INACTIVE`,
        {
          cancelToken: source2.token,
        },
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(
            showInfo('You have no Vendor Management for selected status'),
          );
          setServiceProvidersData([]);
        } else {
          setServiceProvidersData(res.data.reverse());
        }
        setIsLoading(() => false);
      } else {
        setServiceProvidersData([]);
        setIsLoading(() => false);
      }
    } catch (e) {
      if (!axios.isCancel(e)) {
        apiCatchErrorMessage(e, dispatch, fetchError);
      }
      setServiceProvidersData([]);
    }
    setIsLoading(() => false);
  };

  const handleRedirectEditServiceProvider = (id) => {
    dispatch(closeCompanyModel());
    Router.push('/company-builder/query-builder-update?id=' + id);
  };
  const handleRedirectViewServiceProvider = (id) => {
    Router.push('/company-builder/query-builder-update?id=' + id);
  };

  const handleDeactivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = <IntlMessages id='queryBuilder.deactivateQuery' />;
    tempAlertProps.message = (
      <span>
        <IntlMessages id='common.massage.Deactivate' />
        {params.data.name} {' ?'}
      </span>
    );
    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleAlertYes = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.actionParams.data.status == 'ACTIVE' &&
      handleDeactivateServiceProvider(tempAlertProps.actionParams);
    tempAlertProps.actionParams.data.status == 'INACTIVE' &&
      handleActivateServiceProvider(tempAlertProps.actionParams);
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };

  const handleAlertNo = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };

  const handleDeactivateServiceProvider = async (params) => {
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));
      const response = await jwtAxios.put(
        `${API_ROUTS.customquery}/inactivate/${params.data.id}`,
      );
      if (response.status == 200) {
        dispatch(showMessage('Query Deactivated Successfully'));
        const serviceProviderIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );
        if (serviceProviderIndex != -1) {
          rowData[serviceProviderIndex].status = 'INACTIVE';
        }
        getAllInactiveServiceProviders(selectedCompany.id);
        setAlignment('INACTIVE');
      }
    } catch (e) {
      dispatch(fetchError(e.response.data.title));
    }
  };

  const handleActivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = <IntlMessages id='queryBuilder.activateQuery' />;
    tempAlertProps.message = (
      <span>
        <IntlMessages id='common.massage.Aactivate' />
        {params.data.name} {' ?'}
      </span>
    );
    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleActivateServiceProvider = async (params) => {
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));
      const response = await jwtAxios.put(
        `${API_ROUTS.customquery}/activate/${params.data.id}`,
      );

      if (response.status == 200) {
        dispatch(showMessage('Query Activated Successfully'));
        const serviceProviderIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );
        if (serviceProviderIndex != -1) {
          rowData[serviceProviderIndex].status = 'ACTIVE';
        }
        getAllActiveQuery(selectedCompany.id);
        setAlignment('ACTIVE');
      }
    } catch (e) {
      dispatch(fetchError(e.response.data.title));
    }
  };

  const [alignment, setAlignment] = React.useState('ACTIVE');

  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
  };

  const onFilterTextBoxChanged = useCallback(() => {
    const filterText = document.getElementById("filter-text-box").value;
    gridRef.current.api.setGridOption("quickFilterText", filterText);
    const totalResults = gridRef.current.api.getDisplayedRowCount();
    if (!isEmptyNullUndefined(serviceProvidersData) && serviceProvidersData.length > 0) {
      if (totalResults === 0 && !isEmptyNullUndefined(filterText)) {
        setOverlayMessage('No Record Found');
        gridRef.current.api.showNoRowsOverlay();
      } else if (totalResults !== 0) {
        setOverlayMessage('No Rows To Show');
        gridRef.current.api.hideOverlay();
      }
    }
  }, []);

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (!isAuthorized) {
    return <Error403 />;
  }

  return (
      <AppAnimate animation='transition.slideUpIn' delay={500}>
        <AppPageMeta />
        <h2 style={{marginBottom: 20}}>
          <IntlMessages id='queryBuilder.pageHeaderName' />
        </h2>
        <AppCard>
          <Stack style={{width: '100%'}}>
            <Stack
              direction='row'
              sx={{mb: 2}}
              justifyContent={'end'}
              spacing={2}
            >
              <TextField
                sx={{width: 200}}
                id="filter-text-box"
                onInput={onFilterTextBoxChanged}
                type={'search'}
                name='search'
                label={<IntlMessages id='common.button.Search' />}
                variant='outlined'
              />
              {isAllowedUser(permissionName.CREATE) && (
                <Button variant='outlined' onClick={() => handleAddQuery()}>
                  <IntlMessages id='queryBuilder.addNewQuery' />
                </Button>
              )}
              <ToggleButtonGroup
                color='primary'
                value={alignment}
                exclusive
                onChange={handleChange}
              >
                <ToggleButton
                  value='ACTIVE'
                  disabled={isLoading}
                  onClick={() => getAllActiveQuery(selectedCompany.id)}
                >
                  <IntlMessages id='common.button.Active' />
                </ToggleButton>
                <ToggleButton
                  value='INACTIVE'
                  disabled={isLoading}
                  onClick={() =>
                    getAllInactiveServiceProviders(selectedCompany.id)
                  }
                >
                  <IntlMessages id='common.button.Inactive' />
                </ToggleButton>
              </ToggleButtonGroup>
            </Stack>
            {isLoading ? (
              domCreactionGridSkeletonLoader()
            ) : (
              <Stack
                className='ag-theme-alpine'
                style={{height: 525, width: '100%'}}
              >
                <AgGridReact
                  ref={gridRef}
                  rowData={serviceProvidersData}
                  columnDefs={columnDefs}
                  defaultColDef={defaultColDef}
                  animateRows={true}
                  pagination={true}
                  paginationPageSize={10}
                  overlayLoadingTemplate={
                    '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'
                  }
                  overlayNoRowsTemplate={`<span class="ag-overlay-loading-center">${overlayMessage}</span>`}
                />
              </Stack>
            )}
          </Stack>
          {alertProps.isHideShow && (
            <AlertDialog
              alertProps={alertProps}
              handleYes={() => handleAlertYes()}
              handleNo={() => handleAlertNo()}
            />
          )}
        </AppCard>
        <AppInfoView />
      </AppAnimate>
  );
};

export default QueryBuilderUpdate;
