import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import Stack from '@mui/material/Stack';
import { AppCard } from '../../../@crema';
import { showMessage, fetchError } from '../../../redux/actions';
import TextField from '@mui/material/TextField';
import PropTypes from 'prop-types';
import AppInfoView from '../../../@crema/core/AppInfoView';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import { useDispatch } from 'react-redux';
import jwtAxios from '@crema/services/auth/jwt-auth';
import { API_ROUTS } from 'shared/constants/ApiRouts';
import {
  apiCatchErrorMessage,
  isDuplicate,
  isStrExceeds,
} from 'shared/utils/CommonUtils';
import IntlMessages from '@crema/utility/IntlMessages';
const AddRoleModal = ({
  company,
  handleAddRole,
  handleUpdateRole,
  handleClose,
  isEdit,
  editRole,
  rolesData,
}) => {
  const dispatch = useDispatch();
  const [role, setRole] = React.useState({
    id: null,
    name: '',
    status: '',
    company: {
      id: company.id,
    },
  });
  React.useEffect(() => {
    if (isEdit) {
      setRole(editRole);
    }
  }, []);
  const [formError, setFormError] = React.useState({
    name: {isError: false, errorMessage: ''},
    status: {isError: false, errorMessage: ''},
  });
  const textFieldStyled = {
    backgroundColor: 'white',
    mb: 4,
    width: {xs: '100%'},
  };

  const handleValidateRole = async () => {
    let isValid = true;
    const tempError = {...formError};
    const tempRole = {...role};
    if (tempRole.name.trim() == '') {
      tempError.name.isError = true;
      tempError.name.errorMessage = <IntlMessages id='error.pleaseEnterName' />;
      isValid = false;
    }
    if (isStrExceeds(tempRole.name.toString(), 50)) {
      tempError.name.isError = true;
      tempError.name.errorMessage = 'should not exceed 50 characters';
      isValid = false;
    }
    if (
      !isEdit
        ? isDuplicate(tempRole.name, rolesData)
        : isDuplicate(tempRole.name, rolesData, tempRole.id)
    ) {
      tempError.name.isError = true;
      tempError.name.errorMessage = (
        <IntlMessages id='error.duplicateEntryFound' />
      );
      isValid = false;
    }

    if (tempRole.status.trim() == '') {
      tempError.status.isError = true;
      tempError.status.errorMessage = (
        <IntlMessages id='error.pleaseSelectStatus' />
      );
      isValid = false;
    }
    if (isValid) {
      if (isEdit) {
        updateRoles();
      } else {
        submitRoles();
      }
    } else {
      setFormError(tempError);
    }
  };

  const submitRoles = async () => {
    try {
      const response = await jwtAxios.post(`${API_ROUTS.employeelevel}`, role);
      if (response.status == 201) {
        dispatch(
          showMessage(response.data.name + ' Level added successfully..!'),
        );
        handleAddRole(response.data);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const updateRoles = async () => {
    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.employeelevel}${role.id}`,
        role,
      );
      if (response.status == 200) {
        dispatch(
          showMessage(response.data.name + ' Level updated successfully..!'),
        );
        handleUpdateRole(response.data);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleChangeRoleData = (event) => {
    const tempRole = {...role};
    const tempError = {...formError};
    tempRole[event.target.name] = event.target.value;
    tempError[event.target.name].isError = false;
    tempError[event.target.name].errorMessage = '';
    setRole(tempRole);
    setFormError(tempError);
  };

  return (
    <Dialog maxWidth={'sm'} open={true}>
      <DialogContent>
        <Stack direction='row' justifyContent='center' sx={{mt: '7%'}}>
          <AppCard style={{width: '350px'}}>
            <h4 style={{display: 'flex'}}>
              {!isEdit ? (
                <IntlMessages id='roles.addGradesLevel' />
              ) : (
                <IntlMessages id='roles.updateGradesLevel' />
              )}
            </h4>
            <Stack
              sx={{mt: 2}}
              display='flex'
              justifyContent='center'
              spacing={2}
            >
              <TextField
                size='small'
                name='name'
                label={<IntlMessages id='configuration.dialogbox.Name' />}
                onChange={(event) => handleChangeRoleData(event)}
                value={role?.name}
                error={formError.name.isError}
                helperText={formError.name.errorMessage}
                variant='outlined'
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              />
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id='event-type'>
                  <IntlMessages id='configuration.dialogbox.Status' />
                </InputLabel>
                <Select
                  size='small'
                  name='status'
                  label='Status'
                  value={role?.status}
                  error={formError.status.isError}
                  helperText={formError.status.errorMessage}
                  onChange={(event) => handleChangeRoleData(event)}
                  variant='outlined'
                  sx={{...textFieldStyled}}
                >
                  <MenuItem key='Active' value='ACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Active' />
                  </MenuItem>
                  <MenuItem key='Inactive' value='INACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                  </MenuItem>
                </Select>
                <FormHelperText style={{color: '#d32f2f'}}>
                  {formError.status.errorMessage}
                </FormHelperText>
              </FormControl>
            </Stack>
          </AppCard>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={() => handleValidateRole()}>
          <IntlMessages id='common.button.Submit' />
        </Button>
        <Button onClick={() => handleClose()}>
          <IntlMessages id='common.button.Close' />
        </Button>
      </DialogActions>
      <AppInfoView />
    </Dialog>
  );
};

export default AddRoleModal;
AddRoleModal.propTypes = {
  company: PropTypes.object,
  handleAddRole: PropTypes.func,
  handleUpdateRole: PropTypes.func,
  handleClose: PropTypes.func,
  isEdit: PropTypes.bool,
  editRole: PropTypes.object,
  rolesData: PropTypes.array,
};
