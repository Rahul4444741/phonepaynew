import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard} from '../../../@crema';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import {AgGridReact} from 'ag-grid-react';
import {useDispatch, useSelector} from 'react-redux';
import AppInfoView from '../../../@crema/core/AppInfoView';
import AddRoleModal from './AddRoleModal';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import {
  fetchStart,
  showMessage,
  fetchError,
  showInfo,
} from '../../../redux/actions';
import axios from 'axios';
import AlertDialog from '../../Common/AlertDialog';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {TextField} from '@mui/material';
import {
  isEmptyNullUndefined,
  buttonStyle,
  apiCatchErrorMessage,
  isAllowedUser,
} from 'shared/utils/CommonUtils';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import IntlMessages from '@crema/utility/IntlMessages';
import {permissionName} from 'shared/utils/PermissionName';
import Error403 from 'modules/errorPages/Error403';
import { useCallback } from 'react';

const CustomHeaderName = () => <IntlMessages id='aggrid.tableHeader.Name' />;
const CustomHeaderStatus = () => (
  <IntlMessages id='aggrid.tableHeader.Status' />
);
const CustomHeaderAction = () => (
  <IntlMessages id='aggrid.tableHeader.Action' />
);

const Roles = () => {
  const dispatch = useDispatch();
  const [rolesData, setRolesData] = React.useState(null);
  const [isAddRoleOpen, setIsAddRoleOpen] = React.useState(false);
  const [isEdit, setIsEdit] = React.useState(false);
  const [editRole, setEditRole] = React.useState(undefined);
  const [overlayMessage, setOverlayMessage] = React.useState('No Rows To Show');
  const [isLoading, setIsLoading] = React.useState(true);
  const [alertProps, setAlertProps] = React.useState({
    isHideShow: false,
    message: '',
    title: '',
    alertType: '',
    actionParams: null,
  });

  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);

  React.useEffect(() => {
    if (isAllowedUser(permissionName.COMPANY_VARIABLES_EMPLOYEE_LEVELS)) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  // Custom Cell Renderer Components
  const StatusRenderer = (params) => (
    <Stack direction='row'>
      <div
        style={{color: params.data.status === 'ACTIVE' ? '#11C15B' : '#D32F2F'}}
      >
        {params.data.status}
      </div>
    </Stack>
  );

  const ActionRenderer = (params) => (
    <Stack direction='row'>
      {isAllowedUser(permissionName.UPDATE) && (
        <Button onClick={() => handleOpenEditModel(params)} style={buttonStyle}>
          <IntlMessages id='common.button.Edit' />
        </Button>
      )}
      {isAllowedUser(permissionName.DEACTIVATE) &&
        params.data.status === 'ACTIVE' && (
          <Button
            onClick={() => handleDeactivateConfirmation(params)}
            style={buttonStyle}
          >
            <IntlMessages id='common.button.Deactivate' />
          </Button>
        )}
      {isAllowedUser(permissionName.ACTIVATE) &&
        params.data.status === 'INACTIVE' && (
          <Button
            onClick={() => handleActivateConfirmation(params)}
            style={buttonStyle}
          >
            <IntlMessages id='common.button.Activate' />
          </Button>
        )}
    </Stack>
  );

  // Column Definitions
  const columnDefs = [
    {
      field: 'name',
      filter: true,
      headerName: 'Name',
      minWidth: 350,
      headerComponentFramework: CustomHeaderName,
    },
    {
      field: 'status',
      filter: true,
      headerName: 'Status',
      headerComponentFramework: CustomHeaderStatus,
      minWidth: 350,
      cellRenderer: StatusRenderer,
    },
    {
      headerName: 'Action',
      headerComponentFramework: CustomHeaderAction,
      minWidth: 300,
      cellRenderer: ActionRenderer,
    },
  ];

  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();
  React.useEffect(() => {
    dispatch(fetchStart);
    if (
      isAuthorized &&
      selectedCompany != null &&
      selectedCompany != undefined
    ) {
      getAllActiveRoles(selectedCompany.id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, [isAuthorized, selectedCompany]);

  const gridRef = React.useRef();
  const defaultColDef = React.useMemo(() => ({
    sortable: true,
  }));

  const getAllActiveRoles = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.employeelevel_companyID}${companyId}?status=ACTIVE`,
        {cancelToken: source.token},
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no roles for selected company'));
          setRolesData([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setRolesData(reversed);
        }
        setIsLoading(() => false);
      } else {
        setRolesData([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setRolesData([]);
    }
    setIsLoading(() => false);
  };
  const getAllInactiveRoles = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.employeelevel_companyID}${companyId}?status=INACTIVE`,
        {cancelToken: source2.token},
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no roles for selected company'));
          setRolesData([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setRolesData(reversed);
        }
        setIsLoading(() => false);
      } else {
        setRolesData([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setRolesData([]);
      setIsLoading(() => false);
    }
  };

  const handleOpenEditModel = (params) => {
    let rowData = [];
    params.api.forEachNode((node) => rowData.push(node.data));
    const roleIndex = rowData.findIndex((item) => item.id == params.data.id);

    if (roleIndex != -1) setEditRole(rowData[roleIndex]);
    setIsEdit(true);
    setIsAddRoleOpen(true);
  };

  const handleDeactivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = <IntlMessages id='warning.deactivateRole' />;

    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureDeactivate' /> {params.data.name} ?
      </span>
    );

    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleAlertYes = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.actionParams.data.status == 'ACTIVE' &&
      handleDeactivateRole(tempAlertProps.actionParams);
    tempAlertProps.actionParams.data.status == 'INACTIVE' &&
      handleActivateRole(tempAlertProps.actionParams);
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };

  const handleAlertNo = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };
  const handleDeactivateRole = async (params) => {
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));
      const response = await jwtAxios.put(
        `${API_ROUTS.employeelevel_inactivate}${params.data.id}`,
      );
      if (response.status == 200) {
        dispatch(showMessage('Role deactivate successfully..!'));

        const roleIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );

        if (roleIndex != -1) {
          rowData[roleIndex].status = 'INACTIVE';
        }
        getAllInactiveRoles(selectedCompany.id);
        setAlignment('INACTIVE');
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleActivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = <IntlMessages id='warning.activateRole' />;
    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureActivate' /> {params.data.name} ?
      </span>
    );
    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleActivateRole = async (params) => {
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));
      const response = await jwtAxios.put(
        `${API_ROUTS.employeelevel_activate}${params.data.id}`,
      );
      if (response.status == 200) {
        dispatch(showMessage('Role activate successfully..!'));
        const roleIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );
        if (roleIndex != -1) {
          rowData[roleIndex].status = 'ACTIVE';
        }
        getAllActiveRoles(selectedCompany.id);
        setAlignment('ACTIVE');
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleUpdateRole = (role) => {
    const isActive = role.status === 'ACTIVE';
    const isInactive = role.status === 'INACTIVE';
  
    if ((isActive && alignment === 'ACTIVE') || (isInactive && alignment === 'INACTIVE')) {
      const tempRoles = [...rolesData];
      const roleIndex = tempRoles.findIndex((item) => item.id === role.id);
  
      if (roleIndex !== -1) {
        tempRoles[roleIndex] = role;
        setRolesData(tempRoles);
      }
    }
  
    if ((isActive && alignment === 'INACTIVE') || (isInactive && alignment === 'ACTIVE')) {
      setAlignment(isActive ? 'ACTIVE' : 'INACTIVE');
      isActive ? getAllActiveRoles(selectedCompany.id) : getAllInactiveRoles(selectedCompany.id);
    }
  
    setEditRole(null);
    setIsEdit(false);
    setIsAddRoleOpen(false);
  };
  
  const handleAddRoleToList = (role) => {
    if (role.status == 'ACTIVE') {
      if (alignment == 'ACTIVE') {
        const tempRoles = [...rolesData];
        tempRoles.unshift(role);
        setRolesData(tempRoles);
      }
    }
    if (role.status == 'INACTIVE') {
      if (alignment == 'INACTIVE') {
        const tempRoles = [...rolesData];
        tempRoles.unshift(role);
        setRolesData(tempRoles);
      }
    }
    if (role.status == 'ACTIVE') {
      if (alignment == 'INACTIVE') {
        setAlignment('ACTIVE');
        getAllActiveRoles(selectedCompany.id);
      }
    }
    if (role.status == 'INACTIVE') {
      if (alignment == 'ACTIVE') {
        setAlignment('INACTIVE');
        getAllInactiveRoles(selectedCompany.id);
      }
    }

    setIsAddRoleOpen(false);
  };

  const handleCloseAddRole = () => {
    setIsAddRoleOpen(false);
  };
  const handleOpenAddRole = () => {
    setIsAddRoleOpen(true);
    setIsEdit(false);
  };

  const [alignment, setAlignment] = React.useState('ACTIVE');

  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
  };

  const onFilterTextBoxChanged = useCallback(() => {
    const filterText = document.getElementById("filter-text-box").value;
    gridRef.current.api.setGridOption("quickFilterText", filterText);
    const totalResults = gridRef.current.api.getDisplayedRowCount();
    if (!isEmptyNullUndefined(rolesData) && rolesData.length > 0) {
      if (totalResults === 0 && !isEmptyNullUndefined(filterText)) {
        setOverlayMessage('No Record Found');
        gridRef.current.api.showNoRowsOverlay();
      } else if (totalResults !== 0) {
        setOverlayMessage('No Rows To Show');
        gridRef.current.api.hideOverlay();
      }
    }
  }, []);

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (!isAuthorized) {
    return <Error403 />;
  }

  return (
      <AppAnimate animation='transition.slideUpIn' delay={500}>
        <AppPageMeta />
        <h2 style={{marginBottom: 20}}>
          <IntlMessages id='roles.pageHeaderName' />
        </h2>
        <AppCard>
          <Stack style={{width: '100%'}}>
            <Stack direction='row' sx={{mb: 2}} justifyContent={'end'}>
              <TextField
                //size='small'
                sx={{width: 200, mr: 2}}
                id="filter-text-box"
                onInput={onFilterTextBoxChanged}
                type={'search'}
                name='search'
                label={<IntlMessages id='common.button.Search' />}
                variant='outlined'
              />
              {isAllowedUser(permissionName.CREATE) && (
                <Button
                  sx={{mr: 2}}
                  variant='outlined'
                  onClick={() => handleOpenAddRole()}
                >
                  <IntlMessages id='roles.addGradesLevel' />
                </Button>
              )}
              <ToggleButtonGroup
                color='primary'
                value={alignment}
                exclusive
                onChange={handleChange}
              >
                <ToggleButton
                  value='ACTIVE'
                  onClick={() => getAllActiveRoles(selectedCompany.id)}
                >
                  <IntlMessages id='common.button.Active' />
                </ToggleButton>
                <ToggleButton
                  value='INACTIVE'
                  onClick={() => getAllInactiveRoles(selectedCompany.id)}
                >
                  <IntlMessages id='common.button.Inactive' />
                </ToggleButton>
              </ToggleButtonGroup>
            </Stack>
            {isLoading ? (
              domCreactionGridSkeletonLoader()
            ) : (
              <Stack
                className='ag-theme-alpine'
                style={{height: 525, width: '100%'}}
              >
                <AgGridReact
                  ref={gridRef}
                  rowData={rolesData}
                  columnDefs={columnDefs}
                  defaultColDef={defaultColDef}
                  animateRows={true}
                  pagination={true}
                  paginationPageSize={10}
                  overlayLoadingTemplate={
                    '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'
                  }
                  overlayNoRowsTemplate={`<span class="ag-overlay-loading-center">${overlayMessage}</span>`}
                />
              </Stack>
            )}
          </Stack>
          {isAddRoleOpen && (
            <AddRoleModal
              company={selectedCompany}
              isEdit={isEdit}
              editRole={editRole}
              handleAddRole={(role) => handleAddRoleToList(role)}
              handleUpdateRole={(role) => handleUpdateRole(role)}
              handleClose={() => handleCloseAddRole()}
              rolesData={rolesData}
            ></AddRoleModal>
          )}
          {alertProps.isHideShow && (
            <AlertDialog
              alertProps={alertProps}
              handleYes={() => handleAlertYes()}
              handleNo={() => handleAlertNo()}
            />
          )}
        </AppCard>
        <AppInfoView />
      </AppAnimate>
  );
};

export default Roles;
