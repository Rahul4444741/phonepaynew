import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../../@crema/core/AppAnimate';
import DoneAllIcon from '@mui/icons-material/DoneAll';
import SpeakerNotesOffIcon from '@mui/icons-material/SpeakerNotesOff';
import {green, red} from '@mui/material/colors';
import {AppCard, AppInfoView} from '../../../../@crema';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import AppPageMeta from '../../../../@crema/core/AppPageMeta';
import Router, {useRouter} from 'next/router';
import {styled} from '@mui/material/styles';
import {useDispatch, useSelector} from 'react-redux';
import {fetchError} from '../../../../redux/actions';
import axios from 'axios';
import {isEmptyNullUndefined} from 'shared/utils/CommonUtils';
import IntlMessages from '@crema/utility/IntlMessages';
import {footerButton} from 'shared/constants/AppConst';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {Box, Divider, Pagination} from '@mui/material';
import {Card, CardContent, Typography} from '@mui/material';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';

const ViewScheduler = () => {
  const router = useRouter();
  const selectedCompany = useSelector(({company}) => company.selectedCompany);
  const {id,name} = router.query;
  const dispatch = useDispatch();

  const [item, setItem] = React.useState(null)
  const [loading, setLoading] = React.useState(true);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();

  React.useEffect(() => {
    if (!isEmptyNullUndefined(id)) {
      getSchedulerHistoryDetails(id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
    };
  }, [id]);

  const getSchedulerHistoryDetails = async (id) => {
    setLoading(true);
    try {
      const response = await jwtAxios.get(
        `${API_ROUTS.schedulerHistory}/by-id?id=${id}`,
        {
          cancelToken: source.token,
        },
      );
      if (response.status === 200) {
        setItem(response.data);
        setLoading(false);
      }
    } catch (e) {
      dispatch(fetchError(e.response?.data?.detail));
      setLoading(false);
    }
  };

 console.log('item',item)

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <Typography variant='h2' style={{marginBottom: '10px'}}>
        Scheduler Details - {item?.schedulerType}
      </Typography>

      {loading ? (
        <AppCard>{domCreactionGridSkeletonLoader('60vh')}</AppCard>
      ) : (
          <Box
            sx={{display: 'flex', flexWrap: 'wrap', justifyContent: 'center'}}
          >
            {item ? <Card sx={{width: '100%', margin: '10px', mb: 5}}>
              <CardContent>
                <Stack
                  display={'flex'}
                  justifyContent={'space-between'}
                  direction={'row'}
                  sx={{mr: 3, ml: 3}}
                >
                  <Typography variant='h4' component='div'>
                    Type : {item?.schedulerType}
                  </Typography>
                  <Typography
                    variant='h4'
                    sx={{mb: 1.5}}
                    color='text.secondary'
                  >
                    Date : {item.date}
                  </Typography>
                </Stack>
                <Stack
                  display={'flex'}
                  justifyContent={'space-between'}
                  direction={'row'}
                >
                  {item.successfulRecords && (
                    <Card
                      sx={{
                        width: '100%',
                        margin: '10px 10px',
                        mb: 2,
                        backgroundColor: '#f5f2eb',
                        boxShadow: 'none',
                      }}
                    >
                      <CardContent>
                        <Box
                          sx={{
                            display: 'flex',
                            alignItems: 'center',
                            mt: 2,
                          }}
                        >
                          <DoneAllIcon sx={{color: green[500], mr: 1}} />
                          <Typography variant='h4'>
                            Successful Records:
                            {`(${item.successfulRecords?.length})`}
                          </Typography>
                        </Box>
                        <Divider sx={{mt: 1, mb: 1}} />
                        <Box>
                          {item.successfulRecords?.map((record) => (
                            <React.Fragment key={record}>
                              <Typography variant='h4' sx={{mt:1 , mb: 1,color:'green'}}>
                                {record}
                              </Typography>
                              <Divider sx={{mt: 1, mb: 1}} />
                            </React.Fragment>
                          ))}
                        </Box>
                      </CardContent>
                    </Card>
                  )}

                  {item.unSuccessfulRecords && (
                    <Card
                      sx={{
                        width: '100%',
                        margin: '10px 10px',
                        backgroundColor: '#f5f2eb',
                        boxShadow: 'none',
                      }}
                    >
                      <CardContent>
                        <Box
                          sx={{
                            display: 'flex',
                            alignItems: 'center',
                            mt: 2,
                          }}
                        >
                          <SpeakerNotesOffIcon sx={{color: red[500], mr: 1}} />
                          <Typography variant='h4'>
                            Unsuccessful Records:
                            {`(${item.unSuccessfulRecords?.length})`}
                          </Typography>
                        </Box>
                        <Divider sx={{mt: 1, mb: 1}} />
                        <Box>
                          {item.unSuccessfulRecords?.map((record, index) => (
                            <React.Fragment key={index}>
                              <Typography variant='h4' sx={{mb: 1, color:'red'}}>
                                {record?.recordId}
                              </Typography>
                              <Typography variant='body1' sx={{mb: 1}}>
                                <span style={{fontWeight:'700'}}>Reason :</span>{record?.reason}
                              </Typography>
                              <Divider sx={{mt: 1, mb: 1}} />
                            </React.Fragment>
                          ))}
                        </Box>
                      </CardContent>
                    </Card>
                  )}
                </Stack>
              </CardContent>
            </Card> : 'Scheduler data not found !'}
          </Box>
      )}
      <AppInfoView />

      <Stack
        sx={{
          bottom: 0,
          zIndex: 10,
          position: 'fixed',
          backdropFilter: 'blur(5px)',
          width: '100%',
          right: 0,
        }}
      >
        <Stack
          direction='row'
          justifyContent='end'
          alignItems='flex-start'
          spacing={2}
          sx={{
            pt: 5,
            ml: 3,
            margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
          }}
        >
          <Button
            color={footerButton.back.color}
            variant={footerButton.back.variant}
            sx={footerButton.back.sx}
            size={footerButton.back.size}
            onClick={() => Router.push(`/company-builder/view-schedular?name=${name}`)}
          >
            <IntlMessages id='common.button.Back' />
          </Button>
        </Stack>
      </Stack>
    </AppAnimate>
  );
};

export default ViewScheduler;
