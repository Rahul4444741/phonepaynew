import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../../@crema/core/AppAnimate';
import {green, purple, red} from '@mui/material/colors';
import {AppCard, AppInfoView} from '../../../../@crema';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import AppPageMeta from '../../../../@crema/core/AppPageMeta';
import Router, {useRouter} from 'next/router';
import {useDispatch, useSelector} from 'react-redux';
import {fetchError} from '../../../../redux/actions';
import axios from 'axios';
import {
  buttonStyle,
  getCompanyDateFormat,
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';
import IntlMessages from '@crema/utility/IntlMessages';
import {footerButton} from 'shared/constants/AppConst';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {
  FormControl,
  MenuItem,
  Pagination,
  Paper,
  Select,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@mui/material';
import {Typography} from '@mui/material';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import moment from 'moment';

const ViewScheduler = () => {
  const router = useRouter();
  const selectedCompany = useSelector(({company}) => company.selectedCompany);
  const {name} = router.query;
  const dispatch = useDispatch();

  const [api, setApi] = React.useState([]);
  const [loading, setLoading] = React.useState(true);
  const [paginatedData, setPaginatedData] = React.useState(null);
  const [currentPage, setCurrentPage] = React.useState(1);
  const [itemsPerPage, setItemsPerPage] = React.useState(10);
  const [totalPages, setTotalPages] = React.useState(null);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();

  const handleRedirectViewSchedulerDetails = (id,name) => {
    Router.push(`/company-builder/view-scheduler-details?id=${id}&name=${name}`);
  };

  React.useEffect(() => {
    // Calculate pagination
    if (!isEmptyNullUndefined(api)) {
      let tempStartIndex = (currentPage - 1) * itemsPerPage;
      let tempPaginationData = api.slice(
        tempStartIndex,
        tempStartIndex + itemsPerPage,
      );
      setPaginatedData(tempPaginationData);
    }
  }, [api, currentPage]);

  const handlePageChange = (event, newPage) => {
    setCurrentPage(newPage);
  };

  React.useEffect(() => {
    if (!isEmptyNullUndefined(name)) {
      getSchedulerHistoryDetails(name,currentPage,itemsPerPage);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
    };
  }, [name,currentPage,itemsPerPage]);

  const getSchedulerHistoryDetails = async (name,page,size) => {
    setLoading(true);
    try {
      const response = await jwtAxios.get(
        `${API_ROUTS.schedulerHistory}?type=${name}&companyId=${selectedCompany.id}&page=${page-1}&size=${size}`,
        {
          cancelToken: source.token,
        },
      );
      if (response.status === 200) {
        const sortedData = response.data?.data.sort(
          (a, b) => new Date(b.date) - new Date(a.date),
        );
        setApi(sortedData);
        setTotalPages(response.data?.totalPages);
        setLoading(false);
      }
    } catch (e) {
      dispatch(fetchError(e.response?.data?.detail));
      setLoading(false);
    }
  };

  console.log('api', api);

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <Typography variant='h2' style={{marginBottom: '10px'}}>
        Scheduler History Info
      </Typography>

      {loading ? (
        <AppCard>{domCreactionGridSkeletonLoader('60vh')}</AppCard>
      ) : (
        <AppCard>
          <Stack
            display='flex'
            justifyContent='center'
            alignItems='center'
            height='100%'
            sx={{mb: 10}}
          >
            <TableContainer component={Paper}>
              <Table sx={{width: '100%'}} aria-label='simple table'>
                <TableHead>
                  <TableRow>
                    <TableCell
                      sx={{backgroundColor: purple['100']}}
                      align='center'
                    >
                      Type
                    </TableCell>

                    <TableCell
                      sx={{backgroundColor: purple['100']}}
                      align='center'
                    >
                      Date
                    </TableCell>
                    <TableCell
                      sx={{backgroundColor: purple['100']}}
                      align='center'
                    >
                      Successful Record Count
                    </TableCell>
                    <TableCell
                      sx={{backgroundColor: purple['100']}}
                      align='center'
                    >
                      Unsuccessful Record Count
                    </TableCell>
                    <TableCell
                      sx={{backgroundColor: purple['100']}}
                      align='center'
                    >
                      Action
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {api &&
                    api.map((item, index) => (
                      <TableRow
                        key={index}
                        sx={{'&:last-child td, &:last-child th': {border: 0}}}
                      >
                        <TableCell
                          sx={{backgroundColor: green['100']}}
                          align='center'
                        >
                          {item.schedulerType}
                        </TableCell>
                        <TableCell
                          sx={{backgroundColor: red['50']}}
                          align='center'
                        >
                          {/* {item.date} */}
                          {moment(item.date && item.date).format(
                            getCompanyDateFormat(selectedCompany),
                          )}
                        </TableCell>
                        <TableCell
                          sx={{backgroundColor: green['100']}}
                          component='th'
                          scope='row'
                          align='center'
                        >
                          {item.successfulRecords?.length}
                        </TableCell>
                        <TableCell
                          sx={{backgroundColor: red['50']}}
                          align='center'
                        >
                          {item.unSuccessfulRecords?.length}
                        </TableCell>
                        <TableCell
                          sx={{backgroundColor: green['100']}}
                          align='center'
                        >
                          <Stack direction='row' sx={{ml:5}}>
                            <div
                              onClick={() =>
                                handleRedirectViewSchedulerDetails(item.id,item.schedulerType)
                              }
                              style={buttonStyle}
                            >
                              View Details
                            </div>
                          </Stack>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Stack>
          <Stack
            display='flex'
            alignItems='center'
            justifyContent='center'
            style={{
              // marginTop: '10px',
              marginBottom: '20px',
            }}
          >
            {api.length > 0 && (
              <Stack display='flex' direction='row'>
                <Stack display='flex' direction='row'>
                  <FormControl sx={{m: 1, minWidth: 70}} size='small'>
                    <Select
                      labelId='demo-customized-select-label'
                      id='demo-customized-select'
                      value={itemsPerPage}
                      autoWidth
                      onChange={(event) => {
                        setItemsPerPage(event.target.value);
                        setCurrentPage(1);
                      }}
                    >
                      <MenuItem value={10}>10</MenuItem>
                      <MenuItem value={20}>20</MenuItem>
                      <MenuItem value={50}>50</MenuItem>
                      <MenuItem value={100}>100</MenuItem>
                    </Select>
                  </FormControl>
                </Stack>
                <Stack>
                  <Pagination
                    count={totalPages}
                    page={currentPage}
                    onChange={handlePageChange}
                    color='primary'
                    size='large'
                  />
                </Stack>
              </Stack>
            )}
          </Stack>
        </AppCard>
      )}
      <AppInfoView />

      <Stack
        sx={{
          bottom: 0,
          zIndex: 10,
          position: 'fixed',
          backdropFilter: 'blur(5px)',
          width: '100%',
          right: 0,
        }}
      >
        <Stack
          direction='row'
          justifyContent='end'
          alignItems='flex-start'
          spacing={2}
          sx={{
            pt: 5,
            ml: 3,
            margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
          }}
        >
          <Button
            color={footerButton.back.color}
            variant={footerButton.back.variant}
            sx={footerButton.back.sx}
            size={footerButton.back.size}
            onClick={() => Router.push('/company-builder/schedular-history')}
          >
            <IntlMessages id='common.button.Back' />
          </Button>
        </Stack>
      </Stack>
    </AppAnimate>
  );
};

export default ViewScheduler;
