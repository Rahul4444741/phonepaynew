import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard} from '../../../@crema';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import {AgGridReact} from 'ag-grid-react';
import {useDispatch, useSelector} from 'react-redux';
import AppInfoView from '../../../@crema/core/AppInfoView';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import {
  fetchStart,
  fetchSuccess,
  showMessage,
  fetchError,
  showInfo,
} from '../../../redux/actions';
import axios from 'axios';
import AlertDialog from '../../Common/AlertDialog';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {TextField} from '@mui/material';
import {
  isEmptyNullUndefined,
  buttonStyle,
  apiCatchErrorMessage,
  isAllowedUser,
} from 'shared/utils/CommonUtils';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import IntlMessages from '@crema/utility/IntlMessages';
import Router, {useRouter} from 'next/router';
import {permissionName} from 'shared/utils/PermissionName';
import Error403 from 'modules/errorPages/Error403';
import { useCallback } from 'react';

const SchedulerHistory = () => {
  const dispatch = useDispatch();
  const [schedulerHistory, setSchedulerHistory] = React.useState(null);
  const [overlayMessage, setOverlayMessage] = React.useState('No Rows To Show');
  const [isLoading, setIsLoading] = React.useState(true);
  const [alertProps, setAlertProps] = React.useState({
    isHideShow: false,
    message: '',
    title: '',
    alertType: '',
    actionParams: null,
  });

  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);

  React.useEffect(() => {
    if (isAllowedUser(permissionName.SET_UP_EEP_SCHEDULER_HISTORY)) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  const CustomHeaderName = () => (
    <IntlMessages id='aggrid.tableHeader.Name' />
  );
  const CustomHeaderAction = () => (
    <IntlMessages id='aggrid.tableHeader.Action' />
  );

  
  const columnDefs = [
    {
      field: 'name',
      filter: true,
      headerName: 'Name',
      headerComponentFramework: CustomHeaderName,
      resizable: true, // Makes the column resizable
      flex: 2, // Automatically adjusts the width relative to other columns
    },
    {
      headerName: 'Action',
      headerComponentFramework: CustomHeaderAction,
      resizable: true, // Makes the column resizable
      flex: 1, // Automatically adjusts the width relative to other columns
      cellRenderer: function (params) {
        return (
          <Stack direction='row'>
            {isAllowedUser(permissionName.READ) && (
              <Button onClick={() => handleRedirectViewApi(params)} style={buttonStyle}>
                <IntlMessages id='common.button.View' />
              </Button>
            )}
          </Stack>
        );
      },
    },
  ];
  

  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();
  React.useEffect(() => {
    dispatch(fetchStart);
    if (
      isAuthorized &&
      selectedCompany != null &&
      selectedCompany != undefined
    ) {
      getAPIHistory(selectedCompany.id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, [isAuthorized, selectedCompany]);

  const gridRef = React.useRef();
  const defaultColDef = React.useMemo(() => ({
    sortable: true,
  }));

  const onFilterTextBoxChanged = useCallback(() => {
    const filterText = document.getElementById("filter-text-box").value;
    gridRef.current.api.setGridOption("quickFilterText", filterText);
    const totalResults = gridRef.current.api.getDisplayedRowCount();
    if (!isEmptyNullUndefined(schedulerHistory) && schedulerHistory.length > 0) {
      if (totalResults === 0 && !isEmptyNullUndefined(filterText)) {
        setOverlayMessage('No Record Found');
        gridRef.current.api.showNoRowsOverlay();
      } else if (totalResults !== 0) {
        setOverlayMessage('No Rows To Show');
        gridRef.current.api.hideOverlay();
      }
    }
  }, []);

  const handleRedirectViewApi = (params) => {
    if(params.data.name==='API HISTORY'){
      Router.push(`/company-builder/api-history`);
    }else{
      Router.push(`/company-builder/view-schedular?name=${params.data?.name}`);
    }
  };

  const getAPIHistory = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.schedulerHistory}/${companyId}`,
        {
          cancelToken: source.token,
        },
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(
            showInfo('You have no schedular history for selected company'),
          );
          setSchedulerHistory([]);
        } else {
          const reversed = res.data?.map((item) => ({
            name: item,
          }));
          setSchedulerHistory([{name:'API HISTORY'},...reversed]);
        }
        setIsLoading(() => false);
      } else {
        setSchedulerHistory([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setSchedulerHistory([]);
    }
    setIsLoading(() => false);
  };

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (!isAuthorized) {
    return <Error403 />;
  }

  return (
    <>
      <AppAnimate animation='transition.slideUpIn' delay={500}>
        <AppPageMeta />
        <h2 style={{marginBottom: 20}}>
          {/* <IntlMessages id='roles.pageHeaderName' /> */}
          Scheduler History
        </h2>
        <AppCard>
          <Stack style={{width: '100%'}}>
            <Stack direction='row' sx={{mb: 2}} justifyContent={'end'}>
              <TextField
                //size='small'
                sx={{width: 200, mr: 2}}
                id="filter-text-box"
                onInput={onFilterTextBoxChanged}
                type={'search'}
                name='search'
                label={<IntlMessages id='common.button.Search' />}
                variant='outlined'
              />
            </Stack>
            {isLoading ? (
              domCreactionGridSkeletonLoader()
            ) : (
              <Stack
                className='ag-theme-alpine'
                style={{height: 525, width: '100%'}}
              >
                <AgGridReact
                  ref={gridRef}
                  rowData={schedulerHistory}
                  columnDefs={columnDefs}
                  defaultColDef={defaultColDef}
                  animateRows={true}
                  pagination={true}
                  paginationPageSize={10}
                  overlayLoadingTemplate={
                    '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'
                  }
                  overlayNoRowsTemplate={`<span class="ag-overlay-loading-center">${overlayMessage}</span>`}
                />
              </Stack>
            )}
          </Stack>
        </AppCard>
        <AppInfoView />
      </AppAnimate>
    </>
  );
};

export default SchedulerHistory;
