import { AppAnimate, AppCard, AppInfoView } from "@crema";
import { Button, Checkbox, Stack } from "@mui/material";
import AppPageMeta from '../../../../../../@crema/core/AppPageMeta';
import Router, { useRouter } from "next/router";
import { useState } from "react";
import IntlMessages from "@crema/utility/IntlMessages";

const label = { inputProps: { 'aria-label': 'Checkbox demo' } };

const TargetMsg = () => {

  const router = useRouter();

  const [name, setName] = useState(null);

  const handleNext = () => {
    router.push({
        pathname: "/mails/configurations/createConfiguration/create",
        query: { name: name }
      })
  }

    return(
        <AppAnimate animation='transition.slideUpIn' delay={500}>
        <AppPageMeta />
        <h2 style={{ marginBottom: 20 }}><IntlMessages id='templeteConfiguration.targetMsg'/></h2>
        <AppCard>
          <div className="target-msg-options">
            {/* <div className="msg-options">
                <Checkbox 
                checked={name && name === "Benefit Update"}
                onClick={() => setName("Benefit Update")}
                {...label} 
                sx={{ '& .MuiSvgIcon-root': { fontSize: 28 } }}
                />
                <span><IntlMessages id='templeteConfiguration.targetMsg.benefitUpdate'/></span>
            </div>
            <div className="msg-options">
                <Checkbox 
                checked={name && name === "Personal Information"}
                onClick={() => setName("Personal Information")}
                {...label} 
                sx={{ '& .MuiSvgIcon-root': { fontSize: 28 } }}
                />
                <span><IntlMessages id='templeteConfiguration.targetMsg.personalInformation'/></span>
            </div> */}
            <div className="msg-options">
                <Checkbox 
                checked={name && name === "Scheduled Message"}
                onClick={() => setName("Scheduled Message")}
                {...label} 
                sx={{ '& .MuiSvgIcon-root': { fontSize: 28 } }}
                />
                <span><IntlMessages id='templeteConfiguration.targetMsg.customScheduledMessage'/></span>
            </div>
            <div className="msg-options">
                <Checkbox 
                checked={name && name === "Event-Based Message"}
                onClick={() => setName("Event-Based Message")}
                {...label} 
                sx={{ '& .MuiSvgIcon-root': { fontSize: 28 } }}
                />
                <span><IntlMessages id='templeteConfiguration.targetMsg.customEventBasedMessage'/></span>
            </div>
          </div>     

          <Button 
          sx={{mt:4, mr:4}}
          variant="contained"
          // onClick={() => router.back()}
          onClick={() => Router.push('/mails/configurations/configurations')}
          // disabled={name === null}
          >
            <IntlMessages id='common.button.Back'/>                 
          </Button>
          <Button 
          sx={{mt:4}}
          color="success"
          variant="contained"
          onClick={() => handleNext()}
          disabled={name === null}
          >
            <IntlMessages id='common.button.Next'/>               
          </Button>
          
        </AppCard>
        <AppInfoView />
        </AppAnimate>    
    )
}

export default TargetMsg;