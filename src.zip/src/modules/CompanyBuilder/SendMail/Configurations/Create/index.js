import {AppAnimate} from '@crema';
import {useState} from 'react';
import {AppCard} from '../../../../../@crema';
import AppPageMeta from '../../../../../@crema/core/AppPageMeta';
import AppInfoView from '../../../../../@crema/core/AppInfoView';
import Stack from '@mui/material/Stack';
import {
  Box,
  Button,
  CircularProgress,
  FormControl,
  FormControlLabel,
  FormGroup,
  FormHelperText,
  IconButton,
  InputLabel,
  MenuItem,
  Select,
  Skeleton,
  Switch,
  TextField,
  Typography,
} from '@mui/material';
// import { align, font, fontColor, fontSize, formatBlock, hiliteColor, horizontalRule, image, lineHeight, link, list, paragraphStyle, table, template, textStyle } from "../../../../../../node_modules/suneditor/src/plugins";
import Router, {useRouter} from 'next/router';
import {useEffect} from 'react';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API, API_ROUTS, baseURL} from 'shared/constants/ApiRouts';
import {useDispatch, useSelector} from 'react-redux';
import {fetchError, fetchSuccess, showInfo, showMessage} from 'redux/actions';
import {footerButton, frequency} from 'shared/constants/AppConst';
import {GoCloudUpload} from 'react-icons/go';
import {
  apiCatchErrorMessage,
  getCompanyDateFormatForInputs,
  getIdListFromObjects,
  getListItemDescription,
  isEmptyNullUndefined,
  onlyAcceptWholeNumbers,
} from 'shared/utils/CommonUtils';
import {ImCross} from 'react-icons/im';
import {DesktopDatePicker, LocalizationProvider} from '@mui/lab';
import {AdapterDateFns} from '@mui/x-date-pickers/AdapterDateFns';
import React from 'react';

import {
  align,
  font,
  fontColor,
  fontSize,
  formatBlock,
  hiliteColor,
  horizontalRule,
  image,
  lineHeight,
  link,
  list,
  paragraphStyle,
  table,
  template,
  textStyle,
} from '../../../../../../node_modules/suneditor/src/plugins';
import 'suneditor/dist/css/suneditor.min.css';
import mergeTag from '../Edit/merge_tag_plugin';
import dynamic from 'next/dynamic';
import Preview from '../Preview/Preview';
import {Divider} from '@mui/material';
import axios from 'axios';
import Checkbox from '@mui/material/Checkbox';
import IntlMessages from '@crema/utility/IntlMessages';

const SunEditor = dynamic(() => import('suneditor-react'), {
  ssr: false,
});

const SunEditorForFooter = dynamic(() => import('suneditor-react'), {
  ssr: false,
});

const parse = require('html-react-parser');

const requiredSelectStyled = {
  backgroundColor: 'white',
  '& fieldset': {
    borderLeftColor: 'red',
    borderLeftWidth: 3,
  },
};

// const selectedFrequency value of pos_t: __
const mailScheduleFrequencyList = [
  {value: 'Now', name: 'Now', id: 'Now'},
  {value: 'Daily', name: 'Daily', id: 'Daily'},
  {value: 'Weekly', name: 'Weekly', id: 'Weekly'},
  {value: 'Monthly', name: 'Monthly', id: 'Monthly'},
  {value: 'Custom', name: 'Custom', id: 'Custom'},
];

const CreateConfiguration = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const {id, page} = router.query;

  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const [days, setDays] = useState(Array(31).fill(false)); // days: null, // [1,2,3,4,5],
  const [startDate, setStartDate] = useState(null); //       startDate: null, // "2023-10-01T05:53:58.000+00:00",
  const [endDate, setEndDate] = useState(null); //        endDate: null, // "2024-11-01T05:53:58.000+00:00",
  const [time, setTime] = useState(null); //        time: null

  const [daysErr, setDaysErr] = useState(false);
  const [startDateErr, setStartDateErr] = useState(false);
  const [endDateErr, setEndDateErr] = useState(false);
  const [timeErr, setTimeErr] = useState(false);

  const [isBodyEditActive, setIsBodyEditActive] = useState(false);
  const [isFooterEditActive, setIsFooterEditActive] = useState(false);

  const cTypes = ['SCHEDULE_EVENT'];
  const xTypes = ['enrollment', 'life Event', 'open enrollment'];
  const ztypes = [
    {
      key: 'EMPLOYEMENT_EVENT',
      name: 'EMPLOYEMENT_EVENT',
      value: 'EMPLOYEMENT_EVENT',
      view: 'Employement Event',
    },
    {
      key: 'LIFE_EVENT',
      name: 'LIFE_EVENT',
      value: 'LIFE_EVENT',
      view: 'Life Event',
    },
    {
      key: 'PLATFORM_EVENT',
      name: 'PLATFORM_EVENT',
      value: 'PLATFORM_EVENT',
      view: 'Platform Event',
    },
  ];
  const subTypeDropDown = [
    {key: 'INITIAL', name: 'INITIAL', value: 'INITIAL', view: 'Initial'},
    {key: 'REMINDER', name: 'REMINDER', value: 'REMINDER', view: 'Reminder'},
    {key: 'FINAL', name: 'FINAL', value: 'FINAL', view: 'Confirm'},
    {
      key: 'FINAL_REMINDER',
      name: 'FINAL_REMINDER',
      value: 'FINAL_REMINDER',
      view: 'Final Reminder',
    },
    // added new dropdown 6 feb //
    {key: 'FEEDBACK_PROVIDED', name: 'FEEDBACK_PROVIDED', value: 'FEEDBACK_PROVIDED', view: 'Feedback Provided'},
    {key: 'FEEDBACK_RQUEST_DECLINED', name: 'FEEDBACK_RQUEST_DECLINED', value: 'FEEDBACK_RQUEST_DECLINED', view: 'Feedback Request Declined'},
    {key: 'FEEDBACK_REQUEST_EXPIRED', name: 'FEEDBACK_REQUEST_EXPIRED', value: 'FEEDBACK_REQUEST_EXPIRED', view: 'Feedback Request Expired'},
    {key: 'FEEDBACK_REQUEST_RECALLED', name: 'FEEDBACK_REQUEST_RECALLED', value: 'FEEDBACK_REQUEST_RECALLED', view: 'Feedback Request Recalled'},
  ];
  const applicableToDropdown = [
    {key: 'Employee', name: 'Employee', value: 'Employee', view: 'Employee'},
    {key: 'Manager', name: 'Manager', value: 'Manager', view: 'Manager'},
    {key: 'Peer', name: 'Peer', value: 'Peer', view: 'Peer'},
  ];

  // const [name, setName] = useState(null);
  const name = router?.query?.name;
  const [applicableTo, setApplicableTo] = useState('');
  const [applicableToError, setApplicableToError] = useState(false);
  const [subType, setSubType] = useState('');
  const [sendEmail, setSendEmail] = useState(true);
  const [sendNotification, setSendNotification] = useState(true);
  const [subTypeError, setSubTypeError] = useState(false);
  const [eventType, setEventType] = useState(null);
  const [eventTypeErr, setEventTypeErr] = useState(false);
  const [type, setType] = useState(null);
  const [typeErr, setTypeErr] = useState(false);
  const [templateName, setTemplateName] = useState(null);
  const [templateNameErr, setTemplateNameErr] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState('<p><br></p>');
  const [selectedTemplateErr, setSelectedTemplateErr] = useState(false);
  const [selectedTemplateInfo, setSelectedTemplateInfo] =
    useState('<p><br></p>');
  const [selectedTemplateInfoError, setSelectedTemplateInfoError] =
    useState(false);
  const [selectedFrequency, setSelectedFrequency] = useState(null);
  const [selectedFrequencyErr, setSelectedFrequencyErr] = useState(false);
  const [day, setDay] = useState('');
  const [dayErr, setDayErr] = useState('');
  const [isFileRequired, setIsFileRequired] = useState(false);
  const [isTemplateRequired, setIsTemplateRequired] = useState(false);
  const [file, setFile] = useState(null);
  const [fileErr, setFileErr] = useState(false);
  const [fileUploading, setFileUploading] = useState(false);
  const [dateC, setDateC] = useState(null);
  const [submitLoader, setSubmitLoader] = useState(false);
  const [isPreviewPageOpen, setpreviewPageOpen] = React.useState(false);
  const [mailFreq, setmailFreq] = useState(0);
  const [mailFreqErr, setmailFreqErr] = useState(false);
  const [queryList, setQueryList] = useState(null);
  const [customQuery, setCustomQuery] = useState(null);
  const [customQueryErr, setCustomQueryErr] = useState(null);
  const [eventList, setEventList] = React.useState({
    events: [],
    EMPLOYEMENT_EVENT: [],
    LIFE_EVENT: [],
    PLATFORM_EVENT: [],
  });

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  useEffect(() => {
    if (id) {
      (async () => {
        await getExistingData(selectedCompany.id);
      })();
    }
    if (name == 'Event-Based Message') getAllActiveEventList();

    if (selectedCompany != null && selectedCompany != undefined) {
      if (name == 'Scheduled Message' || name == 'Event-Based Message')
        getAllActiveQuery(selectedCompany.id);
    }

    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, []);

  const getAllActiveQuery = async (companyId) => {
    // setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        // `${baseURL}${API}/customquery?companyId=${companyId}&relationTable=Employee&status=ACTIVE`,
        `${API_ROUTS.customquery}?companyId=${companyId}&relationTable=Employee&status=ACTIVE`,
        {
          cancelToken: source.token,
        },
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no record'));
          setQueryList([]);
        } else {
          setQueryList(res.data.reverse());
        }
        // setIsLoading(() => false);
      } else {
        setQueryList([]);
        // setIsLoading(() => false);
      }
    } catch (e) {
      if (axios.isCancel(e)) {
      } else {
        apiCatchErrorMessage(e, dispatch, fetchError);
      }
      setQueryList([]);
    }
    // setIsLoading(() => false);
  };

  const handleChangeCheckDays = (index) => {
    const newChecked = [...days];
    newChecked[index] = !newChecked[index];
    setDays(newChecked);
    setDaysErr(false);
  };

  const handleChangeDates = (event, dateType) => {
    let tempEndDate = endDate;
    let tempStartDate = startDate;

    let tempEndDateErr = structuredClone(endDateErr);
    let tempStartDateErr = structuredClone(startDateErr);
    if (dateType == 'endDate') {
      tempEndDate = event;
    } else if (dateType == 'startDate') {
      tempStartDate = event;
    }

    if (event != 'Invalid Date') {
      if (tempEndDate != null && tempStartDate != null) {
        if (dateType == 'endDate') {
          if (Date.parse(tempEndDate) <= Date.parse(tempStartDate)) {
            tempEndDateErr = true;
          } else {
            tempEndDateErr = false;
          }
        } else if (dateType == 'startDate') {
          if (Date.parse(tempEndDate) <= Date.parse(tempStartDate)) {
            tempStartDateErr = true;
          } else {
            tempStartDateErr = false;
          }
        }
      } else {
        tempEndDateErr = false;
        tempStartDateErr = false;
      }
    } else {
      if (dateType == 'endDate') {
        tempEndDateErr = true;
      } else if (dateType == 'startDate') {
        tempStartDateErr = true;
      }
    }

    if (dateType == 'endDate') {
      setEndDateErr(tempEndDateErr);
      setEndDate(tempEndDate);
    } else if (dateType == 'startDate') {
      setStartDateErr(tempStartDateErr);
      setStartDate(tempStartDate);
    }
  };

  const handleChangetime = (event) => {
    const newValue = event.target.value;

    // Define your regex pattern (e.g., whole numbers from 0 to 24)
    const pattern = /^(?:[0-9]|1[0-9]|2[0-4])$/;

    // Check if the input matches the pattern
    const isValidInput = pattern.test(newValue);
    if (isValidInput) {
      setTime(newValue);
    } else if (event.target.value == null || event.target.value == '') {
      setTime('');
    }
    setTimeErr(!isValidInput); // Set error state based on validity
  };

  const getAllActiveEventList = async () => {
    const arrangeObjectEventList = (data) => {
      const tempEventList = JSON.parse(JSON.stringify(eventList));
      tempEventList.events = [];
      tempEventList.EMPLOYEMENT_EVENT = [];
      tempEventList.LIFE_EVENT = [];
      tempEventList.PLATFORM_EVENT = [];
      // {events: [], EMPLOYEMENT_EVENT: [], LIFE_EVENT: [], PLATFORM_EVENT: []}
      tempEventList.events = data;
      data.forEach((element) => {
        if (element.eventType == 'LIFE_EVENT') {
          tempEventList.LIFE_EVENT.push(element);
        } else if (element.eventType == 'EMPLOYEMENT_EVENT') {
          tempEventList.EMPLOYEMENT_EVENT.push(element);
        } else if (element.eventType == 'PLATFORM_EVENT') {
          tempEventList.PLATFORM_EVENT.push(element);
        }
      });
      setEventList(() => tempEventList);
    };
    try {
      const response = await jwtAxios.get(`${API_ROUTS.events}?status=ACTIVE`, {
        cancelToken: source.token,
      });
      if (response.status == 200) {
        if (response.data.length == 0) {
          dispatch(showInfo('You have no event for selected status'));
        } else {
          arrangeObjectEventList(response.data);
        }
      } else {
        console.log(response);
      }
    } catch (error) {
      if (axios.isCancel(error)) {
      } else {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setEventList([]);
    }
  };

  const isValid = () => {
    let valid = true;

    if (name === 'Scheduled Message') {
      if (isEmptyNullUndefined(applicableTo)) {
        setApplicableToError(() => true);
        valid = false;
      }

      if (isEmptyNullUndefined(eventType)) {
        setEventTypeErr(true);
        valid = false;
      } else if (eventType[0] === 'SCHEDULE_EVENT') {
        if (!isEmptyNullUndefined(selectedFrequency)) {
          if (isEmptyNullUndefined(customQuery)) {
            setCustomQueryErr(true);
            valid = false;
          }
          if (isEmptyNullUndefined(templateName)) {
            setTemplateNameErr(true);
            valid = false;
          }
          if (
            isEmptyNullUndefined(selectedTemplate) ||
            selectedTemplate === '<p><br></p>'
          ) {
            setSelectedTemplateErr(true);
            valid = false;
          }
          if (
            isEmptyNullUndefined(selectedTemplateInfo) ||
            selectedTemplateInfo === '<p><br></p>'
          ) {
            setSelectedTemplateInfoError(true);
            valid = false;
          }
          if (selectedFrequency === 'Now') {
          } else if (selectedFrequency === 'Daily') {
            if (startDateErr) {
              valid = false;
            } else if (isEmptyNullUndefined(startDate)) {
              setStartDateErr(true);
              valid = false;
            }
            if (endDateErr) {
              valid = false;
            } else if (isEmptyNullUndefined(endDate)) {
              setEndDateErr(true);
              valid = false;
            }
            if (isEmptyNullUndefined(time)) {
              setTimeErr(true);
              valid = false;
            }
          } else if (
            selectedFrequency === 'Weekly' ||
            selectedFrequency === 'Monthly'
          ) {
            if (startDateErr) {
              valid = false;
            } else if (isEmptyNullUndefined(startDate)) {
              setStartDateErr(true);
              valid = false;
            }
            if (endDateErr) {
              valid = false;
            } else if (isEmptyNullUndefined(endDate)) {
              setEndDateErr(true);
              valid = false;
            }
            if (isEmptyNullUndefined(time)) {
              setTimeErr(true);
              valid = false;
            }
            if (!days.some((e) => e == true)) {
              setDaysErr(true);
              valid = false;
            }
          } else if (selectedFrequency === 'Custom') {
            if (startDateErr) {
              valid = false;
            } else if (isEmptyNullUndefined(startDate)) {
              setStartDateErr(true);
              valid = false;
            }
            if (endDateErr) {
              valid = false;
            } else if (isEmptyNullUndefined(endDate)) {
              setEndDateErr(true);
              valid = false;
            }
            if (isEmptyNullUndefined(time)) {
              setTimeErr(true);
              valid = false;
            }
            if (isEmptyNullUndefined(mailFreq)) {
              setmailFreqErr(true);
              valid = false;
            }
          }
        } else {
          setSelectedFrequencyErr(true);
          valid = false;
        }
      }
    } else if (name === 'Event-Based Message') {
      if (isEmptyNullUndefined(customQuery)) {
        setCustomQueryErr(true);
        valid = false;
      }
      if (isEmptyNullUndefined(eventType)) {
        setEventTypeErr(true);
        valid = false;
      }
      if (eventType) {
        if (type === null) {
          setTypeErr(true);
          valid = false;
        }
        if (isEmptyNullUndefined(templateName)) {
          setTemplateNameErr(true);
          valid = false;
        }
        if (
          isEmptyNullUndefined(selectedTemplate) ||
          selectedTemplate === '<p><br></p>'
        ) {
          setSelectedTemplateErr(true);
          valid = false;
        }
        if (
          isEmptyNullUndefined(selectedTemplateInfo) ||
          selectedTemplateInfo === '<p><br></p>'
        ) {
          setSelectedTemplateInfoError(true);
          valid = false;
        }
      }
      if (isEmptyNullUndefined(subType)) {
        setSubTypeError(() => true);
        valid = false;
      }
      if (isEmptyNullUndefined(applicableTo)) {
        setApplicableToError(() => true);
        valid = false;
      }
      if (subType == 'REMINDER') {
        if (Number(mailFreq) === 0 || mailFreq === '') {
          setmailFreqErr(true);
          valid = false;
        }
      }
    }
    if (isFileRequired) {
      if (isEmptyNullUndefined(file)) {
        setFileErr(true);
        valid = false;
      }
    }
    return valid;
  };
  const getDays = (payload) => {
    const indicesWithValueTruePlusOne = [];

    for (let i = 0; i < payload.length; i++) {
      if (payload[i] === true) {
        indicesWithValueTruePlusOne.push(i + 1);
      }
    }
    return indicesWithValueTruePlusOne;
  };
  const handleSubmit = (isDraft) => {
    if (isDraft) {
      let payLoadForEventBasedMessage = {
        name: name,
        eventType: eventType,
        type: type,
        subType: subType,
        sendEmail: sendEmail,
        sendNotification: sendNotification,
        applicableTo: applicableTo,
        body: selectedTemplate,
        info: selectedTemplateInfo,
        subject: templateName,
        company: {
          id: selectedCompany?.id,
        },
        status: 'ISDRAFT',
        reportingFrequency: selectedFrequency,
        day: day,
        file: file,
        isTemplateRequired: isTemplateRequired,
        mailFrequency: subType === 'REMINDER' ? mailFreq : null,
        date: dateC,
        classname: null,
        planId: null,
        rules: rulesPayload(),
        customQuery: {id: customQuery},
      };
      let payLoadForScheduledMessage = {
        name: name,
        eventType: eventType,
        type: type,
        subType: subType,
        sendEmail: sendEmail,
        sendNotification: sendNotification,
        applicableTo: applicableTo,
        body: selectedTemplate,
        info: selectedTemplateInfo,
        subject: templateName,
        company: {
          id: selectedCompany?.id,
        },
        status: 'ISDRAFT',
        mailFrequency: mailFreq,
        reportingFrequency: null,
        mailScheduleFrequency: selectedFrequency,
        day: day,
        company: {
          id: selectedCompany?.id,
        },
        file: file,
        isTemplateRequired: isTemplateRequired,
        date: new Date().toISOString(),
        classname: null,
        planId: null,
        rules: rulesPayload(),
        days: getDays([...days]),
        startDate: startDate, // "2023-10-01T05:53:58.000+00:00",
        endDate: endDate, // "2024-11-01T05:53:58.000+00:00",
        time: time, // 0 - 24 hours
        customQuery: {id: customQuery},
      };
      setSubmitLoader(true);
      jwtAxios
        .post(
          `${API_ROUTS.submitMailTempConfiguration}`,
          name == 'Scheduled Message'
            ? payLoadForScheduledMessage
            : payLoadForEventBasedMessage,
        )
        .then((res) => {
          // setSubmitLoader(false);
          dispatch(
            showMessage(' Draft Configuration added successfully..!'),
            router.push(`/mails/configurations/configurations`),
          );
        })
        .catch((error) => {
          setSubmitLoader(false);
          apiCatchErrorMessage(error, dispatch, fetchError);
        });
    } else {
      if (isValid()) {
        let payLoadForEventBasedMessage = {
          name: name,
          eventType: eventType,
          type: type,
          subType: subType,
          sendEmail: sendEmail,
          sendNotification: sendNotification,
          applicableTo: applicableTo,
          body: selectedTemplate,
          info: selectedTemplateInfo,
          subject: templateName,
          company: {
            id: selectedCompany?.id,
          },
          status: isDraft ? 'INACTIVE' : 'ACTIVE',
          reportingFrequency: selectedFrequency,
          day: day,
          file: file,
          isTemplateRequired: isTemplateRequired,
          mailFrequency: subType === 'REMINDER' ? mailFreq : null,
          date: dateC,
          classname: null,
          planId: null,
          rules: rulesPayload(),
          customQuery: {id: customQuery},
        };
        let payLoadForScheduledMessage = {
          name: name,
          eventType: eventType,
          type: type,
          subType: subType,
          sendEmail: sendEmail,
          sendNotification: sendNotification,
          applicableTo: applicableTo,
          body: selectedTemplate,
          info: selectedTemplateInfo,
          subject: templateName,
          company: {
            id: selectedCompany?.id,
          },
          status: isDraft ? 'INACTIVE' : 'ACTIVE',
          mailFrequency: mailFreq,
          reportingFrequency: null,
          mailScheduleFrequency: selectedFrequency,
          day: day,
          company: {
            id: selectedCompany?.id,
          },
          file: file,
          isTemplateRequired: isTemplateRequired,
          date: new Date().toISOString(),
          classname: null,
          planId: null,
          rules: rulesPayload(),
          days: getDays([...days]),
          startDate: startDate, // "2023-10-01T05:53:58.000+00:00",
          endDate: endDate, // "2024-11-01T05:53:58.000+00:00",
          time: time, // 0 - 24 hours
          customQuery: {id: customQuery},
        };
        setSubmitLoader(true);
        if (id) {
          jwtAxios
            .put(
              `${API_ROUTS.submitMailTempConfiguration}/${id}`,
              name == 'Scheduled Message'
                ? payLoadForScheduledMessage
                : payLoadForEventBasedMessage,
            )
            .then((res) => {
              // setSubmitLoader(false);
              dispatch(
                showMessage(' Configuration updated successfully..!'),
                // router.push(`/mails/configurations/configurations?templateCreated=true`)
                router.push(`/mails/configurations/configurations`),
              );
            })
            .catch((error) => {
              setSubmitLoader(false);
              apiCatchErrorMessage(error, dispatch, fetchError);
            });
        } else {
          jwtAxios
            .post(
              `${API_ROUTS.submitMailTempConfiguration}`,
              name == 'Scheduled Message'
                ? payLoadForScheduledMessage
                : payLoadForEventBasedMessage,
            )
            .then((res) => {
              // setSubmitLoader(false);
              dispatch(
                showMessage(' Configuration added successfully..!'),
                // router.push(`/mails/configurations/configurations?templateCreated=true`)
                router.push(`/mails/configurations/configurations`),
              );
            })
            .catch((error) => {
              setSubmitLoader(false);
              apiCatchErrorMessage(error, dispatch, fetchError);
            });
        }
      }
    }
  };

  if (router.isFallback) {
    <h1>Data is loading</h1>;
  }

  const handleCaptureFile = (event) => {
    // const tempPlanData = JSON.parse(JSON.stringify(planData));
    const file =
      event.target.files.length > 0 ? event.target.files[0] : undefined;
    if (file != undefined) {
      setFileUploading(true);
      setTimeout(() => {
        UploadFile(file);
        const inputElem = document.getElementById('inputFile_');
        if (inputElem != undefined) inputElem.value = null;
      }, 200);
    }
  };

  const UploadFile = async (file) => {
    const formData = new FormData();
    formData.append('file', file);
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.file_upload}`,
        formData,

        // {headers: {ContentType: 'multipart/form-data'}},
      );
      if (response.status == 201) {
        setFileUploading(false);
        setFile(response.data);
        setFileErr(false);
        // setIsLoad(() => true);
      } else {
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleDeleteFile = () => {
    setFile(null);
  };

  const [rulesArr, setRulesArr] = useState([]);

  const rulesPayload = () => {
    let reqArr = [];
    let arr = JSON.parse(JSON.stringify(rulesArr));

    arr?.forEach((a) => {
      a?.value?.forEach((v) => {
        reqArr.push({
          field: a.field,
          eventType: '',
          value: v,
        });
      });
    });

    return reqArr;
  };

  const handleClosePreviewPage = () => {
    setpreviewPageOpen(false);
  };
  const [previewLoader, setPreviewLoader] = useState(false);
  const [fechedTemplate, setFechedTemplate] = useState('<p></p>');
  const [sampleMailId, setSampleMailId] = useState(null);
  const [smapleMailSendLoader, setsmapleMailSendLoader] = useState(false);
  const [sampleMailIdErr, setSampleMailIdErr] = useState(false);

  const handleOpenPreviewPage = () => {
    if (isTemplateRequired) {
      setpreviewPageOpen(true);
      setPreviewLoader(true);
      jwtAxios
        .post(
          `${API_ROUTS.staticTemplateAndSendAsMail}/${selectedCompany?.id}?isTemplateRequired=${isTemplateRequired}&sendMail=false&to=`,
          {
            body: selectedTemplate,
            info: selectedTemplateInfo,
            templateName: name,
            company: {
              id: selectedCompany?.id,
            },
            status: 'ACTIVE',
            subject: templateName,
            file: file, //  added 04-10-23
          },
        )
        .then((res) => {
          setFechedTemplate(res.data);
          setPreviewLoader(false);
        })
        .catch((error) => {
          setPreviewLoader(false);
          apiCatchErrorMessage(error, dispatch, fetchError);
        });
    } else {
      setpreviewPageOpen(true);
    }
  };

  const handleSendSampleMail = () => {
    if (isEmptyNullUndefined(sampleMailId)) {
      setSampleMailIdErr(true);
    } else if (
      !sampleMailId.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)
    ) {
      setSampleMailIdErr(true);
    } else {
      setsmapleMailSendLoader(true);
      jwtAxios
        .post(
          `${API_ROUTS.staticTemplateAndSendAsMail}/${selectedCompany?.id}?isTemplateRequired=${isTemplateRequired}&sendMail=true&to=${sampleMailId}`,
          {
            body: selectedTemplate,
            templateName: name,
            company: {
              id: selectedCompany?.id,
            },
            status: 'ACTIVE',
            subject: templateName,
            info: selectedTemplateInfo,
            file: file,
            customQuery: {id: customQuery},
          },
        )
        .then((res) => {
          // setFechedTemplate(res.data)
          setSampleMailId(null);
          dispatch(showMessage('Mail sent successfull'));
          setsmapleMailSendLoader(false);
        })
        .catch((error) => {
          setSampleMailId(null);
          setsmapleMailSendLoader(false);
          apiCatchErrorMessage(error, dispatch, fetchError);
        });
    }
  };

  const handleMail = (event) => {
    setSampleMailId(event.target.value);
    if (!isEmptyNullUndefined(sampleMailId)) {
      setSampleMailIdErr(false);
    }
  };

  const generateNewDateIncrease = (payLoad) => {
    let date = new Date(payLoad);
    return date.setDate(date.getDate() + 1);
  };

  const getExistingData = () => {
    let existingPlanId = null;
    // setExistingDataLoader(true);
    jwtAxios
      .get(`${API_ROUTS.getMailConfigById}${id}`)
      .then((res) => {
        setType(res?.data?.type);
        setSendEmail(res?.data.sendEmail);
        setSendNotification(res?.data.sendNotification);
        setEventType(res?.data?.eventType);
        setSubType(res?.data?.subType);
        setApplicableTo(res?.data?.applicableTo);
        setTemplateName(res?.data?.subject);
        setSelectedTemplate(res?.data?.body);
        setDay(res?.data?.day);
        setIsFileRequired(isEmptyNullUndefined(res?.data?.file) ? false : true);
        setIsTemplateRequired(res?.data?.isTemplateRequired);
        setFile(res?.data?.file);
        setDateC(res?.data?.date);
        existingPlanId = res?.data?.planId;
        setmailFreq(res?.data?.mailFrequency);
        setSelectedTemplateInfo(res?.data?.info);
        setSelectedFrequency(res?.data?.mailScheduleFrequency);
        setStartDate(res?.data?.startDate);
        setEndDate(res?.data?.endDate);
        setTime(res?.data?.time);
        let tempDays =
          res?.data?.mailScheduleFrequency == 'Weekly'
            ? Array(7).fill(false)
            : Array(31).fill(false);
        res?.data?.days.forEach((e) => {
          tempDays[e - 1] = true;
        });
        setDays(tempDays);
        setCustomQuery(res?.data?.customQuery?.id);
      })
      .catch((error) => {
        apiCatchErrorMessage(error, dispatch, fetchError);
      });
  };

  const getValueById = (queryList, id) => {
    if (!isEmptyNullUndefined(queryList) && !isEmptyNullUndefined(id)) {
      let index = queryList.findIndex((element) => element.id === id);
      if (index !== -1) {
        return queryList[index].query;
      } else {
        return null; // Return null if the object with the given id is not found
      }
    }
  };

  const routeBack = () => {
    if (id) {
      if (page == 'viewPage') {
        // Router.push('/mails/configurations/configurations')
        router.push({
          pathname: `/mails/configurations/viewConfiguration/${id}`,
          query: {name: name, query: getValueById(queryList, customQuery)},
        });
      } else {
        Router.push('/mails/configurations/configurations');
      }
    } else {
      Router.push('/mails/configurations/TargetMsg');
    }
  };

  const weeksToString = (e) => {
    let stringWeaks = [];

    e == 0
      ? stringWeaks.push(
          <Typography variant='subtitle2' gutterBottom>
            sunday
          </Typography>,
        )
      : e == 1
      ? stringWeaks.push(
          <Typography variant='subtitle2' gutterBottom>
            monday
          </Typography>,
        )
      : e == 2
      ? stringWeaks.push(
          <Typography variant='subtitle2' gutterBottom>
            tuesday
          </Typography>,
        )
      : e == 3
      ? stringWeaks.push(
          <Typography variant='subtitle2' gutterBottom>
            wednesday
          </Typography>,
        )
      : e == 4
      ? stringWeaks.push(
          <Typography variant='subtitle2' gutterBottom>
            thrusday
          </Typography>,
        )
      : e == 5
      ? stringWeaks.push(
          <Typography variant='subtitle2' gutterBottom>
            friday
          </Typography>,
        )
      : e == 6
      ? stringWeaks.push(
          <Typography variant='subtitle2' gutterBottom>
            saturday
          </Typography>,
        )
      : stringWeaks.push(
          <Typography variant='subtitle2' gutterBottom>
            days not in week
          </Typography>,
        );

    return stringWeaks;
  };

  console.log('sendEmail', sendEmail);
  console.log('sendNotification', sendNotification);

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        {id ? (
          <IntlMessages id='templeteConfiguration.edit.createTempleteFor' />
        ) : (
          <IntlMessages id='templeteConfiguration.create.createTempleteFor' />
        )}
        {name}
      </h2>
      <AppCard>
        <Stack style={{width: '100%'}}>
          {/* /////////////Event-Based Message -- ApplicableTo/////////////////// */}
          {name &&
            (name === 'Event-Based Message' ||
              name === 'Scheduled Message') && (
              <div className='template-config-row'>
                <div className='left'>
                  <IntlMessages id='templeteConfiguration.ApplicableTo' />
                </div>
                <div className='right'>
                  <FormControl
                    sx={{mb: 2, width: '70%', minWidth: '10rem', ml: 4}}
                  >
                    <InputLabel
                      sx={{backgroundColor: '#ffffff', padding: '0px 0.5rem'}}
                      size='small'
                      id='type-'
                    >
                      <IntlMessages id='templeteConfiguration.ApplicableTo' />
                    </InputLabel>
                    <Select
                      value={applicableTo}
                      id={'applicableTo'}
                      name='applicableTo'
                      error={applicableToError}
                      onChange={(event) => {
                        setApplicableTo(event.target.value);
                        setApplicableToError(false);
                      }}
                      variant='outlined'
                      size='small'
                      sx={requiredSelectStyled}
                    >
                      {applicableToDropdown.map((t, i) => {
                        return (
                          <MenuItem
                            value={t.value}
                            id={t.key}
                            name={t.name}
                            size='small'
                            key={i.key}
                          >
                            {t.view}
                          </MenuItem>
                        );
                      })}
                    </Select>
                    {name &&
                      (name === 'Event-Based Message' ||
                        name === 'Scheduled Message') &&
                      applicableToError && (
                        <FormHelperText className='Mui-error'>
                          <IntlMessages id='error.Please_select_applicable_to' />
                        </FormHelperText>
                      )}
                  </FormControl>
                </div>
              </div>
            )}
          {/* //////////////////////////// */}

          <div className='template-config-row'>
            <div className='left'>
              <IntlMessages id='templeteConfiguration.create.eventType' />
            </div>
            <div className='right'>
              {eventType == 'Benefit Update' ||
              eventType == 'Personal Information' ? (
                <TextField
                  disabled
                  size='small'
                  value={eventType || ''}
                  id='outlined-basic'
                  label={
                    <IntlMessages id='templeteConfiguration.create.eventType' />
                  }
                  variant='outlined'
                  sx={{
                    width: '70%',
                    backgroundColor: 'white',
                    '& fieldset': {
                      // borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                    marginLeft: '16px',
                  }}
                />
              ) : (
                <FormControl
                  sx={{mb: 2, width: '70%', minWidth: '10rem', ml: 4}}
                >
                  <InputLabel
                    sx={{backgroundColor: '#ffffff', padding: '0px 0.5rem'}}
                    size='small'
                    id='Type-'
                  >
                    <IntlMessages id='templeteConfiguration.create.selectEventType' />
                  </InputLabel>
                  {/* /////////////////////////////// */}
                  {(name === 'Event-Based Message' ||
                    name === 'Scheduled Message') && (
                    <Select
                      value={eventType || []}
                      id={'eventType'}
                      name='eventType'
                      onChange={(event) => {
                        setEventType(event.target.value);
                        setEventTypeErr(false);
                        setTypeErr(false);
                        setSelectedFrequencyErr(false);
                        setDayErr(false);
                        setFileErr(false);
                        setType(null);
                        setSelectedFrequency(null);
                        setDay('');
                        setFile(null);
                        setDateC(null);
                      }}
                      multiple
                      error={eventTypeErr}
                      variant='outlined'
                      size='small'
                      sx={requiredSelectStyled}
                      renderValue={(selected) =>
                        name === 'Event-Based Message'
                          ? selected
                              ?.map((item) => {
                                return ztypes[
                                  ztypes.findIndex(
                                    (element) => element.value === item,
                                  )
                                ].view;
                              })
                              .join(' + ')
                          : selected
                              ?.map((item) => {
                                return item;
                              })
                              .join(' + ')
                      }
                    >
                      {name === 'Scheduled Message' &&
                        cTypes?.map((t, i) => {
                          return (
                            <MenuItem
                              value={t}
                              id={t}
                              name={t}
                              size='small'
                              key={i}
                            >
                              {t}
                            </MenuItem>
                          );
                        })}
                      {name === 'Benefit Update' &&
                        xTypes?.map((t, i) => {
                          return (
                            <MenuItem
                              value={t}
                              id={t}
                              name={t}
                              size='small'
                              key={i}
                            >
                              {t}
                            </MenuItem>
                          );
                        })}
                      {name === 'Event-Based Message' &&
                        ztypes?.map((t, i) => {
                          return (
                            <MenuItem
                              value={t.value}
                              id={t.key}
                              name={t.name}
                              size='small'
                              key={i.key}
                            >
                              {t.view}
                            </MenuItem>
                          );
                        })}
                    </Select>
                  )}
                  {(name === 'Event-Based Message' ||
                    name === 'Scheduled Message') &&
                    eventTypeErr && (
                      <FormHelperText className='Mui-error'>
                        {/* Please select Event Type */}
                        <IntlMessages id='error.pleaseSelectEventType' />
                      </FormHelperText>
                    )}
                </FormControl>
              )}
            </div>
          </div>

          {eventType &&
            (eventType === 'EMPLOYEMENT_EVENT' ||
              eventType === 'LIFE_EVENT' ||
              eventType === 'PLATFORM_EVENT') && (
              <div className='template-config-row'>
                <div className='left'>
                  <IntlMessages id='templeteConfiguration.create.type' />
                </div>
                <div className='right'>
                  <FormControl
                    sx={{mb: 2, width: '70%', minWidth: '10rem', ml: 4}}
                  >
                    <InputLabel
                      sx={{backgroundColor: '#ffffff', padding: '0px 0.5rem'}}
                      size='small'
                      id='type-'
                    >
                      <IntlMessages id='templeteConfiguration.create.selectSubType' />
                    </InputLabel>
                    <Select
                      value={type}
                      id={'type'}
                      name='type'
                      error={typeErr}
                      onChange={(event) => {
                        setType(event.target.value);
                        setTypeErr(false);
                      }}
                      variant='outlined'
                      size='small'
                      sx={requiredSelectStyled}
                    >
                      {name === 'Event-Based Message' &&
                        eventList[`${eventType}`]?.map((t, i) => {
                          return (
                            <MenuItem
                              value={t.name}
                              id={t.name}
                              name={t.name}
                              size='small'
                              key={i}
                            >
                              {t.name}
                            </MenuItem>
                          );
                        })}
                    </Select>
                    {typeErr && (
                      <FormHelperText className='Mui-error'>
                        {/* Please select Subtype */}
                        <IntlMessages id='error.pleaseSelectSubType' />
                      </FormHelperText>
                    )}
                  </FormControl>
                </div>
              </div>
            )}

          {name && name === 'Event-Based Message' && (
            <div className='template-config-row'>
              <div className='left'>
                <IntlMessages id='templeteConfiguration.create.type' />
              </div>
              <div className='right'>
                <FormControl
                  sx={{mb: 2, width: '70%', minWidth: '10rem', ml: 4}}
                >
                  <InputLabel
                    sx={{backgroundColor: '#ffffff', padding: '0px 0.5rem'}}
                    size='small'
                    id='type-'
                  >
                    <IntlMessages id='templeteConfiguration.create.selectType' />
                  </InputLabel>
                  <Select
                    multiple
                    value={type || []}
                    id={'type'}
                    name='type'
                    error={typeErr}
                    onChange={(event) => {
                      setType(event.target.value);
                      setTypeErr(false);
                    }}
                    variant='outlined'
                    size='small'
                    sx={requiredSelectStyled}
                  >
                    {/* {
                      xSubTypes?.map((t) => {
                        return(
                          <MenuItem  
                          value={t}
                          id={t}
                          name={t}
                          size="small"
                          >
                          {t}
                        </MenuItem>          
                        )
                      })
                    }                  */}
                    {name === 'Event-Based Message' &&
                      eventType &&
                      eventType[0] &&
                      eventList[`${eventType[0]}`]?.map((t, i) => {
                        return (
                          <MenuItem
                            sx={{backgroundColor: 'rgb(236, 232, 178)'}}
                            value={t.name}
                            id={t.name}
                            name={t.name}
                            size='small'
                            key={i}
                          >
                            {t.name}
                          </MenuItem>
                        );
                      })}
                    {name === 'Event-Based Message' &&
                      eventType &&
                      eventType[1] &&
                      eventList[`${eventType[1]}`]?.map((t, i) => {
                        return (
                          <MenuItem
                            sx={{backgroundColor: 'rgb(236, 198, 178)'}}
                            value={t.name}
                            id={t.name}
                            name={t.name}
                            size='small'
                            key={i}
                          >
                            {t.name}
                          </MenuItem>
                        );
                      })}
                    {name === 'Event-Based Message' &&
                      eventType &&
                      eventType[2] &&
                      eventList[`${eventType[2]}`]?.map((t, i) => {
                        return (
                          <MenuItem
                            sx={{backgroundColor: 'rgb(232 176 147)'}}
                            value={t.name}
                            id={t.name}
                            name={t.name}
                            size='small'
                            key={i}
                          >
                            {t.name}
                          </MenuItem>
                        );
                      })}
                  </Select>
                  {typeErr && (
                    <FormHelperText className='Mui-error'>
                      {/* Please select Type */}
                      <IntlMessages id='error.pleaseSelectType' />
                    </FormHelperText>
                  )}
                </FormControl>
              </div>
            </div>
          )}

          {/* /////////////Event-Based Message -- subType/////////////////// */}
          {name && name === 'Event-Based Message' && (
            <div className='template-config-row'>
              <div className='left'>
                <IntlMessages id='templeteConfiguration.create.subType' />
              </div>
              <div className='right'>
                <FormControl
                  sx={{mb: 2, width: '70%', minWidth: '10rem', ml: 4}}
                >
                  <InputLabel
                    sx={{backgroundColor: '#ffffff', padding: '0px 0.5rem'}}
                    size='small'
                    id='type-'
                  >
                    <IntlMessages id='templeteConfiguration.create.selectSubType' />
                  </InputLabel>
                  <Select
                    value={subType}
                    id={'subType'}
                    name='subType'
                    error={subTypeError}
                    onChange={(event) => {
                      setSubType(event.target.value);
                      setSubTypeError(false);
                    }}
                    variant='outlined'
                    size='small'
                    sx={requiredSelectStyled}
                  >
                    {subTypeDropDown.map((t, i) => {
                      return (
                        <MenuItem
                          value={t.value}
                          id={t.key}
                          name={t.name}
                          size='small'
                          key={i.key}
                        >
                          {t.view}
                        </MenuItem>
                      );
                    })}
                  </Select>
                  {name && name === 'Event-Based Message' && subTypeError && (
                    <FormHelperText className='Mui-error'>
                      {/* Please select Sub Type */}
                      <IntlMessages id='error.pleaseSelectSubType' />
                    </FormHelperText>
                  )}
                </FormControl>
              </div>
            </div>
          )}
          {/* //////////////////////////// */}
          {name &&
            (name === 'Event-Based Message' ||
              name === 'Scheduled Message') && (
              <div className='template-config-row'>
                <div className='left'>
                <IntlMessages id='notification.NotificationType'/>
                </div>
                <div style={{marginLeft: '35px'}} className='right'>
                  <span>
                    <Box
                      display='flex'
                      direction='row'
                      justifyContent='flex-start'
                    >
                      <FormGroup
                        sx={{
                          display: 'flex',
                          flexDirection: 'row',
                          flexWrap: 'wrap',
                          justifyContent: 'flex-start',
                        }}
                      >
                        <FormControlLabel
                          sx={{
                            display: 'flex',
                            flexDirection: 'row',
                          }}
                          key={'sendEmail'}
                          control={
                            <Checkbox
                              checked={sendEmail}
                              onChange={() => setSendEmail(!sendEmail)}
                            />
                          }
                          label={<IntlMessages id='notification.sendEmail'/>}
                        />
                      </FormGroup>
                      <FormGroup
                        sx={{
                          display: 'flex',
                          flexDirection: 'row',
                          flexWrap: 'wrap',
                          justifyContent: 'flex-start',
                        }}
                      >
                        <FormControlLabel
                          sx={{
                            display: 'flex',
                            flexDirection: 'row',
                          }}
                          key={'sendEmail'}
                          control={
                            <Checkbox
                              checked={sendNotification}
                              onChange={() =>
                                setSendNotification(!sendNotification)
                              }
                            />
                          }
                          label={<IntlMessages id='notification.sendNotification'/>}
                        />
                      </FormGroup>
                    </Box>
                  </span>
                </div>
              </div>
            )}

          {/* //////////////////////////// */}

          {name && name == 'Scheduled Message' && (
            <div className='template-config-row'>
              <div className='left'>
                {/* <IntlMessages id='providerReporting.edit.reportingFrequency' /> */}
                <IntlMessages id='templeteConfiguration.create.mailScheduleFrequency' />
              </div>
              <div className='right'>
                <FormControl
                  sx={{mb: 2, width: '70%', minWidth: '10rem', ml: 4}}
                >
                  <InputLabel
                    sx={{backgroundColor: '#ffffff', padding: '0px 0.5rem'}}
                    size='small'
                    id='Type-'
                  >
                    {name === 'Scheduled Message' && (
                      <>
                        <IntlMessages id='select' />{' '}
                        <IntlMessages id='templeteConfiguration.create.mailScheduleFrequency' />
                      </>
                    )}
                    {/* <IntlMessages id='templeteConfiguration.create.selectFrequency' /> */}
                  </InputLabel>
                  <Select
                    value={selectedFrequency || ''}
                    id={'selectedFrequency'}
                    name='frequency'
                    error={selectedFrequencyErr}
                    onChange={(event) => {
                      setSelectedFrequency(() => event.target.value);
                      setSelectedFrequencyErr(false);
                      if (event.target.value == 'Weekly') {
                        setDays(Array(7).fill(false));
                      } else {
                        setDays(Array(31).fill(false));
                      }
                      setStartDate(null);
                      setEndDate(null);
                      setTime(null);
                    }}
                    variant='outlined'
                    size='small'
                    sx={requiredSelectStyled}
                  >
                    {name === 'Scheduled Message' &&
                      mailScheduleFrequencyList?.map((t, i) => {
                        return (
                          <MenuItem
                            value={t.value}
                            id={t.name}
                            name={t.name}
                            size='small'
                            key={i}
                          >
                            {t.name}
                          </MenuItem>
                        );
                      })}
                  </Select>
                  {selectedFrequencyErr && (
                    <FormHelperText className='Mui-error'>
                      <>
                        <IntlMessages id='error.pleaseSelectFrequency' />
                      </>
                    </FormHelperText>
                  )}
                </FormControl>
              </div>
            </div>
          )}

          {/* ///////////////////// */}
          {name && name === 'Scheduled Message' && selectedFrequency !== 'Now' && (
            <div className='template-config-row'>
              <div className='left'>
                <IntlMessages id='calender.startDate' />
              </div>
              <div className='right'>
                <Stack
                  id='plan-start-date-picker'
                  name='plan-start-date-picker'
                  sx={{
                    mb: 2,
                    width: '70%',
                    minWidth: '10rem',
                    ml: 4,
                    ...requiredSelectStyled,
                  }}
                >
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DesktopDatePicker
                      disabled={selectedFrequency == 'Now' ? true : false}
                      inputFormat={getCompanyDateFormatForInputs(
                        selectedCompany,
                      )}
                      value={startDate}
                      label={<IntlMessages id='calender.startDate' />}
                      name='startDate'
                      onChange={(event) => {
                        handleChangeDates(event, 'startDate');
                        // setStartDate(event);
                        // setStartDateErr(false);
                      }}
                      renderInput={(params) => (
                        <TextField
                          variant='outlined'
                          helperText={
                            startDateErr ? (
                              <>
                                <IntlMessages id='error.pleaseEnterDate' />{' '}
                                <IntlMessages id='error.smaller_then_end_date' />
                              </>
                            ) : (
                              ''
                            )
                          }
                          size='small'
                          {...params}
                          error={startDateErr}
                        />
                      )}
                    />
                  </LocalizationProvider>
                </Stack>
              </div>
            </div>
          )}
          {name && name === 'Scheduled Message' && selectedFrequency !== 'Now' && (
            <div className='template-config-row'>
              <div className='left'>
                <IntlMessages id='calender.endDate' />
              </div>
              <div className='right'>
                <Stack
                  id='plan-start-date-picker'
                  name='plan-start-date-picker'
                  sx={{
                    mb: 2,
                    width: '70%',
                    minWidth: '10rem',
                    ml: 4,
                    ...requiredSelectStyled,
                  }}
                >
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DesktopDatePicker
                      disabled={selectedFrequency == 'Now' ? true : false}
                      minDate={generateNewDateIncrease(startDate)}
                      inputFormat={getCompanyDateFormatForInputs(
                        selectedCompany,
                      )}
                      value={endDate}
                      label={<IntlMessages id='calender.endDate' />}
                      name='endDate'
                      onChange={(event) => {
                        handleChangeDates(event, 'endDate');
                        // handleChangeEndDate(event)
                        //
                        //   setEndDate(event);
                        //   setEndDateErr(false);
                      }}
                      renderInput={(params) => (
                        <TextField
                          variant='outlined'
                          helperText={
                            endDateErr ? (
                              <>
                                <IntlMessages id='error.pleaseEnterDate' />{' '}
                                <IntlMessages id='error.greater_then_start_date' />
                              </>
                            ) : (
                              ''
                            )
                          }
                          size='small'
                          {...params}
                          error={endDateErr}
                          data-test='plan-start-date-picker'
                        />
                      )}
                    />
                  </LocalizationProvider>
                </Stack>
              </div>
            </div>
          )}

          {name && name === 'Scheduled Message' && selectedFrequency !== 'Now' && (
            <div className='template-config-row'>
              <div className='left'>
                <IntlMessages id='templeteConfiguration.time_in_hour' />
              </div>
              <div className='right'>
                <span>
                  <TextField
                    disabled={selectedFrequency == 'Now' ? true : false}
                    label={<IntlMessages id='templeteConfiguration.Time' />}
                    size='small'
                    name='time'
                    sx={{...requiredSelectStyled, ml: 4}}
                    variant='outlined'
                    // placeholder='0'
                    InputProps={{inputProps: {min: 0}}}
                    onChange={(event) => handleChangetime(event)}
                    value={time || ''}
                    helperText={
                      timeErr ? (
                        <IntlMessages id='templeteConfiguration.Please_enter_number_(0_to_24)' />
                      ) : (
                        ''
                      )
                    }
                    error={timeErr}
                  />
                </span>
              </div>
            </div>
          )}

          {name &&
            name === 'Scheduled Message' &&
            (selectedFrequency == 'Weekly' ||
              selectedFrequency == 'Monthly') && (
              <div className='template-config-row'>
                <div className='left'>
                  <IntlMessages id='templeteConfiguration.days' />
                </div>
                <div style={{marginLeft: '35px'}} className='right'>
                  <span>
                    <Box>
                      <FormGroup
                        sx={{
                          display: 'flex',
                          flexDirection: 'row',
                          flexWrap: 'wrap',
                          justifyContent: 'flex-start',
                        }}
                      >
                        {days.map((isChecked, index) => (
                          <FormControlLabel
                            sx={{
                              display: 'flex',
                              flexDirection: 'column',
                            }}
                            key={index}
                            control={
                              <Checkbox
                                disabled={
                                  selectedFrequency == 'Weekly' ||
                                  selectedFrequency == 'Monthly'
                                    ? false
                                    : true
                                }
                                checked={isChecked}
                                onChange={() => handleChangeCheckDays(index)}
                              />
                            }
                            label={
                              selectedFrequency == 'Weekly'
                                ? weeksToString(index)
                                : `${index + 1}`
                            }
                          />
                        ))}
                      </FormGroup>
                      {daysErr && (
                        <FormHelperText className='Mui-error'>
                          <IntlMessages id='templeteConfiguration.Please_Check_Days' />
                        </FormHelperText>
                      )}
                    </Box>
                  </span>
                </div>
              </div>
            )}

          <div className='template-config-row'>
            <div className='left'>
              <IntlMessages id='templeteConfiguration.create.isFileRequired' />
            </div>
            <div className='right'>
              <span>
                <Switch
                  checked={isFileRequired}
                  onChange={() => setIsFileRequired(() => !isFileRequired)}
                  inputProps={{'aria-label': 'controlled'}}
                />
              </span>
              {isFileRequired && (
                <Stack
                  direction='row'
                  sx={{
                    display: 'flex',
                    justifyContent: 'flex-start',
                    alignItems: 'center',
                  }}
                >
                  {fileUploading && <CircularProgress />}
                  {!fileUploading && isEmptyNullUndefined(file?.path) && (
                    <Stack
                      sx={{
                        mb: 2,
                        width: '70%',
                        minWidth: '10rem',
                        ml: 4,
                        // width:"50%",
                        height: '50px',
                        border: '1px dashed gray',
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        backgroundColor: '#f6f6f6',
                      }}
                    >
                      <IconButton
                        //disabled={!checked}
                        color='primary'
                        aria-label='upload document'
                        component='label'
                        sx={{
                          width: '100%',
                          height: '100%',
                          borderRadius: '0px',
                        }}
                      >
                        <input
                          id={'inputFile_'}
                          onChange={(event) => handleCaptureFile(event)}
                          hidden
                          type='file'
                          label='File upload'
                          // value={cases.fileUrl.name}
                          // error={formError.fileUrl.id.isError}
                          // helperText={formError.fileUrl.id.errorMessage}
                          accept='.png,.pdf,.doc,.docx'
                          disabled={fileUploading}
                        />
                        <GoCloudUpload
                          style={{fontSize: '3.2rem', marginRight: '2rem'}}
                        />
                        <IntlMessages id='templeteConfiguration.create.uploadFile' />
                      </IconButton>
                      {/* {formError.icon.isError && (
                      <FormHelperText className='Mui-error'>
                        {formError.icon.errorMessage}
                      </FormHelperText>
                    )} */}
                    </Stack>
                  )}

                  {!fileUploading && !isEmptyNullUndefined(file?.path) && (
                    <Stack
                      sx={{
                        mb: 2,
                        ml: 4,
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        position: 'relative',
                        border: '1px solid gray',
                        borderRadius: '5px',
                        padding: '0.5rem',
                        backgroundColor: '#eeecec',
                      }}
                    >
                      <div className='template-config-uploaded-files'>
                        {file?.fname}

                        <ImCross
                          onClick={() => handleDeleteFile()}
                          style={{
                            position: 'absolute',
                            right: '-16px',
                            top: '-16px',
                            fontSize: '1rem',
                            // color:"blue",
                            backgroundColor: '#ffffff',
                            padding: '2px',
                            width: '1rem',
                            height: '1rem',
                            borderRadius: '1rem',
                            border: '1px solid gray',
                            cursor: 'pointer',
                          }}
                        />
                      </div>
                      <a
                        href={file?.path}
                        target='_blank'
                        download
                        rel='noreferrer'
                      >
                        <IntlMessages id='common.button.View' />
                      </a>
                    </Stack>
                  )}
                  {fileErr && (
                    <FormHelperText className='Mui-error'>
                      <IntlMessages id='error.Please_upload_file' />
                    </FormHelperText>
                  )}
                </Stack>
              )}
            </div>
          </div>
          <div className='template-config-row'>
            <div className='left'>
              <IntlMessages id='templeteConfiguration.create.isTemplateRequired' />
            </div>
            <div className='right'>
              <span>
                <Switch
                  checked={isTemplateRequired}
                  onChange={() =>
                    setIsTemplateRequired(() => !isTemplateRequired)
                  }
                  inputProps={{'aria-label': 'controlled'}}
                />
              </span>
            </div>
          </div>
          {((name === 'Event-Based Message' && subType === 'REMINDER') ||
            (name === 'Scheduled Message' &&
              selectedFrequency === 'Custom')) && (
            <div className='template-config-row'>
              <div className='left'>
                <IntlMessages id='templeteConfiguration.create.reminderFreq' />
              </div>
              <div className='right'>
                <span>
                  <TextField
                    label={
                      <IntlMessages id='templeteConfiguration.create.No_of_days' />
                    }
                    size='small'
                    name='mailFrequency'
                    sx={{...requiredSelectStyled, ml: 4}}
                    variant='outlined'
                    onChange={(event) => {
                      setmailFreq(onlyAcceptWholeNumbers(event.target.value));
                      setmailFreqErr(false);
                    }}
                    value={mailFreq || ''}
                    helperText={
                      mailFreqErr ? (
                        <>
                          <IntlMessages id='error.PleaseEnterFrequency' />
                        </>
                      ) : (
                        ''
                      )
                    }
                    error={mailFreqErr}
                  />
                </span>
              </div>
            </div>
          )}

          {name &&
            (name == 'Scheduled Message' || name === 'Event-Based Message') && (
              <div className='template-config-row' style={{marginTop: 25}}>
                <div className='left'>
                  <>
                    <IntlMessages id='customizer.custom' />{' '}
                    <IntlMessages id='queryBuilder.query' />
                  </>
                </div>
                <div className='right'>
                  <FormControl
                    sx={{mb: 2, width: '70%', minWidth: '10rem', ml: 4}}
                  >
                    <InputLabel
                      sx={{backgroundColor: '#ffffff', padding: '0px 0.5rem'}}
                      size='small'
                      id='Type-'
                    >
                      {name === 'Scheduled Message' && (
                        <>
                          <IntlMessages id='select' />{' '}
                          <>
                            <IntlMessages id='customizer.custom' />{' '}
                            <IntlMessages id='queryBuilder.query' />
                          </>
                        </>
                      )}
                      {/* <IntlMessages id='templeteConfiguration.create.selectFrequency' /> */}
                    </InputLabel>
                    <Select
                      value={customQuery || ''}
                      id={'customQuery'}
                      name='customQuery'
                      error={customQueryErr}
                      onChange={(event) => {
                        setCustomQuery(event.target.value);
                        setCustomQueryErr(false);
                      }}
                      variant='outlined'
                      size='small'
                      sx={requiredSelectStyled}
                    >
                      {queryList &&
                        queryList?.map((t, i) => {
                          return (
                            <MenuItem
                              value={t.id}
                              id={t.id}
                              name={t.query}
                              size='small'
                              key={i}
                            >
                              {t.variableName}
                            </MenuItem>
                          );
                        })}
                    </Select>
                    {customQueryErr && (
                      <FormHelperText className='Mui-error'>
                        <>
                          <IntlMessages id='error.pleaseSelectCustomQuery' />
                        </>
                      </FormHelperText>
                    )}
                  </FormControl>
                </div>
              </div>
            )}

          {name &&
            (name == 'Scheduled Message' || name === 'Event-Based Message') && (
              <div className='template-config-row' style={{marginTop: 25}}>
                <div className='left'>
                  <>
                    <IntlMessages id='queryBuilder.query' />
                  </>
                </div>
                <div className='right'>
                  <FormControl
                    sx={{mb: 2, width: '70%', minWidth: '10rem', ml: 4}}
                  >
                    <TextField
                      disabled
                      size='small'
                      value={getValueById(queryList, customQuery)}
                      id='outlined-basic'
                      variant='outlined'
                      multiline
                      rows={4}
                    />
                  </FormControl>
                </div>
              </div>
            )}

          <Divider sx={{my: 3}} width={'86%'} />

          <div className='template-config-row'>
            <div className='left'>
              <IntlMessages id='templeteConfiguration.create.subject' />
            </div>
            <div className='right'>
              <FormControl sx={{mb: 2, width: '70%', minWidth: '10rem', ml: 4}}>
                <TextField
                  size='small'
                  value={templateName || ''}
                  onChange={(e) => {
                    setTemplateName(() => e.target.value);
                    setTemplateNameErr(false);
                  }}
                  id='outlined-basic'
                  label={
                    <IntlMessages id='templeteConfiguration.create.subject' />
                  }
                  variant='outlined'
                  error={templateNameErr}
                  // helperText={templateNameErr ? 'Please enter subject' : ''}
                  helperText={
                    templateNameErr ? (
                      <IntlMessages id='error.pleaseEnterSubject' />
                    ) : (
                      ''
                    )
                  }
                  sx={requiredSelectStyled}
                />
              </FormControl>
              {selectedTemplateErr && (
                <Stack direction='row' justifyContent='space-between'>
                  <h4 style={{marginTop: 20, marginBottom: 15}}>
                    {/* Employee Eligibility Rules */}
                  </h4>
                  <Stack
                    style={{marginTop: 20, marginBottom: 15, color: 'red'}}
                  >
                    {/* <i> Please enter Text</i> */}
                    <i>
                      {' '}
                      <IntlMessages id='error.pleaseEnterText' />
                    </i>
                  </Stack>
                </Stack>
              )}
            </div>
          </div>

          <Stack style={{width: '100%'}}>
            <Stack
              className='ag-theme-alpine'
              // style={{ height: 477, width: '100%' }}
            >
              <div>
                <Divider
                  border-color='rgba(0, 0, 0, 0.12)'
                  sx={{my: 3}}
                  varint='fullWidth'
                />
                <Stack
                  sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                  }}
                >
                  <h4 style={{marginTop: 20}}>
                    <IntlMessages id='templeteConfiguration.create.body' />
                    {/* Body */}
                  </h4>
                </Stack>

                <Stack>
                  {!isBodyEditActive ? (
                    <Stack className='description-modal-style-popup'>
                      <div
                        dangerouslySetInnerHTML={{__html: selectedTemplate}}
                      ></div>
                    </Stack>
                  ) : (
                    <SunEditor
                      setOptions={{
                        showPathLabel: false,
                        minHeight: '41vh',
                        placeholder: 'Enter your text here!!!',

                        mode: 'classic',
                        rtl: false,
                        katex: 'window.katex',
                        imageGalleryUrl:
                          'https://etyswjpn79.execute-api.ap-northeast-1.amazonaws.com/suneditor-demo',
                        videoFileInput: false,
                        tableCellControllerPosition: '',
                        tabDisable: false,

                        plugins: [
                          align,
                          font,
                          fontColor,
                          fontSize,
                          formatBlock,
                          hiliteColor,
                          horizontalRule,
                          lineHeight,
                          list,
                          paragraphStyle,
                          table,
                          template,
                          textStyle,
                          image,
                          link,
                          mergeTag,
                        ],
                        buttonList: [
                          ['undo', 'redo'],
                          [
                            'font',
                            'fontSize',
                            'formatBlock',
                            {
                              name: 'merge_tag',
                              dataCommand: 'merge_tag',
                              buttonClass: '',
                              title: 'Variable',
                              dataDisplay: 'submenu',
                              innerHTML:
                                '<span style="font-size: 20px;"><strong>P</strong></span>',
                            },
                          ],
                          ['paragraphStyle'],
                          [
                            'bold',
                            'underline',
                            'italic',
                            'strike',
                            'subscript',
                            'superscript',
                          ],
                          ['fontColor', 'hiliteColor'],
                          ['removeFormat'],
                          '/', // Line break
                          ['outdent', 'indent'],
                          ['align', 'horizontalRule', 'list', 'lineHeight'],
                          ['table', 'link', 'image'],
                          [
                            'textStyle',
                            'math',
                            'imageGallery',
                            'fullScreen',
                            'showBlocks',
                            'codeView',
                            'preview',
                            'print',
                            'save',
                            'template',
                          ],
                        ],

                        formats: [
                          'p',
                          'div',
                          'h1',
                          'h2',
                          'h3',
                          'h4',
                          'h5',
                          'h6',
                        ],
                        font: [
                          'Arial',
                          'Calibri',
                          'Comic Sans',
                          'Courier',
                          'Garamond',
                          'Georgia',
                          'Impact',
                          'Lucida Console',
                          'Palatino Linotype',
                          'Segoe UI',
                          'Tahoma',
                          'Times New Roman',
                          'Trebuchet MS',
                        ],
                      }}
                      onChange={(event) => {
                        setSelectedTemplate(event);
                        setSelectedTemplateErr(false);
                      }}
                      setContents={selectedTemplate}
                      // defaultValue={tileDescription}
                      // value={tileDescription}
                    />
                  )}

                  <Button
                    id={`edit-submit-description`}
                    // color= {footerButton.back.color}
                    variant='outlined'
                    // sx= {footerButton.back.sx}
                    // size= {footerButton.back.size}
                    // onClick={() => handleChangeTabsData({target: {name: 'description', value: tileDescription}}, index, structuredClone(tab), structuredClone(tabError), tileIndex, structuredClone(tab[index].tiles), structuredClone(tabError[index].tiles))}
                    onClick={() => {
                      if (isBodyEditActive) {
                        setIsBodyEditActive(false);
                      } else {
                        setIsBodyEditActive(true);
                      }
                      setIsFooterEditActive(false);
                    }}
                  >
                    {/* {isBodyEditActive
                      ? 'Submit Description'
                      : 'Edit Description'} */}
                    {isBodyEditActive ? (
                      <IntlMessages id='templeteConfiguration.create.submitBody' />
                    ) : (
                      <IntlMessages id='templeteConfiguration.create.editBody' />
                    )}
                  </Button>
                </Stack>
                <Divider
                  border-color='rgba(0, 0, 0, 0.12)'
                  sx={{my: 3}}
                  varint='fullWidth'
                />

                {/* <div className="template-config-row"> */}
                <div className='right'>
                  {selectedTemplateInfoError && (
                    <Stack direction='row' justifyContent='end'>
                      <Stack
                        style={{marginTop: 20, marginBottom: 15, color: 'red'}}
                      >
                        {/* <i> Please enter Text</i> */}
                        <i>
                          {' '}
                          <IntlMessages id='error.pleaseEnterText' />
                        </i>
                      </Stack>
                    </Stack>
                  )}
                </div>
                {/* </div> */}

                <Stack
                  sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                  }}
                >
                  <h4 style={{marginTop: 20}}>
                    <IntlMessages id='templeteConfiguration.create.footer' />
                    {/* Footer */}
                  </h4>
                </Stack>
                <Stack>
                  {!isFooterEditActive ? (
                    <Stack className='description-modal-style-popup'>
                      {/* <p className="title"> {tab[index].tiles[tileIndex].tileTitle} </p> */}
                      <div
                        dangerouslySetInnerHTML={{__html: selectedTemplateInfo}}
                      ></div>
                    </Stack>
                  ) : (
                    <SunEditorForFooter
                      setOptions={{
                        showPathLabel: false,
                        minHeight: '41vh',
                        placeholder: 'Enter your text here!!!',

                        mode: 'classic',
                        rtl: false,
                        katex: 'window.katex',
                        imageGalleryUrl:
                          'https://etyswjpn79.execute-api.ap-northeast-1.amazonaws.com/suneditor-demo',
                        videoFileInput: false,
                        tableCellControllerPosition: '',
                        tabDisable: false,

                        plugins: [
                          align,
                          font,
                          fontColor,
                          fontSize,
                          formatBlock,
                          hiliteColor,
                          horizontalRule,
                          lineHeight,
                          list,
                          paragraphStyle,
                          table,
                          template,
                          textStyle,
                          image,
                          link,
                          mergeTag,
                        ],
                        buttonList: [
                          ['undo', 'redo'],
                          [
                            'font',
                            'fontSize',
                            'formatBlock',
                            {
                              name: 'merge_tag',
                              dataCommand: 'merge_tag',
                              buttonClass: '',
                              title: 'Variable',
                              dataDisplay: 'submenu',
                              innerHTML:
                                '<span style="font-size: 20px;"><strong>P</strong></span>',
                            },
                          ],
                          ['paragraphStyle'],
                          [
                            'bold',
                            'underline',
                            'italic',
                            'strike',
                            'subscript',
                            'superscript',
                          ],
                          ['fontColor', 'hiliteColor'],
                          ['removeFormat'],
                          '/', // Line break
                          ['outdent', 'indent'],
                          ['align', 'horizontalRule', 'list', 'lineHeight'],
                          ['table', 'link', 'image'],
                          [
                            'textStyle',
                            'math',
                            'imageGallery',
                            'fullScreen',
                            'showBlocks',
                            'codeView',
                            'preview',
                            'print',
                            'save',
                            'template',
                          ],
                        ],

                        formats: [
                          'p',
                          'div',
                          'h1',
                          'h2',
                          'h3',
                          'h4',
                          'h5',
                          'h6',
                        ],
                        font: [
                          'Arial',
                          'Calibri',
                          'Comic Sans',
                          'Courier',
                          'Garamond',
                          'Georgia',
                          'Impact',
                          'Lucida Console',
                          'Palatino Linotype',
                          'Segoe UI',
                          'Tahoma',
                          'Times New Roman',
                          'Trebuchet MS',
                        ],
                      }}
                      onChange={(event) => {
                        setSelectedTemplateInfo(event);
                        setSelectedTemplateInfoError(false);
                      }}
                      setContents={selectedTemplateInfo}
                      // defaultValue={tileDescription}
                      // value={tileDescription}
                    />
                  )}

                  <Button
                    id={`edit-submit-description`}
                    // color= {footerButton.back.color}
                    variant='outlined'
                    // sx= {footerButton.back.sx}
                    // size= {footerButton.back.size}
                    // onClick={() => handleChangeTabsData({target: {name: 'description', value: tileDescription}}, index, structuredClone(tab), structuredClone(tabError), tileIndex, structuredClone(tab[index].tiles), structuredClone(tabError[index].tiles))}
                    onClick={() => {
                      if (isFooterEditActive) {
                        setIsFooterEditActive(false);
                      } else {
                        setIsFooterEditActive(true);
                      }
                      setIsBodyEditActive(false);
                    }}
                  >
                    {/* {isFooterEditActive ? 'Submit Footer' : 'Edit Footer'} */}
                    {isFooterEditActive ? (
                      <IntlMessages id='templeteConfiguration.create.submitFooter' />
                    ) : (
                      <IntlMessages id='templeteConfiguration.create.editFooter' />
                    )}
                  </Button>
                </Stack>
              </div>
            </Stack>
          </Stack>

          <div className='template-config-row' style={{marginTop: '100px'}}>
            <div className='left'>
              <IntlMessages id='templeteConfiguration.create.sendSampleMail' />
            </div>
            <div className='right'>
              <FormControl sx={{mb: 2, width: '70%', minWidth: '10rem', ml: 4}}>
                <TextField
                  size='small'
                  value={sampleMailId || ''}
                  onChange={handleMail}
                  id='outlined-basic'
                  label={
                    <IntlMessages id='templeteConfiguration.create.emailId' />
                  }
                  variant='outlined'
                  error={sampleMailIdErr}
                  helperText={
                    // sampleMailIdErr ? 'Please enter valid email Id' : ''
                    sampleMailIdErr ? (
                      <IntlMessages id='error.pleaseEnterValidEmail' />
                    ) : (
                      ''
                    )
                  }
                  sx={{
                    backgroundColor: 'white',
                    '& fieldset': {
                      borderLeftColor: 'gray',
                      borderLeftWidth: 3,
                    },
                  }}
                  disabled={!templateName}
                />
              </FormControl>
              <Button
                variant='outlined'
                onClick={() => handleSendSampleMail()}
                sx={{ml: 4, height: '2.3rem'}}
                disabled={smapleMailSendLoader || !templateName}
              >
                {smapleMailSendLoader ? (
                  <CircularProgress size={20} />
                ) : (
                  <IntlMessages id='common.button.Send' />
                )}
              </Button>
            </div>
          </div>
        </Stack>
      </AppCard>

      <Stack sx={{mb: 15}} />

      <Stack
        sx={{
          bottom: 0,
          zIndex: 10,
          position: 'fixed',
          backdropFilter: 'blur(5px)',
          width: '100%',
          right: 0,
        }}
      >
        <Stack
          direction='row'
          justifyContent='end'
          alignItems='center'
          spacing={2}
          sx={{
            pt: 5,
            ml: 3,
            //// add marging for fixed stack///
            margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
          }}
        >
          <Button
            disabled={
              !templateName ||
              isEmptyNullUndefined(selectedTemplate) ||
              selectedTemplate === '<p><br></p>'
            }
            variant='outlined'
            onClick={() => handleOpenPreviewPage()}
            // sx={{mt:4, mr:4}}
          >
            <IntlMessages id='common.button.Preview' />
          </Button>
          <Button
            sx={{mt: 4, mr: 4}}
            variant='contained'
            onClick={
              () => routeBack()
              // id
              //   ? Router.push('/mails/configurations/configurations')
              //   : Router.push('/mails/configurations/TargetMsg')
            }
            disabled={submitLoader}
          >
            <IntlMessages id='common.button.Back' />
          </Button>
          {!id && (
            <Button
              sx={footerButton.saveDraft.sx}
              color={footerButton.saveDraft.color}
              variant={footerButton.saveDraft.variant}
              onClick={() => handleSubmit(true)}
              disabled={submitLoader}
            >
              {submitLoader ? (
                <CircularProgress size={25} />
              ) : (
                <IntlMessages id='common.button.SubmitAsDraft' />
              )}
            </Button>
          )}
          <Button
            sx={{mt: 4}}
            color='success'
            variant='contained'
            onClick={() => handleSubmit(false)}
            disabled={submitLoader || isFooterEditActive || isBodyEditActive}
          >
            {submitLoader ? (
              <CircularProgress size={25} />
            ) : (
              <IntlMessages id='common.button.Submit' />
            )}
          </Button>
        </Stack>
      </Stack>

      <AppInfoView />
      {isPreviewPageOpen && (
        <Preview handleClose={() => handleClosePreviewPage()}>
          {isTemplateRequired ? (
            <>{previewLoader ? <CircularProgress /> : parse(fechedTemplate)}</>
          ) : (
            <div className='preview-mains'>
              <div className='preview-mail-subject'>
                <IntlMessages id='templeteConfiguration.create.subject' /> :{' '}
                {templateName}
              </div>
              <div className='preview-mail-body'>{parse(selectedTemplate)}</div>
              <div className='preview-mail-footer'>
                {parse(selectedTemplateInfo)}
              </div>
            </div>
          )}
        </Preview>
      )}
    </AppAnimate>
  );
};

export default CreateConfiguration;
