import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import Stack from '@mui/material/Stack';
import {AppCard} from '../../../../../@crema';
import PropTypes from 'prop-types';
import AppInfoView from '../../../../../@crema/core/AppInfoView';
import {useDispatch} from 'react-redux';
import { useState } from 'react';
import IntlMessages from '@crema/utility/IntlMessages';


const Preview = ({handleClose, children}) => {
  const dispatch = useDispatch();

  const [activeTabIndex, setActiveTabIndex] = useState(0)
 
  return (
    <Dialog
    sx={{
      '& .MuiDialogContent-root': {
        padding: 0
      },
    }}
    maxWidth={'md'} open={true}
    >
          
          <DialogContent>
            {children}
          </DialogContent>
        <DialogActions>
          <Button
            onClick={() => handleClose()}
            sx={{backdropFilter: "blur(10px)",
              zIndex: 11}}
          ><IntlMessages id='common.button.Close'/></Button>
        </DialogActions>
        <AppInfoView />
      </Dialog>
  );
};

export default Preview;