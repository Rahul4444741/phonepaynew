import {AppAnimate} from '@crema';
import {useState} from 'react';
import {AppCard} from '../../../../../@crema';
import AppPageMeta from '../../../../../@crema/core/AppPageMeta';
import AppInfoView from '../../../../../@crema/core/AppInfoView';
import Stack from '@mui/material/Stack';
import {
  Box,
  Button,
  CircularProgress,
  FormControl,
  TextField,
} from '@mui/material';
// import { align, font, fontColor, fontSize, formatBlock, hiliteColor, horizontalRule, image, lineHeight, link, list, paragraphStyle, table, template, textStyle } from "../../../../../../node_modules/suneditor/src/plugins";
import Router, {useRouter} from 'next/router';
import {useEffect} from 'react';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {useDispatch, useSelector} from 'react-redux';
import {fetchError, showMessage} from 'redux/actions';
import {
  apiCatchErrorMessage,
  getCompanyDateFormat,
  getListItemDescription,
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';
import React from 'react';
import Preview from '../Preview/Preview';
import {Divider} from '@mui/material';
import axios from 'axios';
import {FormLabel} from '@mui/material';
import moment from 'moment';
import IntlMessages from '@crema/utility/IntlMessages';
import {domCreactionHeaderListSingle} from 'shared/utils/domCreaction';

const initialData = {
  eventType: ['SCHEDULE_EVENT'],
  body: '<p>new one body</p>',
  info: null,
  subject: 'new one subject',
  mailFrequency: 0,
  company: {
    id: '38fa3a57-f81b-4cfe-9cf4-59cc5a85de69',
  },
  status: 'ACTIVE',
  file: null,
  isTemplateRequired: false,
  date: null,
  name: 'Event-Based Message',
  className: null,
  planId: null,
  mailScheduleFrequency: 'Daily', // [Now, Daily, Weekly, Monthly, Custom]
  days: [1, 2, 3, 4, 5],
  startDate: '2023-10-01T05:53:58.000+00:00',
  endDate: '2024-11-01T05:53:58.000+00:00',
  time: 14, // 0 - 24 hours
};

const parse = require('html-react-parser');

const requiredSelectStyled = {
  backgroundColor: 'white',
  // mb: 2,
  // width: {xs: '100%', xl: '60%', md: '75%'},
  '& fieldset': {
    borderLeftColor: 'red',
    borderLeftWidth: 3,
  },
};

const ViewConfiguration = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const {id, query} = router.query;

  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const [data, setDate] = useState(initialData);
  // const [name, setName] = useState(null);
  const name = router?.query?.name;

  const [submitLoader, setSubmitLoader] = useState(false);
  const [isPreviewPageOpen, setpreviewPageOpen] = React.useState(false);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  useEffect(() => {
    (async () => {
      await getExistingData();
    })();

    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, []);

  const [existingDataLoader, setExistingDataLoader] = useState(false);

  const getExistingData = () => {
    setExistingDataLoader(true);
    jwtAxios
      .get(`${API_ROUTS.getMailConfigById}${id}`)
      .then((res) => {
        setDate(res.data);

        setExistingDataLoader(false);
      })
      .catch((error) => {
        apiCatchErrorMessage(error, dispatch, fetchError);
        setExistingDataLoader(false);
      });
  };

  if (router.isFallback) {
    <h1>Data is loading</h1>;
  }

  const handleClosePreviewPage = () => {
    setpreviewPageOpen(false);
  };

  const [previewLoader, setPreviewLoader] = useState(false);
  const [fechedTemplate, setFechedTemplate] = useState('<p></p>');
  const [sampleMailId, setSampleMailId] = useState(null);
  const [smapleMailSendLoader, setsmapleMailSendLoader] = useState(false);
  const [sampleMailIdErr, setSampleMailIdErr] = useState(false);

  const handleOpenPreviewPage = () => {
    if (data.isTemplateRequired) {
      setpreviewPageOpen(true);
      setPreviewLoader(true);
      jwtAxios
        .post(
          `${API_ROUTS.staticTemplateAndSendAsMail}/${selectedCompany?.id}?isTemplateRequired=${data.isTemplateRequired}&sendMail=false&to=`,
          {
            body: data.body,
            info: data.info,
            templateName: data.name,
            company: {
              id: selectedCompany?.id,
            },
            status: 'ACTIVE',
            subject: data.subject,
            file: data.file, //  added 04-10-23
          },
        )
        .then((res) => {
          setFechedTemplate(res.data);
          setPreviewLoader(false);
        })
        .catch((error) => {
          setPreviewLoader(false);
          apiCatchErrorMessage(error, dispatch, fetchError);
        });
    } else {
      setpreviewPageOpen(true);
    }
  };

  const handleSendSampleMail = () => {
    if (isEmptyNullUndefined(sampleMailId)) {
      setSampleMailIdErr(true);
    } else if (
      !sampleMailId.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)
    ) {
      setSampleMailIdErr(true);
    } else {
      setsmapleMailSendLoader(true);
      jwtAxios
        .post(
          `${API_ROUTS.staticTemplateAndSendAsMail}/${selectedCompany?.id}?isTemplateRequired=${data?.isTemplateRequired}&sendMail=true&to=${sampleMailId}`,
          {
            body: data.body,
            templateName: data.name,
            company: {
              id: selectedCompany?.id,
            },
            status: 'ACTIVE',
            subject: data.subject,
            file: data.file, //  added 04-10-23
            customQuery: {id: data?.customQuery?.id},
          },
        )
        .then((res) => {
          setSampleMailId(null);
          dispatch(showMessage('Mail sent successfull'));
          setsmapleMailSendLoader(false);
        })
        .catch((error) => {
          setSampleMailId(null);
          setsmapleMailSendLoader(false);
          apiCatchErrorMessage(error, dispatch, fetchError);
        });
    }
  };

  const handleMail = (event) => {
    setSampleMailId(event.target.value);
    if (!isEmptyNullUndefined(sampleMailId)) {
      setSampleMailIdErr(false);
    }
  };

  const chipViewPageHandleClick = () => {
    if (data?.file?.path) {
      window.open(`${data?.file?.path}`);
    } else {
      dispatch(fetchError('Something went wrong!'));
    }
  };

  const stringWithPlusSigns = (inputString) => {
    return inputString.replace(/ /g, '+');
  };

  const handleRedirectEditEmployee = (id) => {
    router.push(
      `/mails/configurations/createConfiguration/create?name=${stringWithPlusSigns(
        data?.name,
      )}&id=${data?.id}&page=viewPage`,
    );
  };

  const weeksToString = (days) => {
    let stringWeaks = [];

    days.forEach((e) => {
      e == 1
        ? stringWeaks.push('sunday')
        : e == 2
        ? stringWeaks.push('monday')
        : e == 3
        ? stringWeaks.push('tuesday')
        : e == 4
        ? stringWeaks.push('wednesday')
        : e == 5
        ? stringWeaks.push('thrusday')
        : e == 6
        ? stringWeaks.push('friday')
        : e == 7
        ? stringWeaks.push('saturday')
        : stringWeaks.push('days not in week');
    });
    return stringWeaks;
  };

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <Stack direction='row' sx={{mb: 2}} justifyContent='space-between'>
        <h2 style={{marginBottom: 2}}>
          <IntlMessages id='templeteConfiguration.view.viewTemplate' /> {name}
        </h2>
        <Button
          name='edit'
          variant='contained'
          onClick={() => handleRedirectEditEmployee(id)}
        >
          <IntlMessages id='common.button.Edit' />
        </Button>
      </Stack>

      {existingDataLoader ? (
        <CircularProgress />
      ) : (
        <Stack>
          <AppCard>
            {data.applicableTo &&
              domCreactionHeaderListSingle(
                <IntlMessages id='templeteConfiguration.ApplicableTo' />,
                data?.applicableTo,
              )}

            {data &&
              domCreactionHeaderListSingle(
                <IntlMessages id='templeteConfiguration.create.selectEventType' />,
                data?.eventType,
              )}

            {data?.eventType != 'SCHEDULE_EVENT' &&
              domCreactionHeaderListSingle(
                <IntlMessages id='templeteConfiguration.create.type' />,
                data?.type,
              )}

            {data?.eventType != 'SCHEDULE_EVENT' &&
              domCreactionHeaderListSingle(
                <IntlMessages id='templeteConfiguration.create.subType' />,
                data?.subType,
              )}

            {data?.eventType == 'SCHEDULE_EVENT' &&
              domCreactionHeaderListSingle(
                <IntlMessages id='templeteConfiguration.create.mailScheduleFrequency' />,
                data?.mailScheduleFrequency,
              )}

            {data?.eventType == 'SCHEDULE_EVENT' &&
              data?.mailScheduleFrequency != 'Now' &&
              domCreactionHeaderListSingle(
                <IntlMessages id='calender.startDate' />,
                moment(data.startDate).format(
                  getCompanyDateFormat(selectedCompany),
                ),
              )}

            {data?.eventType == 'SCHEDULE_EVENT' &&
              data?.mailScheduleFrequency != 'Now' &&
              domCreactionHeaderListSingle(
                <IntlMessages id='calender.endDate' />,
                moment(data.endDate).format(
                  getCompanyDateFormat(selectedCompany),
                ),
              )}

            {data?.eventType == 'SCHEDULE_EVENT' &&
              data?.mailScheduleFrequency != 'Now' &&
              domCreactionHeaderListSingle(
                <IntlMessages id='templeteConfiguration.time_in_hour' />,
                data?.time,
              )}

            {data?.eventType == 'SCHEDULE_EVENT' &&
              data?.mailScheduleFrequency == 'Weekly' &&
              domCreactionHeaderListSingle(
                <IntlMessages id='templeteConfiguration.days' />,
                weeksToString(data.days),
              )}

            {data?.eventType == 'SCHEDULE_EVENT' &&
              data?.mailScheduleFrequency == 'Monthly' &&
              domCreactionHeaderListSingle(
                <IntlMessages id='templeteConfiguration.days' />,
                data.days,
              )}

            {data.customQuery &&
              domCreactionHeaderListSingle(
                <IntlMessages id='templeteConfiguration.CustomQueryName' />,
                data?.customQuery.variableName,
              )}

            {data.customQuery &&
              domCreactionHeaderListSingle(
                <IntlMessages id='templeteConfiguration.CustomQuery' />,
                data?.customQuery.query,
              )}

            {data.sendEmail &&
              domCreactionHeaderListSingle(
                <IntlMessages id='templeteConfiguration.sendEmail' />,
                data.sendEmail ? 'Yes' : 'No',
              )}
            {data.sendNotification &&
              domCreactionHeaderListSingle(
                <IntlMessages id='templeteConfiguration.sendNotification' />,
                data.sendNotification ? 'Yes' : 'No',
              )}
            {data &&
              domCreactionHeaderListSingle(
                <IntlMessages id='templeteConfiguration.create.isFileRequired' />,
                data.file?.path ? 'Yes' : 'No',
              )}

            <div className='template-config-row'>
              <Stack sx={{width: '40%'}}></Stack>
              <Stack sx={{width: '60%'}}>
                {
                  <Stack
                    direction='row'
                    sx={{
                      display: 'flex',
                      justifyContent: 'flex-start',
                      alignItems: 'center',
                    }}
                  >
                    {!isEmptyNullUndefined(data.file?.path) && (
                      <Stack
                        sx={{
                          mb: 2,
                          ml: 4,
                          display: 'flex',
                          justifyContent: 'center',
                          alignItems: 'center',
                          position: 'relative',
                          border: '1px solid gray',
                          borderRadius: '5px',
                          padding: '0.5rem',
                          backgroundColor: '#eeecec',
                          cursor: 'pointer',
                        }}
                        onClick={() => chipViewPageHandleClick()}
                      >
                        <div className='template-config-uploaded-files'>
                          {data.file?.fname}
                        </div>
                      </Stack>
                    )}
                  </Stack>
                }
              </Stack>
            </div>

            {data &&
              domCreactionHeaderListSingle(
                <IntlMessages id='templeteConfiguration.create.isTemplateRequired' />,
                data.isTemplateRequired == true ? 'Yes' : 'No',
              )}

            {(data.subType === 'REMINDER' ||
              data?.mailScheduleFrequency == 'Custom') &&
              domCreactionHeaderListSingle(
                <IntlMessages id='templeteConfiguration.create.reminderFreq' />,
                data.mailFrequency,
              )}

            {data?.eventType == 'SCHEDULE_EVENT' &&
              domCreactionHeaderListSingle(
                <IntlMessages id='templeteConfiguration.create.mailScheduleFrequency' />,
                query,
              )}

            {domCreactionHeaderListSingle(
              <IntlMessages id='templeteConfiguration.create.subject' />,
              data?.subject,
            )}

            <Stack style={{width: '100%'}}>
              <Stack
                className='ag-theme-alpine'
                // style={{ height: 477, width: '100%' }}
              >
                <Divider sx={{my: 3}} width={'86%'} />

                <Stack
                  direction='row'
                  sx={{mt: 2, ml: 3}}
                  justifyContent='space-between'
                  alignItems='center'
                  spacing={2}
                >
                  <Stack sx={{width: '40%'}}>
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>
                          {
                            <IntlMessages id='templeteConfiguration.view.body' />
                          }
                        </Stack>
                      </Stack>
                    </FormLabel>
                  </Stack>
                  <Stack
                    sx={{width: '60%'}}
                    direction='row'
                    alignItems='center'
                  >
                    <div dangerouslySetInnerHTML={{__html: data.body}}></div>
                  </Stack>
                </Stack>

                <Divider sx={{my: 3}} width={'86%'} />
              </Stack>
              <Stack
                className='ag-theme-alpine'
                // style={{ height: 477, width: '100%' }}
              >
                <Divider sx={{my: 3}} width={'86%'} />

                <Stack
                  direction='row'
                  sx={{mt: 2, ml: 3}}
                  justifyContent='space-between'
                  alignItems='center'
                  spacing={2}
                >
                  <Stack sx={{width: '40%'}}>
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>
                          {
                            <IntlMessages id='templeteConfiguration.view.info' />
                          }
                        </Stack>
                      </Stack>
                    </FormLabel>
                  </Stack>
                  <Stack
                    sx={{width: '60%'}}
                    direction='row'
                    alignItems='center'
                  >
                    <div dangerouslySetInnerHTML={{__html: data.info}}></div>
                  </Stack>
                </Stack>

                <Divider sx={{my: 3}} width={'86%'} />
              </Stack>
              <div className='template-config-row'>
                <div className='left'>
                  <IntlMessages id='templeteConfiguration.create.sendSampleMail' />
                </div>
                <div className='right'>
                  <FormControl
                    sx={{mb: 2, width: '70%', minWidth: '10rem', ml: 4}}
                  >
                    <TextField
                      size='small'
                      value={sampleMailId || ''}
                      onChange={handleMail}
                      id='outlined-basic'
                      label={
                        <IntlMessages id='templeteConfiguration.create.emailId' />
                      }
                      variant='outlined'
                      error={sampleMailIdErr}
                      helperText={
                        sampleMailIdErr ? 'Please enter valid email Id' : ''
                      }
                      sx={requiredSelectStyled}
                    />
                  </FormControl>

                  <Button
                    variant='outlined'
                    onClick={() => handleSendSampleMail()}
                    sx={{ml: 4, height: '2.3rem'}}
                    disabled={smapleMailSendLoader}
                  >
                    {smapleMailSendLoader ? (
                      <CircularProgress size={20} />
                    ) : (
                      <IntlMessages id='common.button.Send' />
                    )}
                  </Button>
                </div>
              </div>
            </Stack>
          </AppCard>

          <Stack sx={{mb: 15}} />

          <Stack
            sx={{
              bottom: 0,
              zIndex: 10,
              position: 'fixed',
              backdropFilter: 'blur(5px)',
              width: '100%',
              right: 0,
            }}
          >
            <Stack
              direction='row'
              justifyContent='end'
              alignItems='center'
              spacing={2}
              sx={{
                pt: 5,
                ml: 3,
                margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
              }}
            >
              <Button
                disabled={
                  !data?.subject ||
                  isEmptyNullUndefined(data?.body) ||
                  data?.body === '<p><br></p>'
                }
                variant='outlined'
                onClick={() => handleOpenPreviewPage()}
              >
                <IntlMessages id='common.button.Preview' />
              </Button>
              <Button
                sx={{mt: 4, mr: 4}}
                variant='contained'
                onClick={() =>
                  Router.push('/mails/configurations/configurations')
                }
                disabled={submitLoader}
              >
                <IntlMessages id='common.button.Back' />
              </Button>
            </Stack>
          </Stack>
        </Stack>
      )}

      <AppInfoView />
      {isPreviewPageOpen && (
        <Preview handleClose={() => handleClosePreviewPage()}>
          {data.isTemplateRequired ? (
            <>{previewLoader ? <CircularProgress /> : parse(fechedTemplate)}</>
          ) : (
            <div className='preview-mains'>
              <div className='preview-mail-subject'>
                Subject : {data.subject}
              </div>
              <div className='preview-mail-body'>{parse(data.body)}</div>
              <div className='preview-mail-footer'>{parse(data.info)}</div>
            </div>
          )}
        </Preview>
      )}
    </AppAnimate>
  );
};

export default ViewConfiguration;
