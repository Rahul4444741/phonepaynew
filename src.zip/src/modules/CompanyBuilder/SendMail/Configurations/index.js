import Stack from '@mui/material/Stack';
import AppAnimate from '../../../../@crema/core/AppAnimate';
import {AppCard} from '../../../../@crema';
import AppPageMeta from '../../../../@crema/core/AppPageMeta';
import AppInfoView from '../../../../@crema/core/AppInfoView';
import {AgGridReact} from 'ag-grid-react';
import {
  Button,
  CircularProgress,
  Skeleton,
  TextField,
  ToggleButton,
  ToggleButtonGroup,
} from '@mui/material';
import {useState} from 'react';
import React from 'react';
import {useEffect} from 'react';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {useDispatch, useSelector} from 'react-redux';
import {fetchError, showMessage} from 'redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {useRouter} from 'next/router';
import {
  apiCatchErrorMessage,
  buttonStyle,
  isAllowedUser,
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';
import IntlMessages from '@crema/utility/IntlMessages';
import AlertDialog from 'modules/Common/AlertDialog';
import {yellow, green} from '@mui/material/colors';
import Error403 from 'modules/errorPages/Error403';
import {permissionName} from 'shared/utils/PermissionName';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import { useCallback } from 'react';

const ConfigurationList = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const {templateCreated} = router.query;

  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const [loading, setLoading] = useState(false);
  const [deActiveLoader, setDeActiveLoader] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [templates, setTemplates] = useState(null);
  const [filteredTemplateData, setFilteredTemplateData] = useState(null);
  const [alignment, setAlignment] = React.useState('ACTIVE');
  const [overlayMessage, setOverlayMessage] = React.useState('No Rows To Show');

  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);

  React.useEffect(() => {
    if (isAllowedUser(permissionName.SET_UP_PMS_NOTIFICATION)) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  useEffect(() => {
    if (isAuthorized) {
      fetchActiveTemplates(templateCreated);
    }
  }, [isAuthorized, selectedCompany]);

  useEffect(() => {
    let arr = JSON.parse(JSON.stringify(templates));
    setFilteredTemplateData(arr?.filter((x) => x.status === alignment));
  }, [alignment]);

  const handleAction = (params, action) => {
    if (action === 'create') {
      router.push({
        pathname: `/mails/configurations/editConfiguration/${params?.data?.id}`,
        query: {name: params?.data?.name, className: params?.data?.className},
      });
    }
    if (action === 'view') {
      router.push({
        pathname: `/mails/configurations/viewConfiguration/${params?.data?.id}`,
        query: {
          name: params?.data?.name,
          query: params?.data?.customQuery?.query,
        },
      });
    }
    if (action === 'deactivate') {
      setSelectedTemplate(params?.data);
      setDeActiveLoader(true);
      let tempData = params?.data;
      tempData.status = 'INACTIVE';
      jwtAxios
        .put(
          `${API_ROUTS.submitMailTempConfiguration}/inactivate/${params?.data?.id}`,
          // {{host}}/api/mail-template-configuration/inactivate/{{id}}
          tempData,
        )
        .then((res) => {
          fetchInactiveTemplates();
          setDeActiveLoader(false);
          setAlignment(() => 'INACTIVE');
          dispatch(showMessage(' Template Deactivated successfully..!'));
          setSelectedTemplate(null);
        })
        .catch((error) => {
          setDeActiveLoader(false);
          apiCatchErrorMessage(error, dispatch, fetchError);
          setSelectedTemplate(null);
        });
    }
    if (action === 'activate') {
      setSelectedTemplate(params?.data);
      setDeActiveLoader(true);
      let tempData = params?.data;
      tempData.status = 'ACTIVE';
      jwtAxios
        .put(
          `${API_ROUTS.submitMailTempConfiguration}/activate/${params?.data?.id}`,
          // {{host}}/api/mail-template-configuration/activate/{{id}}
          {
            id: params?.data?.id,
            body: params?.data?.body,
            templateName: params?.data?.templateName,
            company: {id: selectedCompany?.id},
            status: 'ACTIVE',
          },
        )
        .then((res) => {
          fetchActiveTemplates();
          setDeActiveLoader(false);
          setAlignment(() => 'ACTIVE');
          dispatch(showMessage(' Template Activated successfully..!'));
          setSelectedTemplate(null);
        })
        .catch((error) => {
          setDeActiveLoader(false);
          apiCatchErrorMessage(error, dispatch, fetchError);
          setSelectedTemplate(null);
        });
    }
  };

  const fetchActiveTemplates = (templateCreated) => {
    setLoading(true);
    jwtAxios
      .get(`${API_ROUTS.getAllMailConfig}${selectedCompany?.id}&status=ACTIVE`)
      .then((res) => {
        // if(templateCreated) {
        // } else {
        //   setTemplates(res?.data);
        // }
        const reversed = res.data.reverse();
        setTemplates(reversed);

        setFilteredTemplateData(
          res?.data?.filter((x) => x.status === 'ACTIVE'),
        );
        setLoading(false);
      })
      .catch((error) => {
        apiCatchErrorMessage(error, dispatch, fetchError);
        setLoading(false);
      });
  };

  const fetchInactiveTemplates = () => {
    setLoading(true);
    jwtAxios
      .get(
        `${API_ROUTS.getAllMailConfig}${selectedCompany?.id}&status=INACTIVE`,
      )
      .then((res) => {
        const reversed = res.data.reverse();
        setTemplates(reversed);
        // setTemplates(res?.data);
        setFilteredTemplateData(
          res?.data?.filter((x) => x.status === 'INACTIVE'),
        );
        setLoading(false);
      })
      .catch((error) => {
        apiCatchErrorMessage(error, dispatch, fetchError);
        setLoading(false);
      });
  };

  const fetchDraftTemplates = () => {
    setLoading(true);
    jwtAxios
      .get(`${API_ROUTS.getAllMailConfig}${selectedCompany?.id}&status=ISDRAFT`)
      .then((res) => {
        const reversed = res.data.reverse();
        setTemplates(reversed);
        // setTemplates(res?.data);
        setFilteredTemplateData(
          res?.data?.filter((x) => x.status === 'ISDRAFT'),
        );
        setLoading(false);
      })
      .catch((error) => {
        apiCatchErrorMessage(error, dispatch, fetchError);
        setLoading(false);
      });
  };

  const gridRef = React.useRef();
  const defaultColDef = React.useMemo(() => ({
    sortable: true,
  }));

  const CustomHeaderEventType = () => (
    <IntlMessages id='aggrid.tableHeader.eventType' />
  );
  const CustomHeaderType = () => <IntlMessages id='aggrid.tableHeader.Type' />;
  const CustomHeaderSubType = () => (
    <IntlMessages id='aggrid.tableHeader.SubType' />
  );
  const CustomHeaderSubject = () => (
    <IntlMessages id='aggrid.tableHeader.Subject' />
  );
  const CustomHeaderStatus = () => (
    <IntlMessages id='aggrid.tableHeader.Status' />
  );
  const CustomHeaderAction = () => (
    <IntlMessages id='aggrid.tableHeader.Action' />
  );

  const columnDefs = [
    // {
    //   field: 'name',
    //   filter: true,
    //   headerName: 'Configuration',
    //   minWidth: 200,
    //   cellRendererFramework: searchHighlightCellRenderer,
    // //   cellStyle: (params) => {
    // //     return getCellStyle(params.data.isDraft);
    // //   },
    // },

    {
      field: 'eventType',
      filter: true,
      headerName: 'Event Type',
      headerComponentFramework: CustomHeaderEventType,
      minWidth: 200,
      cellRendererFramework: searchHighlightCellRenderer,
      //   cellStyle: (params) => {
      //     return getCellStyle(params.data.isDraft);
      //   },
    },

    {
      field: 'type',
      filter: true,
      headerName: 'Type',
      headerComponentFramework: CustomHeaderType,
      minWidth: 200,
      cellRendererFramework: searchHighlightCellRenderer,
      //   cellStyle: (params) => {
      //     return getCellStyle(params.data.isDraft);
      //   },
    },

    {
      field: 'subType',
      filter: true,
      headerName: 'Sub Type',
      headerComponentFramework: CustomHeaderSubType,
      minWidth: 200,
      cellRendererFramework: searchHighlightCellRenderer,
      //   cellStyle: (params) => {
      //     return getCellStyle(params.data.isDraft);
      //   },
      cellRenderer: function (params) {
        return (
          <Stack direction='row'>
            {params.data.subType == 'FINAL' ? (
              <div>CONFIRM</div>
            ) : (
              <div>{params.data.subType}</div>
            )}
          </Stack>
        );
      },
    },

    {
      field: 'subject',
      filter: true,
      headerName: 'Subject',
      headerComponentFramework: CustomHeaderSubject,
      minWidth: 200,
      cellRendererFramework: searchHighlightCellRenderer,
      //   cellStyle: (params) => {
      //     return getCellStyle(params.data.isDraft);
      //   },
    },

    {
      cellStyle: (params) => {
        return getCellStyle(params.data.status == 'ISDRAFT');
      },
      field: 'status',
      filter: true,
      headerName: 'Status',
      headerComponentFramework: CustomHeaderStatus,
      minWidth: 100,
      maxWidth: 110,
      cellRenderer: function (params) {
        return (
          <Stack direction='row'>
            {params.data.status == 'ACTIVE' ? (
              <div style={{color: '#11C15B'}}>{params.data.status}</div>
            ) : (
              <div style={{color: '#D32F2F'}}>{params.data.status}</div>
            )}
          </Stack>
        );
      },
    },
    {
      headerName: 'Action',
      headerComponentFramework: CustomHeaderAction,
      minWidth: 500,

      cellRenderer: function (params) {
        return (
          <Stack direction='row'>
            {isAllowedUser(permissionName.READ) && (
              <Button
                style={{
                  ...buttonStyle,
                  ...getCellStyle(params.data.status == 'ISDRAFT'),
                }}
                sx={getCellStyle(true)}
                onClick={() => handleAction(params, 'view')}
              >
                <IntlMessages id='common.button.View' />
              </Button>
            )}
            {isAllowedUser(permissionName.UPDATE) && (
              <Button
                style={{
                  ...buttonStyle,
                  ...getCellStyle(params.data.status == 'ISDRAFT'),
                }}
                onClick={() => editRow(params)}
              >
                <IntlMessages id='common.button.Edit' />
              </Button>
            )}

            {params.data.status != 'ISDRAFT' &&
              (alignment === 'ACTIVE' ? (
                <>
                  {isAllowedUser(permissionName.DEACTIVATE) && (
                    <Button
                      style={buttonStyle}
                      //   sx={{ ...getCellStyle(params.data.isDraft) }}
                      onClick={() =>
                        handleActivatePlanConfirmation(params, 'deactivate')
                      }
                      disabled={deActiveLoader}
                    >
                      {selectedTemplate?.id === params?.data?.id &&
                      deActiveLoader ? (
                        <CircularProgress size={25} />
                      ) : (
                        <IntlMessages id='common.button.Deactivate' />
                      )}
                    </Button>
                  )}
                </>
              ) : (
                <>
                  {' '}
                  {isAllowedUser(permissionName.ACTIVATE) && (
                    <Button
                      style={buttonStyle}
                      // sx={{ ...getCellStyle(true) }}
                      onClick={() =>
                        handleActivatePlanConfirmation(params, 'activate')
                      }
                      disabled={deActiveLoader}
                    >
                      {selectedTemplate?.id === params?.data?.id &&
                      deActiveLoader ? (
                        <CircularProgress size={25} />
                      ) : (
                        <IntlMessages id='common.button.Activate' />
                      )}
                    </Button>
                  )}
                </>
              ))}
          </Stack>
        );
      },
    },
  ];

  const getCellStyle = (isDraft) => {
    return {color: isDraft ? yellow[800] : green[800], fontWeight: 600};
  };

  const stringWithPlusSigns = (inputString) => {
    return inputString.replace(/ /g, '+');
  };

  const editRow = (params) => {
    router.push(
      `/mails/configurations/createConfiguration/create?name=${stringWithPlusSigns(
        params?.data?.name,
      )}&id=${params?.data?.id}`,
    );
  };


  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
  };

  function searchHighlightCellRenderer(params) {
    const textToHighlight = params?.value?.toString();
    const searchRegex = new RegExp(`(${searchText})`, 'gi');
    const highlightedText = textToHighlight?.replace(
      searchRegex,
      '<span class="highlighted">$1</span>',
    );
    return <div dangerouslySetInnerHTML={{__html: highlightedText}} />;
  }

  const [alertProps, setAlertProps] = React.useState({
    isHideShow: false,
    message: '',
    title: '',
    alertType: '',
    actionParams: null,
  });

  const handleActivatePlanConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title =
      params.data.status == 'ACTIVE' ? (
        <IntlMessages id='template.deactivateTemplate' />
      ) : (
        <IntlMessages id='template.activateTemplate' />
      );
    tempAlertProps.message =
      params.data.status == 'ACTIVE' ? (
        <span>
          <IntlMessages id='common.massage.Deactivate' /> {params.data.subject}
        </span>
      ) : (
        <span>
          <IntlMessages id='common.massage.Aactivate' /> {params.data.subject}
        </span>
      );
    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };

  const handleAlertNo = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };

  const handleAlertYes = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.actionParams.data.status == 'ACTIVE'
      ? handleAction(tempAlertProps.actionParams, 'deactivate')
      : handleAction(tempAlertProps.actionParams, 'activate');
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };

  const onFilterTextBoxChanged = useCallback(() => {
    const filterText = document.getElementById("filter-text-box").value;
    gridRef.current.api.setGridOption("quickFilterText", filterText);
    const totalResults = gridRef.current.api.getDisplayedRowCount();
    if (!isEmptyNullUndefined(filteredTemplateData) && filteredTemplateData.length > 0) {
      if (totalResults === 0 && !isEmptyNullUndefined(filterText)) {
        setOverlayMessage('No Record Found');
        gridRef.current.api.showNoRowsOverlay();
      } else if (totalResults !== 0) {
        setOverlayMessage('No Rows To Show');
        gridRef.current.api.hideOverlay();
      }
    }
  }, []);

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (!isAuthorized) {
    return <Error403 />;
  }

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        {' '}
        <IntlMessages id='sidebar.master.templateConfigurations' />
      </h2>
      <AppCard>
        <Stack
          sx={{
            width: '100%',
            display: 'flex',
            flexDirection: 'row',
            justifyContent: 'flex-end',
            mb: 4,
          }}
        >
          <TextField
            sx={{width: 200, ml: 2, mr: 4}}
            id="filter-text-box"
            onInput={onFilterTextBoxChanged}
            type={'search'}
            name='search'
            label={<IntlMessages id='common.button.Search' />}
            variant='outlined'
          />
          {isAllowedUser(permissionName.CREATE) && (
            <Button
              sx={{width: '13rem', p: 4}}
              variant='contained'
              onClick={() => router.push(`/mails/configurations/TargetMsg`)}
            >
              <IntlMessages id='templeteConfiguration.addConfiguration' />
            </Button>
          )}
          <ToggleButtonGroup
            color='primary'
            value={alignment}
            exclusive
            onChange={handleChange}
          >
            <ToggleButton
              value='ACTIVE'
              sx={{ml: 2}}
              onClick={() => fetchActiveTemplates(selectedCompany.id)}
            >
              <IntlMessages id='common.button.Active' />
            </ToggleButton>
            <ToggleButton
              value='INACTIVE'
              onClick={() => fetchInactiveTemplates(selectedCompany.id)}
            >
              <IntlMessages id='common.button.Inactive' />
            </ToggleButton>
            <ToggleButton
              value='ISDRAFT'
              onClick={() => fetchDraftTemplates(selectedCompany.id)}
            >
              <IntlMessages id='common.draft' />
            </ToggleButton>
          </ToggleButtonGroup>
        </Stack>
        <Stack style={{width: '100%'}}>
          <Stack
            className='ag-theme-alpine'
            style={{height: 535, width: '100%'}}
          >
            {loading ? (
              <Skeleton
                animation='wave'
                sx={{height: '25rem', width: '100%'}}
              />
            ) : (
              <AgGridReact
                ref={gridRef}
                rowData={filteredTemplateData}
                columnDefs={columnDefs}
                defaultColDef={defaultColDef}
                animateRows={true}
                pagination={true}
                paginationPageSize={10}
              />
            )}
          </Stack>
        </Stack>
        {alertProps.isHideShow && (
          <AlertDialog
            alertProps={alertProps}
            handleYes={() => handleAlertYes()}
            handleNo={() => handleAlertNo()}
          />
        )}
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default ConfigurationList;
