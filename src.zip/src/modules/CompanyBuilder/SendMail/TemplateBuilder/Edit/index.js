import { AppAnimate } from "@crema";
import { useState } from "react";
import { AppCard } from '../../../../../@crema';
import AppPageMeta from '../../../../../@crema/core/AppPageMeta';
import AppInfoView from '../../../../../@crema/core/AppInfoView';
import Stack from '@mui/material/Stack';
import { Box, Button, CircularProgress, FormControl, InputLabel, MenuItem, Select, Skeleton, TextField } from '@mui/material';
import { align, font, fontColor, fontSize, formatBlock, hiliteColor, horizontalRule, image, lineHeight, link, list, paragraphStyle, table, template, textStyle } from "../../../../../../node_modules/suneditor/src/plugins";
import { useRouter } from "next/router";
import { useEffect } from "react";
import 'suneditor/dist/css/suneditor.min.css';
import dynamic from "next/dynamic";
import jwtAxios from "@crema/services/auth/jwt-auth";
import { API_ROUTS } from "shared/constants/ApiRouts";
import { useDispatch, useSelector } from "react-redux";
import { fetchError, showMessage } from "redux/actions";
import mergeTag from "./merge_tag_plugin";

const SunEditor = dynamic(() => import("suneditor-react"), {
  ssr: false,
});

const EditTemplate = () => {
    
    const dispatch = useDispatch();
    const router = useRouter();
    const { id } = router.query;

    let selectedCompany = useSelector(({company}) => company.selectedCompany);

    const [loading, setLoading] = useState(false);
    const [editLoader, setEditLoader] = useState(false);
    const [tileDescription, setTileDescription] = useState('');
    const [selectedTemplate, setSelectedTemplate] = useState(null);
    const [templateName, setTemplateName] = useState(null);

    useEffect(() => {
        setLoading(true);
        jwtAxios.get(`${API_ROUTS.getMailTemplatesById}${id}`)
        .then((res) => {
            setSelectedTemplate(() => res?.data);
            setTileDescription(() => res?.data?.body)
            setTemplateName(() => res?.data?.templateName)
            setLoading(false);
        })
        .catch((err) => {
          dispatch(fetchError(err?.message));
          setLoading(false);
        })
      }, [id]);      

    const handleChangeTileDescription = (event) => {
        setTileDescription(() => event)
      }

    const handleSubmitMail = () => {
      setEditLoader(true);
      jwtAxios.put(`${API_ROUTS.submitMailTemplate}/${selectedTemplate?.id}`,
      {
        id:selectedTemplate?.id,
        body:tileDescription,
        templateName:templateName,
        company:{id:selectedCompany?.id},
        status:"ACTIVE"
      }
      ).then((res) => {
        setEditLoader(false);
        dispatch(
          showMessage(
              ' Template added successfully..!',
          ),
          router.push(`/mails/template-builder/templates`)
        );
      }).catch((err) => {  
        setEditLoader(false);      
        dispatch(fetchError(err.message));
      })
    }

    if (router.isFallback) {
      <h1>Data is loading</h1>;
  }


    return(
        <AppAnimate animation='transition.slideUpIn' delay={500}>
        <AppPageMeta />
        <h2 style={{ marginBottom: 20 }}>Create Mail</h2>
        <AppCard>
          <Stack style={{ width: '100%' }}>
          <Stack
                  className='ag-theme-alpine'
                  style={{ height: 525, width: '100%' }}
                >
                  {loading ? (
                    <Skeleton
                      animation='wave'
                      sx={{ height: '25rem', width: '100%' }}
                    />
                  ) : (
                    <div>
                         <Box sx={{ width: {md:"50%"}, mb:4 }}>
                            <FormControl fullWidth>
                                <TextField 
                                value={templateName}
                                onChange={(e) => setTemplateName(() => e.target.value)}
                                id="outlined-basic" 
                                label="Template Name" 
                                variant="outlined" />
                            </FormControl>
                            </Box>
                        <SunEditor
                            setOptions={{
                            showPathLabel: false,
                            minHeight: "41vh",
                            placeholder: "Enter your text here!!!",

                            "mode": "classic",
                            "rtl": false,
                            "katex": "window.katex",
                            "imageGalleryUrl": "https://etyswjpn79.execute-api.ap-northeast-1.amazonaws.com/suneditor-demo",
                            "videoFileInput": false,
                            "tableCellControllerPosition": "",
                            "tabDisable": false,

                            plugins: [
                            align,
                            font,
                            fontColor,
                            fontSize,
                            formatBlock,
                            hiliteColor,
                            horizontalRule,
                            lineHeight,
                            list,
                            paragraphStyle,
                            table,
                            template,
                            textStyle,
                            image,
                            link,
                            mergeTag
                            ],
                            buttonList: [
                            ["undo", "redo"],
                            ["font", "fontSize", "formatBlock",{
                                name: 'merge_tag',
                                dataCommand: 'merge_tag',
                                buttonClass: '',
                                title: 'Merge Tag',
                                dataDisplay: 'submenu',
                                innerHTML: '<span style="font-size: 20px;"><strong>P</strong></span>',
                            }],
                            ["paragraphStyle"],
                            [
                                "bold",
                                "underline",
                                "italic",
                                "strike",
                                "subscript",
                                "superscript"
                            ],
                            ["fontColor", "hiliteColor"],
                            ["removeFormat"],
                            "/", // Line break
                            ["outdent", "indent"],
                            ["align", "horizontalRule", "list", "lineHeight"],
                            ["table", "link", "image"],
                            ["textStyle", "math", "imageGallery", "fullScreen", "showBlocks", "codeView", "preview", "print", "save", "template"],
                              
                        ],
                            
                            formats: ["p", "div", "h1", "h2", "h3", "h4", "h5", "h6"],
                            font: [
                            "Arial",
                            "Calibri",
                            "Comic Sans",
                            "Courier",
                            "Garamond",
                            "Georgia",
                            "Impact",
                            "Lucida Console",
                            "Palatino Linotype",
                            "Segoe UI",
                            "Tahoma",
                            "Times New Roman",
                            "Trebuchet MS"
                            ]
                            }}
                        onChange={(event) => handleChangeTileDescription(event)}
                        setContents={tileDescription} 
                        // defaultValue={tileDescription}
                        // value={tileDescription}
                        />
                    </div>
                  )}
                </Stack>
                <Button 
                sx={{mt:4}}
                variant="contained"
                onClick={() => handleSubmitMail()}
                disabled={editLoader}
                >
                  {
                    editLoader ? 
                    <CircularProgress size={25} />
                    :
                    "Submit"
                  }
                </Button>
          </Stack>
        </AppCard>
        <AppInfoView />
        </AppAnimate>    
    )
}

export default EditTemplate;