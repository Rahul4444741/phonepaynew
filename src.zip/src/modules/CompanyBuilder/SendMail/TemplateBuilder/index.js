import Stack from '@mui/material/Stack';
import AppAnimate from '../../../../@crema/core/AppAnimate';
import { AppCard } from '../../../../@crema';
import AppPageMeta from '../../../../@crema/core/AppPageMeta';
import AppInfoView from '../../../../@crema/core/AppInfoView';
import { AgGridReact } from 'ag-grid-react';
import { Button, CircularProgress, Skeleton, TextField, ToggleButton, ToggleButtonGroup } from '@mui/material';
import { useState } from 'react';
import React from 'react';
import { useEffect } from 'react';
import { API_ROUTS } from 'shared/constants/ApiRouts';
import { useDispatch, useSelector } from 'react-redux';
import { fetchError, showMessage } from 'redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import { useRouter } from 'next/router';
import { useCallback } from 'react';


const TemplateList = () => {

  const dispatch = useDispatch();
  const router = useRouter();

  let selectedCompany = useSelector(({company}) => company.selectedCompany);

    const [loading, setLoading] = useState(false);
    const [deActiveLoader, setDeActiveLoader] = useState(false);
    const [selectedTemplate, setSelectedTemplate] = useState(null);
    const [templates, setTemplates] = useState(null);
    const [filteredTemplateData, setFilteredTemplateData] = useState(null);
    const [alignment, setAlignment] = React.useState('ACTIVE');

    const [gridApi, setGridApi] = React.useState(null);
    const [gridColumnApi, setGridColumnApi] = React.useState(null);

    useEffect(() => {
      fetchTemplates();
    }, [selectedCompany]);

    useEffect(() => {
      let arr = JSON.parse(JSON.stringify(templates))
      setFilteredTemplateData(arr?.filter(x => x.status === alignment))
    }, [alignment]);
    
    const handleAction = (params, action) => {
      console.log("params",params);
      
      if(action === "create"){
        router.push(`/mails/template-builder/editTemplate/${params?.data?.id}`)
      }
      if(action === "deactivate"){
        setSelectedTemplate(params?.data);
        setDeActiveLoader(true);
        jwtAxios.put(`${API_ROUTS.submitMailTemplate}/${params?.data?.id}`,
        {
          id:params?.data?.id,
          body:params?.data?.body,
          templateName:params?.data?.templateName,
          company:{id:selectedCompany?.id},
          status:"INACTIVE"
        }
        ).then((res) => {
          fetchTemplates();
          setDeActiveLoader(false);
          dispatch(
            showMessage(
                ' Template Deactivated successfully..!',
            ),
          );
          setSelectedTemplate(null);
        }).catch((err) => {  
          setDeActiveLoader(false);      
          dispatch(fetchError(err.message));
          setSelectedTemplate(null);
        })
      }
      if(action === "activate"){
        setSelectedTemplate(params?.data);
        setDeActiveLoader(true);
        jwtAxios.put(`${API_ROUTS.submitMailTemplate}/${params?.data?.id}`,
        {
          id:params?.data?.id,
          body:params?.data?.body,
          templateName:params?.data?.templateName,
          company:{id:selectedCompany?.id},
          status:"ACTIVE"
        }
        ).then((res) => {
          fetchTemplates();
          setDeActiveLoader(false);
          dispatch(
            showMessage(
                ' Template Activated successfully..!',
            ),
          );
          setSelectedTemplate(null);
        }).catch((err) => {  
          setDeActiveLoader(false);      
          dispatch(fetchError(err.message));
          setSelectedTemplate(null);
        })
      }
  
    }
    
    const fetchTemplates = () => {
      setLoading(true);
      jwtAxios.get(`${API_ROUTS.getAllMailTemplates}${selectedCompany?.id}`)
      .then((res) => {
        setTemplates(res?.data);
        setFilteredTemplateData(res?.data?.filter(x => x.status === alignment));
        setLoading(false);
      })
      .catch((err) => {
        dispatch(fetchError(err?.message));
        setLoading(false);
      })
    }

    const gridRef = React.useRef();
  const defaultColDef = React.useMemo(() => ({
    sortable: true,
  }));

  

  const columnDefs = [
    {
      field: 'templateName',
      filter: true,
      headerName: 'Template',
      minWidth: 200,
      cellRendererFramework: searchHighlightCellRenderer,
    //   cellStyle: (params) => {
    //     return getCellStyle(params.data.isDraft);
    //   },
    },
    {
      field: 'status',
      filter: true,
      headerName: 'Status',
      minWidth: 200,
    //   cellStyle: (params) => {
    //     return getCellStyle(params.data.isDraft);
    //   },
    },
    {
      headerName: 'Action',
      minWidth: 500,
    //   cellStyle: (params) => {
    //     return getCellStyle(params.data.isDraft);
    //   },
      cellRenderer: function (params ) {
        return (
          <Stack direction='row'>
            
            {/* <Button
            //   sx={{ ...getCellStyle(params.data.isDraft) }}
              onClick={() => handleAction(params)}
            >
              view
            </Button> */}
            <Button
            //   sx={{ ...getCellStyle(params.data.isDraft) }}
              onClick={() => handleAction(params, "create")}
            >
              Edit
            </Button>
            {
              alignment === "ACTIVE" ? 
            <Button
            //   sx={{ ...getCellStyle(params.data.isDraft) }}
              onClick={() => handleAction(params, "deactivate")}
              disabled={deActiveLoader}
            >
              {
                ((selectedTemplate?.id === params?.data?.id) && deActiveLoader) ? 
                <CircularProgress size={25} />
                :
                "Deactivate"
              }              
            </Button>
            :
            <Button
            //   sx={{ ...getCellStyle(params.data.isDraft) }}
              onClick={() => handleAction(params, "activate")}
              disabled={deActiveLoader}
            >
              {
                ((selectedTemplate?.id === params?.data?.id) && deActiveLoader) ? 
                <CircularProgress size={25} />
                :
                "Activate"
              }              
            </Button>
            }
            

            {/* <Button
            //   sx={{ ...getCellStyle(params.data.isDraft) }}
              onClick={() => handleAction(params)}
            >
              Edit
            </Button>  */}
            
          </Stack>
        );
      },
    },
  ];

  function onGridReady(params) {
    console.log('params', params)
    setGridApi(params.api);
    setGridColumnApi(params.api);
  };

  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
    console.log(alignment);
  };

  const onFilterTextBoxChanged = useCallback(() => {
    const filterText = document.getElementById("filter-text-box").value;
    gridRef.current.api.setGridOption("quickFilterText", filterText);
    const totalResults = gridRef.current.api.getDisplayedRowCount();
    if (!isEmptyNullUndefined(filteredTemplateData) && filteredTemplateData.length > 0) {
      if (totalResults === 0 && !isEmptyNullUndefined(filterText)) {
        setOverlayMessage('No Record Found');
        gridRef.current.api.showNoRowsOverlay();
      } else if (totalResults !== 0) {
        setOverlayMessage('No Rows To Show');
        gridRef.current.api.hideOverlay();
      }
    }
  }, []);

    return(
        <AppAnimate animation='transition.slideUpIn' delay={500}>
        <AppPageMeta />
        <h2 style={{ marginBottom: 20 }}>Send Mail</h2>
        <AppCard>
          <Stack sx={{width:"100%", display:"flex", flexDirection:"row", justifyContent:"flex-end", mb:4}}>
            <TextField
              //size='small'
              sx={{ width: 200, ml: 2, mr:4 }}
              type={'search'}
              name='search'
              id="filter-text-box"
              onInput={onFilterTextBoxChanged}
              label='Search...'
              variant='outlined'
            />
            <Button 
              sx={{width:"10rem", p:4}}
              variant="contained"
              onClick={() => router.push(`/mails/template-builder/createTemplate/create`)}
              >
                  Add Template
            </Button>
            <ToggleButtonGroup
                color='primary'
                value={alignment}
                exclusive
                onChange={handleChange}
              >
                <ToggleButton
                  value='ACTIVE'
                  sx={{ml: 2}}
                  // onClick={() => getAllActivePlans(selectedCompany.id)}
                >
                Active
              </ToggleButton>
              <ToggleButton
                value='INACTIVE'
                // onClick={() => getAllInactivePlans(selectedCompany.id)}
              >
                Inactive
              </ToggleButton>
            </ToggleButtonGroup>
          </Stack>      
          <Stack style={{ width: '100%' }}>
          <Stack
                  className='ag-theme-alpine'
                  style={{ height: 525, width: '100%' }}
                >
                  {loading ? (
                    <Skeleton
                      animation='wave'
                      sx={{ height: '25rem', width: '100%' }}
                    />
                  ) : (
                    <AgGridReact
                      ref={gridRef}
                      rowData={filteredTemplateData}
                      columnDefs={columnDefs}
                      defaultColDef={defaultColDef}
                      animateRows={true}
                      pagination={true}
                      paginationPageSize={10}
                    />
                  )}
                </Stack>
          </Stack>
        </AppCard>
        <AppInfoView />
        </AppAnimate>    
    )
}

export default TemplateList;