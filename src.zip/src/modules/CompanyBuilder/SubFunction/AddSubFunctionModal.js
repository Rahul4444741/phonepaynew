import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import Stack from '@mui/material/Stack';
import {AppCard} from '../../../@crema';
import {
  fetchStart,
  showMessage,
  fetchError,
  showInfo,
} from '../../../redux/actions';
import TextField from '@mui/material/TextField';
import PropTypes from 'prop-types';
import AppInfoView from '../../../@crema/core/AppInfoView';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import {useDispatch, useSelector} from 'react-redux';
import jwtAxios from '@crema/services/auth/jwt-auth';
import axios from 'axios';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {
  apiCatchErrorMessage,
  isEmptyNullUndefined,
  isStrExceeds,
} from 'shared/utils/CommonUtils';
import IntlMessages from '@crema/utility/IntlMessages';
const AddSubFunctionModal = ({
  company,
  handleAddSubFunction,
  handleUpdateSubFunction,
  handleClose,
  isEdit,
  editSubFunction,
  subFunctionData,
}) => {
  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const dispatch = useDispatch();
  const [subFunctions, setSubFunctions] = React.useState({
    id: null,
    employeeFunction: {
      id: null,
    },
    name: '',
    status: '',
    company: {
      id: company.id,
    },
  });
  const [functionData, setFunctionData] = React.useState(null);
  const [isLoading, setIsLoading] = React.useState(true);
  const [formError, setFormError] = React.useState({
    employeeFunction: {
      id: {isError: false, errorMessage: ''},
    },
    name: {isError: false, errorMessage: ''},
    status: {isError: false, errorMessage: ''},
  });

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  const textFieldStyled = {
    backgroundColor: 'white',
    mb: 4,
    width: {xs: '100%'},
  };

  React.useEffect(() => {
    if (isEdit) {
      setSubFunctions(editSubFunction);
    }
    getAllActiveFunctions(company.id);
  }, []);

  React.useEffect(() => {
    dispatch(fetchStart);
    if (selectedCompany != null && selectedCompany != undefined) {
      getAllActiveFunctions(selectedCompany.id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, [selectedCompany]);

  const getAllActiveFunctions = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.getAll_function}${companyId}?status=ACTIVE`,
        {cancelToken: source.token},
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no functions for selected company'));
          setFunctionData([]);
        } else {
          setFunctionData(res.data);
        }
        setIsLoading(() => false);
      } else {
        setFunctionData([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setFunctionData([]);
    }
    setIsLoading(() => false);
  };

  const isDuplicateSubfunction = (str, list, id = null) => {
    console.log('str', str);
    console.log('str.name', str.name);
    console.log('str.func', str.employeeFunction.id);

    if (!Array.isArray(list)) {
      return false;
    }

    const compareString = (s) => (s ? s.trim().toLowerCase() : '');

    const hasDuplicate = (item) =>
      compareString(item?.name) === compareString(str.name) &&
      compareString(item?.employeeFunction?.id) ===
        compareString(str.employeeFunction.id) &&
      (!id || item?.id !== id);

    return list.some(hasDuplicate);
  };

  const handleValidateFunction = async () => {
    let isValid = true;
    const tempError = {...formError};
    const tempFunction = {...subFunctions};
    if (tempFunction.name.trim() == '') {
      tempError.name.isError = true;
      tempError.name.errorMessage = <IntlMessages id='error.pleaseEnterName' />;
      isValid = false;
    }
    if (isStrExceeds(tempFunction.name.toString(), 50)) {
      tempError.name.isError = true;
      tempError.name.errorMessage = 'should not exceed 50 characters';
      isValid = false;
    }
    if (
      !isEdit
        ? isDuplicateSubfunction(tempFunction, subFunctionData)
        : isDuplicateSubfunction(tempFunction, subFunctionData, tempFunction.id)
    ) {
      tempError.name.isError = true;
      tempError.name.errorMessage = (
        <IntlMessages id='error.duplicateEntryFound' />
      );
      isValid = false;
    }

    if (isEmptyNullUndefined(tempFunction.employeeFunction.id)) {
      tempError.employeeFunction.id.isError = true;
      tempError.employeeFunction.id.errorMessage =
        // <IntlMessages id='error.pleaseSelectStatus' />
        'Please select function';
      isValid = false;
    }
    if (tempFunction.status.trim() == '') {
      tempError.status.isError = true;
      tempError.status.errorMessage = (
        <IntlMessages id='error.pleaseSelectStatus' />
      );
      isValid = false;
    }
    if (isValid) {
      if (isEdit) {
        updateSubFunction();
      } else {
        submitSubFunction();
      }
    } else {
      setFormError(tempError);
    }
  };

  const submitSubFunction = async () => {
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.create_subfunction}`,
        subFunctions,
      );
      if (response.status == 201) {
        dispatch(
          showMessage(
            response.data.name + 'Sub Function added successfully..!',
          ),
        );
        handleAddSubFunction(response.data);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const updateSubFunction = async () => {
    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.create_subfunction}/${subFunctions.id}`,
        subFunctions,
      );
      if (response.status == 200) {
        dispatch(
          showMessage(
            response.data.name + 'Sub Function updated successfully..!',
          ),
        );
        handleUpdateSubFunction(response.data);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleChangeFunctionData = (event, fieldType) => {
    const tempFunction = {...subFunctions};
    const tempError = {...formError};
    if (fieldType == 'textfield') {
      tempFunction[event.target.name] = event.target.value;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
    } else if (fieldType == 'dropdownID') {
      tempFunction[event.target.name] = {id: event.target.value};
      tempError[event.target.name].id.isError = false;
      tempError[event.target.name].id.errorMessage = '';
    }

    setSubFunctions(tempFunction);
    setFormError(tempError);
  };

  return (
    <Dialog maxWidth={'sm'} open={true}>
      <DialogContent>
        <Stack direction='row' justifyContent='center' sx={{mt: '7%'}}>
          <AppCard style={{width: '350px'}}>
            <h4 style={{display: 'flex'}}>
              {!isEdit
                ? // <IntlMessages id='roles.addGradesLevel' />
                  'Add Sub Function'
                : // <IntlMessages id='roles.updateGradesLevel' />
                  'Update Sub Function'}
            </h4>
            <Stack
              sx={{mt: 2}}
              display='flex'
              justifyContent='center'
              spacing={2}
            >
              <TextField
                size='small'
                name='name'
                label={<IntlMessages id='configuration.dialogbox.Name' />}
                onChange={(event) =>
                  handleChangeFunctionData(event, 'textfield')
                }
                value={subFunctions?.name}
                error={formError.name.isError}
                helperText={formError.name.errorMessage}
                variant='outlined'
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              />

              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id='event-type'>
                  {/* <IntlMessages id='configuration.dialogbox.Status' /> */}
                  Function
                </InputLabel>
                <Select
                  size='small'
                  name='employeeFunction'
                  label='Function'
                  value={subFunctions?.employeeFunction.id}
                  error={formError.employeeFunction.id.isError}
                  helperText={formError.employeeFunction.id.errorMessage}
                  onChange={(event) =>
                    handleChangeFunctionData(event, 'dropdownID')
                  }
                  variant='outlined'
                  sx={{...textFieldStyled}}
                >
                  {functionData &&
                    functionData.map((func, index) => (
                      <MenuItem
                        id={`employeeFunction-MenuItem-${index}`}
                        key={func.id}
                        value={func.id}
                      >
                        {func.name}
                      </MenuItem>
                    ))}
                </Select>
                <FormHelperText style={{color: '#d32f2f'}}>
                  {formError.employeeFunction.id.errorMessage}
                </FormHelperText>
              </FormControl>

              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id='event-type'>
                  <IntlMessages id='configuration.dialogbox.Status' />
                </InputLabel>
                <Select
                  size='small'
                  name='status'
                  label='Status'
                  value={subFunctions?.status}
                  error={formError.status.isError}
                  helperText={formError.status.errorMessage}
                  onChange={(event) =>
                    handleChangeFunctionData(event, 'textfield')
                  }
                  variant='outlined'
                  sx={{...textFieldStyled}}
                >
                  <MenuItem key='Active' value='ACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Active' />
                  </MenuItem>
                  <MenuItem key='Inactive' value='INACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                  </MenuItem>
                </Select>
                <FormHelperText style={{color: '#d32f2f'}}>
                  {formError.status.errorMessage}
                </FormHelperText>
              </FormControl>
            </Stack>
          </AppCard>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={() => handleValidateFunction()} disabled={isLoading}>
          <IntlMessages id='common.button.Submit' />
        </Button>
        <Button onClick={() => handleClose()}>
          <IntlMessages id='common.button.Close' />
        </Button>
      </DialogActions>
      <AppInfoView />
    </Dialog>
  );
};

export default AddSubFunctionModal;
AddSubFunctionModal.propTypes = {
  company: PropTypes.object,
  handleAddSubFunction: PropTypes.func,
  handleUpdateSubFunction: PropTypes.func,
  handleClose: PropTypes.func,
  isEdit: PropTypes.bool,
  editSubFunction: PropTypes.object,
  subFunctionData: PropTypes.array,
};
