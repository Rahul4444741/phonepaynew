import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import { AppCard } from '../../../@crema';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import { AgGridReact } from 'ag-grid-react';
import { useDispatch, useSelector } from 'react-redux';
import AppInfoView from '../../../@crema/core/AppInfoView';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import {
  fetchStart, showMessage,
  fetchError,
  showInfo
} from '../../../redux/actions';
import axios from 'axios';
import AlertDialog from '../../Common/AlertDialog';
import jwtAxios from '@crema/services/auth/jwt-auth';
import { API_ROUTS } from 'shared/constants/ApiRouts';
import { TextField } from '@mui/material';
import {
  isEmptyNullUndefined,
  buttonStyle,
  apiCatchErrorMessage,
  isAllowedUser,
} from 'shared/utils/CommonUtils';
import { domCreactionGridSkeletonLoader } from 'shared/utils/domCreaction';
import IntlMessages from '@crema/utility/IntlMessages';
import AddSubFunctionModal from './AddSubFunctionModal';
import { permissionName } from 'shared/utils/PermissionName';
import Error403 from 'modules/errorPages/Error403';
import { useCallback } from 'react';

const CustomHeaderName = () => (
  <IntlMessages id='aggrid.tableHeader.Name' />
);
const CustomHeaderFunction = () => (
  <IntlMessages id='aggrid.tableHeader.Function' />
);
const CustomHeaderStatus = () => (
  <IntlMessages id='aggrid.tableHeader.Status' />
);
const CustomHeaderAction = () => (
  <IntlMessages id='aggrid.tableHeader.Action' />
);

const SubFunctions = () => {
  const dispatch = useDispatch();
  const [subFunctionData, setSubFunctionData] = React.useState(null);
  const [isAddSubFunctionOpen, setIsAddSubFunctionOpen] = React.useState(false);
  const [isEdit, setIsEdit] = React.useState(false);
  const [editSubFunction, setEditSubFunction] = React.useState(undefined);
  const [overlayMessage, setOverlayMessage] = React.useState('No Rows To Show');
  const [isLoading, setIsLoading] = React.useState(true);
  const [alertProps, setAlertProps] = React.useState({
    isHideShow: false,
    message: '',
    title: '',
    alertType: '',
    actionParams: null,
  });

  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);

  React.useEffect(() => {
    if (isAllowedUser(permissionName.COMPANY_VARIABLES_SUBFUNCTIONS)) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  const StatusRenderer = (params) => (
    <Stack direction='row'>
      <div style={{ color: params.data.status === 'ACTIVE' ? '#11C15B' : '#D32F2F' }}>
        {params.data.status}
      </div>
    </Stack>
  );
  const ActionRenderer = (params) => (
    <Stack direction='row'>
      {isAllowedUser(permissionName.UPDATE) && (
        <Button
          onClick={() => handleOpenEditModel(params)}
          style={buttonStyle}
        >
          <IntlMessages id='common.button.Edit' />
        </Button>
      )}
      {isAllowedUser(permissionName.DEACTIVATE) && params.data.status === 'ACTIVE' && (
        <Button
          onClick={() => handleDeactivateConfirmation(params)}
          style={buttonStyle}
        >
          <IntlMessages id='common.button.Deactivate' />
        </Button>
      )}
      {isAllowedUser(permissionName.ACTIVATE) && params.data.status === 'INACTIVE' && (
        <Button
          onClick={() => handleActivateConfirmation(params)}
          style={buttonStyle}
        >
          <IntlMessages id='common.button.Activate' />
        </Button>
      )}
    </Stack>
  );
  const columnDefs = [
    {
      field: 'name',
      filter: true,
      headerName: 'Name',
      minWidth: 250,
      headerComponentFramework: CustomHeaderName,
    },
    {
      field: 'employeeFunction.name',
      filter: true,
      headerName: 'Function Name',
      minWidth: 250,
      headerComponentFramework: CustomHeaderFunction,
    },
    {
      field: 'status',
      filter: true,
      headerName: 'Status',
      headerComponentFramework: CustomHeaderStatus,
      minWidth: 250,
      cellRenderer: StatusRenderer,  // Use custom status renderer
    },
    {
      headerName: 'Action',
      headerComponentFramework: CustomHeaderAction,
      minWidth: 300,
      cellRenderer: ActionRenderer,  // Use custom action renderer
    },
  ];
     

  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();
  React.useEffect(() => {
    dispatch(fetchStart);
    if (
      isAuthorized &&
      selectedCompany != null &&
      selectedCompany != undefined
    ) {
      getAllActiveSubFunctions(selectedCompany.id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, [isAuthorized, selectedCompany]);

  const gridRef = React.useRef();
  const defaultColDef = React.useMemo(() => ({
    sortable: true,
  }));

  const getAllActiveSubFunctions = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.getAll_subfunction}${companyId}?status=ACTIVE`,
        {cancelToken: source.token},
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no subFunction for selected company'));
          setSubFunctionData([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setSubFunctionData(reversed);
        }
        setIsLoading(() => false);
      } else {
        setSubFunctionData([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setSubFunctionData([]);
    }
    setIsLoading(() => false);
  };
  const getAllInactiveSubFunctions = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.getAll_subfunction}${companyId}?status=INACTIVE`,
        {cancelToken: source2.token},
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no subFunction for selected company'));
          setSubFunctionData([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setSubFunctionData(reversed);
        }
        setIsLoading(() => false);
      } else {
        setSubFunctionData([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setSubFunctionData([]);
      setIsLoading(() => false);
    }
  };

  const handleOpenEditModel = (params) => {
    let rowData = [];
    params.api.forEachNode((node) => rowData.push(node.data));
    const functionIndex = rowData.findIndex(
      (item) => item.id == params.data.id,
    );

    if (functionIndex != -1) setEditSubFunction(rowData[functionIndex]);
    setIsEdit(true);
    setIsAddSubFunctionOpen(true);
  };

  const handleDeactivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = <IntlMessages id='warning.deactivateRole' />;

    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureDeactivate' /> {params.data.name} ?
      </span>
    );

    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleAlertYes = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.actionParams.data.status == 'ACTIVE' &&
      handleDeactivateSubFunction(tempAlertProps.actionParams);
    tempAlertProps.actionParams.data.status == 'INACTIVE' &&
      handleActivateSubFunction(tempAlertProps.actionParams);
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };

  const handleAlertNo = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };
  const handleDeactivateSubFunction = async (params) => {
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));
      const response = await jwtAxios.put(
        `${API_ROUTS.subfunction_inactivate}/${params.data.id}`,
      );
      if (response.status == 200) {
        dispatch(showMessage('Sub function deactivate successfully..!'));

        const functionIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );

        if (functionIndex != -1) {
          rowData[functionIndex].status = 'INACTIVE';
        }
        getAllInactiveSubFunctions(selectedCompany.id);
        setAlignment('INACTIVE');
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleActivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = <IntlMessages id='warning.activateRole' />;
    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureActivate' /> {params.data.name} ?
      </span>
    );
    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleActivateSubFunction = async (params) => {
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));
      const response = await jwtAxios.put(
        `${API_ROUTS.subfunction_activate}/${params.data.id}`,
      );
      if (response.status == 200) {
        dispatch(showMessage('Sub function activate successfully..!'));
        const functionIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );
        if (functionIndex != -1) {
          rowData[functionIndex].status = 'ACTIVE';
        }
        getAllActiveSubFunctions(selectedCompany.id);
        setAlignment('ACTIVE');
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleUpdateSubFunction = (subFunction) => {
    const isActive = subFunction.status === 'ACTIVE';
    const isInactive = subFunction.status === 'INACTIVE';
  
    // Update sub-function data if the status and alignment match
    if ((isActive && alignment === 'ACTIVE') || (isInactive && alignment === 'INACTIVE')) {
      const tempFunctions = [...subFunctionData];
      const functionIndex = tempFunctions.findIndex(
        (item) => item.id === subFunction.id,
      );
  
      if (functionIndex !== -1) {
        tempFunctions[functionIndex] = subFunction;
        setSubFunctionData(tempFunctions);
      }
    }
  
    // Handle alignment changes and fetch data if needed
    if ((isActive && alignment === 'INACTIVE') || (isInactive && alignment === 'ACTIVE')) {
      setAlignment(isActive ? 'ACTIVE' : 'INACTIVE');
      isActive
        ? getAllActiveSubFunctions(selectedCompany.id)
        : getAllInactiveSubFunctions(selectedCompany.id);
    }
  
    // Cleanup
    setEditSubFunction(null);
    setIsEdit(false);
    setIsAddSubFunctionOpen(false);
  };
 
  const handleAddSubFunctionToList = (subFunction) => {
    const { status } = subFunction;
    const isActive = status === 'ACTIVE';
    const isAligned = alignment === status;
  
    if (isAligned) {
      setSubFunctionData([subFunction, ...subFunctionData]);
    } else {
      setAlignment(isActive ? 'ACTIVE' : 'INACTIVE');
      if (isActive) {
        getAllActiveSubFunctions(selectedCompany.id);
      } else {
        getAllInactiveSubFunctions(selectedCompany.id);
      }
    }
  
    setIsAddSubFunctionOpen(false);
  };
  

  const handleCloseAddSubFunction = () => {
    setIsAddSubFunctionOpen(false);
  };
  const handleOpenAddSubFunction = () => {
    setIsAddSubFunctionOpen(true);
    setIsEdit(false);
  };

  const [alignment, setAlignment] = React.useState('ACTIVE');

  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
  };
  
  const onFilterTextBoxChanged = useCallback(() => {
    const filterText = document.getElementById("filter-text-box").value;
    gridRef.current.api.setGridOption("quickFilterText", filterText);
    const totalResults = gridRef.current.api.getDisplayedRowCount();
    if (!isEmptyNullUndefined(subFunctionData) && subFunctionData.length > 0) {
      if (totalResults === 0 && !isEmptyNullUndefined(filterText)) {
        setOverlayMessage('No Record Found');
        gridRef.current.api.showNoRowsOverlay();
      } else if (totalResults !== 0) {
        setOverlayMessage('No Rows To Show');
        gridRef.current.api.hideOverlay();
      }
    }
  }, []);
  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (!isAuthorized) {
    return <Error403 />;
  }

  return (
      <AppAnimate animation='transition.slideUpIn' delay={500}>
        <AppPageMeta />
        <h2 style={{marginBottom: 20}}>
          {/* <IntlMessages id='roles.pageHeaderName' /> */}
          SubFunctions
        </h2>
        <AppCard>
          <Stack style={{width: '100%'}}>
            <Stack direction='row' sx={{mb: 2}} justifyContent={'end'}>
              <TextField
                //size='small'
                sx={{width: 200, mr: 2}}
                id="filter-text-box"
                onInput={onFilterTextBoxChanged}
                type={'search'}
                name='search'
                label={<IntlMessages id='common.button.Search' />}
                variant='outlined'
              />
              {isAllowedUser(permissionName.CREATE) && (
                <Button
                  sx={{mr: 2}}
                  variant='outlined'
                  onClick={() => handleOpenAddSubFunction()}
                >
                  {/* <IntlMessages id='roles.addGradesLevel' /> */}
                  Add Sub Function
                </Button>
              )}
              <ToggleButtonGroup
                color='primary'
                value={alignment}
                exclusive
                onChange={handleChange}
              >
                <ToggleButton
                  value='ACTIVE'
                  onClick={() => getAllActiveSubFunctions(selectedCompany.id)}
                >
                  <IntlMessages id='common.button.Active' />
                </ToggleButton>
                <ToggleButton
                  value='INACTIVE'
                  onClick={() => getAllInactiveSubFunctions(selectedCompany.id)}
                >
                  <IntlMessages id='common.button.Inactive' />
                </ToggleButton>
              </ToggleButtonGroup>
            </Stack>
            {isLoading ? (
              domCreactionGridSkeletonLoader()
            ) : (
              <Stack
                className='ag-theme-alpine'
                style={{height: 525, width: '100%'}}
              >
                <AgGridReact
                  ref={gridRef}
                  rowData={subFunctionData}
                  columnDefs={columnDefs}
                  defaultColDef={defaultColDef}
                  animateRows={true}
                  pagination={true}
                  paginationPageSize={10}
                  overlayLoadingTemplate={
                    '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'
                  }
                  overlayNoRowsTemplate={`<span class="ag-overlay-loading-center">${overlayMessage}</span>`}
                />
              </Stack>
            )}
          </Stack>
          {isAddSubFunctionOpen && (
            <AddSubFunctionModal
              company={selectedCompany}
              isEdit={isEdit}
              editSubFunction={editSubFunction}
              handleAddSubFunction={(subFunction) =>
                handleAddSubFunctionToList(subFunction)
              }
              handleUpdateSubFunction={(subFunction) =>
                handleUpdateSubFunction(subFunction)
              }
              handleClose={() => handleCloseAddSubFunction()}
              subFunctionData={subFunctionData}
            ></AddSubFunctionModal>
          )}
          {alertProps.isHideShow && (
            <AlertDialog
              alertProps={alertProps}
              handleYes={() => handleAlertYes()}
              handleNo={() => handleAlertNo()}
            />
          )}
        </AppCard>
        <AppInfoView />
      </AppAnimate>
  );
};

export default SubFunctions;
