import React from 'react';
import {useDispatch, useSelector} from 'react-redux';
import AppAnimate from '../../../../@crema/core/AppAnimate';
import AppPageMeta from '../../../../@crema/core/AppPageMeta';
import {AppCard, AppInfoView} from '../../../../@crema';
import Stack from '@mui/material/Stack';
import {
  DatePicker,
  DesktopDatePicker,
  LocalizationProvider,
} from '@mui/x-date-pickers';
import {AdapterDateFns} from '@mui/x-date-pickers/AdapterDateFns';
import TextField from '@mui/material/TextField';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import {
  getCompanyDateFormatForInputs,
  isEmptyNullUndefined,
  apiCatchErrorMessage,
} from '../../../../shared/utils/CommonUtils';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import Router, {useRouter} from 'next/router';
import {showMessage, fetchError, showInfo} from '../../../../redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import FormHelperText from '@mui/material/FormHelperText';
import {footerButton} from 'shared/constants/AppConst';
import IntlMessages from '@crema/utility/IntlMessages';
import {
  Autocomplete,
  Checkbox,
  CircularProgress,
  Divider,
  FormControlLabel,
  Radio,
  RadioGroup,
  Tooltip,
} from '@mui/material';
import axios from 'axios';
import InfoIcon from '@mui/icons-material/Info';
import GenericSelectWithSearch from 'modules/Common/GenericSelectWithSearch';
import CheckBoxOutlineBlankIcon from '@mui/icons-material/CheckBoxOutlineBlank';
import CheckBoxIcon from '@mui/icons-material/CheckBox';
import {
  domCreactionGridSkeletonLoader,
  domCreactionHeaderTitle,
} from 'shared/utils/domCreaction';

const icon = <CheckBoxOutlineBlankIcon fontSize='medium' />;
const checkedIcon = <CheckBoxIcon fontSize='medium' />;

const textFieldStyled = {
  backgroundColor: 'white',
  mb: 2,
  width: {xs: '100%', xl: '50%', md: '75%'},
};

const AddThreeSixtyCycle = () => {
  const router = useRouter();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const {id, replica} = router.query;
  const dispatch = useDispatch();

  const initialThreeSixtyCycle = {
    cycleName: '',
    status: null,
    company: null,
    cycleStartDate: null,
    cycleEndDate: null,

    eligibleQuery: {
      id: '',
    },
    ineligibleQuery: {
      id: '',
    },

    requestStartDate: null,
    requestEndDate: null,

    isPeerAppraisalApplicable: false, // -

    peerReviewInitiator: null,
    peerFeedbackType: null,
    minPeerFeedback: null,
    maxPeerFeedback: null,

    managerApprovalRequired: false,
    // requestApprovalStartDate: null,
    // requestApprovalEndDate: null,
    autoApproveAfterDays: '',
    employeeSeeRequest: false,
    // employeeSeeFeedbackDate: null,
    maintainAnonimityForPeer: false,
    isDraft: false,

    assessmentForms: [],
    defaultFormId: null,

    // add 1-march
    // isPeerFeedbackForManagerRequired: false,
    managerWorkflowId: null,

    feedbackStartDate: null,
    feedbackEndDate: null,
  };

  const initialThreeSixtyCycleError = {
    cycleName: {isError: false, errorMessage: ''},
    status: {isError: false, errorMessage: ''},
    cycleStartDate: {isError: false, errorMessage: ''},
    cycleEndDate: {isError: false, errorMessage: ''},

    eligibleQuery: {
      id: {isError: false, errorMessage: ''},
    },
    ineligibleQuery: {
      id: {isError: false, errorMessage: ''},
    },

    requestStartDate: {isError: false, errorMessage: ''},
    requestEndDate: {isError: false, errorMessage: ''},

    isPeerAppraisalApplicable: {isError: false, errorMessage: ''}, // ----

    peerReviewInitiator: {isError: false, errorMessage: ''},
    peerFeedbackType: {isError: false, errorMessage: ''},
    minPeerFeedback: {isError: false, errorMessage: ''},
    maxPeerFeedback: {isError: false, errorMessage: ''},

    managerApprovalRequired: {isError: false, errorMessage: ''},
    // requestApprovalStartDate: {isError: false, errorMessage: ''},
    // requestApprovalEndDate: {isError: false, errorMessage: ''},
    autoApproveAfterDays: {isError: false, errorMessage: ''},
    employeeSeeRequest: {isError: false, errorMessage: ''},
    // employeeSeeFeedbackDate: {isError: false, errorMessage: ''},
    maintainAnonimityForPeer: {isError: false, errorMessage: ''},

    isDraft: {isError: false, errorMessage: ''},

    assessmentForms: {isError: false, errorMessage: ''},
    defaultFormId: {isError: false, errorMessage: ''},
    // isPeerFeedbackForManagerRequired: {isError: false, errorMessage: ''},
    managerWorkflowId: {isError: false, errorMessage: ''},

    feedbackStartDate: {isError: false, errorMessage: ''},
    feedbackEndDate: {isError: false, errorMessage: ''},
  };

  const [threeSixtyCycle, setThreeSixtyCycle] = React.useState(
    initialThreeSixtyCycle,
  );
  const [threeSixtyCycleError, setThreeSixtyCycleError] = React.useState(
    initialThreeSixtyCycleError,
  );
  const [isLoading, setIsLoading] = React.useState(false);
  const [draftLoading, setDraftLoading] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [isEdit, setIsEdit] = React.useState(false);
  const [isReplica, setIsReplica] = React.useState(false);

  const [workflowList, setWorkflowList] = React.useState(null);
  const [queryList, setQueryList] = React.useState(null);

  const [refferedPeerFeedbackFormData, setRefferedPeerFeedbackFormData] =
    React.useState(null);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  React.useEffect(() => {
    if (!isEmptyNullUndefined(selectedCompany)) {
      getAllActiveQuery(selectedCompany?.id);
      getAllActiveWorkflows(selectedCompany?.id);
      getAllRefferedFormData(
        selectedCompany.id,
        setRefferedPeerFeedbackFormData,
        'PeerFeedBack',
      );
    }
    // return () => {
    //   source.cancel('Aborting all previous operations.');
    // };
  }, []);

  React.useEffect(() => {
    if (!isEmptyNullUndefined(id)) {
      getThreeSixtyCycleDetails(id);
      setIsEdit(true);
    }
    if (!isEmptyNullUndefined(replica)) {
      getThreeSixtyCycleDetails(replica);
      setIsReplica(true);
    }
    // return () => {
    //   source2.cancel('Aborting all previous operations.');
    // };
  }, []);

  const getAllActiveQuery = async (companyId) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.customquery}?companyId=${companyId}&relationTable=Employee&status=ACTIVE`,
        {
          cancelToken: source.token,
        },
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no record'));
          setQueryList([]);
        } else {
          setQueryList(res.data.reverse());
        }
      } else {
        setQueryList([]);
      }
    } catch (e) {
      if (!axios.isCancel(e)) {
        apiCatchErrorMessage(e, dispatch, fetchError);
      }
      setQueryList([]);
    }
  };

  const getAllActiveWorkflows = async (companyId) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.get_all_workflow}/${companyId}/ACTIVE`,
        {cancelToken: source.token},
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no workflow for selected company'));
          setWorkflowList([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setWorkflowList(reversed);
        }
      } else {
        setWorkflowList([]);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setWorkflowList([]);
    }
  };

  const getAllRefferedFormData = async (
    companyId,
    setRefferedFormData,
    formType,
  ) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.assessment_all_by_formfor_and_company_new(
          formType,
          companyId,
        )}`,
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(
            showInfo('You have no self appraisal form for selected company'),
          );
          setRefferedFormData([]);
        } else {
          setRefferedFormData(res.data);
        }
      } else {
        setRefferedFormData([]);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setRefferedFormData([]);
    }
  };

  const getThreeSixtyCycleDetails = async (id) => {
    setIsLoading(true);
    try {
      const response = await jwtAxios.get(
        `${API_ROUTS.threeSixtyCycle}/${id}`,
        {
          cancelToken: source2.token,
        },
      );
      if (response.status == 200) {
        if (replica) {
          let {id, cycleName, ...tempRes} = response.data;
          setThreeSixtyCycle(tempRes);
        } else {
          setThreeSixtyCycle(response.data);
        }

        setIsLoading(false);

        // if (response.data.isPeerAppraisalApplicable) {
        //   getAllRefferedFormData(
        //     selectedCompany.id,
        //     setRefferedPeerFeedbackFormData,
        //     'PeerFeedBack',
        //   );
        // }
      }
    } catch (e) {
      dispatch(fetchError(e.response?.data?.detail));
      setIsLoading(false);
    }
  };

  const dateValidation = (cycleStartDate, cycleEndDate) => {
    let isValid = true;
    if (new Date(cycleStartDate) > new Date(cycleEndDate)) {
      isValid = false;
    }

    return isValid;
  };

  const handleChangeThreeSixtyCycleData = (event, fieldType, name) => {
    const tempPmsCycle = structuredClone(threeSixtyCycle);

    const tempError = structuredClone(threeSixtyCycleError);

    if (fieldType == 'textfield' || fieldType == 'dropdown') {
      if (
        event.target.name === 'eligibleQuery' ||
        event.target.name === 'ineligibleQuery'
      ) {
        tempPmsCycle[event.target.name] = {id: event.target.value};
        tempError[event.target.name].id.isError = false;
        tempError[event.target.name].id.errorMessage = '';
      } else {
        tempPmsCycle[event.target.name] = event.target.value;
        tempError[event.target.name].isError = false;
        tempError[event.target.name].errorMessage = '';
      }
    } else if (fieldType == 'date') {
      tempPmsCycle[name] = event;
      tempError[name].isError = false;
      tempError[name].errorMessage = '';
    } else if (fieldType == 'multiselect') {
      const selectedItems = event.target.value;
      tempPmsCycle[event.target.name] = selectedItems;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
    } else if (fieldType == 'radio') {
      tempPmsCycle[event.target.name] = event.target.value;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';

      if (
        threeSixtyCycle.peerReviewInitiator != 'Manager' &&
        event.target.name == 'managerApprovalRequired' &&
        event.target.value === 'false'
      ) {
        tempPmsCycle.autoApproveAfterDays = null;
        tempError.autoApproveAfterDays.isError = false;
        tempError.autoApproveAfterDays.errorMessage = '';

        tempPmsCycle.managerWorkflowId = null;
        tempError.managerWorkflowId.isError = false;
        tempError.managerWorkflowId.errorMessage = '';
        // tempPmsCycle.requestApprovalStartDate = null;
        // tempError.requestApprovalStartDate.isError = false;
        // tempError.requestApprovalStartDate.errorMessage = '';
        // tempPmsCycle.requestApprovalEndDate = null;
        // tempError.managerWorkflowId.isError = false;
        // tempError.requestApprovalEndDate.errorMessage = '';
      }

      if (
        event.target.name === 'isPeerAppraisalApplicable' &&
        event.target.value === 'false'
      ) {
        tempPmsCycle.assessmentForms = [];
        // tempPmsCycle.isPeerFeedbackForManagerRequired = false;

        tempPmsCycle.peerFeedbackType = null;
        tempError.peerFeedbackType.isError = false;
        tempError.peerFeedbackType.errorMessage = '';

        tempPmsCycle.managerApprovalRequired = false;
        tempError.managerApprovalRequired.isError = false;
        tempError.managerApprovalRequired.errorMessage = '';

        tempPmsCycle.managerWorkflowId = null;
        tempError.managerWorkflowId.isError = false;
        tempError.managerWorkflowId.errorMessage = '';

        tempError.peerReviewInitiator.isError = null;
        tempError.peerReviewInitiator.errorMessage = '';
      }
    }
    setThreeSixtyCycle(tempPmsCycle);
    setThreeSixtyCycleError(tempError);
  };

  const validateThreeSixtyCycleData = () => {
    const tempError = {...threeSixtyCycleError};
    let isValid = true;
    const numberRegex = /^\d+$/;

    if (isEmptyNullUndefined(threeSixtyCycle.cycleName)) {
      tempError.cycleName.isError = true;
      tempError.cycleName.errorMessage = 'Please enter 360° cycle name';
      isValid = false;
    }

    if (isEmptyNullUndefined(threeSixtyCycle.status)) {
      tempError.status.isError = true;
      tempError.status.errorMessage = 'Please select status';
      isValid = false;
    }

    //----------------------- 360 cycle period validation------------------------------------------
    if (isEmptyNullUndefined(threeSixtyCycle.cycleStartDate)) {
      tempError.cycleStartDate.isError = true;
      tempError.cycleStartDate.errorMessage = 'Please enter start date';
      isValid = false;
    }

    if (isEmptyNullUndefined(threeSixtyCycle.cycleEndDate)) {
      tempError.cycleEndDate.isError = true;
      tempError.cycleEndDate.errorMessage = 'Please enter end date';
      isValid = false;
    }

    if (
      !dateValidation(
        threeSixtyCycle.cycleStartDate,
        threeSixtyCycle.cycleEndDate,
      )
    ) {
      tempError.cycleEndDate.isError = true;
      tempError.cycleEndDate.errorMessage =
        'End date should be greater than start date';
      isValid = false;
    }

    //----------------------- nominatin period validation------------------------------------------
    if (isEmptyNullUndefined(threeSixtyCycle.requestStartDate)) {
      tempError.requestStartDate.isError = true;
      tempError.requestStartDate.errorMessage = 'Please enter start date';
      isValid = false;
    } else if (
      new Date(threeSixtyCycle.requestStartDate) <
      new Date(threeSixtyCycle.cycleStartDate)
    ) {
      tempError.requestStartDate.isError = true;
      tempError.requestStartDate.errorMessage =
        'Selected date should be greater than cycle start date';
      isValid = false;
    }

    if (isEmptyNullUndefined(threeSixtyCycle.requestEndDate)) {
      tempError.requestEndDate.isError = true;
      tempError.requestEndDate.errorMessage = 'Please enter end date';
      isValid = false;
    } else if (
      new Date(threeSixtyCycle.requestEndDate) >
      new Date(threeSixtyCycle.cycleEndDate)
    ) {
      tempError.requestEndDate.isError = true;
      tempError.requestEndDate.errorMessage =
        'Selected date should be less than cycle end date';
      isValid = false;
    }

    if (
      !dateValidation(
        threeSixtyCycle.requestStartDate,
        threeSixtyCycle.requestEndDate,
      )
    ) {
      tempError.requestEndDate.isError = true;
      tempError.requestEndDate.errorMessage =
        'End date should be greater than start date';
      isValid = false;
    }

    if (isEmptyNullUndefined(threeSixtyCycle?.eligibleQuery?.id)) {
      tempError.eligibleQuery.id.isError = true;
      tempError.eligibleQuery.id.errorMessage = 'Please select eligible query';
      isValid = false;
    }

    if (isEmptyNullUndefined(threeSixtyCycle.assessmentForms)) {
      tempError.assessmentForms.isError = true;
      tempError.assessmentForms.errorMessage = 'Please select forms';
      isValid = false;
    }

    if (
      !isEmptyNullUndefined(threeSixtyCycle.assessmentForms) &&
      isEmptyNullUndefined(threeSixtyCycle.defaultFormId)
    ) {
      tempError.defaultFormId.isError = true;
      tempError.defaultFormId.errorMessage =
        'Please select default peer feedback form.';
      isValid = false;
    }

    if (isEmptyNullUndefined(threeSixtyCycle.peerFeedbackType)) {
      tempError.peerFeedbackType.isError = true;
      tempError.peerFeedbackType.errorMessage =
        'Please select peer feedback type';
      isValid = false;
    }

    //  if peerFeedbackType == 'Solicited' validation
    if (threeSixtyCycle.peerFeedbackType == 'Solicited') {
      if (isEmptyNullUndefined(threeSixtyCycle.peerReviewInitiator)) {
        tempError.peerReviewInitiator.isError = true;
        tempError.peerReviewInitiator.errorMessage =
          'Please select peer review initiator';
        isValid = false;
      }

      if (isEmptyNullUndefined(threeSixtyCycle.minPeerFeedback)) {
        tempError.minPeerFeedback.isError = true;
        tempError.minPeerFeedback.errorMessage =
          'Please enter minimum peer feedback';
        isValid = false;
      }

      if (isEmptyNullUndefined(threeSixtyCycle.maxPeerFeedback)) {
        tempError.maxPeerFeedback.isError = true;
        tempError.maxPeerFeedback.errorMessage =
          'Please enter maximum peer feedback';
        isValid = false;
      }

      if (!numberRegex.test(threeSixtyCycle.minPeerFeedback)) {
        tempError.minPeerFeedback.isError = true;
        tempError.minPeerFeedback.errorMessage = 'Please enter numeric value';
        isValid = false;
      }

      if (!numberRegex.test(threeSixtyCycle.maxPeerFeedback)) {
        tempError.maxPeerFeedback.isError = true;
        tempError.maxPeerFeedback.errorMessage = 'Please enter numeric value';
        isValid = false;
      }
    }

    if (
      threeSixtyCycle.managerApprovalRequired == 'true' ||
      threeSixtyCycle.managerApprovalRequired == true
    ) {
      if (
        threeSixtyCycle.peerFeedbackType == 'Solicited' &&
        isEmptyNullUndefined(threeSixtyCycle.autoApproveAfterDays)
      ) {
        tempError.autoApproveAfterDays.isError = true;
        tempError.autoApproveAfterDays.errorMessage =
          'Please enter auto approve after how many days';
        isValid = false;
      }
      if (
        !isEmptyNullUndefined(threeSixtyCycle.autoApproveAfterDays) &&
        !numberRegex.test(threeSixtyCycle.autoApproveAfterDays)
      ) {
        tempError.autoApproveAfterDays.isError = true;
        tempError.autoApproveAfterDays.errorMessage =
          'Please enter numeric value';
        isValid = false;
      }

      if (isEmptyNullUndefined(threeSixtyCycle.managerWorkflowId)) {
        tempError.managerWorkflowId.isError = true;
        tempError.managerWorkflowId.errorMessage = 'Please select workflow';
        isValid = false;
      }
    }

    if (isEmptyNullUndefined(threeSixtyCycle.feedbackStartDate)) {
      tempError.feedbackStartDate.isError = true;
      tempError.feedbackStartDate.errorMessage = 'Please enter start date';
      isValid = false;
    } else if (
      new Date(threeSixtyCycle.feedbackStartDate) <
      new Date(threeSixtyCycle.cycleStartDate)
    ) {
      tempError.feedbackStartDate.isError = true;
      tempError.feedbackStartDate.errorMessage =
        'Selected date should be greater than cycle start date';
      isValid = false;
    }

    if (isEmptyNullUndefined(threeSixtyCycle.feedbackEndDate)) {
      tempError.feedbackEndDate.isError = true;
      tempError.feedbackEndDate.errorMessage = 'Please enter end date';
      isValid = false;
    } else if (
      new Date(threeSixtyCycle.feedbackEndDate) >
      new Date(threeSixtyCycle.cycleEndDate)
    ) {
      tempError.feedbackEndDate.isError = true;
      tempError.feedbackEndDate.errorMessage =
        'Selected date should be less than cycle end date';
      isValid = false;
    }

    if (
      !dateValidation(
        threeSixtyCycle.feedbackStartDate,
        threeSixtyCycle.feedbackEndDate,
      )
    ) {
      tempError.feedbackEndDate.isError = true;
      tempError.feedbackEndDate.errorMessage =
        'End date should be greater than start date';
      isValid = false;
    }

    if (
      !dateValidation(
        threeSixtyCycle.feedbackStartDate,
        threeSixtyCycle.feedbackEndDate,
      )
    ) {
      tempError.feedbackEndDate.isError = true;
      tempError.feedbackEndDate.errorMessage =
        'End date should be greater than start date';
      isValid = false;
    }

    // if (isEmptyNullUndefined(threeSixtyCycle.employeeSeeFeedbackDate)) {
    //   tempError.employeeSeeFeedbackDate.isError = true;
    //   tempError.employeeSeeFeedbackDate.errorMessage =
    //     'Please enter when employee see feedback';
    //   isValid = false;
    // }

    if (isValid) {
      if (!isEdit) {
        submitThreeSixtyCycleData();
      } else {
        updateThreeSixtyCycleData();
      }
    } else {
      setThreeSixtyCycleError(tempError);
    }
  };

  const submitThreeSixtyCycleData = async () => {
    let tempPmsCycle = {
      ...threeSixtyCycle,
      status:
        threeSixtyCycle.status == 'Draft' ? 'ACTIVE' : threeSixtyCycle.status,
      assessmentForms: threeSixtyCycle.assessmentForms.map((item) => ({
        id: item.id,
      })),
      eligibleQuery: threeSixtyCycle.eligibleQuery?.id
        ? {id: threeSixtyCycle.eligibleQuery.id}
        : null,
      ineligibleQuery: threeSixtyCycle.ineligibleQuery?.id
        ? {id: threeSixtyCycle.ineligibleQuery.id}
        : null,
      company: {id: selectedCompany?.id},
    };
    const submit = async () => {
      setLoading(true);
      try {
        const response = await jwtAxios.post(
          `${API_ROUTS.threeSixtyCycle}`,
          tempPmsCycle,
        );
        if (response.status == 201) {
          dispatch(showMessage('360° cycle added successfully..!'));
          Router.push('/company-builder/three-sixty-cycle');
        } else {
          setLoading(false);
        }
      } catch (error) {
        apiCatchErrorMessage(error, dispatch, fetchError);
        setLoading(false);
      }
    };
    await submit();
  };

  const updateThreeSixtyCycleData = async () => {
    let tempPmsCycle = {
      ...threeSixtyCycle,
      status:
        threeSixtyCycle.status == 'Draft' ? 'ACTIVE' : threeSixtyCycle.status,
      id: id,
    };

    const update = async () => {
      setLoading(true);
      try {
        const response = await jwtAxios.put(
          `${API_ROUTS.threeSixtyCycle}/${id}`,
          tempPmsCycle,
        );
        if (response.status == 200) {
          dispatch(showMessage('360° Cycle updated successfully..!'));
          Router.push('/company-builder/three-sixty-cycle');
        } else {
          setLoading(false);
        }
      } catch (error) {
        apiCatchErrorMessage(error, dispatch, fetchError);
        setLoading(false);
      }
    };
    await update();
  };
  const validateThreeSixtyCycleDataDraft = () => {
    const tempError = {...threeSixtyCycleError};
    let isValid = true;

    if (isEmptyNullUndefined(threeSixtyCycle.cycleName)) {
      tempError.cycleName.isError = true;
      tempError.cycleName.errorMessage = 'Please enter 360° cycle name';
      isValid = false;
    }

    if (isValid) {
      if (!isEdit) {
        submitThreeSixtyCycleDataDraft();
      } else {
        updateThreeSixtyCycleDataDraft();
      }
    } else {
      setThreeSixtyCycleError(tempError);
    }
  };

  const submitThreeSixtyCycleDataDraft = async () => {
    let tempPmsCycle = {
      ...threeSixtyCycle,
      status: 'Draft',
      assessmentForms: threeSixtyCycle.assessmentForms.map((item) => ({
        id: item.id,
      })),
      company: {id: selectedCompany?.id},
    };
    const submit = async () => {
      setDraftLoading(true);
      try {
        const response = await jwtAxios.post(
          `${API_ROUTS.threeSixtyCycle}`,
          tempPmsCycle,
        );
        if (response.status == 201) {
          dispatch(showMessage('360° cycle added as a draft successfully..!'));
          Router.push('/company-builder/three-sixty-cycle');
        } else {
          setDraftLoading(false);
        }
      } catch (error) {
        apiCatchErrorMessage(error, dispatch, fetchError);
        setDraftLoading(false);
      }
    };
    await submit();
  };

  const updateThreeSixtyCycleDataDraft = async () => {
    let tempPmsCycle = {
      ...threeSixtyCycle,
      id: id,
      status: 'Draft',
      assessmentForms: threeSixtyCycle.assessmentForms.map((item) => ({
        id: item.id,
      })),
    };

    const update = async () => {
      setDraftLoading(true);
      try {
        const response = await jwtAxios.put(
          `${API_ROUTS.threeSixtyCycle}/${id}`,
          tempPmsCycle,
        );
        if (response.status == 200) {
          dispatch(
            showMessage('360° Cycle updated as a draft successfully..!'),
          );
          Router.push('/company-builder/three-sixty-cycle');
        } else {
          setDraftLoading(false);
        }
      } catch (error) {
        apiCatchErrorMessage(error, dispatch, fetchError);
        setDraftLoading(false);
      }
    };
    await update();
  };

  const getSelectedForms = (selectedForms) => {
    const selectedFormIds = selectedForms.map((form) => form.id);
    return refferedPeerFeedbackFormData?.filter((item) =>
      selectedFormIds.includes(item.id),
    );
  };

  const getValueById = (queryList, id) => {
    if (!isEmptyNullUndefined(queryList) && !isEmptyNullUndefined(id)) {
      let index = queryList.findIndex((element) => element.id === id);
      if (index !== -1) {
        return queryList[index].query;
      } else {
        return null; // Return null if the object with the given id is not found
      }
    }
  };

  console.log('threeSixtyCycle', threeSixtyCycle);
  console.log('threeSixtyCycleError', threeSixtyCycleError);

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        {!isEdit ? (
          <h3>
            <IntlMessages id='threeSixtyCycle.AddThreeSixtyCycle' />
          </h3>
        ) : (
          <h3>
            <IntlMessages id='threeSixtyCycle.EditThreeSixtyCycle' />
          </h3>
        )}
      </h2>

      <AppCard>
        <Stack sx={{mb: 10}}>
          <Stack>{domCreactionHeaderTitle('Basic Info')}</Stack>
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>Cycle name :</Stack>
            </Stack>

            {isLoading ? (
              domCreactionGridSkeletonLoader('70px')
            ) : (
              <Stack direction={'row'} sx={{width: '50%'}}>
                <TextField
                  size='small'
                  name='cycleName'
                  label={'Cycle name'}
                  onChange={(event) =>
                    handleChangeThreeSixtyCycleData(event, 'textfield')
                  }
                  variant='outlined'
                  error={threeSixtyCycleError.cycleName.isError}
                  helperText={threeSixtyCycleError.cycleName.errorMessage}
                  value={
                    threeSixtyCycle.cycleName ? threeSixtyCycle.cycleName : ''
                  }
                  sx={{
                    ...textFieldStyled,
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                    },
                  }}
                />
              </Stack>
            )}
          </Stack>
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>
                {' '}
                <IntlMessages id='configuration.dialogbox.Status' /> :{' '}
              </Stack>
            </Stack>
            {isLoading ? (
              domCreactionGridSkeletonLoader('70px')
            ) : (
              <Stack direction={'row'} sx={{width: '50%'}}>
                <FormControl
                  sx={{
                    ...textFieldStyled,
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                    },
                  }}
                >
                  <InputLabel size='small' id='status'>
                    <IntlMessages id='configuration.dialogbox.Status' />
                  </InputLabel>
                  <Select
                    size='small'
                    name='status'
                    label='Status'
                    labelId='status'
                    value={threeSixtyCycle?.status || ''}
                    error={threeSixtyCycleError.status?.isError}
                    helperText={threeSixtyCycleError.status?.errorMessage}
                    onChange={(event) =>
                      handleChangeThreeSixtyCycleData(event, 'dropdown')
                    }
                    variant='outlined'
                    sx={{...textFieldStyled, width: '100%'}}
                  >
                    <MenuItem key='Active' value='ACTIVE'>
                      <IntlMessages id='configuration.dialogbox.Status.Active' />
                    </MenuItem>
                    <MenuItem key='Inactive' value='INACTIVE'>
                      <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                    </MenuItem>
                    <MenuItem disabled key='Draft' value='Draft'>
                      Draft
                    </MenuItem>
                  </Select>
                  <FormHelperText style={{color: '#d32f2f'}}>
                    {threeSixtyCycleError.status.errorMessage}
                  </FormHelperText>
                </FormControl>
              </Stack>
            )}
          </Stack>
          {/* -----------------------360 cycle Period--------------------------------- */}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>360° Cycle Period :</Stack>
            </Stack>
            {isLoading ? (
              domCreactionGridSkeletonLoader('70px')
            ) : (
              <Stack direction={'row'} sx={{width: '50%'}}>
                <Stack direction={'column'} sx={{width: '42%'}}>
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DesktopDatePicker
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          '& fieldset': {
                            borderLeftColor: 'red',
                            borderLeftWidth: 3,
                          },
                          height: '40px',
                          width: '180px',
                        },
                      }}
                      minDate={new Date()}
                      format={getCompanyDateFormatForInputs(selectedCompany)}
                      size='small'
                      // value={new Date(threeSixtyCycle.cycleStartDate)}
                      value={
                        !isEmptyNullUndefined(threeSixtyCycle.cycleStartDate)
                          ? new Date(threeSixtyCycle.cycleStartDate)
                          : null
                      }
                      label={'Start Date'}
                      name='cycleStartDate'
                      onChange={(event) =>
                        handleChangeThreeSixtyCycleData(
                          event,
                          'date',
                          'cycleStartDate',
                        )
                      }
                    />
                  </LocalizationProvider>
                  {threeSixtyCycleError.cycleStartDate?.isError && (
                    <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                      {threeSixtyCycleError.cycleStartDate?.errorMessage}
                    </FormHelperText>
                  )}
                </Stack>

                <Stack direction={'column'} sx={{width: '42%'}}>
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DesktopDatePicker
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          '& fieldset': {
                            borderLeftColor: 'red',
                            borderLeftWidth: 3,
                          },
                          height: '40px',
                          width: '180px',
                        },
                      }}
                      minDate={new Date()}
                      format={getCompanyDateFormatForInputs(selectedCompany)}
                      size='small'
                      // value={new Date(threeSixtyCycle.cycleEndDate)}
                      value={
                        !isEmptyNullUndefined(threeSixtyCycle.cycleEndDate)
                          ? new Date(threeSixtyCycle.cycleEndDate)
                          : null
                      }
                      label={'End Date'}
                      name='cycleEndDate'
                      onChange={(event) =>
                        handleChangeThreeSixtyCycleData(
                          event,
                          'date',
                          'cycleEndDate',
                        )
                      }
                    />
                  </LocalizationProvider>
                  {threeSixtyCycleError.cycleEndDate?.isError && (
                    <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                      {threeSixtyCycleError.cycleEndDate?.errorMessage}
                    </FormHelperText>
                  )}
                </Stack>
              </Stack>
            )}
          </Stack>
          {/* -----------------------Nomination Period--------------------------------- */}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>Nomination Period :</Stack>
            </Stack>
            {isLoading ? (
              domCreactionGridSkeletonLoader('70px')
            ) : (
              <Stack direction={'row'} sx={{width: '50%'}}>
                <Stack direction={'column'} sx={{width: '42%'}}>
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DesktopDatePicker
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          '& fieldset': {
                            borderLeftColor: 'red',
                            borderLeftWidth: 3,
                          },
                          height: '40px',
                          width: '180px',
                        },
                      }}
                      minDate={new Date()}
                      format={getCompanyDateFormatForInputs(selectedCompany)}
                      size='small'
                      // value={new Date(threeSixtyCycle.requestStartDate)}
                      value={
                        !isEmptyNullUndefined(threeSixtyCycle.requestStartDate)
                          ? new Date(threeSixtyCycle.requestStartDate)
                          : null
                      }
                      label={'Start Date'}
                      name='requestStartDate'
                      onChange={(event) =>
                        handleChangeThreeSixtyCycleData(
                          event,
                          'date',
                          'requestStartDate',
                        )
                      }
                    />
                  </LocalizationProvider>
                  {threeSixtyCycleError.requestStartDate?.isError && (
                    <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                      {threeSixtyCycleError.requestStartDate?.errorMessage}
                    </FormHelperText>
                  )}
                </Stack>

                <Stack direction={'column'} sx={{width: '42%'}}>
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DesktopDatePicker
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          '& fieldset': {
                            borderLeftColor: 'red',
                            borderLeftWidth: 3,
                          },
                          height: '40px',
                          width: '180px',
                        },
                      }}
                      minDate={new Date()}
                      format={getCompanyDateFormatForInputs(selectedCompany)}
                      size='small'
                      // value={new Date(threeSixtyCycle.requestEndDate)}
                      value={
                        !isEmptyNullUndefined(threeSixtyCycle.requestEndDate)
                          ? new Date(threeSixtyCycle.requestEndDate)
                          : null
                      }
                      label={'End Date'}
                      name='requestEndDate'
                      onChange={(event) =>
                        handleChangeThreeSixtyCycleData(
                          event,
                          'date',
                          'requestEndDate',
                        )
                      }
                      renderInput={(params) => (
                        <TextField
                          id='requestEndDate-textField'
                          variant='outlined'
                          size='small'
                          sx={{
                            ...textFieldStyled,
                            '& .MuiOutlinedInput-root': {
                              '& fieldset': {
                                borderLeftColor: 'red',
                                borderLeftWidth: 3,
                              },
                            },
                          }}
                          {...params}
                        />
                      )}
                    />
                  </LocalizationProvider>
                  {threeSixtyCycleError.requestEndDate?.isError && (
                    <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                      {threeSixtyCycleError.requestEndDate?.errorMessage}
                    </FormHelperText>
                  )}
                </Stack>
              </Stack>
            )}
          </Stack>

          {/* -------------------------------------------------------------------------------------- */}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>Eligible Employee</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '50%'}}>
              <GenericSelectWithSearch
                label={'Select query'}
                name={'eligibleQuery'}
                value={threeSixtyCycle.eligibleQuery?.id || ''}
                error={threeSixtyCycleError.eligibleQuery.id.isError}
                helperText={threeSixtyCycleError.eligibleQuery.id.errorMessage}
                handleChange={handleChangeThreeSixtyCycleData}
                optionList={queryList}
                labelName={'variableName'}
                customStyles={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                  width: '195px',
                }}
              />

              {threeSixtyCycle.eligibleQuery?.id && (
                <FormControl
                  sx={{ml: 5, mb: 2, width: '50%', minWidth: '10rem'}}
                >
                  <TextField
                    disabled
                    size='small'
                    value={getValueById(
                      queryList,
                      threeSixtyCycle.eligibleQuery?.id,
                    )}
                    id='outlined-basic'
                    variant='outlined'
                    multiline
                    rows={2}
                  />
                </FormControl>
              )}
              <Stack sx={{justifyContent: 'center', marginLeft: '1rem'}}>
                <Tooltip title=' Create query from query builder under company settings > setup company variable module'>
                  <IconButton>
                    <InfoIcon />
                  </IconButton>
                </Tooltip>
              </Stack>
            </Stack>
          </Stack>
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>Ineligible Employee</Stack>
            </Stack>

            <Stack direction={'row'} sx={{width: '50%'}}>
              <GenericSelectWithSearch
                label={'Select query'}
                name={'ineligibleQuery'}
                value={threeSixtyCycle.ineligibleQuery?.id || ''}
                error={threeSixtyCycleError.ineligibleQuery.id.isError}
                helperText={
                  threeSixtyCycleError.ineligibleQuery.id.errorMessage
                }
                handleChange={handleChangeThreeSixtyCycleData}
                optionList={queryList}
                labelName={'variableName'}
                customStyles={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'grey',
                      borderLeftWidth: 3,
                    },
                  },
                  width: '195px',
                }}
              />

              {threeSixtyCycle.ineligibleQuery?.id && (
                <FormControl
                  sx={{ml: 5, mb: 2, width: '50%', minWidth: '10rem'}}
                >
                  <TextField
                    disabled
                    size='small'
                    value={getValueById(
                      queryList,
                      threeSixtyCycle.ineligibleQuery?.id,
                    )}
                    id='outlined-basic'
                    variant='outlined'
                    multiline
                    rows={2}
                  />
                </FormControl>
              )}
              <Stack sx={{justifyContent: 'center', marginLeft: '1rem'}}>
                <Tooltip title=' Create query from query builder under company settings > setup company variable module'>
                  <IconButton>
                    <InfoIcon />
                  </IconButton>
                </Tooltip>
              </Stack>
            </Stack>
          </Stack>

          {/* -------------------------------------------------------------------------------------- */}
          <Stack sx={{mt: 5, mb: 3}}>
            {domCreactionHeaderTitle('Other Info')}
          </Stack>

          <>
            <Stack
              id='addEnrollmentStack'
              direction='row'
              sx={{mt: 5, ml: 3}}
              justifyContent='space-between'
              alignItems='flex-start'
              spacing={2}
            >
              <Stack sx={{width: '50%'}}>
                <Stack fontWeight={500}>Select Peer feedback forms : </Stack>
              </Stack>
              {isLoading ? (
                domCreactionGridSkeletonLoader('70px')
              ) : (
                <Stack direction={'row'} sx={{width: '50%'}}>
                  <FormControl
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'red',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  >
                    <InputLabel size='small' id='label_form_For'>
                      Peer feedback form
                    </InputLabel>
                    <Select
                      name='assessmentForms'
                      labelId='label_form_For'
                      label='Peer feedback form'
                      onChange={(event) =>
                        handleChangeThreeSixtyCycleData(event, 'multiselect')
                      }
                      multiple
                      value={
                        getSelectedForms(threeSixtyCycle.assessmentForms) || []
                      }
                      variant='outlined'
                      size='small'
                    >
                      {refferedPeerFeedbackFormData?.map((element) => {
                        return (
                          <MenuItem key={element.id} value={element}>
                            {element.displayName}
                          </MenuItem>
                        );
                      })}
                    </Select>

                    {threeSixtyCycleError.assessmentForms?.isError && (
                      <FormHelperText style={{color: '#d32f2f'}}>
                        {threeSixtyCycleError.assessmentForms?.errorMessage}
                      </FormHelperText>
                    )}
                  </FormControl>
                </Stack>
              )}
            </Stack>
            {!isEmptyNullUndefined(threeSixtyCycle.assessmentForms) && (
              <Stack
                id='addEnrollmentStack'
                direction='row'
                sx={{mt: 5, ml: 3}}
                justifyContent='space-between'
                alignItems='flex-start'
                spacing={2}
              >
                <Stack sx={{width: '50%'}}>
                  <Stack fontWeight={500}>
                    Select default peer feedback form :{' '}
                  </Stack>
                </Stack>
                {isLoading ? (
                  domCreactionGridSkeletonLoader('70px')
                ) : (
                  <Stack direction={'row'} sx={{width: '50%'}}>
                    <FormControl
                      sx={{
                        ...textFieldStyled,
                        '& .MuiOutlinedInput-root': {
                          '& fieldset': {
                            borderLeftColor: 'red',
                            borderLeftWidth: 3,
                          },
                        },
                      }}
                    >
                      <InputLabel size='small' id='defaultFormId'>
                        Default Form
                      </InputLabel>
                      <Select
                        name='defaultFormId'
                        labelId='defaultFormId'
                        label='Default Form'
                        onChange={(event) =>
                          handleChangeThreeSixtyCycleData(event, 'dropdown')
                        }
                        value={threeSixtyCycle.defaultFormId}
                        variant='outlined'
                        size='small'
                      >
                        {getSelectedForms(threeSixtyCycle.assessmentForms)?.map(
                          (element) => {
                            return (
                              <MenuItem key={element.id} value={element.id}>
                                {element.displayName}
                              </MenuItem>
                            );
                          },
                        )}
                      </Select>

                      {threeSixtyCycleError.defaultFormId?.isError && (
                        <FormHelperText style={{color: '#d32f2f'}}>
                          {threeSixtyCycleError.defaultFormId?.errorMessage}
                        </FormHelperText>
                      )}
                    </FormControl>
                  </Stack>
                )}
              </Stack>
            )}

            <Stack
              id='addEnrollmentStack'
              direction='row'
              sx={{mt: 5, ml: 3}}
              justifyContent='space-between'
              alignItems='flex-start'
              spacing={2}
            >
              <Stack sx={{width: '50%'}}>
                <Stack fontWeight={500}>
                  Who can initiate peer review request ?
                </Stack>
              </Stack>
              {isLoading ? (
                domCreactionGridSkeletonLoader('70px')
              ) : (
                <Stack direction={'row'} sx={{width: '50%'}}>
                  <FormControl
                    sx={{
                      ...textFieldStyled,
                      '& .MuiOutlinedInput-root': {
                        '& fieldset': {
                          borderLeftColor: 'red',
                          borderLeftWidth: 3,
                        },
                      },
                    }}
                  >
                    <InputLabel size='small' id='peerFeedbackType'>
                      Select Type
                    </InputLabel>
                    <Select
                      size='small'
                      name='peerFeedbackType'
                      label='Select Type'
                      labelId='peerFeedbackType'
                      value={threeSixtyCycle?.peerFeedbackType || ''}
                      error={threeSixtyCycleError.peerFeedbackType?.isError}
                      helperText={
                        threeSixtyCycleError.peerFeedbackType?.errorMessage
                      }
                      onChange={(event) =>
                        handleChangeThreeSixtyCycleData(event, 'dropdown')
                      }
                      variant='outlined'
                      sx={{...textFieldStyled, width: '100%'}}
                    >
                      <MenuItem key='Unsolicited' value='Unsolicited'>
                        Unsolicited
                      </MenuItem>
                      <MenuItem key='Solicited' value='Solicited'>
                        Solicited
                      </MenuItem>
                    </Select>
                    <FormHelperText style={{color: '#d32f2f'}}>
                      {threeSixtyCycleError.peerFeedbackType?.errorMessage}
                    </FormHelperText>
                  </FormControl>
                </Stack>
              )}
            </Stack>
            {threeSixtyCycle?.peerFeedbackType == 'Solicited' && (
              <>
                <Stack
                  id='addEnrollmentStack'
                  direction='row'
                  sx={{mt: 5, ml: 3}}
                  justifyContent='space-between'
                  alignItems='flex-start'
                  spacing={2}
                >
                  <Stack sx={{width: '50%'}}>
                    <Stack fontWeight={500}> Define initiator :</Stack>
                  </Stack>
                  {isLoading ? (
                    domCreactionGridSkeletonLoader('70px')
                  ) : (
                    <Stack direction={'row'} sx={{width: '50%'}}>
                      <FormControl
                        sx={{
                          ...textFieldStyled,
                          '& .MuiOutlinedInput-root': {
                            '& fieldset': {
                              borderLeftColor: 'red',
                              borderLeftWidth: 3,
                            },
                          },
                        }}
                      >
                        <InputLabel size='small' id='peerReviewInitiator'>
                          Select Initiator
                        </InputLabel>
                        <Select
                          size='small'
                          name='peerReviewInitiator'
                          label='Select Initiator'
                          labelId='peerReviewInitiator'
                          value={threeSixtyCycle?.peerReviewInitiator || ''}
                          error={
                            threeSixtyCycleError.peerReviewInitiator?.isError
                          }
                          helperText={
                            threeSixtyCycleError.peerReviewInitiator
                              ?.errorMessage
                          }
                          onChange={(event) =>
                            handleChangeThreeSixtyCycleData(event, 'dropdown')
                          }
                          variant='outlined'
                          sx={{...textFieldStyled, width: '100%'}}
                        >
                          <MenuItem key='Manager' value='Manager'>
                            Manager
                          </MenuItem>
                          <MenuItem key='Employee' value='Employee'>
                            Employee
                          </MenuItem>
                          <MenuItem key='Both' value='Both'>
                            Both
                          </MenuItem>
                        </Select>
                        <FormHelperText style={{color: '#d32f2f'}}>
                          {
                            threeSixtyCycleError.peerReviewInitiator
                              ?.errorMessage
                          }
                        </FormHelperText>
                      </FormControl>
                    </Stack>
                  )}
                </Stack>
                {threeSixtyCycle.peerReviewInitiator != 'Manager' ? (
                  <>
                    <Stack
                      id='addEnrollmentStack'
                      direction='row'
                      sx={{mt: 5, ml: 3}}
                      justifyContent='space-between'
                      alignItems='flex-start'
                      spacing={2}
                    >
                      <Stack sx={{width: '50%'}}>
                        <Stack fontWeight={500}>
                          Manager approval required ?
                        </Stack>
                      </Stack>
                      {isLoading ? (
                        domCreactionGridSkeletonLoader('70px')
                      ) : (
                        <Stack direction={'row'} sx={{width: '50%'}}>
                          <RadioGroup
                            value={threeSixtyCycle.managerApprovalRequired}
                            row
                            aria-labelledby='demo-row-radio-buttons-group-label'
                            name='managerApprovalRequired'
                            onChange={(event) =>
                              handleChangeThreeSixtyCycleData(event, 'radio')
                            }
                          >
                            <FormControlLabel
                              value={true}
                              control={<Radio />}
                              label={<IntlMessages id='common.button.Yes' />}
                            />
                            <FormControlLabel
                              value={false}
                              control={<Radio />}
                              label={<IntlMessages id='common.button.No' />}
                            />
                          </RadioGroup>
                        </Stack>
                      )}
                    </Stack>
                    {threeSixtyCycle.managerApprovalRequired == 'true' ||
                    threeSixtyCycle.managerApprovalRequired == true ? (
                      <>
                        {/* -----------------------Manager approval Period--------------------------------- */}
                        {/* <Stack
                          id='addEnrollmentStack'
                          direction='row'
                          sx={{mt: 5, ml: 3}}
                          justifyContent='space-between'
                          alignItems='flex-start'
                          spacing={2}
                        >
                          <Stack sx={{width: '50%'}}>
                            <Stack fontWeight={500}>
                              Manager approval period :
                            </Stack>
                          </Stack>
                          {isLoading ? (
                            domCreactionGridSkeletonLoader('70px')
                          ) : (
                            <Stack direction={'row'} sx={{width: '50%'}}>
                              <Stack direction={'column'} sx={{width: '42%'}}>
                                <LocalizationProvider
                                  dateAdapter={AdapterDateFns}
                                >
                                  <DesktopDatePicker
                                    sx={{
                                      '& .MuiOutlinedInput-root': {
                                        '& fieldset': {
                                          borderLeftColor: 'red',
                                          borderLeftWidth: 3,
                                        },
                                        height: '40px',
                                        width: '180px',
                                      },
                                    }}
                                    minDate={new Date()}
                                    format={getCompanyDateFormatForInputs(
                                      selectedCompany,
                                    )}
                                    size='small'
                                    value={
                                      !isEmptyNullUndefined(
                                        threeSixtyCycle.requestApprovalStartDate,
                                      )
                                        ? new Date(
                                            threeSixtyCycle.requestApprovalStartDate,
                                          )
                                        : null
                                    }
                                    label={'Start Date'}
                                    name='requestApprovalStartDate'
                                    onChange={(event) =>
                                      handleChangeThreeSixtyCycleData(
                                        event,
                                        'date',
                                        'requestApprovalStartDate',
                                      )
                                    }
                                  />
                                </LocalizationProvider>
                                {threeSixtyCycleError.requestApprovalStartDate
                                  ?.isError && (
                                  <FormHelperText
                                    sx={{color: '#d32f2f', mt: -2}}
                                  >
                                    {
                                      threeSixtyCycleError
                                        .requestApprovalStartDate?.errorMessage
                                    }
                                  </FormHelperText>
                                )}
                              </Stack>

                              <Stack direction={'column'} sx={{width: '42%'}}>
                                <LocalizationProvider
                                  dateAdapter={AdapterDateFns}
                                >
                                  <DesktopDatePicker
                                    sx={{
                                      '& .MuiOutlinedInput-root': {
                                        '& fieldset': {
                                          borderLeftColor: 'red',
                                          borderLeftWidth: 3,
                                        },
                                        height: '40px',
                                        width: '180px',
                                      },
                                    }}
                                    minDate={new Date()}
                                    format={getCompanyDateFormatForInputs(
                                      selectedCompany,
                                    )}
                                    size='small'
                                    value={
                                      !isEmptyNullUndefined(
                                        threeSixtyCycle.requestApprovalEndDate,
                                      )
                                        ? new Date(
                                            threeSixtyCycle.requestApprovalEndDate,
                                          )
                                        : null
                                    }
                                    label={'End Date'}
                                    name='requestApprovalEndDate'
                                    onChange={(event) =>
                                      handleChangeThreeSixtyCycleData(
                                        event,
                                        'date',
                                        'requestApprovalEndDate',
                                      )
                                    }
                                  />
                                </LocalizationProvider>
                                {threeSixtyCycleError.requestApprovalEndDate
                                  ?.isError && (
                                  <FormHelperText
                                    sx={{color: '#d32f2f', mt: -2}}
                                  >
                                    {
                                      threeSixtyCycleError
                                        .requestApprovalEndDate?.errorMessage
                                    }
                                  </FormHelperText>
                                )}
                              </Stack>
                            </Stack>
                          )}
                        </Stack> */}
                        {/* ------------Manager approval workflow------------------------ */}

                        <Stack
                          id='addEnrollmentStack'
                          direction='row'
                          sx={{mt: 5, ml: 3}}
                          justifyContent='space-between'
                          alignItems='flex-start'
                          spacing={2}
                        >
                          <Stack sx={{width: '50%'}}>
                            <Stack fontWeight={500}>
                              After how many days will it be auto-approved ?
                            </Stack>
                          </Stack>
                          {isLoading ? (
                            domCreactionGridSkeletonLoader('70px')
                          ) : (
                            <Stack direction={'row'} sx={{width: '50%'}}>
                              <TextField
                                size='small'
                                name='autoApproveAfterDays'
                                type='number'
                                label={'Days'}
                                onChange={(event) =>
                                  handleChangeThreeSixtyCycleData(
                                    event,
                                    'textfield',
                                  )
                                }
                                variant='outlined'
                                error={
                                  threeSixtyCycleError.autoApproveAfterDays
                                    ?.isError
                                }
                                helperText={
                                  threeSixtyCycleError.autoApproveAfterDays
                                    ?.errorMessage
                                }
                                value={
                                  threeSixtyCycle.autoApproveAfterDays
                                    ? threeSixtyCycle.autoApproveAfterDays
                                    : ''
                                }
                                sx={{
                                  ...textFieldStyled,
                                  '& .MuiOutlinedInput-root': {
                                    '& fieldset': {
                                      borderLeftColor: 'red',
                                      borderLeftWidth: 3,
                                    },
                                  },
                                }}
                              />
                            </Stack>
                          )}
                        </Stack>

                        {/* ------------Manager approval workflow------------------------ */}
                        <Stack
                          id='addEnrollmentStack'
                          direction='row'
                          sx={{mt: 5, ml: 3}}
                          justifyContent='space-between'
                          alignItems='flex-start'
                          spacing={2}
                        >
                          <Stack sx={{width: '50%'}}>
                            <Stack fontWeight={500}>Select Workflow : </Stack>
                          </Stack>
                          {isLoading ? (
                            domCreactionGridSkeletonLoader('70px')
                          ) : (
                            <Stack direction={'row'} sx={{width: '50%'}}>
                              <FormControl
                                sx={{
                                  ...textFieldStyled,
                                  '& .MuiOutlinedInput-root': {
                                    '& fieldset': {
                                      borderLeftColor: 'red',
                                      borderLeftWidth: 3,
                                    },
                                  },
                                }}
                              >
                                <InputLabel
                                  size='small'
                                  id='managerWorkflowId '
                                >
                                  Select Workflow
                                </InputLabel>
                                <Select
                                  size='small'
                                  name='managerWorkflowId'
                                  label='Select Workflow'
                                  labelId='managerWorkflowId '
                                  value={
                                    threeSixtyCycle?.managerWorkflowId || ''
                                  }
                                  error={
                                    threeSixtyCycleError.managerWorkflowId
                                      ?.isError
                                  }
                                  helperText={
                                    threeSixtyCycleError.managerWorkflowId
                                      ?.errorMessage
                                  }
                                  onChange={(event) =>
                                    handleChangeThreeSixtyCycleData(
                                      event,
                                      'dropdown',
                                    )
                                  }
                                  variant='outlined'
                                  sx={{...textFieldStyled, width: '100%'}}
                                >
                                  {workflowList?.map((work, index) => (
                                    <MenuItem key='index' value={work.id}>
                                      {work.name}
                                    </MenuItem>
                                  ))}
                                </Select>
                                {threeSixtyCycleError.managerWorkflowId
                                  ?.isError && (
                                  <FormHelperText style={{color: '#d32f2f'}}>
                                    {
                                      threeSixtyCycleError.managerWorkflowId
                                        .errorMessage
                                    }
                                  </FormHelperText>
                                )}
                              </FormControl>
                            </Stack>
                          )}
                        </Stack>
                      </>
                    ) : null}
                  </>
                ) : (
                  <Stack
                    id='addEnrollmentStack'
                    direction='row'
                    sx={{mt: 5, ml: 3}}
                    justifyContent='space-between'
                    alignItems='flex-start'
                    spacing={2}
                  >
                    <Stack sx={{width: '50%'}}>
                      <Stack fontWeight={500}>
                        Does employees see those requests ?
                      </Stack>
                    </Stack>
                    {isLoading ? (
                      domCreactionGridSkeletonLoader('70px')
                    ) : (
                      <Stack direction={'row'} sx={{width: '50%'}}>
                        <RadioGroup
                          value={threeSixtyCycle.employeeSeeRequest}
                          row
                          aria-labelledby='demo-row-radio-buttons-group-label'
                          name='employeeSeeRequest'
                          onChange={(event) =>
                            handleChangeThreeSixtyCycleData(event, 'radio')
                          }
                        >
                          <FormControlLabel
                            value={true}
                            control={<Radio />}
                            label={<IntlMessages id='common.button.Yes' />}
                          />
                          <FormControlLabel
                            value={false}
                            control={<Radio />}
                            label={<IntlMessages id='common.button.No' />}
                          />
                        </RadioGroup>
                      </Stack>
                    )}
                  </Stack>
                )}

                <Stack
                  id='addEnrollmentStack'
                  direction='row'
                  sx={{mt: 5, ml: 3}}
                  justifyContent='space-between'
                  alignItems='flex-start'
                  spacing={2}
                >
                  <Stack sx={{width: '50%'}}>
                    <Stack fontWeight={500}>Define feedback limit :</Stack>
                  </Stack>
                  {isLoading ? (
                    domCreactionGridSkeletonLoader('70px')
                  ) : (
                    <Stack direction={'row'} sx={{width: '50%'}}>
                      <TextField
                        size='small'
                        name='minPeerFeedback'
                        label={'Min'}
                        onChange={(event) =>
                          handleChangeThreeSixtyCycleData(event, 'textfield')
                        }
                        variant='outlined'
                        error={threeSixtyCycleError.minPeerFeedback?.isError}
                        helperText={
                          threeSixtyCycleError.minPeerFeedback?.errorMessage
                        }
                        value={
                          threeSixtyCycle.minPeerFeedback
                            ? threeSixtyCycle.minPeerFeedback
                            : ''
                        }
                        sx={{
                          ...textFieldStyled,
                          '& .MuiOutlinedInput-root': {
                            '& fieldset': {
                              borderLeftColor: 'red',
                              borderLeftWidth: 3,
                            },
                          },
                          mr: 5,
                          width: '35%',
                        }}
                      />
                      <TextField
                        size='small'
                        name='maxPeerFeedback'
                        label={'Max'}
                        onChange={(event) =>
                          handleChangeThreeSixtyCycleData(event, 'textfield')
                        }
                        variant='outlined'
                        error={threeSixtyCycleError.maxPeerFeedback?.isError}
                        helperText={
                          threeSixtyCycleError.maxPeerFeedback?.errorMessage
                        }
                        value={
                          threeSixtyCycle.maxPeerFeedback
                            ? threeSixtyCycle.maxPeerFeedback
                            : ''
                        }
                        sx={{
                          ...textFieldStyled,
                          '& .MuiOutlinedInput-root': {
                            '& fieldset': {
                              borderLeftColor: 'red',
                              borderLeftWidth: 3,
                            },
                          },
                          ml: 5,
                          width: '35%',
                        }}
                      />
                    </Stack>
                  )}
                </Stack>
              </>
            )}
          </>
          {/* )} */}

          {/* -----------------------Respondent feedback Period--------------------------------- */}
          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>Respondent feedback period :</Stack>
            </Stack>
            {isLoading ? (
              domCreactionGridSkeletonLoader('70px')
            ) : (
              <Stack direction={'row'} sx={{width: '50%'}}>
                <Stack direction={'column'} sx={{width: '42%'}}>
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DesktopDatePicker
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          '& fieldset': {
                            borderLeftColor: 'red',
                            borderLeftWidth: 3,
                          },
                          height: '40px',
                          width: '180px',
                        },
                      }}
                      minDate={new Date()}
                      format={getCompanyDateFormatForInputs(selectedCompany)}
                      size='small'
                      // value={new Date(threeSixtyCycle.feedbackStartDate)}
                      value={
                        !isEmptyNullUndefined(threeSixtyCycle.feedbackStartDate)
                          ? new Date(threeSixtyCycle.feedbackStartDate)
                          : null
                      }
                      label={'Start Date'}
                      name='feedbackStartDate'
                      onChange={(event) =>
                        handleChangeThreeSixtyCycleData(
                          event,
                          'date',
                          'feedbackStartDate',
                        )
                      }
                    />
                  </LocalizationProvider>
                  {threeSixtyCycleError.feedbackStartDate?.isError && (
                    <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                      {threeSixtyCycleError.feedbackStartDate?.errorMessage}
                    </FormHelperText>
                  )}
                </Stack>

                <Stack direction={'column'} sx={{width: '42%'}}>
                  <LocalizationProvider dateAdapter={AdapterDateFns}>
                    <DesktopDatePicker
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          '& fieldset': {
                            borderLeftColor: 'red',
                            borderLeftWidth: 3,
                          },
                          height: '40px',
                          width: '180px',
                        },
                      }}
                      minDate={new Date()}
                      format={getCompanyDateFormatForInputs(selectedCompany)}
                      size='small'
                      // value={new Date(threeSixtyCycle.feedbackEndDate)}
                      value={
                        !isEmptyNullUndefined(threeSixtyCycle.feedbackEndDate)
                          ? new Date(threeSixtyCycle.feedbackEndDate)
                          : null
                      }
                      label={'End Date'}
                      name='feedbackEndDate'
                      onChange={(event) =>
                        handleChangeThreeSixtyCycleData(
                          event,
                          'date',
                          'feedbackEndDate',
                        )
                      }
                    />
                  </LocalizationProvider>
                  {threeSixtyCycleError.feedbackEndDate?.isError && (
                    <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                      {threeSixtyCycleError.feedbackEndDate?.errorMessage}
                    </FormHelperText>
                  )}
                </Stack>
              </Stack>
            )}
          </Stack>

          {/* -------Employee See feedback date----------------------------------------------------- */}
          {/* <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>
                Date on which employee see the feedback :
              </Stack>
            </Stack>

            <Stack direction={'column'} sx={{width: '50%'}}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DesktopDatePicker
                  sx={{
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                      height: '40px',
                      width: '400px',
                    },
                  }}
                  minDate={new Date()}
                  format={getCompanyDateFormatForInputs(selectedCompany)}
                  size='small'
                  // value={new Date(threeSixtyCycle.employeeSeeFeedbackDate)}
                  value={
                    !isEmptyNullUndefined(threeSixtyCycle.employeeSeeFeedbackDate)
                      ? new Date(threeSixtyCycle.employeeSeeFeedbackDate)
                      : null 
                  }
                  label={'See feedback date'}
                  name='employeeSeeFeedbackDate'
                  onChange={(event) =>
                    handleChangeThreeSixtyCycleData(
                      event,
                      'date',
                      'employeeSeeFeedbackDate',
                    )
                  }
                />
              </LocalizationProvider>
              {threeSixtyCycleError.employeeSeeFeedbackDate?.isError && (
                <FormHelperText sx={{color: '#d32f2f', mt: -2}}>
                  {threeSixtyCycleError.employeeSeeFeedbackDate?.errorMessage}
                </FormHelperText>
              )}
            </Stack>
          </Stack> */}

          <Stack
            id='addEnrollmentStack'
            direction='row'
            sx={{mt: 5, ml: 3}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <Stack fontWeight={500}>
                Maintain Anonimity for Peer feedback :
              </Stack>
            </Stack>
            {isLoading ? (
              domCreactionGridSkeletonLoader('70px')
            ) : (
              <Stack direction={'row'} sx={{width: '50%'}}>
                <RadioGroup
                  value={threeSixtyCycle.maintainAnonimityForPeer}
                  row
                  aria-labelledby='demo-row-radio-buttons-group-label'
                  name='maintainAnonimityForPeer'
                  onChange={(event) =>
                    handleChangeThreeSixtyCycleData(event, 'radio')
                  }
                >
                  <FormControlLabel
                    value={true}
                    control={<Radio />}
                    label={<IntlMessages id='common.button.Yes' />}
                  />
                  <FormControlLabel
                    value={false}
                    control={<Radio />}
                    label={<IntlMessages id='common.button.No' />}
                  />
                </RadioGroup>
              </Stack>
            )}
          </Stack>

          {/* -------------------------------------------------------------------------------------- */}
        </Stack>
        {/* ////////add Stack for fixed////// */}
        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0,
          }}
        >
          <Stack
            direction='row'
            justifyContent='end'
            alignItems='center'
            spacing={2}
            sx={{
              pt: 5,
              ml: 3,
              //// add marging for fixed stack///
              margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
            }}
          >
            <Button
              color={footerButton.back.color}
              variant={footerButton.back.variant}
              sx={footerButton.back.sx}
              size={footerButton.back.size}
              onClick={() => Router.push('/company-builder/three-sixty-cycle')}
            >
              <IntlMessages id='common.button.Back' />
            </Button>

            <Button
              color={footerButton.saveDraft.color}
              variant={footerButton.saveDraft.variant}
              sx={footerButton.saveDraft.sx}
              size={footerButton.saveDraft.size}
              disabled={draftLoading || loading}
              onClick={() => {
                validateThreeSixtyCycleDataDraft();
              }}
            >
              {draftLoading ? (
                <CircularProgress
                  sx={{
                    width: '15px !important',
                    margin: '4px !important',
                    height: '15px !important',
                  }}
                />
              ) : (
                <Stack>Save Draft</Stack>
              )}
            </Button>

            <Button
              color={footerButton.submit.color}
              variant={footerButton.submit.variant}
              sx={footerButton.submit.sx}
              size={footerButton.submit.size}
              disabled={loading || draftLoading}
              onClick={() => {
                validateThreeSixtyCycleData();
              }}
            >
              {loading ? (
                <CircularProgress
                  sx={{
                    width: '15px !important',
                    margin: '4px !important',
                    height: '15px !important',
                  }}
                />
              ) : (
                <Stack>
                  {isEdit ? (
                    <IntlMessages id='common.button.Update' />
                  ) : (
                    <IntlMessages id='common.button.Submit' />
                  )}
                </Stack>
              )}
            </Button>
          </Stack>
        </Stack>
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default AddThreeSixtyCycle;
