import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard, AppInfoView} from '../../../@crema';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import Router, {useRouter} from 'next/router';
import moment from 'moment';
import {useDispatch, useSelector} from 'react-redux';
import {showMessage, fetchError} from '../../../redux/actions';
import axios from 'axios';
import {
  apiCatchErrorMessage,
  getCompanyDateFormat,
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';
import IntlMessages from '@crema/utility/IntlMessages';
import {footerButton} from 'shared/constants/AppConst';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {
  domCreactionHeaderListSingle,
  domCreactionHeaderTitle,
} from 'shared/utils/domCreaction';
import {CircularProgress, Divider} from '@mui/material';
import {useState} from 'react';

const ViewThreeSixtyCycle = () => {
  const router = useRouter();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const {id} = router.query;
  const dispatch = useDispatch();

  const [threeSixtyCycle, setThreeSixtyCycle] = React.useState({});
  const [isLoading, setIsLoading] = React.useState(true);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  React.useEffect(() => {
    if (!isEmptyNullUndefined(id)) {
      getThreeSixtyCycleDetails(id);
    }
    // return () => {
    //   source.cancel('Aborting all previous operations.');
    //   source2.cancel('Aborting all previous operations.');
    // };
  }, []);

  const getThreeSixtyCycleDetails = async (id) => {
    setIsLoading(true);
    try {
      const response = await jwtAxios.get(
        `${API_ROUTS.threeSixtyCycle}/${id}`,
        {
          cancelToken: source2.token,
        },
      );
      if (response.status == 200) {
        setThreeSixtyCycle(response.data);
        setIsLoading(false);
      }
    } catch (e) {
      dispatch(fetchError(e.response?.data?.detail));
      setIsLoading(false);
    }
  };

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 5}}>
        {' '}
        <IntlMessages id='threeSixtyCycle.ViewThreeSixtyCycle' />
      </h2>
      <Stack spacing={2} sx={{mb: 10}}>
        <AppCard>
          {domCreactionHeaderTitle('360° Cycle Information')}
          {domCreactionHeaderListSingle('Name ', threeSixtyCycle.cycleName)}
          {domCreactionHeaderListSingle('Status ', threeSixtyCycle.status)}
          <Divider />
          {domCreactionHeaderListSingle(
            'Cycle start date',
            threeSixtyCycle?.cycleStartDate
              ? moment(threeSixtyCycle?.cycleStartDate).format(
                  getCompanyDateFormat(selectedCompany),
                )
              : '-',
          )}
          {domCreactionHeaderListSingle(
            'Cycle end date',
            threeSixtyCycle?.cycleEndDate
              ? moment(threeSixtyCycle?.cycleEndDate).format(
                  getCompanyDateFormat(selectedCompany),
                )
              : '-',
          )}
          <Divider />
          {domCreactionHeaderListSingle(
            'Nomination start date',
            threeSixtyCycle?.requestStartDate
              ? moment(threeSixtyCycle?.requestStartDate).format(
                  getCompanyDateFormat(selectedCompany),
                )
              : '-',
          )}
          {domCreactionHeaderListSingle(
            'Nomination end date',
            threeSixtyCycle?.requestEndDate
              ? moment(threeSixtyCycle?.requestEndDate).format(
                  getCompanyDateFormat(selectedCompany),
                )
              : '-',
          )}
          <Divider />

          {domCreactionHeaderListSingle(
            'Eligible employee query name',
            threeSixtyCycle.eligibleQuery?.variableName,
          )}
          {domCreactionHeaderListSingle(
            'Eligible employee query',
            threeSixtyCycle.eligibleQuery?.query
              ? threeSixtyCycle.eligibleQuery?.query
              : '-',
          )}
          {domCreactionHeaderListSingle(
            'Ineligible employee query name',
            threeSixtyCycle.ineligibleQuery?.variableName,
          )}
          {domCreactionHeaderListSingle(
            'Ineligible employee query',
            threeSixtyCycle.ineligibleQuery?.query
              ? threeSixtyCycle.ineligibleQuery?.query
              : '-',
          )}
        </AppCard>

        <AppCard>
          {domCreactionHeaderListSingle(
            'Peer forms ',
            threeSixtyCycle.assessmentForms
              ?.map((item) => item.displayName)
              .join(' , '),
          )}

          {domCreactionHeaderListSingle(
            'Default Peer form',
            threeSixtyCycle.defaultFormId,
          )}
          <Divider />
          {domCreactionHeaderListSingle(
            'Who can initiate peer review request ?',
            threeSixtyCycle?.peerFeedbackType,
          )}

          {domCreactionHeaderListSingle(
            'Peer review initiator',
            threeSixtyCycle?.peerReviewInitiator,
          )}

          {domCreactionHeaderListSingle(
            'Does employees see those requests?',
            threeSixtyCycle?.employeeSeeRequest ? 'Yes' : 'No',
          )}
            <Divider />
          {domCreactionHeaderListSingle(
            'Manager approval required ?',
            threeSixtyCycle.managerApprovalRequired ? 'Yes' : 'No',
          )}

          {domCreactionHeaderListSingle(
            'After how many days will it be auto-approved?',
            threeSixtyCycle.autoApproveAfterDays,
          )}

          {domCreactionHeaderListSingle(
            'Manager approval workflow',
            threeSixtyCycle.managerWorkflowId,
          )}

          <Divider />
          {domCreactionHeaderListSingle(
            'Min peer feedback',
            threeSixtyCycle?.minPeerFeedback,
          )}

          {domCreactionHeaderListSingle(
            'Max peer feedback',
            threeSixtyCycle?.maxPeerFeedback,
          )}
          <Divider />
          {domCreactionHeaderListSingle(
            'Respondent feedback start date',
            threeSixtyCycle?.feedbackStartDate
              ? moment(threeSixtyCycle?.feedbackStartDate).format(
                  getCompanyDateFormat(selectedCompany),
                )
              : '-',
          )}
          {domCreactionHeaderListSingle(
            'Respondent feedback end date',
            threeSixtyCycle?.feedbackEndDate
              ? moment(threeSixtyCycle?.feedbackEndDate).format(
                  getCompanyDateFormat(selectedCompany),
                )
              : '-',
          )}

          {domCreactionHeaderListSingle(
            'Maintain anonimity for Peer feedback',
            threeSixtyCycle.maintainAnonimityForPeer ? 'Yes' : 'No',
          )}
        </AppCard>

        <Stack
          sx={{
            bottom: 0,
            zIndex: 10,
            position: 'fixed',
            backdropFilter: 'blur(5px)',
            width: '100%',
            right: 0,
          }}
        >
          <Stack
            direction='row'
            justifyContent='end'
            alignItems='center'
            spacing={2}
            sx={{
              pt: 5,
              ml: 3,
              margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
            }}
          ></Stack>
        </Stack>
      </Stack>
      <AppInfoView />

      {/* ////////add Stack for fixed////// */}
      <Stack
        sx={{
          bottom: 0,
          zIndex: 10,
          position: 'fixed',
          backdropFilter: 'blur(5px)',
          width: '100%',
          right: 0,
        }}
      >
        <Stack
          direction='row'
          justifyContent='end'
          alignItems='center'
          spacing={2}
          sx={{
            pt: 5,
            ml: 3,
            //// add marging for fixed stack///
            margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
          }}
        >
          <Button
            color={footerButton.back.color}
            variant={footerButton.back.variant}
            sx={footerButton.back.sx}
            size={footerButton.back.size}
            onClick={() => Router.push('/company-builder/three-sixty-cycle')}
          >
            <IntlMessages id='common.button.Back' />
          </Button>
        </Stack>
      </Stack>
    </AppAnimate>
  );
};

export default ViewThreeSixtyCycle;
