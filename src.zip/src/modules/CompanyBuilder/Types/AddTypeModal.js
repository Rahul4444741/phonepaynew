import * as React from 'react';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import Stack from '@mui/material/Stack';
import { AppCard } from '../../../@crema';
import TextField from '@mui/material/TextField';
import PropTypes from 'prop-types';
import AppInfoView from '../../../@crema/core/AppInfoView';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import FormHelperText from '@mui/material/FormHelperText';
import { useDispatch } from 'react-redux';
import { showMessage, fetchError } from '../../../redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import { API_ROUTS } from 'shared/constants/ApiRouts';
import {
  apiCatchErrorMessage,
  isDuplicate,
  isStrExceeds,
} from 'shared/utils/CommonUtils';
import IntlMessages from '@crema/utility/IntlMessages';

const AddTypesModal = ({
  company,
  handleAddType,
  handleClose,
  editType,
  isEdit,
  handleUpdateType,
  typesData,
}) => {
  const dispatch = useDispatch();
  const [type, setType] = React.useState({
    id: null,
    name: '',
    status: '',
    company: {
      id: company.id,
    },
  });

  React.useEffect(() => {
    if (isEdit) {
      setType(editType);
    }
  }, []);

  const [formError, setFormError] = React.useState({
    name: {isError: false, errorMessage: ''},
    status: {isError: false, errorMessage: ''},
  });
  const textFieldStyled = {
    backgroundColor: 'white',
    mb: 4,
    width: {xs: '100%'},
  };

  const handleValidateType = async () => {
    let isValid = true;
    const tempError = {...formError};
    const tempType = {...type};
    if (tempType.name.trim() == '') {
      tempError.name.isError = true;
      tempError.name.errorMessage = <IntlMessages id='error.pleaseEnterName' />;
      isValid = false;
    }
    if (isStrExceeds(tempType.name.toString(), 50)) {
      tempError.name.isError = true;
      tempError.name.errorMessage = 'should not exceed 50 characters';
      isValid = false;
    }
    if (
      !isEdit
        ? isDuplicate(tempType.name, typesData)
        : isDuplicate(tempType.name, typesData, tempType.id)
    ) {
      tempError.name.isError = true;
      tempError.name.errorMessage = (
        <IntlMessages id='error.duplicateEntryFound' />
      );
      isValid = false;
    }

    if (tempType.status.trim() == '') {
      tempError.status.isError = true;
      tempError.status.errorMessage = (
        <IntlMessages id='error.pleaseSelectStatus' />
      );
      isValid = false;
    }
    if (isValid) {
      if (isEdit) {
        updateTypes();
      } else {
        submitTypes();
      }
    } else {
      setFormError(tempError);
    }
  };
  const submitTypes = async () => {
    try {
      const response = await jwtAxios.post(`${API_ROUTS.employeetype}`, type);
      if (response.status == 201) {
        dispatch(
          showMessage(response.data.name + ' Type added successfully..!'),
        );
        handleAddType(response.data);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const updateTypes = async () => {
    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.employeetype}${type.id}`,
        type,
      );
      if (response.status === 200) {
        dispatch(
          showMessage(response.data.name + ' Type updated successfully..!'),
        );
        handleUpdateType(response.data);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleChangeTypeData = (event) => {
    const tempType = {...type};
    const tempError = {...formError};
    tempType[event.target.name] = event.target.value;
    tempError[event.target.name].isError = false;
    tempError[event.target.name].errorMessage = '';
    setType(tempType);
    setFormError(tempError);
  };

  return (
    <Dialog maxWidth={'sm'} open={true}>
      <DialogContent>
        <Stack direction='row' justifyContent='center' sx={{mt: '7%'}}>
          <AppCard style={{width: '350px'}}>
            <h4 style={{display: 'flex'}}>
              {!isEdit ? (
                <IntlMessages id='types.addTypes' />
              ) : (
                <IntlMessages id='types.updateTypes' />
              )}
            </h4>
            <Stack
              sx={{mt: 2}}
              display='flex'
              justifyContent='center'
              spacing={2}
            >
              <TextField
                size='small'
                name='name'
                label={<IntlMessages id='configuration.dialogbox.Name' />}
                onChange={(event) => handleChangeTypeData(event)}
                value={type?.name}
                error={formError.name.isError}
                helperText={formError.name.errorMessage}
                variant='outlined'
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              />

              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id='event-type'>
                  <IntlMessages id='configuration.dialogbox.Status' />
                </InputLabel>
                <Select
                  size='small'
                  name='status'
                  label='Status'
                  value={type?.status}
                  error={formError.status.isError}
                  helperText={formError.status.errorMessage}
                  onChange={(event) => handleChangeTypeData(event)}
                  variant='outlined'
                  sx={{...textFieldStyled}}
                >
                  <MenuItem key='Active' value='ACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Active' />
                  </MenuItem>
                  <MenuItem key='Inactive' value='INACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                  </MenuItem>
                </Select>
                <FormHelperText style={{color: '#d32f2f'}}>
                  {formError.status.errorMessage}
                </FormHelperText>
              </FormControl>
            </Stack>
          </AppCard>
        </Stack>
      </DialogContent>
      <DialogActions>
        <Button onClick={() => handleValidateType()}>
          <IntlMessages id='common.button.Submit' />
        </Button>
        <Button onClick={() => handleClose()}>
          <IntlMessages id='common.button.Close' />
        </Button>
      </DialogActions>
      <AppInfoView />
    </Dialog>
  );
};

export default AddTypesModal;
AddTypesModal.propTypes = {
  company: PropTypes.object,
  handleAddType: PropTypes.func,
  handleUpdateType: PropTypes.func,
  handleClose: PropTypes.func,
  isEdit: PropTypes.bool,
  editType: PropTypes.object,
  typesData: PropTypes.array,
};
