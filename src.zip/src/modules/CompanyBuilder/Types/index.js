import * as React from 'react';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard} from '../../../@crema';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import {AgGridReact} from 'ag-grid-react';
import {useDispatch, useSelector} from 'react-redux';
import ToggleButton from '@mui/material/ToggleButton';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import AddTypeModal from './AddTypeModal';
import {
  fetchStart,
  fetchError,
  showMessage,
  showInfo,
} from '../../../redux/actions';
import axios from 'axios';
import AppInfoView from '../../../@crema/core/AppInfoView';
import AlertDialog from '../../Common/AlertDialog';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {TextField} from '@mui/material';
import {
  isEmptyNullUndefined,
  buttonStyle,
  apiCatchErrorMessage,
  isAllowedUser,
} from 'shared/utils/CommonUtils';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import IntlMessages from '@crema/utility/IntlMessages';
import {permissionName} from 'shared/utils/PermissionName';
import Error403 from 'modules/errorPages/Error403';
import { useCallback } from 'react';

const CustomHeaderName = () => <IntlMessages id='aggrid.tableHeader.Name' />;
const CustomHeaderStatus = () => (
  <IntlMessages id='aggrid.tableHeader.Status' />
);
const CustomHeaderAction = () => (
  <IntlMessages id='aggrid.tableHeader.Action' />
);

const Types = () => {
  const dispatch = useDispatch();
  const [typesData, setTypesData] = React.useState(null);
  const [isAddTypeOpen, setIsAddTypeOpen] = React.useState(false);
  const [isEdit, setIsEdit] = React.useState(false);
  const [editType, setEditType] = React.useState(undefined);
  const [overlayMessage, setOverlayMessage] = React.useState('No Rows To Show');
  const [isLoading, setIsLoading] = React.useState(true);
  const [alertProps, setAlertProps] = React.useState({
    isHideShow: false,
    message: '',
    title: '',
    alertType: '',
    actionParams: null,
  });

  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);

  React.useEffect(() => {
    if (isAllowedUser(permissionName.COMPANY_VARIABLES_CLASS_OF_EMPLOYEEMENT)) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  React.useEffect(() => {
    dispatch(fetchStart);
    if (
      isAuthorized &&
      selectedCompany != null &&
      selectedCompany != undefined
    ) {
      getAllActiveTypes(selectedCompany.id);
    }
    return () => {
      source.cancel('Aborting all previous operations.');
      source2.cancel('Aborting all previous operations.');
    };
  }, [isAuthorized, selectedCompany]);

  const gridRef = React.useRef();
  const defaultColDef = React.useMemo(() => ({
    sortable: true,
  }));

   // Custom Status Cell Renderer
  const StatusRenderer = (params) => (
    <Stack direction='row'>
      <div
        style={{color: params.data.status === 'ACTIVE' ? '#11C15B' : '#D32F2F'}}
      >
        {params.data.status}
      </div>
    </Stack>
  );

  // Custom Action Cell Renderer
  const ActionRenderer = (params) => (
    <Stack direction='row'>
      {isAllowedUser(permissionName.UPDATE) && (
        <Button onClick={() => handleOpenEditModel(params)} style={buttonStyle}>
          <IntlMessages id='common.button.Edit' />
        </Button>
      )}
      {isAllowedUser(permissionName.DEACTIVATE) &&
        params.data.status === 'ACTIVE' && (
          <Button
            onClick={() => handleDeactivateConfirmation(params)}
            style={buttonStyle}
          >
            <IntlMessages id='common.button.Deactivate' />
          </Button>
        )}
      {isAllowedUser(permissionName.ACTIVATE) &&
        params.data.status === 'INACTIVE' && (
          <Button
            onClick={() => handleActivateConfirmation(params)}
            style={buttonStyle}
          >
            <IntlMessages id='common.button.Activate' />
          </Button>
        )}
    </Stack>
  );

  const columnDefs = [
    {
      field: 'name',
      filter: true,
      headerName: 'Name',
      headerComponentFramework: CustomHeaderName,
      minWidth: 350,
    },
    {
      field: 'status',
      filter: true,
      headerName: 'Status',
      headerComponentFramework: CustomHeaderStatus,
      minWidth: 350,
      cellRenderer: StatusRenderer, // Use custom status renderer
    },
    {
      headerName: 'Action',
      headerComponentFramework: CustomHeaderAction,
      minWidth: 250,
      cellRenderer: ActionRenderer, // Use custom action renderer
    },
  ];

  const getAllActiveTypes = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.employeetype_companyID}${companyId}?status=ACTIVE`,
        {cancelToken: source.token},
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no class for selected company'));
          setTypesData([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setTypesData(reversed);
        }
        setIsLoading(() => false);
      } else {
        setTypesData([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setTypesData([]);
      setIsLoading(() => false);
    }
  };

  const getAllInactiveTypes = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.employeetype_companyID}${companyId}?status=INACTIVE`,
        {cancelToken: source2.token},
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no class for selected company'));
          setTypesData([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setTypesData(reversed);
        }
        setIsLoading(() => false);
      } else {
        setTypesData([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setTypesData([]);
      setIsLoading(() => false);
    }
  };

  const handleDeactivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = <IntlMessages id='warning.deactivateClass' />;
    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureDeactivate' /> {params.data.name} ?
      </span>
    );
    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };
  const handleAlertYes = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.actionParams.data.status == 'ACTIVE' &&
      handleDeactivateType(tempAlertProps.actionParams);
    tempAlertProps.actionParams.data.status == 'INACTIVE' &&
      handleActivateType(tempAlertProps.actionParams);
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };

  const handleAlertNo = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };

  const handleDeactivateType = async (params) => {
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));
      const response = await jwtAxios.put(
        `${API_ROUTS.employeetype_inactivate}${params.data.id}`,
        {headers: {}},
      );
      if (response.status == 200) {
        dispatch(showMessage('Type Deactivted Successfully..!'));
        const typeIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );
        if (typeIndex != -1) {
          rowData[typeIndex].status = 'INACTIVE';
        }
        getAllInactiveTypes(selectedCompany.id);
        setAlignment('INACTIVE');
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleActivateConfirmation = (params) => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = true;
    tempAlertProps.alertType = 'Confirmation';
    tempAlertProps.title = <IntlMessages id='warning.activateClass' />;
    tempAlertProps.message = (
      <span>
        <IntlMessages id='warning.areYouSureActivate' /> {params.data.name} ?
      </span>
    );
    tempAlertProps.actionParams = params;
    setAlertProps(tempAlertProps);
  };

  const handleActivateType = async (params) => {
    try {
      let rowData = [];
      params.api.forEachNode((node) => rowData.push(node.data));
      const response = await jwtAxios.put(
        `${API_ROUTS.employeetype_activate}${params.data.id}`,
        {headers: {}},
      );
      if (response.status == 200) {
        dispatch(showMessage('Type Activated Successfully..!'));
        const typeIndex = rowData.findIndex(
          (item) => item.id == params.data.id,
        );
        if (typeIndex != -1) {
          rowData[typeIndex].status = 'ACTIVE';
        }
        getAllActiveTypes(selectedCompany.id);
        setAlignment('ACTIVE');
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
  };

  const handleOpenEditModel = (params) => {
    let rowData = [];
    params.api.forEachNode((node) => rowData.push(node.data));
    const typeIndex = rowData.findIndex((item) => item.id == params.data.id);
    if (typeIndex != -1) setEditType(rowData[typeIndex]);
    setIsEdit(true);
    setIsAddTypeOpen(true);
  };

  const handleAddTypeToList = (type) => {
    if (type.status == 'ACTIVE') {
      if (alignment == 'ACTIVE') {
        const temptypes = [...typesData];
        temptypes.unshift(type);
        setTypesData(temptypes);
      }
    }
    if (type.status == 'INACTIVE') {
      if (alignment == 'INACTIVE') {
        const temptypes = [...typesData];
        temptypes.unshift(type);
        setTypesData(temptypes);
      }
    }
    if (type.status == 'ACTIVE') {
      if (alignment == 'INACTIVE') {
        setAlignment('ACTIVE');
        getAllActiveTypes(selectedCompany.id);
      }
    }
    if (type.status == 'INACTIVE') {
      if (alignment == 'ACTIVE') {
        setAlignment('INACTIVE');
        getAllInactiveTypes(selectedCompany.id);
      }
    }
    setIsAddTypeOpen(false);
  };

  const handleUpdateType = (type) => {
    const isActive = type.status === 'ACTIVE';
    const isAlignmentActive = alignment === 'ACTIVE';

    if ((isActive && isAlignmentActive) || (!isActive && !isAlignmentActive)) {
      const updatedTypes = typesData.map((item) =>
        item.id === type.id ? type : item,
      );
      setTypesData(updatedTypes);
    } else {
      setAlignment(isActive ? 'ACTIVE' : 'INACTIVE');
      isActive
        ? getAllActiveTypes(selectedCompany.id)
        : getAllInactiveTypes(selectedCompany.id);
    }

    setEditType(null);
    setIsEdit(false);
    setIsAddTypeOpen(false);
  };

  const handleCloseAddType = () => {
    setIsAddTypeOpen(false);
  };
  const handleOpenAddType = () => {
    setIsEdit(false);
    setIsAddTypeOpen(true);
  };

  const [alignment, setAlignment] = React.useState('ACTIVE');

  const handleChange = (event, newAlignment) => {
    setAlignment(newAlignment);
  };

  const onFilterTextBoxChanged = useCallback(() => {
    const filterText = document.getElementById("filter-text-box").value;
    gridRef.current.api.setGridOption("quickFilterText", filterText);
    const totalResults = gridRef.current.api.getDisplayedRowCount();
    if (!isEmptyNullUndefined(typesData) && typesData.length > 0) {
      if (totalResults === 0 && !isEmptyNullUndefined(filterText)) {
        setOverlayMessage('No Record Found');
        gridRef.current.api.showNoRowsOverlay();
      } else if (totalResults !== 0) {
        setOverlayMessage('No Rows To Show');
        gridRef.current.api.hideOverlay();
      }
    }
  }, []);

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (!isAuthorized) {
    return <Error403 />;
  }

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        <IntlMessages id='types.pageHeaderName' />
      </h2>
      <AppCard>
        <Stack style={{width: '100%'}}>
          <Stack direction='row' sx={{mb: 2}} justifyContent={'end'}>
            <TextField
              sx={{width: 200, mr: 2}}
              id="filter-text-box"
              onInput={onFilterTextBoxChanged}
              type={'search'}
              name='search'
              label={<IntlMessages id='common.button.Search' />}
              variant='outlined'
            />
            {isAllowedUser(permissionName.CREATE) && (
              <Button
                sx={{mr: 2}}
                variant='outlined'
                onClick={() => handleOpenAddType()}
              >
                <IntlMessages id='types.addTypes' />
              </Button>
            )}
            <ToggleButtonGroup
              color='primary'
              value={alignment}
              exclusive
              onChange={handleChange}
            >
              <ToggleButton
                value='ACTIVE'
                onClick={() => getAllActiveTypes(selectedCompany.id)}
              >
                <IntlMessages id='common.button.Active' />
              </ToggleButton>
              <ToggleButton
                value='INACTIVE'
                onClick={() => getAllInactiveTypes(selectedCompany.id)}
              >
                <IntlMessages id='common.button.Inactive' />
              </ToggleButton>
            </ToggleButtonGroup>
          </Stack>
          {isLoading ? (
            domCreactionGridSkeletonLoader()
          ) : (
            <Stack
              className='ag-theme-alpine'
              style={{height: 525, width: '100%'}}
            >
              <AgGridReact
                ref={gridRef}
                rowData={typesData}
                columnDefs={columnDefs}
                defaultColDef={defaultColDef}
                animateRows={true}
                pagination={true}
                paginationPageSize={10}
                overlayLoadingTemplate={
                  '<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'
                }
                overlayNoRowsTemplate={`<span class="ag-overlay-loading-center">${overlayMessage}</span>`}
              />
            </Stack>
          )}
        </Stack>
        {isAddTypeOpen && (
          <AddTypeModal
            company={selectedCompany}
            isEdit={isEdit}
            handleAddType={(type) => handleAddTypeToList(type)}
            handleClose={() => handleCloseAddType()}
            editType={editType}
            handleUpdateType={(type) => handleUpdateType(type)}
            typesData={typesData}
          ></AddTypeModal>
        )}
        {alertProps.isHideShow && (
          <AlertDialog
            alertProps={alertProps}
            handleYes={() => handleAlertYes()}
            handleNo={() => handleAlertNo()}
          />
        )}
      </AppCard>
      <AppInfoView />
    </AppAnimate>
  );
};

export default Types;
