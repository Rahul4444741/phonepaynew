import * as React from 'react';
import Stack from '@mui/material/Stack';
import AppAnimate from '../../../@crema/core/AppAnimate';
import { AppCard, AppInfoView } from '../../../@crema';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import { useDispatch, useSelector } from 'react-redux';
import {
  showMessage,
  fetchError,
  showInfo
} from '../../../redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import { API_ROUTS } from 'shared/constants/ApiRouts';
import {
  Button,
  FormControl,
  InputLabel,
  ListItemText,
  MenuItem,
  Select,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Paper,
  TextField, FormControlLabel, FormGroup,
  Checkbox,
  CircularProgress,
  Typography
} from '@mui/material';
import axios from 'axios';
import { domCreactionGridSkeletonLoader } from 'shared/utils/domCreaction';
import {
  apiCatchErrorMessage,
  isAllowedUser,
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';
import IntlMessages from '@crema/utility/IntlMessages';
import {
  footerButton,
  variableNamemappingDropDown,
} from 'shared/constants/AppConst';
import FormHelperText from '@mui/material/FormHelperText';
import { green, purple, red } from '@mui/material/colors';
import { permissionName } from 'shared/utils/PermissionName';
import Error403 from 'modules/errorPages/Error403';

const VariableNameMapping = () => {
  const dispatch = useDispatch();
  const [isError, setIsError] = React.useState(false);
  const [variableNameData, setVariableNameData] = React.useState([]);
  const [isLoading, setIsLoading] = React.useState(false);
  const [submitLoading, setSubmitLoading] = React.useState(false);
  const [selectedDropdownIntity, setSelectedDropdownIntity] =
    React.useState(null);
  const [variableNameMappingList, setVariableNameMappingList] =
    React.useState(null);
  const [firstTimeData, setFirstTimeData] = React.useState([]);

  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);

  React.useEffect(() => {
    if (
      isAllowedUser(permissionName.COMPANY_VARIABLES_VARIABLE_NAME_MAPPINNG)
    ) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
 
  const mandatoryFields = [
    'name',
    'employeeId',
    'emailId',
    'dateOfJoining',
    'employeeType',
    'employeeLevel',
    'empstatus',
    'employeeGrade',
    'employeeFunction',
    'dateOfBirth',
    'employmentStatus',
  ];

  const getVariableNameMappingList = async (selectedDropDown) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.variable_name_mapping}/${selectedDropDown}?companyId=${selectedCompany.id}`,
        {headers: {}},
        {
          cancelToken: source.token,
        },
      );

      if (res.status == 200) {
        setVariableNameMappingList(res.data);

        if (res.data.length == 0) {
          dispatch(
            showInfo(
              'You have no Variable Name Mapping List for selected company',
            ),
          );
          setVariableNameMappingList([]);
        } else {
          const sortedData = res.data?.sort();
          setVariableNameMappingList(sortedData);
        }
        setIsLoading(() => false);
      } else {
        setVariableNameMappingList([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setVariableNameMappingList([]);
    }
    setIsLoading(() => false);
  };

  React.useEffect(() => {
    if (isAuthorized) {
      convertMappingListToObject(
        variableNameMappingList,
        selectedDropdownIntity,
      );
    }
  }, [isAuthorized, variableNameMappingList, variableNameData]);

  const toPascalCase = (str) => {
    return str
      .split(/[_\s]+|(?=[A-Z])/) // Split by underscore, space, or before an uppercase letter
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join('');
  };

  const convertMappingListToObject = (list, dropdown) => {
    const variableNameMappingData = list?.map((item, index) => ({
      entityName: dropdown,
      variableName: item,
      displayName: toPascalCase(item),
      company: null,
      isRequired: mandatoryFields.includes(item),
      isVisible: true,
      defaultValue: null,
    }));
    if (isEmptyNullUndefined(variableNameData)) {
      setFirstTimeData(variableNameMappingData);
    } else {
      setFirstTimeData(variableNameData);
    }
  };

  const getAllVariableNameMapping = async (selectedDropDown) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.variable_name_mapping}/find-by-entity/${selectedDropDown}/${selectedCompany.id}`,
        {headers: {}},
        {
          cancelToken: source.token,
        },
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(
            showInfo('You have no Variable Name Mapping for selected company'),
          );
          setVariableNameData([]);
        } else {
          const sortedData = res.data?.sort((a, b) => {
            if (a.variableName < b.variableName) return -1;
            if (a.variableName > b.variableName) return 1;
            return 0;
          });
          const newData = sortedData?.map((data) => ({
            ...data,
            displayName:
              data.displayName === data.variableName
                ? toPascalCase(displayName)
                : data.displayName,
          }));

          setVariableNameData(newData);
        }
        setIsLoading(() => false);
      }
    } catch (error) {
      setVariableNameData([]);
    }
    setIsLoading(() => false);
  };

  const handleEdit = (index, key, value) => {
    setFirstTimeData((prevData) => {
      const newData = [...prevData];
      newData[index] = {
        ...newData[index],
        [key]: value,
      };
      return newData;
    });
  };

  const validateDisplayName = (value) => {
    return value.trim() !== '' && value.length <= 50;
  };

  const handleSubmitChanges = async () => {
    const isValid = firstTimeData.every((item) =>
      validateDisplayName(item.displayName),
    );
    if (!isValid) {
      dispatch(
        fetchError(
          'Display Name must not be empty and should be up to 50 characters.',
        ),
      );
      return;
    }
    const dataWithCompanyId = firstTimeData.map((item) => ({
      ...item,
      company: {
        id: selectedCompany.id,
      },
    }));
    console.log('dataWithCompanyId', dataWithCompanyId);
    setSubmitLoading(true);
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.variable_name_mapping}/add`,
        dataWithCompanyId,
      );
      if (response.status == 200) {
        dispatch(showMessage('Display Name updated successfully..!'));
        setSubmitLoading(false);
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
      setSubmitLoading(false);
    }
  };
  
  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (!isAuthorized) {
    return <Error403 />;
  }
console.log('firstTimeData',firstTimeData)
  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        <IntlMessages id='variableNameMapping.pageHeaderName' />
      </h2>
      <AppCard>
        <Stack direction='row' sx={{mb: 2}} justifyContent={'end'} spacing={2}>
          <FormControl sx={{mb: 2, width: '30%', ml: 4}}>
            <InputLabel
              sx={{backgroundColor: '#ffffff', padding: '0px 0.5rem'}}
              size='small'
              id='actor'
            >
              <IntlMessages id='report.select' />
            </InputLabel>
            <Select
              value={selectedDropdownIntity}
              id={'selectedDropdownIntity'}
              name='selectedDropdownIntity'
              error={isError}
              onChange={async (event) => {
                setIsError(false);
                setSelectedDropdownIntity(event.target.value);
                await getAllVariableNameMapping(event.target.value);
                await getVariableNameMappingList(event.target.value);
              }}
              variant='outlined'
              size='small'
              sx={{backgroundColor: 'white', width: '100%'}}
            >
              {variableNamemappingDropDown?.map((item, index) => {
                return (
                  <MenuItem
                    value={item.value}
                    id={item.key + '-' + index}
                    name={item.name}
                    key={item.key + '-' + index}
                    size='small'
                  >
                    <ListItemText primary={item.name} />
                  </MenuItem>
                );
              })}
            </Select>
            {isError && (
              <FormHelperText sx={{color: '#d32f2f', mt: -1}}>
                Please select Entity Name
              </FormHelperText>
            )}
          </FormControl>
        </Stack>
        {isLoading ? (
          domCreactionGridSkeletonLoader()
        ) : (
          <Stack style={{width: 1025, marginBottom: '50px'}}>
            <div className='ag-theme-alpine' style={{width: '100%'}}>
              {firstTimeData?.length > 0 && (
                <Typography
                  variant='h5'
                  sx={{mt: 3, mb: 3, color: 'red'}}
                  justifyContent={'center'}
                >
                  Note: Variables marked with * are mandatory for backend
                  operations.
                </Typography>
              )}
              <TableContainer component={Paper}>
                <Table sx={{minWidth: 750}} aria-label='simple table'>
                  <TableHead>
                    <TableRow>
                      <TableCell
                        sx={{backgroundColor: purple['100']}}
                        align='center'
                      >
                        <IntlMessages id='variableNameMapping.entityName' />
                      </TableCell>

                      <TableCell
                        sx={{backgroundColor: purple['100']}}
                        align='center'
                      >
                        <IntlMessages id='variableNameMapping.variableName' />
                      </TableCell>
                      <TableCell
                        sx={{backgroundColor: purple['100']}}
                        align='center'
                      >
                        <IntlMessages id='variableNameMapping.displayName' />
                      </TableCell>
                      <TableCell
                        sx={{backgroundColor: purple['100']}}
                        align='center'
                      >
                        <IntlMessages id='variableNameMapping.isRequired' />
                      </TableCell>
                      <TableCell
                        sx={{backgroundColor: purple['100']}}
                        align='center'
                      >
                        Is Visible
                      </TableCell>
                      <TableCell
                        sx={{backgroundColor: purple['100']}}
                        align='center'
                      >
                        <IntlMessages id='variableNameMapping.defaultValue' />
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {firstTimeData?.length > 0 ? (
                      firstTimeData.map((row, index) => (
                        <TableRow
                          key={row?.variableName}
                          sx={{'&:last-child td, &:last-child th': {border: 0}}}
                        >
                          <TableCell
                            sx={{backgroundColor: green['100']}}
                            align='center'
                          >
                            {row.entityName}
                          </TableCell>
                          <TableCell
                            sx={{backgroundColor: red['50']}}
                            align='center'
                          >
                            {row.variableName}
                            {mandatoryFields.includes(row.variableName) && (
                              <span
                                style={{
                                  marginLeft: '5px',
                                  fontSize: '18px',
                                  color: 'red',
                                }}
                              >
                                *
                              </span>
                            )}
                          </TableCell>
                          <TableCell
                            sx={{
                              backgroundColor: red['50'],
                              textAlign: 'center',
                            }}
                            component='th'
                            scope='row'
                          >
                            <TextField
                              value={row.displayName}
                              onChange={(e) =>
                                handleEdit(index, 'displayName', e.target.value)
                              }
                            />
                          </TableCell>
                          <TableCell
                            sx={{backgroundColor: red['50']}}
                            align='center'
                          >
                            <FormControl component='fieldset'>
                              <FormGroup aria-label='position' row>
                                <FormControlLabel
                                  fontWeight={500}
                                  control={
                                    <Checkbox
                                      disabled={mandatoryFields.includes(
                                        row.variableName,
                                      )}
                                      checked={row.isRequired}
                                      onChange={(e) =>
                                        handleEdit(
                                          index,
                                          'isRequired',
                                          e.target.checked,
                                        )
                                      }
                                    />
                                  }
                                  // label={<IntlMessages id='notification.sendNotification' />}
                                  labelPlacement='end'
                                />
                              </FormGroup>
                            </FormControl>
                          </TableCell>
                          <TableCell
                            sx={{backgroundColor: red['50']}}
                            align='center'
                          >
                            <FormControl component='fieldset'>
                              <FormGroup aria-label='position' row>
                                <FormControlLabel
                                  fontWeight={500}
                                  control={
                                    <Checkbox
                                      disabled={mandatoryFields.includes(
                                        row.variableName,
                                      )}
                                      checked={row.isVisible}
                                      onChange={(e) =>
                                        handleEdit(
                                          index,
                                          'isVisible',
                                          e.target.checked,
                                        )
                                      }
                                    />
                                  }
                                  labelPlacement='end'
                                />
                              </FormGroup>
                            </FormControl>
                          </TableCell>
                          <TableCell
                            sx={{
                              backgroundColor: red['50'],
                              textAlign: 'center',
                            }}
                            component='th'
                            scope='row'
                          >
                            <TextField
                              value={row.defaultValue}
                              onChange={(e) =>
                                handleEdit(
                                  index,
                                  'defaultValue',
                                  e.target.value,
                                )
                              }
                            />
                          </TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={3}>
                          <p style={{textAlign: 'center', fontSize: '15px'}}>
                            <IntlMessages id='warning.noRowsToShow' />
                          </p>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </TableContainer>
            </div>
          </Stack>
        )}
      </AppCard>
      <AppInfoView />
      <Stack
        sx={{
          bottom: 0,
          zIndex: 10,
          position: 'fixed',
          backdropFilter: 'blur(5px)',
          width: '100%',
          right: 0,
        }}
      >
        <Stack
          direction='row'
          justifyContent='end'
          alignItems='center'
          spacing={2}
          sx={{
            pt: 5,
            ml: 3,
            margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
          }}
        >
          <Button
            color={footerButton.submit.color}
            variant={footerButton.submit.variant}
            sx={footerButton.submit.sx}
            size={footerButton.submit.size}
            disabled={!selectedDropdownIntity || submitLoading}
            onClick={handleSubmitChanges}
          >
            {submitLoading ? (
              <CircularProgress
                sx={{
                  width: '15px !important',
                  margin: '4px !important',
                  height: '15px !important',
                }}
              />
            ) : (
              <IntlMessages id='common.button.Submit' />
            )}
          </Button>
        </Stack>
      </Stack>
    </AppAnimate>
  );
};

export default VariableNameMapping;
