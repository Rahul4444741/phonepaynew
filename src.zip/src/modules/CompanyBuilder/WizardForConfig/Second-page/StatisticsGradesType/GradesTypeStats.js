import React from 'react';
import Avatar from '@mui/material/Avatar';
import Box from '@mui/material/Box';
import {green, red} from '@mui/material/colors';
import AppCard from '../../../../../../src/@crema/core/AppCard';
import {deepOrange, deepPurple} from '@mui/material/colors';
import PropTypes from 'prop-types';

import RecentActorsIcon from '@mui/icons-material/RecentActors';

const GradesTypeStats = ({data}) => {
  return (
    <AppCard
      sxStyle={{
        borderRadius: 4,
      }}
      className='card-hover'
    >
      <Box
        sx={{
          display: 'flex',
          alignItems: 'center',
        }}
      >
        <Avatar
          sx={{
            p: 3,
            fontSize: {xs: 30, md: 48},
            height: {xs: 46, md: 50, xl: 60},
            width: {xs: 46, md: 50, xl: 60},
            // backgroundColor: 'black',
            // bgcolor: 'black'
          }}
        >
          {/* <img alt='' src={{RecentActorsIcon}} /> */}
          {/* <RecentActorsIcon /> */}
          {data && data.icon && data.icon}
        </Avatar>

        <Box
          sx={{
            position: 'relative',
            ml: 4,
          }}
        >
          <Box
            component='p'
            sx={{
              fontSize: 14,
              color: 'text.secondary',
              mb: 2,
              whiteSpace: 'nowrap'
            }}
          >
            {/* {heading} */}
            {data && data.title && data.title}
          </Box>
          <Box
            component='h3'
            sx={{
              display: 'inline-block',
              //   fontWeight: Fonts.MEDIUM,
              fontSize: 17,
              mr: 3,
            }}
          >
            {/* ${data.price} */}
            {data && data.count && data.count.map(e => {
              return(
                <span>{` ${e},`}</span>
              )
            })}
            {/* {data && data.nestedList && data.nestedList.map(e => {
              return  (
                <div>{`name: ${e.name} status:${e.status}`}</div>
              )
            })} */}
            {/* {data && data.list && data.list.map(e => {
              return (
                <div>{e}</div>
              )
            })} */}
          </Box>
          <Box
            component='span'
            sx={{
              fontSize: 16,
              //   fontWeight: Fonts.MEDIUM,
              //   color: data.increment > 0.0 ? green[500] : red[500],
              color: green[500],
            }}
          >
            {data && data.nestedList && data.nestedList.map(e => {
              return  (
                <div>
                  {e.costCenterId && ` cost center id: ${e.costCenterId} /` }
                  {e.name && ` name: ${e.name} /` }
                  {e.status && ` status ${e.status} ` }
                </div>
                // <div>{`name: ${e.name} status:${e.status}`}</div>
              )
            })}
            {data && data.list && data.list.map(e => {
              return (
                <div>{e}</div>
              )
            })}
            {/* {data.increment}% */}
            {/* 43434 */}
          </Box>
        </Box>
      </Box>
    </AppCard>
  );
};

export default GradesTypeStats;
GradesTypeStats.propTypes = {
  data: PropTypes.object,
};
