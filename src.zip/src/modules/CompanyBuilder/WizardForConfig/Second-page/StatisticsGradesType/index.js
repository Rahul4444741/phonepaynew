import React from 'react';
import Grid from '@mui/material/Grid';
import GradesTypeStats from './GradesTypeStats';
import Box from '@mui/material/Box';
import PropTypes from 'prop-types';

const StatisticsGradesType = ({cardOneDetail, cardTwoDetail}) => {
  return (
    <Box>
      <Grid container spacing={{xs: 4, md: 8}}>
        <Grid item xs={12} sm={12}>
          <GradesTypeStats data={cardOneDetail} />
        </Grid>

        {/* <Grid item xs={12} sm={12}>
          <GradesTypeStats data={cardTwoDetail} />
        </Grid> */}
      </Grid>
    </Box>
  );
};

export default StatisticsGradesType;
StatisticsGradesType.propTypes = {
  cardOneDetail: PropTypes.object,
  cardTwoDetail: PropTypes.object,
};
