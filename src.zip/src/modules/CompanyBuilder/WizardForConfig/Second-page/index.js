import AppGridContainer from '@crema/core/AppGridContainer';
import AllInboxIcon from '@mui/icons-material/AllInbox';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import DoneAllIcon from '@mui/icons-material/DoneAll';
import InboxIcon from '@mui/icons-material/Inbox';
import SpeakerNotesOffIcon from '@mui/icons-material/SpeakerNotesOff';
import {green, grey, purple, red} from '@mui/material/colors';
import FormControl from '@mui/material/FormControl';
import Grid from '@mui/material/Grid';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Paper from '@mui/material/Paper';
import Select from '@mui/material/Select';
import Stack from '@mui/material/Stack';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import axios from 'axios';
import PropTypes, {object} from 'prop-types';
import React from 'react';
import {useDispatch, useSelector} from 'react-redux';
import StatisticsGradesType from './StatisticsGradesType';
import Slide from '@mui/material/Slide';
import {ImCross, ImCheckmark} from 'react-icons/im';

import {
  fetchError,
  fetchStart,
  fetchSuccess,
  showInfo,
  showMessage,
} from '../../../../redux/actions';
import {
  Box,
  Button,
  Checkbox,
  CircularProgress,
  ListItemIcon,
  ListItemText,
} from '@mui/material';
import jwtAxios from '@crema/services/auth/jwt-auth';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import Skeleton from '@mui/material/Skeleton';
import {apiCatchErrorMessage} from 'shared/utils/CommonUtils';
import IntlMessages from '@crema/utility/IntlMessages';

function createData(name, unmapped, header) {
  return {name, unmapped, header};
}

const item = ['ccenter', 'grage/level', 'employee', 'employement'];

const SecondPage = ({
  data,
  submitHandler,
  isLoadingUpload,
  setIsLoadingUpload,
}) => {
  const dispatch = useDispatch();
  let selectedCompanyId = useSelector(
    ({company}) => company?.selectedCompany?.id,
  );

  const [requiredVariable, setRequiredVariable] = React.useState([]);
  const [selectedData, setSelectedData] = React.useState({});
  const [csvEntityFields, setCsvEntityFields] = React.useState({
    totalIntity: [],
    intityDetails: [],
    leftIntity: [],
    headersDetais: {
      headers: [],
      headersIndex: {},
      headersMapedWith: {},
    },
    oldMappedHeadersWithIntityDetails: {
      mappedHeaders: [],
      headersWithIndex: [],
      intityWithIndex: [],
      oldIntity: [],
      oldHeaders: [],
    },
  });
  const [valueOfResponseRecord, setValueOfResponseRecord] = React.useState({
    blankRecords: null,
    duplicateRecords: null,
    successfullyUploaded: null,
    alreadyExistinDbRecords: null,
    mappingNotFound: null,
  });
  const [cardTrollyOpen, setCardTrollyOpen] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(false);
  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();
  React.useEffect(() => {
    submitHandler.isSubmit.buttonClicked && handlerSubmitButton();
  }, [submitHandler]);

  React.useEffect(() => {
    !submitHandler.isIntityGet && getCsventity();
  }, []);

  const menuItems = (row) => {
    let dom = [];
    csvEntityFields.intityDetails.forEach((element) => {
      dom.push(
        <MenuItem
          sx={{
            backgroundColor: requiredVariable.includes(element.intityName)
              ? '#f5f5dc'
              : 'white',
          }}
          value={element.intityName}
          disabled={!element.isVisible}
        >
          {element.intityName}
        </MenuItem>,
      );
    });
    return dom;
  };

  const rows = data.csvFileData.header.map((e) => {
    return createData('map', e.trim(), e.trim());
  });

  const handlerSubmitButton = async () => {
    const reverseKeyValuePair = (obj) =>
      Object.fromEntries(Object.entries(obj).map((a) => a.reverse()));
    const reversedDataForPost = reverseKeyValuePair(selectedData);
    const UploadFile = async (file, companyId, selectedObject) => {
      const formData = new FormData();
      formData.append('file', file);

      let config = {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        params: {
          ...reversedDataForPost,
        },
      };

      if (data.selectForApiType === 'create') {
        try {
          const response = await jwtAxios.post(
            `${API_ROUTS.csventity_upload}/${selectedObject}/${companyId}/create`,
            formData,
            config,
          );
          if (response.status == 200) {
            setCardTrollyOpen(true);

            const tempvalueOfResponseRecord = JSON.parse(
              JSON.stringify(valueOfResponseRecord),
            );

            tempvalueOfResponseRecord.blankRecords = null;
            tempvalueOfResponseRecord.duplicateRecords = null;
            tempvalueOfResponseRecord.successfullyUploaded = null;
            tempvalueOfResponseRecord.alreadyExistinDbRecords = null;
            tempvalueOfResponseRecord.mappingNotFound = null;

            tempvalueOfResponseRecord.blankRecords =
              response.data['Blank Records'];
            tempvalueOfResponseRecord.duplicateRecords =
              response.data.DuplicateRecords;
            tempvalueOfResponseRecord.successfullyUploaded =
              response.data['Successfully uploaded'];
            tempvalueOfResponseRecord.alreadyExistinDbRecords =
              response.data['Already Exist in Db Records'];
            tempvalueOfResponseRecord.mappingNotFound =
              response.data['Mapping Not found'];
            setValueOfResponseRecord(() => tempvalueOfResponseRecord);
            submitHandler.setIsSubmitResponse(() => true);
          } else {
            dispatch(showInfo(e.response.status));
          }
          setIsLoadingUpload(false);
        } catch (error) {
          apiCatchErrorMessage(error, dispatch, fetchError);
          setIsLoadingUpload(false);
        }
      } else if (data.selectForApiType === 'update') {
        try {
          const response = await jwtAxios.post(
            `${API_ROUTS.csventity_upload}/${selectedObject}/${companyId}/update`,
            formData,
            config,
          );
          if (response.status == 200) {
            setCardTrollyOpen(true);

            const tempvalueOfResponseRecord = JSON.parse(
              JSON.stringify(valueOfResponseRecord),
            );

            tempvalueOfResponseRecord.blankRecords = null;
            tempvalueOfResponseRecord.duplicateRecords = null;
            tempvalueOfResponseRecord.successfullyUploaded = null;
            tempvalueOfResponseRecord.alreadyExistinDbRecords = null;
            tempvalueOfResponseRecord.mappingNotFound = null;

            tempvalueOfResponseRecord.blankRecords =
              response.data['Blank Records'];
            tempvalueOfResponseRecord.duplicateRecords =
              response.data.DuplicateRecords;
            tempvalueOfResponseRecord.successfullyUploaded =
              response.data['Successfully uploaded'];
            tempvalueOfResponseRecord.alreadyExistinDbRecords =
              response.data['Already Exist in Db Records'];
            tempvalueOfResponseRecord.mappingNotFound =
              response.data['Mapping Not found'];
            setValueOfResponseRecord(() => tempvalueOfResponseRecord);
            submitHandler.setIsSubmitResponse(() => true);
          } else {
            dispatch(showInfo(e.response.status));
          }
          setIsLoadingUpload(false);
        } catch (error) {
          apiCatchErrorMessage(error, dispatch, fetchError);
          setIsLoadingUpload(false);
        }
      } else if (data.selectForApiType === 'terminate') {
        try {
          const response = await jwtAxios.post(
            `${API_ROUTS.csventity_upload}/${selectedObject}/${companyId}/terminate`,
            formData,
            config,
          );
          if (response.status == 200) {
            dispatch(showInfo('Employee Terminated Successfully'));
            setCardTrollyOpen(true);

            const tempvalueOfResponseRecord = JSON.parse(
              JSON.stringify(valueOfResponseRecord),
            );

            tempvalueOfResponseRecord.blankRecords = null;
            tempvalueOfResponseRecord.duplicateRecords = null;
            tempvalueOfResponseRecord.successfullyUploaded = null;
            tempvalueOfResponseRecord.alreadyExistinDbRecords = null;
            tempvalueOfResponseRecord.mappingNotFound = null;

            tempvalueOfResponseRecord.blankRecords =
              response.data['Blank Records'];
            tempvalueOfResponseRecord.duplicateRecords =
              response.data.DuplicateRecords;
            tempvalueOfResponseRecord.successfullyUploaded =
              response.data['Successfully uploaded'];
            tempvalueOfResponseRecord.alreadyExistinDbRecords =
              response.data['Already Exist in Db Records'];
            tempvalueOfResponseRecord.mappingNotFound =
              response.data['Mapping Not found'];
            setValueOfResponseRecord(() => tempvalueOfResponseRecord);
            submitHandler.setIsSubmitResponse(() => true);
          } else {
            dispatch(showInfo(response.status));
          }
          setIsLoadingUpload(false);
        } catch (error) {
          apiCatchErrorMessage(error, dispatch, fetchError);
          setIsLoadingUpload(false);
        }
      }
    };
    (await submitHandler.setIsApiHits) &&
      UploadFile(data.csvFileData.file, selectedCompanyId, data.selectedIndex);

    const tempClick = JSON.parse(JSON.stringify(submitHandler.isSubmit));
    tempClick.buttonClicked = false;
    submitHandler.setIsSubmit(() => tempClick);
    submitHandler.setIsApiHits(() => true);
  };

  const handleChange = (event, index, row) => {
    let tempCsvEntityFields = JSON.parse(JSON.stringify(csvEntityFields));
    let tempData = JSON.parse(JSON.stringify(selectedData));

    tempData[event.target.name.header] = event.target.value;
    const reverseKeyValuePair = (obj) =>
      Object.fromEntries(Object.entries(obj).map((a) => a.reverse()));
    const reversedTempData = reverseKeyValuePair(tempData);

    setSelectedData(() => tempData);
    if (
      data.selectedIndex != 'Employee' &&
      data.csvFileData.header.length == parseInt(Object.keys(tempData).length)
    ) {
      let tempSubmitHandler = JSON.parse(
        JSON.stringify(submitHandler.isSubmit),
      );
      tempSubmitHandler.submitVisible = true;
      submitHandler.setIsSubmit(() => tempSubmitHandler);
    } else if (
      requiredVariable.length > 0 &&
      requiredVariable.every((variable) =>
        Object.keys(reversedTempData).includes(variable),
      )
    ) {
      let tempSubmitHandler = JSON.parse(
        JSON.stringify(submitHandler.isSubmit),
      );
      tempSubmitHandler.submitVisible = true;
      submitHandler.setIsSubmit(() => tempSubmitHandler);
    } else {
      let tempSubmitHandler = JSON.parse(
        JSON.stringify(submitHandler.isSubmit),
      );
      tempSubmitHandler.submitVisible = false;
      submitHandler.setIsSubmit(() => tempSubmitHandler);
    }

    if (
      tempCsvEntityFields.headersDetais.headersMapedWith[index][
        tempCsvEntityFields.headersDetais.headers[index]
      ]
    ) {
      for (let key in tempCsvEntityFields.intityDetails) {
        if (
          tempCsvEntityFields.intityDetails[key].intityName ==
          tempCsvEntityFields.headersDetais.headersMapedWith[index][
            tempCsvEntityFields.headersDetais.headers[index]
          ]
        ) {
          tempCsvEntityFields.intityDetails[key].isVisible = true;
          setCsvEntityFields(() => tempCsvEntityFields);
        }
      }

      for (let key in tempCsvEntityFields.intityDetails) {
        if (
          tempCsvEntityFields.intityDetails[key].intityName ==
          event.target.value
        ) {
          tempCsvEntityFields.intityDetails[key].isVisible = false;
          tempCsvEntityFields.headersDetais.headersMapedWith[index][
            tempCsvEntityFields.headersDetais.headers[index]
          ] = event.target.value;
          setCsvEntityFields(() => tempCsvEntityFields);
        }
      }
    } else {
      for (let key in tempCsvEntityFields.intityDetails) {
        if (
          tempCsvEntityFields.intityDetails[key].intityName ==
          event.target.value
        ) {
          tempCsvEntityFields.intityDetails[key].isVisible = false;
          tempCsvEntityFields.headersDetais.headersMapedWith[index][
            tempCsvEntityFields.headersDetais.headers[index]
          ] = event.target.value;
          setCsvEntityFields(() => tempCsvEntityFields);
        }
      }
    }
    setCsvEntityFields(() => tempCsvEntityFields);
  };

  const getCsventity = async () => {
    setIsLoading(() => true);
    let tempCsvEntityFields = JSON.parse(JSON.stringify(csvEntityFields));
    let tempselectedData = JSON.parse(JSON.stringify(selectedData));
    let requiredVariableValuesArray = {};

    const getRequiredVariable = async (id, name, selectForApiType) => {
      try {
        const res = await jwtAxios.get(
          `${API_ROUTS.csventity_mandatory}?entityName=${name}&method=${data.selectForApiType}&companyId=${id}`,
          {
            cancelToken: source.token,
          },
        );
        if (res.status == 200) {
          requiredVariableValuesArray = Object.values(res.data);
          setRequiredVariable(Object.values(res.data));
        }
      } catch (error) {
        if (axios.isCancel(error)) {
        } else {
          apiCatchErrorMessage(error, dispatch, fetchError);
        }
      }
    };

    const getAllCsventity = async (id, name) => {
      try {
        const res = await jwtAxios.get(
          `${API_ROUTS.csventity_getCSVEntityFields}/${name}/${id}`,
          {
            cancelToken: source.token,
          },
        );
        if (res.status == 200) {
          const getheaders = async () => {
            let tempheaders = [];
            data.csvFileData.header.forEach((e) => tempheaders.push(e.trim()));
            tempCsvEntityFields.headersDetais.headers = tempheaders;
          };

          const getHeadersIndex = async () => {
            let tempIndexOfHeadersIndex = [];
            data.csvFileData.header.map((e, index) =>
              tempIndexOfHeadersIndex.push({
                headersName: e.trim(),
                index: index,
              }),
            );
            tempCsvEntityFields.headersDetais.headersIndex =
              tempIndexOfHeadersIndex;
          };

          const getHeadersMapedWith = async () => {
            let tempHeadersMapedWith = [];
            data.csvFileData.header.map((f, index) =>
              tempHeadersMapedWith.push({[f.trim()]: null}),
            );
            tempCsvEntityFields.headersDetais.headersMapedWith =
              tempHeadersMapedWith;
          };

          const getTotalIntity = async () => {
            tempCsvEntityFields.totalIntity = res.data;
          };

          const getIntityDetails = async () => {
            res.data.map((e, index) =>
              tempCsvEntityFields.intityDetails.push({
                intityName: e,
                isVisible: true,
                index: index,
              }),
            );
          };

          const getLeftIntity = async () => {
            tempCsvEntityFields.leftIntity = res.data;
          };

          getheaders();
          getHeadersIndex();
          getHeadersMapedWith();
          getTotalIntity();
          getIntityDetails();
          getLeftIntity();
        }
      } catch (error) {
        if (axios.isCancel(error)) {
        } else {
          apiCatchErrorMessage(error, dispatch, fetchError);
        }
      }
    };

    const getOldMappedIntityWighHeaders = async (id, name) => {
      try {
        const res = await jwtAxios.get(
          `${API_ROUTS.getOldMappings}?className=${name}&companyId=${id}`,
          {
            cancelToken: source2.token,
          },
        );
        if (res.status == 200 && Object.keys(res.data).length > 0) {
          const getMappedHeadersData = async () => {
            let tempMappedHeadersData = [];
            for (let key in res.data) {
              tempMappedHeadersData.push({[key]: res.data[key]});
            }
            tempCsvEntityFields.oldMappedHeadersWithIntityDetails.mappedHeaders =
              tempMappedHeadersData;
          };

          const getHeadersWithIndex = async () => {
            let tempHeadersWithIndex = [];
            let index = 0;
            for (let key in res.data) {
              tempHeadersWithIndex.push({
                headersName: res.data[key],
                index: index,
              });
              index++;
            }
            tempCsvEntityFields.oldMappedHeadersWithIntityDetails.headersWithIndex =
              tempHeadersWithIndex;
          };

          const getIntityWithIndex = async () => {
            let tempIntityWithIndex = [];
            let index = 0;
            for (let key in res.data) {
              tempIntityWithIndex.push({intityName: key, index: index});
              index++;
            }
            tempCsvEntityFields.oldMappedHeadersWithIntityDetails.intityWithIndex =
              tempIntityWithIndex;
          };

          const getOldIntity = async () => {
            let tempOldIntity = [];
            for (let key in res.data) {
              tempOldIntity.push(key);
            }
            tempCsvEntityFields.oldMappedHeadersWithIntityDetails.oldIntity =
              tempOldIntity;
          };

          const getOldHeaders = async () => {
            let tempOldHeaders = [];
            for (let key in res.data) {
              tempOldHeaders.push(res.data[key]);
            }
            tempCsvEntityFields.oldMappedHeadersWithIntityDetails.oldHeaders =
              tempOldHeaders;
          };

          getMappedHeadersData();
          getHeadersWithIndex();
          getIntityWithIndex();
          getOldIntity();
          getOldHeaders();

          /////////// working on sync /////////

          const syncOldHeadersWithNewHeaders = async () => {
            tempCsvEntityFields.headersDetais.headersMapedWith.forEach(
              (e, indexE) => {
                tempCsvEntityFields.oldMappedHeadersWithIntityDetails.mappedHeaders.forEach(
                  (f, indexF) => {
                    if (
                      tempCsvEntityFields.totalIntity.includes(
                        Object.keys(f)[0],
                      ) &&
                      tempCsvEntityFields.headersDetais.headersIndex[indexE]
                        .headersName ==
                        tempCsvEntityFields.oldMappedHeadersWithIntityDetails
                          .headersWithIndex[indexF].headersName
                    ) {
                      tempCsvEntityFields.headersDetais.headersMapedWith[
                        indexE
                      ][
                        tempCsvEntityFields.headersDetais.headersIndex[
                          indexE
                        ].headersName
                      ] =
                        tempCsvEntityFields.oldMappedHeadersWithIntityDetails.oldIntity[
                          indexF
                        ];
                    }
                  },
                );
              },
            );
          };

          const syncisVisible = async () => {
            let tempIntityDetails = tempCsvEntityFields.intityDetails;
            tempCsvEntityFields.intityDetails.forEach((e, indexE) => {
              tempCsvEntityFields.headersDetais.headersMapedWith.forEach(
                (f, indexF) => {
                  if (
                    e.intityName ==
                    f[tempCsvEntityFields.headersDetais.headers[indexF]]
                  ) {
                    e.isVisible = false;
                  }
                },
              );
            });
          };

          const syncSelectedData = async () => {
            tempCsvEntityFields.headersDetais.headersMapedWith.forEach(
              (e, index) => {
                if (
                  e[
                    tempCsvEntityFields.headersDetais.headersIndex[index]
                      .headersName
                  ]
                ) {
                  tempselectedData[
                    tempCsvEntityFields.headersDetais.headersIndex[
                      index
                    ].headersName
                  ] =
                    e[
                      tempCsvEntityFields.headersDetais.headersIndex[
                        index
                      ].headersName
                    ];
                }
              },
            );
          };

          const syncIsSubmit = async () => {
            const reverseKeyValuePair = (obj) =>
              Object.fromEntries(Object.entries(obj).map((a) => a.reverse()));
            const reversedTempData = reverseKeyValuePair(tempselectedData);

            if (
              data.selectedIndex != 'Employee' &&
              data.csvFileData.header.length ==
                parseInt(Object.keys(tempselectedData).length)
            ) {
              let tempSubmitHandler = JSON.parse(
                JSON.stringify(submitHandler.isSubmit),
              );
              tempSubmitHandler.submitVisible = true;
              submitHandler.setIsSubmit(() => tempSubmitHandler);
            } else if (
              requiredVariableValuesArray.length > 0 &&
              requiredVariableValuesArray.every((variable) =>
                Object.keys(reversedTempData).includes(variable),
              )
            ) {
              let tempSubmitHandler = JSON.parse(
                JSON.stringify(submitHandler.isSubmit),
              );
              tempSubmitHandler.submitVisible = true;
              submitHandler.setIsSubmit(() => tempSubmitHandler);
            } else {
              let tempSubmitHandler = JSON.parse(
                JSON.stringify(submitHandler.isSubmit),
              );
              tempSubmitHandler.submitVisible = false;
              submitHandler.setIsSubmit(() => tempSubmitHandler);
            }
          };

          await syncOldHeadersWithNewHeaders();
          await syncisVisible();
          await syncSelectedData();
          await syncIsSubmit();
        }
      } catch (error) {
        if (axios.isCancel(error)) {
        } else {
          apiCatchErrorMessage(error, dispatch, fetchError);
        }
      }
    };
    if (data.selectedIndex == 'Employee') {
      await getRequiredVariable(
        selectedCompanyId,
        data.selectedIndex,
        data.selectForApiType,
      );
    }
    await getAllCsventity(selectedCompanyId, data.selectedIndex);
    await getOldMappedIntityWighHeaders(selectedCompanyId, data.selectedIndex);
    submitHandler.setIsIntityGet(() => true);
    setCsvEntityFields(() => tempCsvEntityFields);
    setSelectedData(() => tempselectedData);
    setIsLoading(() => false);
  };

  const fieldType = () => {
    if (data.selectForApiType === 'create') {
      return <IntlMessages id='importWizard.add' />;
    } else if (data.selectForApiType === 'terminate') {
      return <IntlMessages id='importWizard.terminate' />;
    } else {
      return <IntlMessages id='importWizard.edit' />;
    }
  };
  return (
    <Stack>
      <Stack style={{width: '100%'}}>
        <h3 style={{marginBottom: 1}}>
          {fieldType()} <IntlMessages id='importWizard.field' />:{' '}
          {data.selectedIndex === 'CostCenter' ? (
            <IntlMessages id='sidebar.companybuilder.costcenters' />
          ) : data.selectedIndex === 'Employee' ? (
            <IntlMessages id='sidebar.companybuilder.employee' />
          ) : data.selectedIndex === 'EmployeeType' ? (
            <IntlMessages id='sidebar.companybuilder.types' />
          ) : data.selectedIndex === 'EmployeeStatus' ? (
            <IntlMessages id='sidebar.companybuilder.employeestatus' />
          ) : data.selectedIndex === 'EmployeeRole' ? (
            <IntlMessages id='sidebar.companybuilder.types' />
          ) : data.selectedIndex === 'EmploymentStatus' ? (
            <IntlMessages id='sidebar.companybuilder.workPermitStatus' />
          ) : (
            ''
          )}
        </h3>
        <Stack style={{marginBottom: 20}}>
          <IntlMessages id='providerReporting.edit.yourFileHasBeenAutoMapped' />
        </Stack>
        {data.selectedIndex === 'Employee' && (
          <Stack style={{marginBottom: 20, color: 'red', fontSize: '0.75rem'}}>
            * {`${requiredVariable.join(', ')} are mandatory.`}
          </Stack>
        )}
      </Stack>
      {isLoadingUpload ? (
        <TableBody>
          <div
            className='ag-theme-alpine'
            style={{
              width: '100%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <Box
              sx={{
                display: 'flex',
                width: '100%',
                justifyContent: 'center',
              }}
            >
              <CircularProgress />
            </Box>
          </div>
        </TableBody>
      ) : (
        <Stack style={{maxWidth: 650}}>
          <div className='ag-theme-alpine' style={{width: '100%'}}>
            <TableContainer component={Paper}>
              <Table sx={{minWidth: 400}} aria-label='simple table'>
                <TableHead>
                  <TableRow>
                    <TableCell
                      sx={{backgroundColor: purple['100']}}
                      align='center'
                    >
                      <IntlMessages id='providerReporting.edit.CSVHeader' />
                    </TableCell>

                    <TableCell
                      sx={{backgroundColor: purple['100']}}
                      align='center'
                    >
                      <IntlMessages id='providerReporting.edit.mappingStatus' />
                    </TableCell>
                    <TableCell
                      sx={{backgroundColor: purple['100']}}
                      align='center'
                    >
                      <IntlMessages id='common.button.Edit' />
                    </TableCell>
                    <TableCell
                      sx={{backgroundColor: purple['100']}}
                      align='center'
                    >
                      <IntlMessages id='common.button.Deselect' />
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {rows.map((row, index) => (
                    <TableRow
                      key={row.name}
                      sx={{'&:last-child td, &:last-child th': {border: 0}}}
                    >
                      <TableCell
                        sx={{backgroundColor: green['100']}}
                        align='center'
                      >
                        {row.header}
                      </TableCell>
                      <TableCell
                        sx={{backgroundColor: red['50']}}
                        align='center'
                      >
                        {selectedData[row.unmapped] ? 'mapped' : 'unmapped'}
                      </TableCell>
                      <TableCell
                        sx={{backgroundColor: red['50']}}
                        component='th'
                        scope='row'
                      >
                        <FormControl fullWidth>
                          <InputLabel id='demo-simple-select-label'>
                            Map
                          </InputLabel>
                          {isLoading && (
                            <Skeleton
                              variant='rounded'
                              width={200}
                              height={55}
                            />
                          )}
                          {!isLoading && csvEntityFields && (
                            <Select
                              disabled={
                                valueOfResponseRecord.alreadyExistinDbRecords ||
                                valueOfResponseRecord.blankRecords ||
                                valueOfResponseRecord.duplicateRecords ||
                                valueOfResponseRecord.mappingNotFound ||
                                valueOfResponseRecord.successfullyUploaded
                              }
                              labelId='demo-simple-select-label'
                              id={`${index}${row.header}`}
                              name={row}
                              key={row}
                              value={
                                csvEntityFields.headersDetais.headersMapedWith
                                  .length > 0
                                  ? csvEntityFields.headersDetais
                                      .headersMapedWith[index][
                                      csvEntityFields.headersDetais.headers[
                                        index
                                      ]
                                    ]
                                  : ''
                              }
                              label='Age'
                              onChange={(event) =>
                                handleChange(event, index, row)
                              }
                            >
                              {menuItems(row)}
                            </Select>
                          )}
                        </FormControl>
                      </TableCell>
                      <TableCell
                        sx={{backgroundColor: green['100']}}
                        align='center'
                      >
                        {selectedData[row.unmapped] ? (
                          <ImCross
                            style={{cursor: 'pointer', color: 'red'}}
                            onClick={(event) => {
                              let tempData = JSON.parse(
                                JSON.stringify(selectedData),
                              );
                              let tempCsvEntityFields = JSON.parse(
                                JSON.stringify(csvEntityFields),
                              );

                              tempCsvEntityFields.intityDetails.find((elem) => {
                                return (
                                  elem.intityName ==
                                  tempCsvEntityFields.headersDetais
                                    .headersMapedWith[index][
                                    tempCsvEntityFields.headersDetais.headers[
                                      index
                                    ]
                                  ]
                                );
                              }).isVisible = true;
                              tempCsvEntityFields.headersDetais.headersMapedWith[
                                index
                              ][
                                tempCsvEntityFields.headersDetais.headers[index]
                              ] = '';
                              delete tempData[`${row.header}`];
                              const reverseKeyValuePair = (obj) =>
                                Object.fromEntries(
                                  Object.entries(obj).map((a) => a.reverse()),
                                );
                              const reversedTempData =
                                reverseKeyValuePair(tempData);

                              if (
                                requiredVariable.length > 0 &&
                                requiredVariable.every((variable) =>
                                  Object.keys(reversedTempData).includes(
                                    variable,
                                  ),
                                )
                              ) {
                                let tempSubmitHandler = JSON.parse(
                                  JSON.stringify(submitHandler.isSubmit),
                                );
                                tempSubmitHandler.submitVisible = true;
                                submitHandler.setIsSubmit(
                                  () => tempSubmitHandler,
                                );
                              } else {
                                let tempSubmitHandler = JSON.parse(
                                  JSON.stringify(submitHandler.isSubmit),
                                );
                                tempSubmitHandler.submitVisible = false;
                                submitHandler.setIsSubmit(
                                  () => tempSubmitHandler,
                                );
                              }

                              setSelectedData(() => tempData);
                              setCsvEntityFields(() => tempCsvEntityFields);
                            }}
                          />
                        ) : (
                          ''
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </div>
        </Stack>
      )}

      {cardTrollyOpen && (
        <AppGridContainer
          sx={{marginTop: 3}}
          container
          justifyContent='flex-end'
        >
          <Slide direction='up' in={valueOfResponseRecord.duplicateRecords}>
            <Grid item xs={12} md={4}>
              <StatisticsGradesType
                cardOneDetail={{
                  title: (
                    <IntlMessages id='importWizard.successfullyUploaded' />
                  ),
                  count: valueOfResponseRecord.successfullyUploaded,
                  icon: <DoneAllIcon sx={{color: grey[900]}} />,
                }}
              />
            </Grid>
          </Slide>

          <Slide direction='up' in={valueOfResponseRecord.duplicateRecords}>
            <Grid item xs={12} md={4}>
              <StatisticsGradesType
                cardOneDetail={{
                  title: <IntlMessages id='importWizard.duplicateRecords' />,
                  count: valueOfResponseRecord.duplicateRecords,
                  icon: <ContentCopyIcon sx={{color: grey[900]}} />,
                }}
              />
            </Grid>
          </Slide>

          <Slide direction='up' in={valueOfResponseRecord.duplicateRecords}>
            <Grid item xs={12} md={4}>
              <StatisticsGradesType
                cardOneDetail={{
                  title: <IntlMessages id='importWizard.blankRecords' />,
                  count: valueOfResponseRecord.blankRecords,
                  icon: <InboxIcon sx={{color: grey[900]}} />,
                }}
              />
            </Grid>
          </Slide>

          <Slide direction='up' in={valueOfResponseRecord.duplicateRecords}>
            <Grid item xs={12} md={6}>
              <StatisticsGradesType
                cardOneDetail={{
                  title: (
                    <IntlMessages id='importWizard.alreadyExistDbRecords' />
                  ),
                  nestedList: valueOfResponseRecord.alreadyExistinDbRecords,
                  icon: <AllInboxIcon sx={{color: grey[900]}} />,
                }}
              />
            </Grid>
          </Slide>

          <Slide direction='up' in={valueOfResponseRecord.duplicateRecords}>
            <Grid item xs={12} md={6}>
              <StatisticsGradesType
                cardOneDetail={{
                  title: <IntlMessages id='importWizard.mappingNotFound' />,
                  list: valueOfResponseRecord.mappingNotFound,
                  icon: <SpeakerNotesOffIcon sx={{color: grey[900]}} />,
                }}
              />
            </Grid>
          </Slide>
        </AppGridContainer>
      )}
    </Stack>
  );
};

export default SecondPage;
SecondPage.propTypes = {
  data: PropTypes.object,
  submitHandler: PropTypes.object,
  isLoadingUpload: PropTypes.bool,
  setIsLoadingUpload: PropTypes.any,
};
