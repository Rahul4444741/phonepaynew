import AppAnimate from '../../../@crema/core/AppAnimate';
import {AppCard} from '../../../@crema';
import AppPageMeta from '../../../@crema/core/AppPageMeta';
import Box from '@mui/material/Box';
import React from 'react';
import {red} from '@mui/material/colors';
import Stack from '@mui/material/Stack';
import DoneIcon from '@mui/icons-material/Done';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import {useDispatch, useSelector} from 'react-redux';
import PropTypes from 'prop-types';
import Typography from '@mui/material/Typography';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import Divider from '@mui/material/Divider';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import InboxIcon from '@mui/icons-material/Inbox';
import ListSubheader from '@mui/material/ListSubheader';
import ExpandLess from '@mui/icons-material/ExpandLess';
import ExpandMore from '@mui/icons-material/ExpandMore';
import Collapse from '@mui/material/Collapse';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import Button from '@mui/material/Button';
import Fade from '@mui/material/Fade';
import SecondPage from './Second-page';
import AppInfoView from '../../../@crema/core/AppInfoView';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import {fetchError} from '../../../redux/actions';
import {CircularProgress} from '@mui/material';
import IntlMessages from '@crema/utility/IntlMessages';
import {isAllowedUser} from 'shared/utils/CommonUtils';
import {permissionName} from 'shared/utils/PermissionName';
import Error403 from 'modules/errorPages/Error403';
import { domCreactionGridSkeletonLoader } from 'shared/utils/domCreaction';

const configModule = `name ,status
,Capital Only
Row 2-3 provide instructions to update data. Please delete row 2-3 when uploading data. Save file as .csv and upload
`;

const configModuleSubFunction = `name ,function ,status
,,Capital Only
Row 2-3 provide instructions to update data. Please delete row 2-3 when uploading data. Save file as .csv and upload`;

const configModuleJobCode = `Job Code ,Status ,Job Title,Effective Date,Breakout Name,Peer Group Name,Monetary Unit,Job Module,Job Function,Job Area,Job Focus,Job Category,Job Level,Job Family,Tech/Non-Tech,Role Type
Mandatory / Unique,Mandatory
,Capital Only(ACTIVE/INACTIVE)
Row 2-4 provide instructions to update data., Please delete row 2-3 when uploading data., Save file as .csv and upload,
`;

function TabPanel(props) {
  const {children, value, index, ...other} = props;

  return (
    <div
      role='tabpanel'
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{p: 3}}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

const style = {
  width: '100%',
  maxWidth: 360,
  bgcolor: 'background.paper',
};

const WizardForConfig = () => {
  let selectedCompanyId = useSelector(
    ({company}) => company?.selectedCompany?.id,
  );
  const dispatch = useDispatch();

  const [tabKindOfData, setTabKindOfData] = React.useState(0);
  const [selectedIndex, setSelectedIndex] = React.useState(null);
  const [csvFileOpen, setCsvFileOpen] = React.useState(true);

  const [csvFileData, setCsvFileData] = React.useState({
    file: null,
    header: [],
    separateValueBy: ',',
  });
  const [openModule, setOpenModule] = React.useState({pageNumber: 0});
  const [isSubmit, setIsSubmit] = React.useState({
    submitVisible: false,
    buttonClicked: false,
  });
  const [selectForApiType, setSelectForApiType] = React.useState('create');
  const [isSubmitResponse, setIsSubmitResponse] = React.useState(false);
  const [isApiHits, setIsApiHits] = React.useState(false);
  const [isIntityGet, setIsIntityGet] = React.useState(false);
  const [isLoadingUpload, setIsLoadingUpload] = React.useState(false);

  const [demoCsvFileOpenDownload, demoCetCsvFileOpenDownload] =
    React.useState(true);
  const [loadingDemoCsvButton, setLoadingDemoCsvButton] = React.useState(false);

  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);

  React.useEffect(() => {
    if (isAllowedUser(permissionName.COMPANY_VARIABLES_IMPORT_WIZARD)) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  const handleChange = (event, newValue) => {
    setTabKindOfData(newValue);
  };

  const handleListItemClick = (event, index) => {
    if (selectedIndex == index) {
      setSelectedIndex(null);
    } else {
      setSelectedIndex(index);
    }
  };
  const handleClick = () => {
    setCsvFileOpen(!csvFileOpen);
  };

  const handleCaptureFile = (event) => {
    const tempCsvData = JSON.parse(JSON.stringify(csvFileData));

    const file =
      event.target.files.length > 0 ? event.target.files[0] : undefined;

    if (!file) {
      dispatch(fetchError('Invalid file'));
      return;
    }

    tempCsvData.file = file;

    const processCSV = (str, delim = ',') => {
      const headers = str.slice(0, str.indexOf('\n')).split(delim);
      const rows = str.slice(str.indexOf('\n') + 1).split('\n');
      tempCsvData.header = headers;
    };

    const reader = new FileReader();

    reader.onload = function (e) {
      const text = e.target.result;
      processCSV(text, tempCsvData.separateValueBy);
    };
    reader.readAsText(file);

    setCsvFileData(() => tempCsvData);
  };

  const handleChangeSeparateValueBy = (event) => {
    const tempCsvFileData = JSON.parse(JSON.stringify(csvFileData));
    tempCsvFileData.separateValueBy = event.target.value;
    tempCsvFileData.header = [];
    setCsvFileData(() => tempCsvFileData);
  };

  const handleApiType = (event, index) => {
    setSelectForApiType(() => index);
  };

  const downloadCsv = async () => {
    let demoCsvIntity = null;

    if (selectedIndex === 'EmployeeSubFunction') {
      demoCsvIntity = configModuleSubFunction;
    } else if (selectedIndex === 'JobCode') {
      demoCsvIntity = configModuleJobCode;
    } else {
      demoCsvIntity = configModule;
    }
    demoCsvIntity &&
      download('CSV', `${selectedIndex}demo.csv`, 'text/csv', demoCsvIntity);
  };

  const download = (name, filename, type, data) => {
    let blob = new Blob([data], {type: type});
    let url = window.URL.createObjectURL(blob);
    if (navigator.msSaveOrOpenBlob) {
      navigator.msSaveBlob(blob, name);
    } else {
      let a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
    window.URL.revokeObjectURL(url);
  };

  const importDataModule = () => {
    return (
      <Stack>
        <Stack style={{width: 350}}>
          <Stack style={{marginBottom: 20}}>
            <IntlMessages id='importWizard.youCanImportMsg' />
          </Stack>
        </Stack>

        <Stack
          style={{width: '100%', marginBottom: 10, overflowX: 'auto'}}
          direction={{xs: 'column', sm: 'row'}}
          spacing={10}
        >
          <Stack
            style={{
              width: 350,
              minWidth: 312,
            }}
          >
            <h4 style={{marginBottom: 10}}>
              <IntlMessages id='importWizard.WhatKindOfDataMsg' />
            </h4>
            <Box
              sx={{
                width: '100%',
                height: 430,
                border: 1,
                borderColor: 'rgba(0, 0, 0, 0.12)',
              }}
            >
              <Box
                sx={{
                  borderBottom: 1,
                  borderColor: 'divider',
                }}
              >
                {/* <Tabs
                  sx={{backgroundColor: red[200]}}
                  value={tabKindOfData}
                  onChange={handleChange}
                  aria-label='basic tabs example'
                >
                  <Tab
                    sx={{
                      backgroundColor: tabKindOfData == 0 ? '#ffffff' : '',
                    }}
                    label={<IntlMessages id='importWizard.standardObjects' />}
                    {...a11yProps(0)}
                  />
                  <Tab
                    sx={{
                      backgroundColor: tabKindOfData == 1 ? '#ffffff' : '',
                    }}
                    label={<IntlMessages id='importWizard.customObjects' />}
                    {...a11yProps(1)}
                  />
                </Tabs> */}
                <List
                  sx={{
                    width: '100%',
                    maxWidth: 360,
                    bgcolor: 'background.paper',
                  }}
                  component='nav'
                  aria-labelledby='nested-list-subheader'
                  subheader={
                    <ListSubheader
                      component='div'
                      id='nested-list-subheader'
                      sx={{
                        display: 'flex',
                        alignItems: 'center',
                        width: '100%',
                        justifyContent: 'space-between',
                        bgcolor: red[200],
                      }}
                    >
                      <IntlMessages id='importWizard.standardObjects' />
                    </ListSubheader>
                  }
                >
                  <Divider />

                  <TabPanel
                    className='parent-list'
                    value={tabKindOfData}
                    index={0}
                  >
                    <Box
                      sx={{
                        width: '100%',
                        maxWidth: 360,
                        bgcolor: 'background.paper',
                      }}
                    >
                      <List component='nav' aria-label='main mailbox folders'>
                        <ListItemButton
                          selected={selectedIndex === 'EmployeeLevel'}
                          onClick={(event) =>
                            handleListItemClick(event, 'EmployeeLevel')
                          }
                        >
                          <ListItemText
                            primaryTypographyProps={{fontSize: '18px'}}
                            primary={
                              <IntlMessages id='sidebar.companybuilder.roles' />
                            }
                          />
                          {selectedIndex === 'EmployeeLevel' ? (
                            <ListItemIcon>
                              <DoneIcon />
                            </ListItemIcon>
                          ) : (
                            <ListItemIcon>
                              <ChevronRightIcon />
                            </ListItemIcon>
                          )}
                        </ListItemButton>

                        <Divider />

                        <ListItemButton
                          selected={selectedIndex === 'EmployeeType'}
                          onClick={(event) =>
                            handleListItemClick(event, 'EmployeeType')
                          }
                        >
                          <ListItemText
                            primaryTypographyProps={{fontSize: '18px'}}
                            primary={
                              <IntlMessages id='sidebar.companybuilder.types' />
                            }
                          />
                          {selectedIndex === 'EmployeeType' ? (
                            <ListItemIcon>
                              <DoneIcon />
                            </ListItemIcon>
                          ) : (
                            <ListItemIcon>
                              <ChevronRightIcon />
                            </ListItemIcon>
                          )}
                        </ListItemButton>

                        <Divider />

                        <ListItemButton
                          selected={selectedIndex === 'EmployeeStatus'}
                          onClick={(event) =>
                            handleListItemClick(event, 'EmployeeStatus')
                          }
                        >
                          <ListItemText
                            primaryTypographyProps={{fontSize: '18px'}}
                            primary={
                              <IntlMessages id='sidebar.companybuilder.employeestatus' />
                            }
                          />
                          {selectedIndex === 'EmployeeStatus' ? (
                            <ListItemIcon>
                              <DoneIcon />
                            </ListItemIcon>
                          ) : (
                            <ListItemIcon>
                              <ChevronRightIcon />
                            </ListItemIcon>
                          )}
                        </ListItemButton>

                        <Divider />

                        <ListItemButton
                          selected={selectedIndex === 'EmployeeFunction'}
                          onClick={(event) =>
                            handleListItemClick(event, 'EmployeeFunction')
                          }
                        >
                          <ListItemText
                            primaryTypographyProps={{fontSize: '18px'}}
                            primary={
                              <IntlMessages id='sidebar.companybuilder.functions' />
                            }
                          />
                          {selectedIndex === 'EmployeeFunction' ? (
                            <ListItemIcon>
                              <DoneIcon />
                            </ListItemIcon>
                          ) : (
                            <ListItemIcon>
                              <ChevronRightIcon />
                            </ListItemIcon>
                          )}
                        </ListItemButton>

                        <Divider />

                        <ListItemButton
                          selected={selectedIndex === 'EmployeeSubFunction'}
                          onClick={(event) =>
                            handleListItemClick(event, 'EmployeeSubFunction')
                          }
                        >
                          <ListItemText
                            primaryTypographyProps={{fontSize: '18px'}}
                            primary={
                              <IntlMessages id='sidebar.companybuilder.subFunctions' />
                            }
                          />
                          {selectedIndex === 'EmployeeSubFunction' ? (
                            <ListItemIcon>
                              <DoneIcon />
                            </ListItemIcon>
                          ) : (
                            <ListItemIcon>
                              <ChevronRightIcon />
                            </ListItemIcon>
                          )}
                        </ListItemButton>

                        <Divider />

                        <ListItemButton
                          selected={selectedIndex === 'CulturalValue'}
                          onClick={(event) =>
                            handleListItemClick(event, 'CulturalValue')
                          }
                        >
                          <ListItemText
                            primaryTypographyProps={{fontSize: '18px'}}
                            primary={
                              <IntlMessages id='sidebar.companybuilder.values' />
                            }
                          />
                          {selectedIndex === 'CulturalValue' ? (
                            <ListItemIcon>
                              <DoneIcon />
                            </ListItemIcon>
                          ) : (
                            <ListItemIcon>
                              <ChevronRightIcon />
                            </ListItemIcon>
                          )}
                        </ListItemButton>

                        <Divider />

                        <ListItemButton
                          selected={selectedIndex === 'JobCode'}
                          onClick={(event) =>
                            handleListItemClick(event, 'JobCode')
                          }
                        >
                          <ListItemText
                            primaryTypographyProps={{fontSize: '18px'}}
                            primary={'Job Code'}
                          />
                          {selectedIndex === 'JobCode' ? (
                            <ListItemIcon>
                              <DoneIcon />
                            </ListItemIcon>
                          ) : (
                            <ListItemIcon>
                              <ChevronRightIcon />
                            </ListItemIcon>
                          )}
                        </ListItemButton>

                        <Divider />
                      </List>
                    </Box>
                  </TabPanel>
                </List>
              </Box>
            </Box>
          </Stack>

          {selectedIndex && (
            <Fade in={selectedIndex}>
              <Stack style={{width: 350, minWidth: 280}}>
                <h4 style={{marginBottom: 10}}>
                  <IntlMessages id='importWizard.WhatDoYouWantToDo' />
                </h4>
                <Box
                  sx={{
                    width: '100%',
                    height: 430,
                    border: 1,
                    borderColor: 'rgba(0, 0, 0, 0.12)',
                  }}
                >
                  <List
                    sx={{
                      width: '100%',
                      maxWidth: 360,
                      bgcolor: 'background.paper',
                    }}
                    component='nav'
                    aria-labelledby='nested-list-subheader'
                    subheader={
                      <ListSubheader
                        component='div'
                        id='nested-list-subheader'
                        sx={{
                          display: 'flex',
                          alignItems: 'center',
                          width: '100%',
                          justifyContent: 'space-between',
                          bgcolor: red[200],
                        }}
                      >
                        <IntlMessages id='templeteConfiguration.create.select' />
                      </ListSubheader>
                    }
                  >
                    <Divider />

                    <TabPanel
                      className='parent-list'
                      value={tabKindOfData}
                      index={0}
                    >
                      <Box
                        sx={{
                          width: '100%',
                          maxWidth: 360,
                          bgcolor: 'background.paper',
                        }}
                      >
                        <List component='nav' aria-label='main mailbox folders'>
                          <ListItemButton
                            selected={selectForApiType === 'create'}
                            onClick={(event) => handleApiType(event, 'create')}
                          >
                            <ListItemText
                              primaryTypographyProps={{fontSize: '18px'}}
                              primary={
                                <IntlMessages id='importWizard.addNewRecord' />
                              }
                            />
                            {selectForApiType === 'create' ? (
                              <ListItemIcon>
                                <DoneIcon />
                              </ListItemIcon>
                            ) : (
                              <ListItemIcon>
                                <ChevronRightIcon />
                              </ListItemIcon>
                            )}
                          </ListItemButton>

                          <Divider />

                          <ListItemButton
                            selected={selectForApiType === 'update'}
                            onClick={(event) => handleApiType(event, 'update')}
                          >
                            <ListItemText
                              primaryTypographyProps={{fontSize: '18px'}}
                              primary={
                                <IntlMessages id='importWizard.updateExistingRecords' />
                              }
                            />
                            {selectForApiType === 'update' ? (
                              <ListItemIcon>
                                <DoneIcon />
                              </ListItemIcon>
                            ) : (
                              <ListItemIcon>
                                <ChevronRightIcon />
                              </ListItemIcon>
                            )}
                          </ListItemButton>

                          <Divider />

                          {selectedIndex === 'Employee' && (
                            <ListItemButton
                              selected={selectForApiType === 'deactivate'}
                              onClick={(event) =>
                                handleApiType(event, 'deactivate')
                              }
                            >
                              <ListItemText
                                primaryTypographyProps={{fontSize: '18px'}}
                                primary={
                                  <IntlMessages id='importWizard.terminateEmployeeRecord' />
                                }
                              />
                              {selectForApiType === 'deactivate' ? (
                                <ListItemIcon>
                                  <DoneIcon />
                                </ListItemIcon>
                              ) : (
                                <ListItemIcon>
                                  <ChevronRightIcon />
                                </ListItemIcon>
                              )}
                            </ListItemButton>
                          )}

                          <Divider />

                          <Divider />

                          {selectedIndex === 'Employee' && (
                            <ListItemButton
                              selected={selectForApiType === 'changePassword'}
                              onClick={(event) =>
                                handleApiType(event, 'changePassword')
                              }
                            >
                              <ListItemText
                                primaryTypographyProps={{fontSize: '18px'}}
                                primary={
                                  <IntlMessages id='importWizard.resetPassword' />
                                }
                              />
                              {selectForApiType === 'changePassword' ? (
                                <ListItemIcon>
                                  <DoneIcon />
                                </ListItemIcon>
                              ) : (
                                <ListItemIcon>
                                  <ChevronRightIcon />
                                </ListItemIcon>
                              )}
                            </ListItemButton>
                          )}

                          <Divider />
                        </List>
                      </Box>
                    </TabPanel>
                  </List>
                </Box>
              </Stack>
            </Fade>
          )}

          {selectedIndex && (
            <Fade in={selectedIndex}>
              <Stack style={{width: 350, minWidth: 280}}>
                <h4 style={{marginBottom: 10}}>
                  <IntlMessages id='importWizard.whereIsYourDataLocated' />
                </h4>
                <Box
                  sx={{
                    width: '100%',
                    height: 430,
                    border: 1,
                    borderColor: 'rgba(0, 0, 0, 0.12)',
                  }}
                >
                  <List
                    sx={{
                      width: '100%',
                      maxWidth: 360,
                      bgcolor: 'background.paper',
                    }}
                    component='nav'
                    aria-labelledby='nested-list-subheader'
                    subheader={
                      <ListSubheader
                        component='div'
                        id='nested-list-subheader'
                        sx={{
                          bgcolor: red[200],
                        }}
                      >
                        <Stack
                          direction='row'
                          sx={{
                            alignItems: 'center',
                            width: '125px',
                            justifyContent: 'space-between',
                          }}
                        >
                          <InsertDriveFileIcon />
                          <Stack>
                            <IntlMessages id='importWizard.dataOption' />
                          </Stack>
                        </Stack>
                      </ListSubheader>
                    }
                  >
                    <Divider />

                    <ListItemButton onClick={handleClick}>
                      <ListItemIcon>
                        <InboxIcon />
                      </ListItemIcon>
                      <ListItemText
                        primary={<IntlMessages id='importWizard.csv' />}
                      />
                      {csvFileOpen ? <ExpandLess /> : <ExpandMore />}
                    </ListItemButton>
                    <Collapse in={csvFileOpen} timeout='auto' unmountOnExit>
                      <List component='div' disablePadding>
                        <ListItem>
                          <FormControl variant='standard' width={100}>
                            <InputLabel id='demo-simple-select-label'>
                              <IntlMessages id='importWizard.valueSeparateBy' />
                            </InputLabel>
                            <Select
                              labelId='demo-simple-select-label'
                              id='demo-simple-select'
                              value={csvFileData.separateValueBy}
                              displayEmpty
                              inputProps={{'aria-label': 'Without label'}}
                              onChange={(event) =>
                                handleChangeSeparateValueBy(event)
                              }
                            >
                              <MenuItem value={';'}>
                                <IntlMessages id='importWizard.semicolon' />( ;
                                )
                              </MenuItem>
                              <MenuItem value={','}>
                                <IntlMessages id='importWizard.comma' /> ( , )
                              </MenuItem>
                            </Select>
                          </FormControl>
                        </ListItem>

                        <ListItem>
                          <Button
                            variant='contained'
                            component='label'
                            sx={{whiteSpace: 'nowrap'}}
                          >
                            <IntlMessages id='importWizard.chooseFile' />
                            <input
                              type='file'
                              hidden
                              onChange={(event) => handleCaptureFile(event)}
                              accept='.csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'
                            />
                          </Button>

                          {!csvFileData?.file?.name && (
                            <Typography
                              variant='caption'
                              sx={{margin: '0px 10px'}}
                            >
                              {/* No file chosen */}
                              <IntlMessages id='importWizard.uploadYourFile' />
                            </Typography>
                          )}

                          {csvFileData?.file?.name && (
                            <Typography
                              variant='caption'
                              sx={{margin: '0px 10px'}}
                            >
                              {csvFileData.file.name}
                            </Typography>
                          )}
                        </ListItem>
                        <ListItem>
                          {!loadingDemoCsvButton ? (
                            <Button
                              variant='contained'
                              onClick={() => downloadCsv()}
                            >
                              {' '}
                              <IntlMessages id='importWizard.download' />
                            </Button>
                          ) : (
                            <CircularProgress />
                          )}
                          <Typography
                            variant='caption'
                            sx={{margin: '0px 10px'}}
                          >
                            {/* No file chosen */}
                            <IntlMessages id='importWizard.downloadYourDemoFile' />
                          </Typography>
                        </ListItem>
                      </List>
                    </Collapse>
                  </List>
                </Box>
              </Stack>
            </Fade>
          )}
        </Stack>
      </Stack>
    );
  };

  const handlerNextPreviousPage = () => {
    return (
      <Stack
        sx={{
          width: '100%',
          marginTop: 8,
        }}
        direction='row'
        justifyContent={'flex-end'}
        spacing={4}
      >
        <Stack>
          <Stack
            direction='row'
            justifyContent={'flex-end'}
            style={{width: '100%'}}
          >
            <Button
              variant='contained'
              disabled={openModule.pageNumber <= 0}
              color='success'
              onClick={() => {
                const tempOpenModule = JSON.parse(JSON.stringify(openModule));
                if (tempOpenModule.pageNumber > 0) {
                  tempOpenModule.pageNumber -= 1;
                  setOpenModule(() => tempOpenModule);
                }
                const tempIsSubmit = JSON.parse(JSON.stringify(isSubmit));
                tempIsSubmit.submitVisible = false;
                setIsSubmit(() => tempIsSubmit);
                setIsSubmitResponse(() => false);
                setSelectedIndex(() => null);
                setCsvFileData(() => ({
                  file: null,
                  header: [],
                  separateValueBy: ',',
                }));
                setIsIntityGet(() => false);
              }}
            >
              <IntlMessages id='common.button.Back' />
            </Button>
          </Stack>
        </Stack>
        <Stack>
          <Stack
            direction='row'
            justifyContent={'flex-end'}
            style={{width: '100%'}}
          >
            {!openModule.pageNumber >= 1 && (
              <Button
                variant='contained'
                color='primary'
                disabled={
                  (csvFileData.file?.name ? false : true) ||
                  selectedIndex == null ||
                  openModule.pageNumber >= 1
                }
                onClick={() => {
                  const tempOpenModule = JSON.parse(JSON.stringify(openModule));
                  if (tempOpenModule.pageNumber < 1)
                    tempOpenModule.pageNumber += 1;
                  setOpenModule(() => tempOpenModule);
                }}
              >
                <IntlMessages id='common.button.Next' />
              </Button>
            )}
            {openModule.pageNumber >= 1 && (
              <Button
                variant='contained'
                color='primary'
                disabled={
                  isSubmit.submitVisible == false ||
                  isSubmitResponse == true ||
                  isLoadingUpload == true
                }
                onClick={() => {
                  const tempIsSubmit = JSON.parse(JSON.stringify(isSubmit));
                  tempIsSubmit.buttonClicked = true;
                  setIsSubmit(() => tempIsSubmit);
                  setIsLoadingUpload(true);
                }}
              >
                <IntlMessages id='common.button.Submit' />
              </Button>
            )}
          </Stack>
        </Stack>
      </Stack>
    );
  };

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }
  
  if (!isAuthorized) {
    return <Error403 />;
  }

  return (
    <>
      <AppAnimate animation='transition.slideUpIn' delay={500}>
        <AppPageMeta />
        <h2 style={{marginBottom: 20}}>
          <IntlMessages id='sidebar.master.importWizard' />
        </h2>
        <AppCard>
          <stack direction='row'>
            {openModule.pageNumber == 0 && importDataModule()}
            {openModule.pageNumber == 1 && (
              <SecondPage
                data={{
                  selectedIndex: selectedIndex,
                  csvFileData: csvFileData,
                  selectForApiType: selectForApiType,
                }}
                submitHandler={{
                  setIsSubmit: setIsSubmit,
                  isSubmit: isSubmit,
                  setIsSubmitResponse: setIsSubmitResponse,
                  isApiHits: isApiHits,
                  setIsApiHits: setIsApiHits,
                  isIntityGet: isIntityGet,
                  setIsIntityGet: setIsIntityGet,
                }}
                isLoadingUpload={isLoadingUpload}
                setIsLoadingUpload={setIsLoadingUpload}
              />
            )}
            {handlerNextPreviousPage()}
          </stack>
        </AppCard>
      </AppAnimate>
      <AppInfoView />
    </>
  );
};

export default WizardForConfig;
