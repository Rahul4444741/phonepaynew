const now = new Date();

export default [
  {
    id: 1,
    title: 'Annual Conference',
    allDay: true,
    startDate: '2023-04-21T09:00:00.000Z',
    endDate: '2023-04-22T17:00:00.000Z',
    color: '#ff8164',
    description: 'Our annual conference for all employees',
    url: 'https://example.com/events/annual-conference',
    company: {
      id: '5add6de7-1faf-46b1-b070-bf7ffcc1e5fa',
    },
  },
  {
    id: 2,
    title: 'EOFY Break',
    allDay: true,
    startDate: '2023-04-20T09:00:00.000Z',
    endDate: '2023-04-22T17:00:00.000Z',
    color: '#ffd700',
    description: 'Our annual conference for all employees',
    url: 'https://example.com/events/annual-conference',
    company: {
      id: '5add6de7-1faf-46b1-b070-bf7ffcc1e5fa',
    },
  },
];
