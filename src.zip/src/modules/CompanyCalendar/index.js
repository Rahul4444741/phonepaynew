import React, { useState, useEffect } from 'react';
import { Calendar, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';

import { API_ROUTS } from 'shared/constants/ApiRouts';
import { useDispatch, useSelector } from 'react-redux';
import { fetchError, fetchStart, showMessage } from 'redux/actions';
import jwtAxios from '@crema/services/auth/jwt-auth';
import axios from 'axios';
import { AppAnimate, AppCard, AppInfoView } from '@crema';
import AppPageMeta from '../../../src/@crema/core/AppPageMeta';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import FormControl from '@mui/material/FormControl';
import FormControlLabel from '@mui/material/FormControlLabel';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import { DesktopDatePicker } from '@mui/x-date-pickers/DesktopDatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import {
  getCompanyDateFormat,
  getCompanyDateFormatForInputs,
  getIdListFromObjects,
  isAllowedUser,
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';
import { FormHelperText, Stack, TextField } from '@mui/material';
import AlertDialog from 'modules/Common/AlertDialog';
import IntlMessages from '@crema/utility/IntlMessages';
import RadioGroup from '@mui/material/RadioGroup';
import Radio from '@mui/material/Radio';
import { week } from 'shared/constants/AppConst';
import ListItemIcon from '@mui/material/ListItemIcon';
import Checkbox from '@mui/material/Checkbox';
import ListItemText from '@mui/material/ListItemText';
import FormLabel from '@mui/material/FormLabel';
import {permissionName} from 'shared/utils/PermissionName';
import Error403 from 'modules/errorPages/Error403';
import { domCreactionGridSkeletonLoader } from 'shared/utils/domCreaction';

moment.locale('en-GB');
const localizer = momentLocalizer(moment);
const parse = require('html-react-parser');

export default function CompanyCalendar() {
  const dispatch = useDispatch();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const [open, setOpen] = useState(false);
  const [isEdit, setIsEdit] = useState(false);
  const [isNewEvent, setIsNewEvent] = useState(false);
  const [eventsData, setEventsData] = useState([]);
  const [loading, setLoading] = useState(false);
  let initialEmptyEvent = {
    title: null,
    allDay: true,
    startDate: null,
    endDate: null,
    color: null,
    description: null,
    url: null,
    isRepeat: false,
    dayOfWeek: [],
    companyId: selectedCompany?.id,
  };
  let initialEmptyEventError = {
    title: {isError: false, errorMessage: ''},
    allDay: true,
    startDate: {isError: false, errorMessage: ''},
    endDate: {isError: false, errorMessage: ''},
    color: {isError: false, errorMessage: ''},
    description: {isError: false, errorMessage: ''},
    url: {isError: false, errorMessage: ''},
    isRepeat: {isError: false, errorMessage: ''},
    dayOfWeek: {isError: false, errorMessage: ''},
  };
  const [selectedEvent, setSelectedEvent] = useState(initialEmptyEvent);
  const [eventError, setEventError] = useState(initialEmptyEventError);
  const [alertProps, setAlertProps] = React.useState({});

  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);

  React.useEffect(() => {
    if (isAllowedUser(permissionName.COMPANY_CALENDER)) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  useEffect(() => {
    dispatch(fetchStart);
    if (
      isAuthorized &&
      selectedCompany != null &&
      selectedCompany != undefined
    ) {
      getCompanyEvents(selectedCompany.id);
    }
    return () => {
      source.cancel('Abort fetching company events');
    };
  }, [isAuthorized, selectedCompany]);

  const getCompanyEvents = async (companyId) => {
    setLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.companyEvents}companyId/${companyId}`,
        {
          cancelToken: source.token,
        },
      );
      if (res.status == 200) {
        setEventsData(res.data);
        setLoading(() => false);
      }
    } catch (e) {
      if (e?.response?.data?.detail) {
        dispatch(fetchError(e?.response?.data?.title));
      } else {
        dispatch(fetchError(e.message));
      }
      setLoading(() => false);
    }
  };

  const addCompanyEvents = async (companyId) => {
    setLoading(() => true);
    // let tempSelected
    try {
      const res = await jwtAxios.post(
        `${API_ROUTS.companyEvents}addEvent`,
        selectedEvent,
      );
      if (res.status == 201) {
        dispatch(
          showMessage(`${selectedEvent.title} event created successfully..!`),
        );
        handleClose();
        getCompanyEvents(companyId);
        setLoading(() => false);
      }
    } catch (e) {
      if (e?.response?.data?.detail) {
        dispatch(fetchError(e?.response?.data?.title));
      } else {
        dispatch(fetchError(e.message));
      }
      setLoading(() => false);
    }
  };

  const updateCompanyEvents = async (companyId) => {
    setLoading(() => true);
    let payload = {...selectedEvent};
    try {
      const res = await jwtAxios.put(
        `${API_ROUTS.companyEvents}${selectedEvent.id}`,
        payload,
      );
      if (res.status == 201) {
        dispatch(
          showMessage(`${selectedEvent.title} event updated successfully..!`),
        );
        handleClose();
        getCompanyEvents(companyId);
        setLoading(() => false);
      }
    } catch (e) {
      if (e?.response?.data?.detail) {
        dispatch(fetchError(e?.response?.data?.title));
      } else {
        dispatch(fetchError(e.message));
      }
      setLoading(() => false);
    }
  };

  const deleteCompanyEvents = async (companyId) => {
    let tempProps = {
      isHideShow: false,
    };
    setLoading(() => true);
    try {
      const res = await jwtAxios.delete(
        `${API_ROUTS.companyEvents}${selectedEvent.id}`,
        selectedEvent,
      );
      if (res.status == 204) {
        dispatch(
          showMessage(`${selectedEvent.title} event deleted successfully..!`),
        );
        setAlertProps(() => tempProps);
        handleClose();
        getCompanyEvents(companyId);
        setLoading(() => false);
      }
    } catch (e) {
      if (e?.response?.data?.detail) {
        dispatch(fetchError(e?.response?.data?.title));
      } else {
        dispatch(fetchError(e.message));
      }
      setAlertProps(() => tempProps);
      setLoading(() => false);
    }
  };

  const handleDeleteEvent = () => {
    let tempProps = {
      isHideShow: true,
      alertType: 'Confirmation',
      title: <IntlMessages id='calender.deleteEvent' />,
      message: <IntlMessages id='calender.areYouSureWantDeleteThisEvent' />,
    };
    setAlertProps(() => tempProps);
  };

  const handleCloseDeleteAlert = () => {
    let tempProps = {
      isHideShow: false,
    };
    setAlertProps(() => tempProps);
  };

  const requiredStyled = {
    backgroundColor: 'white',
    mb: 2,
    width: '100%',
    '& .MuiOutlinedInput-root': {
      '& fieldset': {
        borderLeftColor: 'red',
        borderLeftWidth: 3,
      },
    },
  };

  const handleClose = () => {
    setOpen(false);
    setIsEdit(false);
    setIsNewEvent(false);
    setSelectedEvent(() => initialEmptyEvent);
    setEventError(initialEmptyEventError);
  };

  const handleClickEvent = (event) => {
    setSelectedEvent(event);
    setOpen(true);
  };

  const handleSelect = ({start, end}) => {
    const title = window.prompt('New Event name');
    if (title)
      setEventsData([
        ...eventsData,
        {
          start,
          end,
          title,
        },
      ]);
  };

  const handleValidateEvent = async () => {
    let isValid = true;
    const tempError = {...eventError};
    const tempEvent = JSON.parse(JSON.stringify(selectedEvent));

    if (tempEvent.title == null || tempEvent.title.trim() == '') {
      tempError.title.isError = true;
      tempError.title.errorMessage = (
        <IntlMessages id='error.calender.pleaseEnterEventTitle' />
      );
      isValid = false;
    }

    if (tempEvent.startDate == null || tempEvent.startDate.trim() == '') {
      tempError.startDate.isError = true;
      tempError.startDate.errorMessage = (
        <IntlMessages id='error.calender.pleaseEnterStartDate' />
      );
      isValid = false;
    }

    if (tempEvent.endDate == null || tempEvent.endDate.trim() == '') {
      tempError.endDate.isError = true;
      tempError.endDate.errorMessage = (
        <IntlMessages id='error.calender.pleaseEnterEndDate' />
      );
      isValid = false;
    }

    if (tempEvent.description == null || tempEvent.description.trim() == '') {
      tempError.description.isError = true;
      tempError.description.errorMessage = (
        <IntlMessages id='error.calender.pleaseEnterEventDescription' />
      );
      isValid = false;
    }

    if (tempEvent.url == null || tempEvent.url.trim() == '') {
      tempError.url.isError = true;
      tempError.url.errorMessage = (
        <IntlMessages id='error.calender.pleaseEnterUrl' />
      );
      isValid = false;
    }

    if (tempEvent.isRepeat == 'true' || tempEvent.isRepeat) {
      if (isEmptyNullUndefined(tempEvent.dayOfWeek)) {
        tempError.dayOfWeek.isError = true;
        tempError.dayOfWeek.errorMessage = (
          <IntlMessages id='error.calender.pleaseEnterRepeatDate' />
        );
        isValid = false;
      }
    }

    if (!isEmptyNullUndefined(tempEvent.url)) {
      if (
        !tempEvent.url.match(
          /^(?:(?:https?|ftp):\/\/)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:\/\S*)?$/,
        )
      ) {
        tempError.url.isError = true;
        tempError.url.errorMessage = (
          <IntlMessages id='error.calender.pleaseEnterValidUrl' />
        );
        isValid = false;
      }
    }

    if (isValid) {
      if (isEdit) {
        updateCompanyEvents(selectedCompany.id);
      } else {
        addCompanyEvents(selectedCompany.id);
      }
    } else {
      setEventError(tempError);
    }
  };

  const handleChangeEventDetails = async (event, fieldType) => {
    let tempSelectedEvent = JSON.parse(JSON.stringify(selectedEvent));
    const tempError = {...eventError};
    if (fieldType == 'textfield') {
      tempSelectedEvent[event.target.name] = event.target.value;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
    }
    if (fieldType == 'ratio') {
      tempSelectedEvent[event.target.name] =
        event.target.value === 'true' ? true : false;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
    }
    if (fieldType == 'dayOfWeek') {
      let value = event.target.value;
      let preventDuplicate = value.filter(
        (v, i, a) => a.findIndex((t) => t === v) === i,
      );
      if (value[value?.length - 1] === 'All') {
        preventDuplicate =
          preventDuplicate?.length - 1 === week?.length
            ? []
            : getIdListFromObjects(week, 'value');
      }
      tempSelectedEvent.dayOfWeek = preventDuplicate;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
    }
    if (fieldType == 'startDate' || fieldType == 'endDate') {
      tempSelectedEvent[fieldType] = event;
      tempError[fieldType].isError = false;
      tempError[fieldType].errorMessage = '';

      if (
        tempSelectedEvent.endDate != null &&
        tempSelectedEvent.startDate != null
      ) {
        //End Date should not be less than Start Date
        if (
          Date.parse(tempSelectedEvent.endDate) <
          Date.parse(tempSelectedEvent.startDate)
        ) {
          tempError.endDate.isError = true;
          tempError.endDate.errorMessage = (
            <IntlMessages id='error.calender.endDateShouldGreaterThanStartDate' />
          );
        } else {
          tempError.endDate.isError = false;
          tempError.endDate.errorMessage = '';
        }
      } else {
        tempError.endDate.isError = false;
        tempError.endDate.errorMessage = '';
        tempError.startDate.isError = false;
        tempError.startDate.errorMessage = '';
      }
    }
    if (event?.target?.name == 'isRepeat') {
      if (event.target.value == false || event.target.value == 'false') {
        tempSelectedEvent.dayOfWeek = [];
        tempError.dayOfWeek.isError = true;
        tempError.dayOfWeek.errorMessage = '';
      }
    }
    setSelectedEvent(tempSelectedEvent);
    setEventError(tempError);
  };

  const handleAddNewEvent = () => {
    setIsNewEvent(true);
    setSelectedEvent(initialEmptyEvent);
    setOpen(true);
  };

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (!isAuthorized) {
    return <Error403 />;
  }

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <Stack
        sx={{
          mb: 5,
        }}
        width={{xs: '100%', sm: '50%', md: '80%', lg: '100%'}}
        height={{
          xs: '100%',
          sm: '100%',
          md: 'calc(100vh - 131px)',
          lg: 'calc(100vh - 165px)',
        }}
      >
        <div
          style={{
            height: '100%',
            width: '100%',
          }}
        >
          <Calendar
            views={['month', 'week', 'day', 'agenda']}
            // selectable
            localizer={localizer}
            defaultDate={new Date()}
            defaultView='month'
            events={eventsData}
            components={{
              eventWrapper: ({event, children}) => (
                <div
                  onContextMenu={(e) => {
                    alert(`${event.title} is clicked.`);
                    e.preventDefault();
                  }}
                >
                  {children}
                </div>
              ),
            }}
            startAccessor={(event) => moment(event.startDate).toDate()}
            endAccessor={(event) => moment(event.endDate).add(10, 'm').toDate()}
            popup={true}
            tooltipAccessor={(e) => e.description}
            // showAllEvents
            dayLayoutAlgorithm='no-overlap'
            eventPropGetter={(event) => {
              const backgroundColor = event.color ? event.color : '#0A8FDC';
              return {style: {backgroundColor}};
            }}
            style={{height: '100%'}}
            onSelectEvent={handleClickEvent}
            onSelectSlot={handleSelect}
          />
        </div>
      </Stack>

      <Dialog
        fullWidth={true}
        maxWidth={'sm'}
        open={open}
        onClose={handleClose}
      >
        <DialogContent>
          <Stack direction='row' justifyContent='center' sx={{mt: '7%'}}>
            <AppCard style={{width: '420px'}}>
              {!isNewEvent ? (
                <h4 style={{display: 'flex'}}>
                  {!isEdit ? (
                    <IntlMessages id='calender.eventDetails' />
                  ) : (
                    <IntlMessages id='calender.editEventDetails' />
                  )}
                </h4>
              ) : (
                <h4 style={{display: 'flex'}}>
                  <IntlMessages id='calender.addNewEvent' />
                </h4>
              )}

              {isNewEvent ? (
                <Stack
                  sx={{mt: 2}}
                  display='flex'
                  justifyContent='center'
                  spacing={2}
                >
                  <TextField
                    size='small'
                    id='eventTitleTextField'
                    name='title'
                    label={<IntlMessages id='calender.eventTitle' />}
                    variant='outlined'
                    InputProps={{inputProps: {min: 0}}}
                    placeholder='Event Title'
                    sx={{
                      ...requiredStyled,
                    }}
                    onChange={(e) => {
                      handleChangeEventDetails(e, 'textfield');
                    }}
                    value={
                      !isEmptyNullUndefined(selectedEvent.title)
                        ? selectedEvent.title
                        : ''
                    }
                    error={eventError.title.isError}
                    helperText={eventError.title.errorMessage}
                  />
                  <Stack
                    id='event-start-date-picker'
                    name='startDate'
                    sx={{
                      width: '100%',
                    }}
                  >
                    <LocalizationProvider dateAdapter={AdapterDateFns}>
                      <DesktopDatePicker
                        inputFormat={getCompanyDateFormatForInputs(
                          selectedCompany,
                        )}
                        value={selectedEvent.startDate}
                        label={
                          <IntlMessages id='calender.startDateOfTheEvent' />
                        }
                        name='startDate'
                        onChange={(e) => {
                          handleChangeEventDetails(e, 'startDate');
                        }}
                        renderInput={(params) => (
                          <TextField
                            variant='outlined'
                            helperText={eventError.startDate.errorMessage}
                            size='small'
                            sx={{...requiredStyled}}
                            {...params}
                            error={eventError.startDate.isError}
                          />
                        )}
                      />
                    </LocalizationProvider>
                  </Stack>
                  <Stack
                    id='event-end-date-picker'
                    name='endDate'
                    sx={{
                      width: '100%',
                    }}
                  >
                    <LocalizationProvider dateAdapter={AdapterDateFns}>
                      <DesktopDatePicker
                        inputFormat={getCompanyDateFormatForInputs(
                          selectedCompany,
                        )}
                        value={selectedEvent.endDate}
                        label={<IntlMessages id='calender.endDateOfTheEvent' />}
                        name='endDate'
                        onChange={(e) => {
                          handleChangeEventDetails(e, 'endDate');
                        }}
                        renderInput={(params) => (
                          <TextField
                            variant='outlined'
                            helperText={eventError.endDate.errorMessage}
                            size='small'
                            sx={{...requiredStyled}}
                            {...params}
                            error={eventError.endDate.isError}
                          />
                        )}
                      />
                    </LocalizationProvider>
                  </Stack>
                  <Stack
                    direction='row'
                    sx={{mt: 2, ml: 3}}
                    justifyContent='space-between'
                    alignItems='center'
                    spacing={2}
                  >
                    <Stack sx={{width: '50%'}}>
                      <FormLabel id='demo-row-radio-buttons-group-label'>
                        <Stack direction='row'>
                          <Stack fontWeight={500}>
                            <IntlMessages id='calender.isThisRepeatEvent' />
                          </Stack>
                          <Stack
                            sx={{color: 'red', ml: 2, mb: 2, fontSize: 14}}
                          >
                            *
                          </Stack>
                        </Stack>
                      </FormLabel>
                    </Stack>
                    <Stack
                      sx={{width: '50%'}}
                      direction='row'
                      alignItems='center'
                    >
                      <RadioGroup
                        id='radio-group-does-the-company-plan-require-depedent-working-declaration-from-employee'
                        value={selectedEvent.isRepeat}
                        onChange={(e) => handleChangeEventDetails(e, 'ratio')}
                        row
                        aria-labelledby='demo-row-radio-buttons-group-label'
                        name='isRepeat'
                      >
                        <FormControlLabel
                          id='form-control-label-true-does-the-company-plan-require-depedent-working-declaration-from-employee'
                          value={true}
                          control={<Radio />}
                          label={<IntlMessages id='common.button.Yes' />}
                        />
                        <FormControlLabel
                          id='form-control-label-false-does-the-company-plan-require-depedent-working-declaration-from-employee'
                          value={false}
                          control={<Radio />}
                          label={<IntlMessages id='common.button.No' />}
                        />
                      </RadioGroup>
                      {eventError.isRepeat.isError && (
                        <FormHelperText className='Mui-error'>
                          {eventError.isRepeat.errorMessage}
                        </FormHelperText>
                      )}
                    </Stack>
                  </Stack>
                  <Stack sx={{width: '100%'}}>
                    <FormControl>
                      <InputLabel size='small' id='dayOfWeek'>
                        <IntlMessages id='calender.repeatDate' />
                      </InputLabel>
                      <Select
                        name='dayOfWeek'
                        disabled={
                          selectedEvent.isRepeat == false ||
                          selectedEvent.isRepeat == 'false'
                        }
                        sx={{
                          ...requiredStyled,
                          backgroundColor: 'white',
                          mb: 2,
                          width: {xs: '100%', xl: '100%', md: '100%'},
                          '& fieldset': {
                            borderLeftColor: 'red',
                            borderLeftWidth: 3,
                          },
                        }}
                        labelId='dayOfWeek'
                        label='dayOfWeek'
                        value={selectedEvent.dayOfWeek}
                        onChange={(e) => {
                          handleChangeEventDetails(e, 'dayOfWeek');
                        }}
                        variant='outlined'
                        multiple
                        renderValue={(selected) => selected + ', '}
                        size='small'
                      >
                        {week?.length > 0 && (
                          <MenuItem value='All'>
                            <ListItemIcon>
                              <Checkbox
                                checked={
                                  selectedEvent?.dayOfWeek?.length ==
                                  week?.length
                                }
                                indeterminate={
                                  selectedEvent.dayOfWeek?.length > 0 &&
                                  selectedEvent.dayOfWeek?.length < week?.length
                                }
                              />
                            </ListItemIcon>
                            <ListItemText
                              primary={
                                <IntlMessages id='auditLogs.selectAll' />
                              }
                            />
                          </MenuItem>
                        )}
                        {week?.map((item) => (
                          <MenuItem
                            key={'class_' + item.value}
                            value={item.value}
                          >
                            <Checkbox
                              checked={
                                selectedEvent.dayOfWeek.findIndex(
                                  (xType) => xType === item.value,
                                ) > -1
                              }
                            />
                            <ListItemText primary={item.name} />
                          </MenuItem>
                        ))}
                      </Select>
                      {eventError.dayOfWeek.isError && (
                        <FormHelperText className='Mui-error'>
                          {eventError.dayOfWeek.errorMessage}
                        </FormHelperText>
                      )}
                    </FormControl>
                  </Stack>
                  <Stack
                    sx={{
                      width: '100%',
                      display: 'flex',
                      alignItems: 'center',
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      border: '1px solid #d8d8d8',
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                      borderRadius: '10px',
                      padding: '7px 14px',
                    }}
                  >
                    <strong
                      style={{
                        fontSize: '14px',
                        fontWeight: '400',
                        color: 'rgb(107, 114, 128)',
                      }}
                    >
                      <IntlMessages id='calender.color' />
                    </strong>
                    <input
                      type='color'
                      onChange={(e) => {
                        let tempSelectedEvent = JSON.parse(
                          JSON.stringify(selectedEvent),
                        );
                        tempSelectedEvent.color = e.target.value;
                        setSelectedEvent(tempSelectedEvent);
                      }}
                      id='eventColorPicker'
                      name='color'
                      value={selectedEvent.color || ''}
                    ></input>
                    {eventError.color.isError && (
                      <FormHelperText className='Mui-error'>
                        {eventError.color.errorMessage}
                      </FormHelperText>
                    )}
                  </Stack>
                  <TextField
                    size='small'
                    id='eventDescriptionTextField'
                    name='description'
                    label={<IntlMessages id='calender.eventDescription' />}
                    variant='outlined'
                    InputProps={{inputProps: {min: 0}}}
                    placeholder='Event Description'
                    sx={{
                      ...requiredStyled,
                    }}
                    onChange={(e) => {
                      handleChangeEventDetails(e, 'textfield');
                    }}
                    value={
                      !isEmptyNullUndefined(selectedEvent.description)
                        ? selectedEvent.description
                        : ''
                    }
                    error={eventError.description.isError}
                    helperText={eventError.description.errorMessage}
                  />
                  <TextField
                    size='small'
                    id='eventDescriptionTextField'
                    name='url'
                    label={<IntlMessages id='calender.url' />}
                    variant='outlined'
                    InputProps={{inputProps: {min: 0}}}
                    placeholder='URL'
                    sx={{
                      ...requiredStyled,
                    }}
                    onChange={(e) => {
                      handleChangeEventDetails(e, 'textfield');
                    }}
                    value={
                      !isEmptyNullUndefined(selectedEvent.url)
                        ? selectedEvent.url
                        : ''
                    }
                    error={eventError.url.isError}
                    helperText={eventError.url.errorMessage}
                  />
                </Stack>
              ) : isEdit ? (
                <Stack
                  sx={{mt: 2}}
                  display='flex'
                  justifyContent='center'
                  spacing={2}
                >
                  <TextField
                    size='small'
                    id='eventTitleTextField'
                    name='title'
                    label={<IntlMessages id='calender.eventTitle' />}
                    variant='outlined'
                    InputProps={{inputProps: {min: 0}}}
                    placeholder='Event Title'
                    sx={{
                      ...requiredStyled,
                    }}
                    onChange={(e) => {
                      handleChangeEventDetails(e, 'textfield');
                    }}
                    value={
                      !isEmptyNullUndefined(selectedEvent.title)
                        ? selectedEvent.title
                        : ''
                    }
                    error={eventError.title.isError}
                    helperText={eventError.title.errorMessage}
                  />
                  <Stack
                    id='event-start-date-picker'
                    name='startDate'
                    sx={{
                      width: '100%',
                    }}
                  >
                    <LocalizationProvider dateAdapter={AdapterDateFns}>
                      <DesktopDatePicker
                        inputFormat={getCompanyDateFormatForInputs(
                          selectedCompany,
                        )}
                        value={selectedEvent.startDate}
                        label={
                          <IntlMessages id='calender.startDateOfTheEvent' />
                        }
                        name='startDate'
                        onChange={(e) => {
                          handleChangeEventDetails(e, 'startDate');
                        }}
                        renderInput={(params) => (
                          <TextField
                            variant='outlined'
                            helperText={eventError.startDate.errorMessage}
                            size='small'
                            sx={{...requiredStyled}}
                            {...params}
                            error={eventError.startDate.isError}
                          />
                        )}
                      />
                    </LocalizationProvider>
                  </Stack>
                  <Stack
                    id='event-end-date-picker'
                    name='endDate'
                    sx={{
                      width: '100%',
                    }}
                  >
                    <LocalizationProvider dateAdapter={AdapterDateFns}>
                      <DesktopDatePicker
                        inputFormat={getCompanyDateFormatForInputs(
                          selectedCompany,
                        )}
                        value={selectedEvent.endDate}
                        label={<IntlMessages id='calender.endDateOfTheEvent' />}
                        name='endDate'
                        onChange={(e) => {
                          handleChangeEventDetails(e, 'endDate');
                        }}
                        renderInput={(params) => (
                          <TextField
                            variant='outlined'
                            helperText={eventError.endDate.errorMessage}
                            size='small'
                            sx={{...requiredStyled}}
                            {...params}
                            error={eventError.endDate.isError}
                          />
                        )}
                      />
                    </LocalizationProvider>
                  </Stack>
                  <Stack
                    direction='row'
                    sx={{mt: 2, ml: 3}}
                    justifyContent='space-between'
                    alignItems='center'
                    spacing={2}
                  >
                    <Stack sx={{width: '50%'}}>
                      <FormLabel id='demo-row-radio-buttons-group-label'>
                        <Stack direction='row'>
                          <Stack fontWeight={500}>
                            <IntlMessages id='calender.isThisRepeatEvent' />
                          </Stack>
                          <Stack
                            sx={{color: 'red', ml: 2, mb: 2, fontSize: 14}}
                          >
                            *
                          </Stack>
                        </Stack>
                      </FormLabel>
                    </Stack>
                    <Stack
                      sx={{width: '50%'}}
                      direction='row'
                      alignItems='center'
                    >
                      <RadioGroup
                        id='radio-group-does-the-company-plan-require-depedent-working-declaration-from-employee'
                        value={selectedEvent.isRepeat}
                        onChange={(e) => handleChangeEventDetails(e, 'ratio')}
                        row
                        aria-labelledby='demo-row-radio-buttons-group-label'
                        name='isRepeat'
                      >
                        <FormControlLabel
                          id='form-control-label-true-does-the-company-plan-require-depedent-working-declaration-from-employee'
                          value={true}
                          control={<Radio />}
                          label={<IntlMessages id='common.button.Yes' />}
                        />
                        <FormControlLabel
                          id='form-control-label-false-does-the-company-plan-require-depedent-working-declaration-from-employee'
                          value={false}
                          control={<Radio />}
                          label={<IntlMessages id='common.button.No' />}
                        />
                      </RadioGroup>
                      {eventError.isRepeat.isError && (
                        <FormHelperText className='Mui-error'>
                          {eventError.isRepeat.errorMessage}
                        </FormHelperText>
                      )}
                    </Stack>
                    {eventError.isRepeat.isError && (
                      <FormHelperText className='Mui-error'>
                        {eventError.isRepeat.errorMessage}
                      </FormHelperText>
                    )}
                  </Stack>
                  <Stack sx={{width: '100%'}}>
                    <FormControl>
                      <InputLabel size='small' id='dayOfWeek'>
                        <IntlMessages id='calender.repeatDate' />
                      </InputLabel>
                      <Select
                        name='dayOfWeek'
                        disabled={
                          selectedEvent.isRepeat == false ||
                          selectedEvent.isRepeat == 'false'
                        }
                        sx={{
                          ...requiredStyled,
                          backgroundColor: 'white',
                          mb: 2,
                          width: {xs: '100%', xl: '100%', md: '100%'},
                          '& fieldset': {
                            borderLeftColor: 'red',
                            borderLeftWidth: 3,
                          },
                        }}
                        labelId='dayOfWeek'
                        label='dayOfWeek'
                        value={selectedEvent.dayOfWeek || []}
                        onChange={(e) => {
                          handleChangeEventDetails(e, 'dayOfWeek');
                        }}
                        variant='outlined'
                        multiple
                        renderValue={(selected) => selected + ', '}
                        size='small'
                      >
                        {week?.length > 0 && (
                          <MenuItem value='All'>
                            <ListItemIcon>
                              <Checkbox
                                checked={
                                  selectedEvent?.dayOfWeek?.length ==
                                  week?.length
                                }
                                indeterminate={
                                  selectedEvent.dayOfWeek?.length > 0 &&
                                  selectedEvent.dayOfWeek?.length < week?.length
                                }
                              />
                            </ListItemIcon>
                            <ListItemText
                              primary={
                                <IntlMessages id='auditLogs.selectAll' />
                              }
                            />
                          </MenuItem>
                        )}
                        {week?.map((item) => (
                          <MenuItem
                            key={'class_' + item.value}
                            value={item.value}
                          >
                            <Checkbox
                              checked={
                                selectedEvent?.dayOfWeek?.findIndex(
                                  (xType) => xType === item.value,
                                ) > -1
                              }
                            />
                            <ListItemText primary={item.name} />
                          </MenuItem>
                        ))}
                      </Select>
                      {eventError.dayOfWeek.isError && (
                        <FormHelperText className='Mui-error'>
                          {eventError.dayOfWeek.errorMessage}
                        </FormHelperText>
                      )}
                    </FormControl>
                  </Stack>
                  <Stack
                    sx={{
                      width: '100%',
                      display: 'flex',
                      alignItems: 'center',
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      border: '1px solid #d8d8d8',
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                      borderRadius: '10px',
                      padding: '7px 14px',
                    }}
                  >
                    <strong
                      style={{
                        fontSize: '14px',
                        fontWeight: '400',
                        color: 'rgb(107, 114, 128)',
                      }}
                    >
                      <IntlMessages id='calender.color' />
                    </strong>
                    <input
                      type='color'
                      onChange={(e) => {
                        let tempSelectedEvent = JSON.parse(
                          JSON.stringify(selectedEvent),
                        );
                        tempSelectedEvent.color = e.target.value;
                        setSelectedEvent(tempSelectedEvent);
                      }}
                      id='eventColorPicker'
                      name='color'
                      value={selectedEvent.color || ''}
                    ></input>
                    {eventError.color.isError && (
                      <FormHelperText className='Mui-error'>
                        {eventError.color.errorMessage}
                      </FormHelperText>
                    )}
                  </Stack>
                  <TextField
                    size='small'
                    id='eventDescriptionTextField'
                    name='description'
                    label={<IntlMessages id='calender.eventDescription' />}
                    variant='outlined'
                    InputProps={{inputProps: {min: 0}}}
                    placeholder='Event Description'
                    sx={{
                      ...requiredStyled,
                    }}
                    onChange={(e) => {
                      handleChangeEventDetails(e, 'textfield');
                    }}
                    value={
                      !isEmptyNullUndefined(selectedEvent.description)
                        ? selectedEvent.description
                        : ''
                    }
                    error={eventError.description.isError}
                    helperText={eventError.description.errorMessage}
                  />
                  <TextField
                    size='small'
                    id='eventDescriptionTextField'
                    name='url'
                    label={<IntlMessages id='calender.url' />}
                    variant='outlined'
                    InputProps={{inputProps: {min: 0}}}
                    placeholder='URL'
                    sx={{
                      ...requiredStyled,
                    }}
                    onChange={(e) => {
                      handleChangeEventDetails(e, 'textfield');
                    }}
                    value={
                      !isEmptyNullUndefined(selectedEvent.url)
                        ? selectedEvent.url
                        : ''
                    }
                    error={eventError.url.isError}
                    helperText={eventError.url.errorMessage}
                  />
                </Stack>
              ) : (
                <Stack
                  sx={{mt: 2}}
                  display='flex'
                  justifyContent='center'
                  spacing={2}
                >
                  <p>
                    <strong>
                      <IntlMessages id='calender.title' /> :{' '}
                    </strong>
                    {!isEmptyNullUndefined(selectedEvent.title)
                      ? selectedEvent.title
                      : ''}
                  </p>
                  <p>
                    <strong>
                      <IntlMessages id='calender.startDate' /> :{' '}
                    </strong>
                    {!isEmptyNullUndefined(selectedEvent.startDate)
                      ? moment(selectedEvent.startDate).format(
                          getCompanyDateFormat(selectedCompany),
                        )
                      : '-'}
                  </p>
                  <p>
                    <strong>
                      <IntlMessages id='calender.endDate' /> :{' '}
                    </strong>
                    {!isEmptyNullUndefined(selectedEvent.endDate)
                      ? moment(selectedEvent.endDate).format(
                          getCompanyDateFormat(selectedCompany),
                        )
                      : '-'}
                  </p>
                  <p>
                    <strong>
                      <IntlMessages id='calender.color' /> :{' '}
                    </strong>
                    {!isEmptyNullUndefined(selectedEvent.color) ? (
                      <input
                        disabled={true}
                        type='color'
                        id='currentSelectedEventColorInput'
                        name='currentSelectedEventColor'
                        value={selectedEvent.color || ''}
                      ></input>
                    ) : (
                      '-'
                    )}
                  </p>
                  <p>
                    <strong>
                      <IntlMessages id='calender.description' /> :
                    </strong>
                    {!isEmptyNullUndefined(selectedEvent.description)
                      ? selectedEvent.description
                      : '-'}
                  </p>
                  <p>
                    <strong>
                      <IntlMessages id='calender.url' /> :{' '}
                    </strong>
                    {!isEmptyNullUndefined(selectedEvent.url) ? (
                      <span
                        onClick={() => {
                          let link = selectedEvent.url.startsWith('http')
                            ? `${selectedEvent.url}`
                            : `https://${selectedEvent.url}`;
                          window.open(
                            `${link}`,
                            'Window Title',
                            'width=500, height=450',
                            '_blank',
                          );
                        }}
                        style={{color: '#0A8FDC', cursor: 'pointer'}}
                      >
                        {selectedEvent.url}
                      </span>
                    ) : (
                      '-'
                    )}
                  </p>
                </Stack>
              )}
            </AppCard>
          </Stack>
        </DialogContent>
        <DialogActions>
          {!isNewEvent && (
            <Button disabled={loading} onClick={() => setIsEdit(() => !isEdit)}>
              {isEdit ? (
                <IntlMessages id='common.button.View' />
              ) : (
                <IntlMessages id='common.button.Edit' />
              )}
            </Button>
          )}
          <Button disabled={loading} onClick={handleValidateEvent}>
            <IntlMessages id='common.button.Submit' />
          </Button>
          {!isNewEvent && (
            <Button disabled={loading} onClick={handleDeleteEvent}>
              <IntlMessages id='common.button.Delete' />
            </Button>
          )}
          <Button onClick={handleClose}>
            <IntlMessages id='common.button.Close' />
          </Button>
        </DialogActions>
      </Dialog>
      <Stack
        sx={{
          bottom: 0,
          zIndex: 10,
          position: 'fixed',
          backdropFilter: 'blur(5px)',
          width: '100%',
          right: 0,
        }}
      >
        <Stack
          direction='row'
          justifyContent='end'
          alignItems='center'
          spacing={2}
          sx={{
            pt: 5,
            ml: 3,
            //// add marging for fixed stack///
            margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
          }}
        >
          <Button
            name='addEventBtn'
            variant='outlined'
            onClick={() => handleAddNewEvent()}
            // disabled={isLoadingDel || loadingCnfg}
            sx={{mr: 1}}
          >
            <IntlMessages id='events.addEvent' />
          </Button>
        </Stack>
      </Stack>
      {alertProps?.isHideShow && (
        <AlertDialog
          alertProps={alertProps}
          handleYes={() => {
            deleteCompanyEvents(selectedCompany.id);
          }}
          handleNo={() => handleCloseDeleteAlert()}
        />
      )}
      <AppInfoView />
    </AppAnimate>
  );
}
