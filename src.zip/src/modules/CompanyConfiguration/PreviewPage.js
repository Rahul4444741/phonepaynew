import Button from '@mui/material/Button';
import { yellow } from '@mui/material/colors';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import PropTypes from 'prop-types';
import { useEffect, useState } from 'react';
import { BsChevronDown } from "react-icons/bs";
import { IoIosArrowBack } from "react-icons/io";
import AppInfoView from '../../@crema/core/AppInfoView';
import Logout from "../../assets/dynamicSidebar/logout";
import ProfilePage from './ProfilePage';
import { managerRoutes } from "./Routes";

const PreviewPage = ({
  handleClose,
  primaryColor,
  secondaryColor,
  tertiaryColor,
}) => {

  const [routes, setRoutes] = useState(null);
  const [sidebarCollide, setSidebarCollide] = useState(false);

  useEffect(() => {
        setRoutes(managerRoutes);

    
  }, []);

  const handleSidebarCollide = () => {
    setSidebarCollide(!sidebarCollide);
    // console.log('in')
    // console.log(sidebarCollide)
  }  

  const handleSidebarCollideTypeClassName = (element) => {
    if(false) {
    // if((location.pathname === '/login') || (location.pathname === '/forgot-password') || (location.pathname === '/account/reset/finish')) {
      if(element === 'sidebar') {
        return "sidebar-login-page"
      } else {
        if(element === 'main') {
          return "main-login-page"
        }
      }
    } else {
      if(element === 'sidebar') {
        if(sidebarCollide) {
          return "sidebar-Collide"
        } else {
          return "sidebar"
        }
      } else if(element === 'main') {
        if(sidebarCollide) {
          return "main-Collide"
        } else {
          return "main"
        }
      }
    }
  }

  return (
    <Dialog
    fullScreen
      // sx={{
      //   '& .MuiDialogContent-root': {
      //     padding: 0,
      //   },
      // }}
      open={true}
    >
      <DialogContent
      >
        <div className='main-employee-preview-page'>
          <div className='side-nav-main-div'>

                <div className="main-container">
                  <div 
                  // className='sidebar'
                  className={handleSidebarCollideTypeClassName('sidebar')}
                  >
                    <div className="sidebar-main-outer">
                    <div className="sidebarMain">
                      <div className="headMiddle">
                        <div className="header">
                              
                          <div className="user-container">
                            <div className="user-container-margin">
                              <div className="icon-container">
                                <div className="icon-size">
                                  <div className='div-one'>
                                    <div className='div-two'>
                                      <div className='div-three'>
                                        <span className='span-one'>
                                          <span className='span-two'>
                                            PE
                                          </span>
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="title-container">
                                <div className="align-title">
                                <div className="upper-title">
                                  pytzq ehbkb
                                </div>
                                <div className="lower-title">
                                  Employee
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="middle">
                        <section className="routes">
                        {
                            routes?.map((route,index) => {
                                return(
                                    <div className="route-item">
                                        <div 
                                          // className={`category ${(aciveTab === route?.path || activeHead === route?.path) ? "active" : ""}`} onClick={() => handleNavigation(route, false)}
                                          className={`category ${(route?.path == '/profile') ? "active" : ""}`}
                                        >
                                        <span> {route?.icon} </span>
                                        <span> 
                                          {route?.name}
                                          {
                                            route?.subcategory && <BsChevronDown />
                                          }          
                                          </span>                         
                                        </div>
                                        {/* {
                                            route?.subcategory && 
                                            activeHead === route?.path &&
                                            !sidebarCollide &&
                                            route?.subcategory?.map((sub) => {
                                                return(
                                                    <div className={`sub-cat ${(aciveTab === sub?.path || window.location.pathname === sub?.path) ? "active" : ""}`} onClick={() => handleNavigation(sub, true)}>{sub?.name}</div>
                                                )
                                            })
                                        } */}
                                    </div>
                                )
                            })
                        }
                          </section>
                        </div>
                      </div>
                      <div className="footer">
                        {
                          // employeeDetails?.company?.showAppraisal && 
                          <div className="logout-size">
                          <div className="title">
                            Logout
                          </div>
                          <div 
                            // onClick={() => {
                            //   dispatch(logInActions.clearLogInToken())
                            // }} 
                            className="logout-icon"
                            >
                            <Logout />
                            {/* logout icon */}
                          </div>
                        </div>
                        }
                      
                      </div>
                      
                    </div>
                    <div className="for-collapse" 
                      onClick={() => handleSidebarCollide()}
                    >
                    <div className="collapsible-nav-bar">
                            <div className="collapsible-nav-size">
                              <IoIosArrowBack style={{transform: sidebarCollide ? "rotate(-180deg)" : "rotate(0deg)"}} />
                            </div>
                          </div>
                      </div>
                    </div>
                  </div>
                  <main className={handleSidebarCollideTypeClassName('main')}>{
                    <ProfilePage
                    primaryColor={
                      primaryColor
                    }
                    secondaryColor={
                      secondaryColor
                    }
                    tertiaryColor={
                      tertiaryColor
                    }
                    />}</main>
                </div>
          </div>
          <div className='profile-container-main-div'>
          </div>
        </div>

      </DialogContent>
      <DialogActions>
        <Button
          onClick={() => handleClose()}
          sx={{
            backdropFilter: 'blur(10px)',
            zIndex: 11,
            backgroundColor: yellow[800],
            variant: 'contained',
          }}
        >
          Close
        </Button>
      </DialogActions>
      <AppInfoView />
    </Dialog>
  );
};

export default PreviewPage;
PreviewPage.propTypes = {
  handleClose: PropTypes.func,
  primaryColor: PropTypes.any,
  secondaryColor: PropTypes.any,
  tertiaryColor: PropTypes.any,
};


          // <Stack direction='row' justifyContent='center' sx={{mt: '7%', width: '90%'}}>
          //   <div style={{
          //   }}>
          //     testing
          //   </div>

          //   <Stack style={{width: '720px'}}>
          //     <div
          //       className='stype-upper-header'
          //       style={{background: secondaryColor}}
          //     >
          //       <div style={{margin: '12px'}}>
          //         <div
          //           style={{
          //             width: '29px',
          //             background: '#1A4D2E',
          //             marginBottom: '2px',
          //             height: '3px',
          //           }}
          //         ></div>
          //         <div
          //           style={{
          //             width: '16px',
          //             background: '#1A4D2E',
          //             marginTop: '3px',
          //             height: '3px',
          //           }}
          //         ></div>
          //       </div>
          //       <div>
          //         <div style={{color: primaryColor, fontWeight: 600}}>
          //           Plan Name
          //         </div>
          //       </div>
          //       <div
          //         style={{
          //           display: 'flex',
          //           justifyContent: 'space-around',
          //           alignItems: 'center',
          //           width: '169px',
          //           marginRight: '6px',
          //         }}
          //       >
          //         <div className='coin-root-container'>
          //           <div
          //             className='coin-icon-title-container'
          //             style={{
          //               background: '#1A4D2E',
          //             }}
          //           >
          //             <PaidIcon />
          //             2000
          //             <br />
          //             coins
          //           </div>
          //         </div>
          //         <div>
          //           <NotificationsIcon
          //             style={{
          //               width: '37px',
          //               height: '37px',
          //               color: '#000000',
          //             }}
          //           />
          //         </div>
          //         <div
          //           className='parent-center-div'
          //           style={{
          //             height: '30px',
          //             width: '30px',
          //             background: '#1A4D2E',
          //             borderRadius: '50%',
          //           }}
          //         >
          //           <div
          //             style={{
          //               position: 'absolute',
          //               color: '#fff',
          //               fontStyle: 'normal',
          //               fontWeight: '600',
          //               fontSize: '22px',
          //               textTransform: 'uppercase',
          //             }}
          //           >
          //             <h6>T</h6>
          //           </div>
          //         </div>
          //       </div>
          //     </div>

          //     <div>
          //       <div className='banner-image-container'>
          //       </div>
          //     </div>

          //     <div className='divider'></div>

          //     <div className='outer-pagination'>
          //       <div className='inner-pagination'>
          //         <div
          //           style={{background: secondaryColor}}
          //           className='pagination-div'
          //         ></div>
          //         <div
          //           style={{background: primaryColor}}
          //           className='pagination-div-active'
          //         ></div>
          //         <div
          //           style={{background: secondaryColor}}
          //           className='pagination-div'
          //         ></div>
          //         <div
          //           style={{background: secondaryColor}}
          //           className='pagination-div'
          //         ></div>
          //       </div>
          //     </div>

          //     <div className='divider'></div>

          //     <div className='body-grid-container-root'>
          //       <div className='body-grid-container-one'>
          //         <div
          //           style={{background: primaryColor}}
          //           className='container-one-tile parent-center-div'
          //         >
          //           <div className='container-one-tile-inner'>
          //             <div>
          //               <Image
          //                 src={enrollIcon}
          //                 alt='Picture of the author'
          //                 width={'62px'}
          //                 height={'62px'}
          //               />
          //             </div>
          //             <div
          //               style={{color: tertiaryColor}}
          //               className='tile-title'
          //             >
          //               Enroll
          //             </div>
          //           </div>
          //         </div>
          //         <div
          //           style={{background: tertiaryColor}}
          //           className='container-one-tile parent-center-div'
          //         >
          //           <div className='container-one-tile-inner'>
          //             <div>
          //               <Image
          //                 src={learnIcon}
          //                 alt='Picture of the author'
          //                 width={'62px'}
          //                 height={'62px'}
          //               />
          //             </div>
          //             <div style={{color: primaryColor}} className='tile-title'>
          //               Learn
          //             </div>
          //           </div>
          //         </div>
          //         <div
          //           style={{background: tertiaryColor}}
          //           className='container-one-tile parent-center-div'
          //         >
          //           <div className='container-one-tile-inner'>
          //             <div>
          //               <Image
          //                 src={reportIcon}
          //                 alt='Picture of the author'
          //                 width={'62px'}
          //                 height={'62px'}
          //               />
          //             </div>
          //             <div style={{color: primaryColor}} className='tile-title'>
          //               Report a change
          //             </div>
          //           </div>
          //         </div>
          //       </div>

          //       <div>
          //         <div
          //           style={{
          //             fontWeight: '500',
          //             fontSize: '16px',
          //             margin: '11px 15px',
          //             color: primaryColor,
          //           }}
          //         >
          //           Bencoin plan options
          //         </div>
          //       </div>

          //       <div className='body-grid-container-one'>
          //         <div
          //           style={{background: primaryColor}}
          //           className='container-one-tile parent-center-div'
          //         >
          //           <div className='container-one-tile-inner'>
          //             <div>
          //               <Image
          //                 src={enrollIcon}
          //                 alt='Picture of the author'
          //                 width={'62px'}
          //                 height={'62px'}
          //               />
          //             </div>
          //             <div
          //               style={{color: tertiaryColor}}
          //               className='tile-title'
          //             >
          //               Enroll with Bencoin plans
          //             </div>
          //           </div>
          //         </div>
          //         <div
          //           style={{background: tertiaryColor}}
          //           className='container-one-tile parent-center-div'
          //         >
          //           <div className='container-one-tile-inner'>
          //             <div>
          //               <Image
          //                 src={balanceIcon}
          //                 alt='Picture of the author'
          //                 width={'62px'}
          //                 height={'62px'}
          //               />
          //             </div>
          //             <div style={{color: primaryColor}} className='tile-title'>
          //               Bencoin Balances
          //             </div>
          //           </div>
          //         </div>
          //       </div>

          //       <div
          //         style={{
          //           display: 'flex',
          //           justifyContent: 'space-between',
          //         }}
          //       >
          //         <div
          //           style={{
          //             fontWeight: '500',
          //             fontSize: '16px',
          //             margin: '11px 15px',
          //             color: primaryColor,
          //           }}
          //         >
          //           All Benefits
          //         </div>
          //         <div
          //           style={{
          //             fontWeight: '400',
          //             fontSize: '10px',
          //             margin: '11px 15px',
          //             color: primaryColor,
          //           }}
          //         >
          //           View all
          //         </div>
          //       </div>

          //       <div className='body-grid-container-two'>
          //         <div
          //           style={{background: tertiaryColor}}
          //           className='container-two-tile parent-center-div'
          //         >
          //           <div className='container-one-tile-inner'>
          //             <div>
          //               <Image
          //                 src={medicalIcon}
          //                 alt='Picture of the author'
          //                 width={'62px'}
          //                 height={'62px'}
          //               />
          //             </div>
          //             <div style={{color: primaryColor}} className='tile-title'>
          //               Bencoin Balances
          //             </div>
          //             <div
          //               style={{color: secondaryColor}}
          //               className='tile-title-lower'
          //             >
          //               Not Enrolled
          //             </div>
          //           </div>
          //         </div>
          //         <div
          //           style={{background: tertiaryColor}}
          //           className='container-two-tile parent-center-div'
          //         >
          //           <div className='container-one-tile-inner'>
          //             <div>
          //               <Image
          //                 src={medicalIcon}
          //                 alt='Picture of the author'
          //                 width={'62px'}
          //                 height={'62px'}
          //               />
          //             </div>
          //             <div style={{color: primaryColor}} className='tile-title'>
          //               Bencoin Balances
          //             </div>
          //             <div
          //               style={{color: secondaryColor}}
          //               className='tile-title-lower'
          //             >
          //               Not Enrolled
          //             </div>
          //           </div>
          //         </div>
          //         <div
          //           style={{background: tertiaryColor}}
          //           className='container-two-tile parent-center-div'
          //         >
          //           <div className='container-one-tile-inner'>
          //             <div>
          //               <Image
          //                 src={medicalIcon}
          //                 alt='Picture of the author'
          //                 width={'62px'}
          //                 height={'62px'}
          //               />
          //             </div>
          //             <div style={{color: primaryColor}} className='tile-title'>
          //               Bencoin Balances
          //             </div>
          //             <div
          //               style={{color: secondaryColor}}
          //               className='tile-title-lower'
          //             >
          //               Not Enrolled
          //             </div>
          //           </div>
          //         </div>
          //         <div
          //           style={{background: tertiaryColor}}
          //           className='container-two-tile parent-center-div'
          //         >
          //           <div className='container-one-tile-inner'>
          //             <div>
          //               <Image
          //                 src={medicalIcon}
          //                 alt='Picture of the author'
          //                 width={'62px'}
          //                 height={'62px'}
          //               />
          //             </div>
          //             <div style={{color: primaryColor}} className='tile-title'>
          //               Bencoin Balances
          //             </div>
          //             <div
          //               style={{color: secondaryColor}}
          //               className='tile-title-lower'
          //             >
          //               Not Enrolled
          //             </div>
          //           </div>
          //         </div>
          //         <div
          //           style={{background: tertiaryColor}}
          //           className='container-two-tile parent-center-div'
          //         >
          //           <div className='container-one-tile-inner'>
          //             <div>
          //               <Image
          //                 src={medicalIcon}
          //                 alt='Picture of the author'
          //                 width={'62px'}
          //                 height={'62px'}
          //               />
          //             </div>
          //             <div style={{color: primaryColor}} className='tile-title'>
          //               Bencoin Balances
          //             </div>
          //             <div
          //               style={{color: secondaryColor}}
          //               className='tile-title-lower'
          //             >
          //               Not Enrolled
          //             </div>
          //           </div>
          //         </div>
          //         <div
          //           style={{background: tertiaryColor}}
          //           className='container-two-tile parent-center-div'
          //         >
          //           <div className='container-one-tile-inner'>
          //             <div>
          //               <Image
          //                 src={medicalIcon}
          //                 alt='Picture of the author'
          //                 width={'62px'}
          //                 height={'62px'}
          //               />
          //             </div>
          //             <div style={{color: primaryColor}} className='tile-title'>
          //               Bencoin Balances
          //             </div>
          //             <div
          //               style={{color: secondaryColor}}
          //               className='tile-title-lower'
          //             >
          //               Not Enrolled
          //             </div>
          //           </div>
          //         </div>
          //       </div>
          //     </div>

          //     <div className='divider'></div>

          //     <div className='style-footer'>
          //       <div className='footer-svg-title-container'>
          //         <div style={{position: 'relative'}}>
          //           <div
          //             className='footer-svg-active-icon'
          //             style={{background: '#FFD24C'}}
          //           >
          //             <div className='footer-svg-active-icon-inner'>
          //               <SVGHome />
          //             </div>
          //           </div>
          //           <div style={{opacity: 0}}>
          //             <SVGHome />
          //           </div>
          //         </div>
          //         <div>
          //           <div style={{color: primaryColor}}>Home</div>
          //         </div>
          //       </div>
          //       <div className='footer-svg-title-container'>
          //         <div>
          //           <SVGInbox />
          //         </div>
          //         <div style={{color: primaryColor}}>Contact your HR</div>
          //       </div>
          //       <div className='footer-svg-title-container'>
          //         <div>
          //           <SupportAgentIcon />
          //         </div>
          //         <div style={{color: primaryColor}}>Contact Provider</div>
          //       </div>
          //       <div className='footer-svg-title-container'>
          //         <div>
          //           <SVGProfile />
          //         </div>
          //         <div style={{color: primaryColor}}>Profile</div>
          //       </div>
          //       <div className='footer-svg-title-container'>
          //         <div>
          //           <SVGLogout />
          //         </div>
          //         <div style={{color: primaryColor}}>Logout</div>
          //       </div>
          //     </div>
          //   </Stack>
          // </Stack>
