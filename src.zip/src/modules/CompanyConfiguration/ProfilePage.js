import Image from 'next/image';
import { FaCamera } from "react-icons/fa";
import { IoIosArrowBack } from "react-icons/io";
import Banner from '../../assets/banner.png';
import BellIcon from "../../assets/header/bell";
import mediLogo from '../../assets/mdiLogo/logo.PNG';
import reloadIcon from '../../assets/reload.png';

const PreviewPage = () => {

    const header = () => {
        return (
            <div className="siteHeader">
                <div className="laft-side-block">
                    <IoIosArrowBack 
                        // onClick={handleBack} 
                    />
                    <div className="header-title">
                        My Profile
                    </div>
                </div>
            

                {/* <div className="year-text">H1 2024 MBSR</div> */}
                <div className="year-text">
                <div className="sitelogo">
                    <Image src={mediLogo} alt="MediBuddy" />
                </div>
                Mid year MBSR Check-in
                </div>

                <div style={{
                    // pointerEvents: isSettingDropDownOpen ? 'none' : 'auto'
                    pointerEvents: 'auto'
                }} className="iconsBlock">

                    <Image src={reloadIcon} alt="reloadIcon" />

                    {/* <Image src={bellIcon} alt="bellIcon" /> */}
                    <BellIcon />
                    {/* <img
                        style={{ cursor: "pointer" }}
                        onClick={() => settingHandler()}
                        src={settingsIcon}
                        alt=""
                    /> */}
                    <div 
                    className="icon-container"
                    style={{ cursor: "pointer" }}
                    //   onClick={() => settingHandler()}
                    >
                    {/* <div className="icon-size"> */}
                    {/* <div className={employeeDetails?.profilePhoto ? "icon-size" : "icon-size-avatar"}> */}
                    <div className="icon-size-avatar">
                        <div className='div-one'>
                            <div className='div-two'>
                                <div className='div-three'>
                                <span className='span-one'>
                                    <span className='span-two'>
                                    PE
                                    </span>
                                </span>
                                </div>
                            </div>
                        </div>
                        {/* <img src={User} /> */}
                    </div>
                    </div>
                </div>
            </div>
        )
    }

    const EmpProfile = () => {
        return (
            <div className="user-profile-page px-10 container">
            <Image src={Banner} className="banner"></Image>
            <div className="row">
                <div className="col-3" style={{position : 'relative'}}>
                    <div className="profile-details">
                        <div className="user-container">
                        <div className='div-one'>
                            <div className='div-two'>
                                <div className='div-three'>
                                <span className='span-one'>
                                    <span className='span-two'>
                                    PE
                                    </span>
                                </span>
                                </div>
                            </div>
                        </div>
                            {/* <input
                            type="file"
                            accept="image/*"
                            onChange={handleImageChange}
                            style={{ display: 'none' }}
                            id="imageInput"
                            /> */}
                            <label htmlFor="imageInput" className="btn btn-dark edit-button">
                            <FaCamera />
                            </label>
                        </div>
                        <p className="userName">
                            pytzq ehbkb
                        </p>
                        <p className="category">
                            Employee
                        </p>
                        <div className="links">
                            <p className="head">Personal Information</p>
                        </div>
                    </div>
                </div>
                <div className="col-9"> 
                    

                   


                    

                    
                    <div className="accorDetails personalInfo">
                        <p className="accordian-title">Personal Details</p>
                        <div className="accordian-data">
                            <div className="d-flex justify-content-between">
                                <p className="title">Employee Name</p>
                                <p className="subTitle">
                                    Employee Name
                                </p>
                            </div>
                            <div className="d-flex justify-content-between">
                                <p className="title">Employee Id</p>
                                <p className="subTitle">
                                    Employee Id
                                </p>
                            </div>
                            <div className="d-flex justify-content-between">
                                <p className="title">Email Id</p>
                                <p className="subTitle">
                                    Email Id
                                </p>
                            </div>
                            <div className="d-flex justify-content-between">
                                <p className="title">Employee type</p>
                                <p className="subTitle">
                                    Employee type
                                </p>
                            </div>
                            <div className="d-flex justify-content-between">
                                <p className="title">Date of joining</p>
                                <p className="subTitle">
                                    Date of joining
                                </p>
                            </div>
                            <div className="d-flex justify-content-between">
                                <p className="title">Level</p>
                                <p className="subTitle">
                                    Level
                                </p>
                            </div>

                        </div>
                    </div>

                    <div className="accorDetails personalInfo">
                        <p className="accordian-title">Organisational Details</p>
                        <div className="accordian-data">
                            <div className="d-flex justify-content-between">
                                <p className="title">Employee Function</p>
                                <p className="subTitle">
                                    Employee Function
                                </p>
                                {/* <p className="subTitle">{employeeDetails?.employeeFunction}</p> */}
                            </div>
                            <div className="d-flex justify-content-between">
                                <p className="title">Employee Sub function</p>
                                <p className="subTitle">
                                    Employee Sub function
                                </p>
                            </div>
                            <div className="d-flex justify-content-between">
                                <p className="title">Manager Name</p>
                                <p className="subTitle">
                                    Manager Name
                                </p>
                            </div>
                            <div className="d-flex justify-content-between">
                                <p className="title">Manager Id</p>
                                <p className="subTitle">
                                    Manager Id
                                </p>
                            </div>
                            <div className="d-flex justify-content-between">
                                <p className="title">Manager Email Id</p>
                                <p className="subTitle">
                                    Manager Email Id
                                </p>
                            </div>
                            

                        </div>
                    </div>

                   

                    

                    

                </div>
            </div>
        </div>
        )
    }

  return (
    <>
     {header()}
     {EmpProfile()}
    </>
  );
};

export default PreviewPage;