import Dashboard from "../../assets/dynamicSidebar/home";
import Profile from "../../assets/dynamicSidebar/profile";
import SelfAssessment from "../../assets/dynamicSidebar/performance";
import Givefeedback from "../../assets/dynamicSidebar/giveFeedback";
import RatingCollab from "../../assets/dynamicSidebar/msbr";
import MyTeam from "../../assets/dynamicSidebar/myteam";
import Feedback from "../../assets/dynamicSidebar/feedback";

export const allRoutes = [
    {
        path: "/dashboard",
        name: "Home",
        icon: <Dashboard />,
      },
      {
        path: "/profile",
        name: "My Profile",
        icon: <Profile />,
      },
      {
        path: "/self-assesment/allinone",
        name: "My Assesment",
        icon: <SelfAssessment />,
      },
      {
        path: "cat-head",
        name: "Feedback",
        icon: <Feedback />,
        subcategory: [          
          {
            path: "/self-assesment/request-feedback",
            name: "Request Feedback",
            icon: <SelfAssessment />,
          },
          {
            path: "/give-peer-feedback",
            name: "Give Feedback(0)",
            icon: <Givefeedback />,
          } ,
        ]
      } ,     
      
      
      {
        path: "/feedback",
        name: "My Team",
        icon: <MyTeam />,
      },
      
      {
        path: "/hrb",
        name: "Rating Calibration",
        icon: <RatingCollab />,
      },
     
];

export const managerRoutes = [
    {
        path: "/dashboard",
        name: "Home",
        icon: <Dashboard />,
      },
      {
        path: "/profile",
        name: "My Profile",
        icon: <Profile />,
      },
      {
        path: "/self-assesment/allinone",
        name: "My Assesment",
        icon: <SelfAssessment />,
      },
      {
        path: "cat-head",
        name: "Feedback",
        icon: <Feedback />,
        subcategory: [          
          {
            path: "/self-assesment/request-feedback",
            name: "Request Feedback",
            icon: <SelfAssessment />,
          },
          {
            path: "/self-assesment/aprove",
            name: "Approve/Suggest",
            icon: <SelfAssessment />,
          },
          {
            path: "/give-peer-feedback",
            name: "Give Feedback(0)",
            icon: <Givefeedback />,
          } ,
        ]
      } ,     
      
      
      {
        path: "/feedback",
        name: "My Team",
        icon: <MyTeam />,
      },
      
      {
        path: "/hrb",
        name: "Rating Calibration",
        icon: <RatingCollab />,
      },
     
];

export const prodRoutes = [   
     {
        path: "/profile",
        name: "My Profile",
        icon: <Profile />,
      },  
      {
        path: "/feedback",
        name: "My Team",
        icon: <MyTeam />,
      },
     
]