import IntlMessages from '@crema/utility/IntlMessages';
import {FormLabel, Stack, Typography} from '@mui/material';
import Divider from '@mui/material/Divider';
import moment from 'moment';
import PropTypes from 'prop-types';
import {useSelector} from 'react-redux';
import {getCompanyDateFormat} from 'shared/utils/CommonUtils';
import {AppCard} from '../../../src/@crema';

const ViewCompanyConfiguration = ({
  CompanyConfigurationData,
  workflowList,
  handleOpenPreviewPage,
}) => {
  let selectedCompany = useSelector(({company}) => company?.selectedCompany);

  return (
    <>
      {CompanyConfigurationData && (
        <AppCard>
          {/* ///////////isCustomizationrequired////////// */}

          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    {
                      <IntlMessages id='companyConfiguration.isCustomizationRequired' />
                    }
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
              <Typography variant='h4' gutterBottom>
                {CompanyConfigurationData?.isCustomizationrequired ? (
                  <IntlMessages id='common.button.Yes' />
                ) : (
                  <IntlMessages id='common.button.No' />
                )}
              </Typography>
              {/* <Button
                color={footerButton.back.color}
                variant={footerButton.back.variant}
                sx={footerButton.back.sx}
                size={footerButton.back.size}
                onClick={() => handleOpenPreviewPage()}
                style={{marginLeft: '52px'}}
              >
                <IntlMessages id='common.button.Preview' />
              </Button> */}
            </Stack>
          </Stack>
          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    {
                      <IntlMessages id='companyConfiguration.choosePrimaryThemeColour' />
                    }
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}}>
              <input
                disabled
                type='color'
                onFocus={(event) =>
                  handleClearColorErrorOnfocus(
                    event,
                    JSON.parse(JSON.stringify(formError)),
                  )
                }
                onChange={(event) => setPrimaryColor(() => event.target.value)}
                id='head'
                name='primaryColor'
                value={CompanyConfigurationData?.primaryColor || ''}
              ></input>
            </Stack>
          </Stack>

          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    {
                      <IntlMessages id='companyConfiguration.chooseSecondaryThemeColour' />
                    }
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}}>
              <input
                disabled
                type='color'
                onFocus={(event) =>
                  handleClearColorErrorOnfocus(
                    event,
                    JSON.parse(JSON.stringify(formError)),
                  )
                }
                onChange={(event) =>
                  setSecondaryColor(() => event.target.value)
                }
                id='head'
                name='secondaryColor'
                value={CompanyConfigurationData?.secondaryColor || ''}
              ></input>
            </Stack>
          </Stack>

          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    {
                      <IntlMessages id='companyConfiguration.chooseTertiaryThemeColour' />
                    }
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>

            <Stack sx={{width: '50%'}}>
              <input
                disabled
                type='color'
                onFocus={(event) =>
                  handleClearColorErrorOnfocus(
                    event,
                    JSON.parse(JSON.stringify(formError)),
                  )
                }
                onChange={(event) => setTertiaryColor(() => event.target.value)}
                id='head'
                name='tertiaryColor'
                value={CompanyConfigurationData?.tertiaryColor || ''}
              ></input>
            </Stack>
          </Stack>
          <Divider color='grey' sx={{my: 3}} varint='fullWidth' />
          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    Is Import Wizard Approval Required ?
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
              <Typography variant='h4' gutterBottom>
                {(CompanyConfigurationData?.importApproval == 'true' ||
                CompanyConfigurationData?.importApproval == true)
                  ? 'Yes'
                  : 'No'}
              </Typography>
            </Stack>
          </Stack>
          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    Selected workflow for import approval?
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
              <Typography variant='h4' gutterBottom>
                {workflowList?.find((item)=>item.id === CompanyConfigurationData?.importWorkflowId)?.name}
              </Typography>
            </Stack>
          </Stack>
          <Divider color='grey' sx={{my: 3}} varint='fullWidth' />
          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    {/* What will be the starting date of the financial year? */}
                    <IntlMessages id='companyConfiguration.startingDateOfFiscal' />
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
              <Typography variant='h4' gutterBottom>
                <span style={{marginLeft: '5'}}>
                  {moment(CompanyConfigurationData?.startCalendarDate).format(
                    getCompanyDateFormat(selectedCompany),
                  )}
                </span>
              </Typography>
            </Stack>
          </Stack>
          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    {/* Company Locale */}
                    <IntlMessages id='companyConfiguration.companyLocale' />
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
              <Typography variant='h4' gutterBottom>
                {CompanyConfigurationData?.companyLocale
                  ? CompanyConfigurationData?.companyLocale
                  : 'NA'}
              </Typography>
            </Stack>
          </Stack>
          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    {<IntlMessages id='companyConfiguration.companyURL' />}
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
              <Typography variant='h4' gutterBottom>
                {CompanyConfigurationData?.companyUrl
                  ? CompanyConfigurationData?.companyUrl
                  : 'NA'}
              </Typography>
            </Stack>
          </Stack>
          {/* ///////////icon ////////// */}
          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    {<IntlMessages id='companyConfiguration.companyIcon' />}
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack
              sx={{
                width: '50%',
                height: '100px',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              <Stack
                sx={{
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  position: 'relative',
                  border: '1px solid blue',
                }}
              >
                <img
                  src={CompanyConfigurationData?.icon?.path}
                  alt='icon'
                  style={{width: 'auto', height: '100px', maxWidth: '100%'}}
                />
              </Stack>
            </Stack>
          </Stack>

          {/* ///////////Banner ////////// */}
          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    {<IntlMessages id='companyConfiguration.companyBanner' />}
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack
              sx={{
                width: '50%',
                height: '100px',
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              <Stack
                sx={{
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  position: 'relative',
                  border: '1px solid blue',
                }}
              >
                <img
                  src={CompanyConfigurationData?.bannerFile?.path}
                  alt='icon'
                  style={{width: 'auto', height: '100px', maxWidth: '100%'}}
                />
              </Stack>
            </Stack>
          </Stack>
          <Divider color='grey' sx={{my: 3}} varint='fullWidth' />
          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    <IntlMessages id='companyConfiguration.primaryContactName' />
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
              <Typography variant='h4' gutterBottom>
                {CompanyConfigurationData?.primaryContactName
                  ? CompanyConfigurationData?.primaryContactName
                  : 'NA'}
              </Typography>
            </Stack>
          </Stack>

          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    <IntlMessages id='companyConfiguration.secondaryContactName' />
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
              <Typography variant='h4' gutterBottom>
                {CompanyConfigurationData?.secondaryContactName
                  ? CompanyConfigurationData?.secondaryContactName
                  : 'NA'}
              </Typography>
            </Stack>
          </Stack>

          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    <IntlMessages id='companyConfiguration.primaryEmail' />
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
              <Typography variant='h4' gutterBottom>
                {CompanyConfigurationData?.primaryEmail
                  ? CompanyConfigurationData?.primaryEmail
                  : 'NA'}
              </Typography>
            </Stack>
          </Stack>
          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    <IntlMessages id='companyConfiguration.secondaryEmail' />
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
              <Typography variant='h4' gutterBottom>
                {CompanyConfigurationData?.secondaryEmail
                  ? CompanyConfigurationData?.secondaryEmail
                  : 'NA'}
              </Typography>
            </Stack>
          </Stack>

          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    <IntlMessages id='companyConfiguration.primaryPhone' />
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
              <Typography variant='h4' gutterBottom>
                {`${CompanyConfigurationData?.primaryPhoneCountryCode} `}
                {CompanyConfigurationData?.primaryPhone
                  ? CompanyConfigurationData?.primaryPhone
                  : 'NA'}
              </Typography>
            </Stack>
          </Stack>

          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    <IntlMessages id='companyConfiguration.secondaryPhone' />
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
              <Typography variant='h4' gutterBottom>
                {`${
                  CompanyConfigurationData?.secondaryPhoneCountryCode ?? ''
                } `}
                {CompanyConfigurationData?.secondaryPhone ?? 'NA'}
              </Typography>
            </Stack>
          </Stack>
          <Divider color='grey' sx={{my: 3}} varint='fullWidth' />

          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    <IntlMessages id='companyConfiguration.companyDateFormat' />
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
              <Typography variant='h4' gutterBottom>
                {CompanyConfigurationData?.dateFormat
                  ? CompanyConfigurationData?.dateFormat
                  : 'NA'}
              </Typography>
            </Stack>
          </Stack>
          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    <IntlMessages id='companyConfiguration.defaultTimeZone' />
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
              <Typography variant='h4' gutterBottom>
                {CompanyConfigurationData?.timezone
                  ? CompanyConfigurationData?.timezone
                  : 'NA'}
              </Typography>
            </Stack>
          </Stack>
          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    <IntlMessages id='companyConfiguration.preferredLanguage' />
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
              <Typography variant='h4' gutterBottom>
                {CompanyConfigurationData?.preferredLanguage
                  ? CompanyConfigurationData?.preferredLanguage.join(', ')
                  : 'NA'}
              </Typography>
            </Stack>
          </Stack>

          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    <IntlMessages id='companyConfiguration.defaultLanguage' />
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
              <Typography variant='h4' gutterBottom>
                {CompanyConfigurationData?.defaultLanguage
                  ? CompanyConfigurationData?.defaultLanguage
                  : 'NA'}
              </Typography>
            </Stack>
          </Stack>

          <Divider color='grey' sx={{my: 3}} varint='fullWidth' />

          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    <IntlMessages id='companyConfiguration.localCurrency' />
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
              <Typography variant='h4' gutterBottom>
                {CompanyConfigurationData?.currency
                  ? CompanyConfigurationData?.currency
                  : 'NA'}
              </Typography>
            </Stack>
          </Stack>

          <Divider color='grey' sx={{my: 3}} varint='fullWidth' />

          <Stack
            direction='row'
            sx={{mt: 2, ml: 3}}
            justifyContent='space-between'
            alignItems='center'
            spacing={2}
          >
            <Stack sx={{width: '50%'}}>
              <FormLabel id='demo-row-radio-buttons-group-label'>
                <Stack direction='row'>
                  <Stack fontWeight={500}>
                    {/* <IntlMessages id='companyConfiguration.localCurrency' /> */}
                    Default Role
                  </Stack>
                </Stack>
              </FormLabel>
            </Stack>
            <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
              <Typography variant='h4' gutterBottom>
                {CompanyConfigurationData?.defaultRole
                  ? CompanyConfigurationData?.defaultRole
                  : 'NA'}
              </Typography>
            </Stack>
          </Stack>

          <Divider color='grey' sx={{my: 3}} varint='fullWidth' />
        </AppCard>
      )}
    </>
  );
};

export default ViewCompanyConfiguration;

ViewCompanyConfiguration.propTypes = {
  CompanyConfigurationData: PropTypes.object,
  handleOpenPreviewPage: PropTypes.func,
};
