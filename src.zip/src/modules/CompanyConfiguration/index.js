import jwtAxios from '@crema/services/auth/jwt-auth';
import IntlMessages from '@crema/utility/IntlMessages';
import {
  Autocomplete,
  CircularProgress,
  FormControl,
  FormLabel,
  IconButton,
  InputLabel,
  MenuItem,
  Select,
  Stack,
} from '@mui/material';
import Button from '@mui/material/Button';
import Checkbox from '@mui/material/Checkbox';
import Divider from '@mui/material/Divider';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormHelperText from '@mui/material/FormHelperText';
import ListItemText from '@mui/material/ListItemText';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import TextField from '@mui/material/TextField';
import {AdapterDateFns} from '@mui/x-date-pickers/AdapterDateFns';
import {DesktopDatePicker} from '@mui/x-date-pickers/DesktopDatePicker';
import {LocalizationProvider} from '@mui/x-date-pickers/LocalizationProvider';
import axios from 'axios';
import Error403 from 'modules/errorPages/Error403';
import * as React from 'react';
import {useEffect, useState} from 'react';
import {GoCloudUpload} from 'react-icons/go';
import {RiDeleteBin4Fill, RiEdit2Fill} from 'react-icons/ri';
import {useDispatch, useSelector} from 'react-redux';
import {showInfo} from 'redux/actions';
import {getCompanyConfigurationData} from 'redux/actions/CompanyConfiguration';
import {API_ROUTS} from 'shared/constants/ApiRouts';
import {footerButton, locale} from 'shared/constants/AppConst';
import {
  ImagesIconsFileType,
  apiCatchErrorMessage,
  getCompanyDateFormatForInputs,
  getIdListFromObjects,
  imageIconAcceptInputString,
  isAllowedUser,
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';
import {permissionName} from 'shared/utils/PermissionName';
import {AppCard} from '../../../src/@crema';
import AppAnimate from '../../../src/@crema/core/AppAnimate';
import AppPageMeta from '../../../src/@crema/core/AppPageMeta';
import {fetchError, fetchStart} from '../../../src/redux/actions';
import AppInfoView from '../../@crema/core/AppInfoView';
import AppLoader from '../../@crema/core/AppLoader';
import {getAllCurrency} from '../../shared/utils/Currency';
import {getAllTimeZonesGMT} from '../../shared/utils/TimeZoneGMT';
import AlertDialog from '../Common/AlertDialog';
import PreviewPage from './PreviewPage';
import ViewCompanyConfiguration from './ViewCompanyConfiguration';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';
import GenericSelectWithSearch from 'modules/Common/GenericSelectWithSearch';
import {getALLCustomQueries} from 'redux/actions/CustomQuery';

const initialConfigurationData = {
  isCustomizationrequired: false,
  icon: null,
  fileUploadStatus: 'NA',
  bannerFile: null,
  bannerFileUploadStatus: 'NA',
  companyUrl: null,

  startCalendarDate: null,
  companyLocale: '',
  primaryContactName: null,
  secondaryContactName: null,
  primaryEmail: null,
  secondaryEmail: null,
  primaryPhone: null,
  primaryPhoneCountryCode: null,
  secondaryPhone: null,
  secondaryPhoneCountryCode: null,

  dateFormat: '',
  regionType: null,
  language: null,
  currency: null,
  defaultLanguage: null,
  preferredLanguage: null,
  templateConfigurationRequired: false,

  defaultRole: null,

  importApproval: false,
  importWorkflowId: null,
};

const languagesList = [
  {code: 'zh', name: 'Chinese'},
  {code: 'es', name: 'Spanish'},
  {code: 'en', name: 'English'},
  {code: 'hi', name: 'Hindi'},
  {code: 'ar', name: 'Arabic'},
  {code: 'bn', name: 'Bengali'},
  {code: 'pt', name: 'Portuguese'},
  {code: 'ru', name: 'Russian'},
  {code: 'ja', name: 'Japanese'},
  {code: 'pa', name: 'Punjabi'},
  {code: 'de', name: 'German'},
  {code: 'jv', name: 'Javanese'},
  {code: 'id', name: 'Indonesian'},
  {code: 'fr', name: 'French'},
];

const CompanyConfiguration = () => {
  let timer;
  const dispatch = useDispatch();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  let companyConfigurationData = useSelector(
    ({companyConfigurationReducer}) =>
      companyConfigurationReducer.companyConfigurationData,
  );

  const [isAuthorized, setIsAuthorized] = React.useState(false);
  const [authLoading, setAuthLoading] = React.useState(true);

  React.useEffect(() => {
    if (isAllowedUser(permissionName.BASIC_CONFIGURATION)) {
      setIsAuthorized(true);
    }
    setAuthLoading(false);
  }, []);

  React.useEffect(() => {
    if (isAuthorized) {
      dispatch(fetchStart);
      dispatch(getCompanyConfigurationData(selectedCompany.id));
      getAllRoles(selectedCompany.id);
      getAllActiveWorkflows(selectedCompany.id);
    }
  }, [isAuthorized, selectedCompany]);

  React.useEffect(() => {
    if (
      isAuthorized &&
      selectedCompany != null &&
      selectedCompany != undefined
    ) {
      if (companyConfigurationData != null) {
        settingCompanyConfigurationBackendData(
          structuredClone(CompanyConfigurationData),
        );
      }
    }
  }, [isAuthorized, companyConfigurationData]);

  const [employeeData, setEmployeeData] = React.useState(null);
  const [CompanyConfigurationData, setCompanyConfigurationData] =
    React.useState(initialConfigurationData);
  const [primaryColor, setPrimaryColor] = React.useState(null);
  const [secondaryColor, setSecondaryColor] = React.useState(null);
  const [tertiaryColor, setTertiaryColor] = React.useState(null);
  const [isActionsDisable, setIsActionsDisable] = React.useState(false);
  const [isUploadingFile, setIsUploadingFile] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(false);
  const [isEdit, setIsEdit] = React.useState(false);
  const [isPreviewPageOpen, setpreviewPageOpen] = React.useState(false);
  const [defaultLanguageOptions, setDefaultLanguageOptions] = useState([]);
  const [roleList, setRoleList] = React.useState([]);
  const [workflowList, setWorkflowList] = React.useState(null);

  // Use useEffect to update the default language options when preferredLanguages changes
  useEffect(() => {
    if (isAuthorized) {
      // Update the default language options based on preferred languages
      const defaultLanguageOptions = languagesList.filter((lang) =>
        CompanyConfigurationData?.preferredLanguage?.includes(lang.name),
      );
      setDefaultLanguageOptions(defaultLanguageOptions);
    }
  }, [isAuthorized, CompanyConfigurationData?.preferredLanguage]);

  const [alertProps, setAlertProps] = React.useState({
    isHideShow: false,
    message: '',
    title: '',
    alertType: '',
    actionParams: null,
  });

  const [formError, setFormError] = React.useState({
    primaryColor: {isError: false, errorMessage: ''},
    secondaryColor: {isError: false, errorMessage: ''},
    tertiaryColor: {isError: false, errorMessage: ''},
    icon: {isError: false, errorMessage: ''},
    bannerFile: {isError: false, errorMessage: ''},
    companyUrl: {isError: false, errorMessage: ''},
    // conversionRate: {isError: false, errorMessage: ''},
    startCalendarDate: {isError: false, errorMessage: ''},
    companyLocale: {isError: false, errorMessage: ''},

    ///////// new field add for contect information ///////
    primaryContactName: {isError: false, errorMessage: ''},
    secondaryContactName: {isError: false, errorMessage: ''},
    primaryEmail: {isError: false, errorMessage: ''},
    secondaryEmail: {isError: false, errorMessage: ''},
    primaryPhone: {isError: false, errorMessage: ''},
    primaryPhoneCountryCode: {isError: false, errorMessage: ''},
    secondaryPhone: {isError: false, errorMessage: ''},
    secondaryPhoneCountryCode: {isError: false, errorMessage: ''},

    dateFormat: {isError: false, errorMessage: ''},
    regionType: {isError: false, errorMessage: ''},
    language: {isError: false, errorMessage: ''},
    preferredLanguage: {isError: false, errorMessage: ''},
    currency: {isError: false, errorMessage: ''},
    timezone: {isError: false, errorMessage: ''},
    defaultLanguage: {isError: false, errorMessage: ''},

    defaultRole: {isError: false, errorMessage: ''},

    importApproval: {isError: false, errorMessage: ''},
    importWorkflowId: {isError: false, errorMessage: ''},
  });

  const getAllRoles = async (companyId) => {
    setIsLoading(() => true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.getAllAuthorities}?companyId=${companyId}`,
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo(`You have no roles`));
          setRoleList([]);
        } else {
          setRoleList(res.data);
        }
        setIsLoading(() => false);
      } else {
        setRoleList([]);
        setIsLoading(() => false);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setRoleList([]);
      setIsLoading(() => false);
    }
  };

  const getAllActiveWorkflows = async (companyId) => {
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.get_all_workflow}/${companyId}/ACTIVE`,
      );

      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no workflow for selected company'));
          setWorkflowList([]);
        } else {
          //*******Reversed original array***********/
          const reversed = res.data.reverse();
          setWorkflowList(reversed);
        }
      } else {
        setWorkflowList([]);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setWorkflowList([]);
    }
  };

  const settingCompanyConfigurationBackendData = (
    tempCompanyConfigurationData,
  ) => {
    tempCompanyConfigurationData.isCustomizationrequired =
      companyConfigurationData.isCustomizationrequired;

    tempCompanyConfigurationData.icon = companyConfigurationData.icon;

    tempCompanyConfigurationData.bannerFile =
      companyConfigurationData.bannerFile;

    tempCompanyConfigurationData.companyUrl =
      companyConfigurationData.companyUrl;

    tempCompanyConfigurationData.conversionRate =
      companyConfigurationData.conversionRate;

    tempCompanyConfigurationData.startCalendarDate =
      companyConfigurationData.startCalendarDate;

    tempCompanyConfigurationData.companyLocale =
      companyConfigurationData.companyLocale;

    //////// mapping contect information ////

    tempCompanyConfigurationData.primaryContactName =
      companyConfigurationData.primaryContactName;

    tempCompanyConfigurationData.secondaryContactName =
      companyConfigurationData.secondaryContactName;

    tempCompanyConfigurationData.primaryEmail =
      companyConfigurationData.primaryEmail;

    tempCompanyConfigurationData.secondaryEmail =
      companyConfigurationData.secondaryEmail;

    tempCompanyConfigurationData.primaryPhone =
      companyConfigurationData.primaryPhone;

    tempCompanyConfigurationData.primaryPhoneCountryCode =
      companyConfigurationData.primaryPhoneCountryCode;

    tempCompanyConfigurationData.secondaryPhone =
      companyConfigurationData.secondaryPhone;

    tempCompanyConfigurationData.secondaryPhoneCountryCode =
      companyConfigurationData.secondaryPhoneCountryCode;

    tempCompanyConfigurationData.dateFormat =
      companyConfigurationData.dateFormat;

    tempCompanyConfigurationData.regionType =
      companyConfigurationData.regionType;

    tempCompanyConfigurationData.language = companyConfigurationData.language;

    tempCompanyConfigurationData.defaultLanguage =
      companyConfigurationData.defaultLanguage;

    tempCompanyConfigurationData.preferredLanguage =
      companyConfigurationData.preferredLanguage;

    tempCompanyConfigurationData.currency = companyConfigurationData.currency;

    tempCompanyConfigurationData.timezone = companyConfigurationData.timezone;

    tempCompanyConfigurationData.templateConfigurationRequired =
      companyConfigurationData.templateConfigurationRequired;

    setPrimaryColor(() => companyConfigurationData.primaryColor);
    setSecondaryColor(() => companyConfigurationData.secondaryColor);
    setTertiaryColor(() => companyConfigurationData.tertiaryColor);
    setCompanyConfigurationData(() => tempCompanyConfigurationData);
  };

  const handleClearColorErrorOnfocus = (event, tempFormError) => {
    tempFormError[event.target.name].isError = false;
    tempFormError[event.target.name].errorMessage = '';
    setFormError(tempFormError);
  };

  const formHelperTextStyle = {
    color: '#d32f2f',
    marginTop: '-12px',
    marginBottom: '16.5px',
  };

  const handleChangeConfigurationData = (
    event,
    fieldName,
    tempCompanyConfigurationData,
    tempFormError,
  ) => {
    if (fieldName === 'ratio') {
      if (tempCompanyConfigurationData[event.target.name] === true) {
        if (event.target.name == 'isCustomizationrequired') {
          tempFormError.primaryColor.isError = false;
          tempFormError.primaryColor.errorMessage = '';
          tempFormError.secondaryColor.isError = false;
          tempFormError.secondaryColor.errorMessage = '';
          tempFormError.tertiaryColor.isError = false;
          tempFormError.tertiaryColor.errorMessage = '';
          setPrimaryColor('#00425A');
          setSecondaryColor('#DFF6FF');
          setTertiaryColor('#7E7E7E');
          document.documentElement.style.setProperty('--primary', '#00425A');
          document.documentElement.style.setProperty('--secondary', '#BAD7E9');
          document.documentElement.style.setProperty('--tertiary', '#7E7E7E');
        }
      }

      tempCompanyConfigurationData[event.target.name] =
        event.target.value === 'true' ? true : false;
      setCompanyConfigurationData(() => tempCompanyConfigurationData);
      setFormError(() => tempFormError);
    } else if (fieldName === 'multiselect') {
      const value = event.target.value;

      let preventDuplicate = value.filter(
        (v, i, a) => a.findIndex((t) => t === v) === i,
      );
      if (value[value?.length - 1] === 'All') {
        preventDuplicate =
          preventDuplicate?.length - 1 === employeeData?.length
            ? []
            : getIdListFromObjects(employeeData, 'id');
      }
      tempCompanyConfigurationData[event.target.name] = preventDuplicate;

      tempFormError[event.target.name].isError = false;
      tempFormError[event.target.name].errorMessage = '';

      setCompanyConfigurationData(() => tempCompanyConfigurationData);
      setFormError(() => tempFormError);
    } else if (fieldName === 'companyUrl') {
      tempCompanyConfigurationData[event.target.name] = event.target.value;
      setCompanyConfigurationData(() => tempCompanyConfigurationData);
      tempFormError[event.target.name].isError = false;
      tempFormError[event.target.name].errorMessage = '';
      setFormError(() => tempFormError);
    } else if (fieldName === 'conversionRate') {
      tempCompanyConfigurationData[event.target.name] = event.target.value;
      setCompanyConfigurationData(() => tempCompanyConfigurationData);
      tempFormError[event.target.name].isError = false;
      tempFormError[event.target.name].errorMessage = '';
      setFormError(() => tempFormError);
    } else if (fieldName === 'startCalendarDate') {
      tempCompanyConfigurationData[fieldName] = event;
      setCompanyConfigurationData(() => tempCompanyConfigurationData);
      tempFormError[fieldName].isError = false;
      tempFormError[fieldName].errorMessage = '';
      setFormError(() => tempFormError);
    } else if (fieldName === 'companyLocale') {
      tempCompanyConfigurationData[event.target.name] = event.target.value;
      setCompanyConfigurationData(() => tempCompanyConfigurationData);
      tempFormError[event.target.name].isError = false;
      tempFormError[event.target.name].errorMessage = '';
      setFormError(() => tempFormError);
    } else if (fieldName === 'textfield') {
      if (
        event.target.name == 'primaryPhone' ||
        event.target.name == 'secondaryPhone'
      ) {
        tempCompanyConfigurationData[event.target.name] =
          event.target.value.replace(/[^0-9]/g, '');
      } else if (
        event.target.name == 'primaryPhoneCountryCode' ||
        event.target.name == 'secondaryPhoneCountryCode'
      ) {
        tempCompanyConfigurationData[event.target.name] =
          event.target.value.replace(/[^+0-9]/g, '');
      } else {
        tempCompanyConfigurationData[event.target.name] = event.target.value;
      }
      setCompanyConfigurationData(() => tempCompanyConfigurationData);
      tempFormError[event.target.name].isError = false;
      tempFormError[event.target.name].errorMessage = '';
      setFormError(() => tempFormError);
    }
  };

  const handleChange = (event, fieldType) => {
    let tempCompanyConfigurationData = {...CompanyConfigurationData};
    let tempFormError = {...formError};

    tempCompanyConfigurationData.importWorkflowId = event.target.value;
    tempFormError.importWorkflowId.isError = false;
    tempFormError.importWorkflowId.errorMessage = '';

    setCompanyConfigurationData(() => tempCompanyConfigurationData);
    setFormError(() => tempFormError);
  };

  const requiredSelectStyled = {
    backgroundColor: 'white',
    mb: 2,
    width: {xs: '100%', xl: '60%', md: '75%'},
    '& fieldset': {
      borderLeftColor: 'red',
      borderLeftWidth: 3,
    },
  };

  const handleDeleteFile = (type) => {
    const tempCategories = JSON.parse(JSON.stringify(CompanyConfigurationData));
    if (type == 'bannerFile') {
      tempCategories.bannerFile = null;
    }
    if (type == 'icon') {
      tempCategories.icon = null;
    }
    setCompanyConfigurationData(tempCategories);
  };

  const handleCaptureFile = (event, type) => {
    const tempCompanyConfigurationData = JSON.parse(
      JSON.stringify(CompanyConfigurationData),
    );
    const file =
      event.target.files.length > 0 ? event.target.files[0] : undefined;
    if (file) {
      if (file.type != 'image/svg+xml') {
        if (file.size > 2097152) {
          if (type == 'bannerFile') {
            setFormError({
              ...formError,
              bannerFile: {
                isError: true,
                // errorMessage: 'Please upload a file smaller than 2 MB',
                errorMessage: (
                  <IntlMessages id='error.pleaseUploadFileSmallerThan2MB' />
                ),
              },
            });
          }
          if (type == 'icon') {
            setFormError({
              ...formError,
              icon: {
                isError: true,
                // errorMessage: 'Please upload a file smaller than 2 MB',
                errorMessage: (
                  <IntlMessages id='error.pleaseUploadFileSmallerThan2MB' />
                ),
              },
            });
          }
        } else {
          if (ImagesIconsFileType(file.name)) {
            if (type == 'bannerFile') {
              tempCompanyConfigurationData.bannerFileUploadStatus = 'LOADING';
            }
            if (type == 'icon') {
              tempCompanyConfigurationData.fileUploadStatus = 'LOADING';
            }
            setCompanyConfigurationData(tempCompanyConfigurationData);
            setTimeout(() => {
              UploadFile(file, type);
              const inputElem = document.getElementById('inputFile_');
              if (inputElem != undefined) inputElem.value = null;
            }, 200);
          } else {
            if (type == 'bannerFile') {
              setFormError({
                ...formError,
                bannerFile: {
                  isError: true,
                  // errorMessage:
                  //   'Select valid image . Allowed formats : png, jpg, jpeg, svg',
                  errorMessage: <IntlMessages id='error.selectValidImage' />,
                },
              });
            }
            if (type == 'icon') {
              setFormError({
                ...formError,
                icon: {
                  isError: true,
                  // errorMessage:
                  //   'Select valid image . Allowed formats : png, jpg, jpeg, svg',
                  errorMessage: <IntlMessages id='error.selectValidImage' />,
                },
              });
            }
          }
        }
      } else {
        if (type == 'bannerFile') {
          setFormError({
            ...formError,
            bannerFile: {
              isError: true,
              errorMessage: (
                <IntlMessages id='error.Please_upload_file_valid' />
              ),
            },
          });
        }
        if (type == 'icon') {
          setFormError({
            ...formError,
            icon: {
              isError: true,
              errorMessage: (
                <IntlMessages id='error.Please_upload_file_valid' />
              ),
            },
          });
        }
      }
    }
  };

  const UploadFile = async (file, type) => {
    setIsActionsDisable(() => true);
    setIsUploadingFile(() => true);
    const formData = new FormData();
    formData.append('file', file);
    const tempCompanyConfigurationData = JSON.parse(
      JSON.stringify(CompanyConfigurationData),
    );
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.file_upload}`,
        formData,
        // {headers: {ContentType: 'multipart/form-data'}},
      );
      if (response.status == 201) {
        if (type == 'bannerFile') {
          tempCompanyConfigurationData.bannerFileUploadStatus = 'LOADED';
          tempCompanyConfigurationData.bannerFile = response.data;
        }
        if (type == 'icon') {
          tempCompanyConfigurationData.fileUploadStatus = 'LOADED';
          tempCompanyConfigurationData.icon = response.data;
        }
      } else {
        if (type == 'bannerFile') {
          tempCompanyConfigurationData.bannerFileUploadStatus = 'NA';
        }
        if (type == 'icon') {
          tempCompanyConfigurationData.fileUploadStatus = 'NA';
        }
      }
    } catch (e) {
      if (type == 'bannerFile') {
        tempCompanyConfigurationData.bannerFileUploadStatus = 'NA';
      }
      if (type == 'icon') {
        tempCompanyConfigurationData.fileUploadStatus = 'NA';
      }
      dispatch(fetchError(e.message));
    }
    setCompanyConfigurationData(tempCompanyConfigurationData);
    if (type == 'icon') {
      setFormError({...formError, icon: {isError: false}});
    }
    if (type == 'bannerFile') {
      setFormError({...formError, bannerFile: {isError: false}});
    }
    setIsActionsDisable(() => false);
    setIsUploadingFile(() => false);
  };
  const getValidateConfiguration = () => {
    let topScrollView = null;
    let isValid = true;
    const temCompanyConfigurationData = structuredClone(
      CompanyConfigurationData,
    );
    const tempError = {...formError};

    if (
      temCompanyConfigurationData.isCustomizationrequired &&
      isEmptyNullUndefined(primaryColor)
    ) {
      tempError.primaryColor.isError = true;
      tempError.primaryColor.errorMessage = (
        <IntlMessages id='error.pleaseSelectPrimaryColour' />
      );
      isValid = false;
      topScrollView = 'stackchoosePrimaryThemeColour';
    }

    if (
      temCompanyConfigurationData.isCustomizationrequired &&
      isEmptyNullUndefined(secondaryColor)
    ) {
      tempError.secondaryColor.isError = true;
      tempError.secondaryColor.errorMessage = (
        <IntlMessages id='error.pleaseSelectSecondaryColour' />
      );
      isValid = false;
      topScrollView = 'stackchooseSecondaryThemeColour';
    }

    if (
      temCompanyConfigurationData.isCustomizationrequired &&
      isEmptyNullUndefined(tertiaryColor)
    ) {
      tempError.tertiaryColor.isError = true;
      tempError.tertiaryColor.errorMessage = (
        <IntlMessages id='error.pleaseSelectTertiaryColour' />
      );
      isValid = false;
      topScrollView = 'stackchooseTertiaryThemeColour';
    }
    if (!isEmptyNullUndefined(temCompanyConfigurationData.companyUrl)) {
      if (
        !temCompanyConfigurationData.companyUrl.match(
          /^(?:(?:https?|ftp):\/\/)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:\/\S*)?$/,
        )
      ) {
        tempError.companyUrl.isError = true;
        tempError.companyUrl.errorMessage = (
          <IntlMessages id='error.pleaseEnterValidURL' />
        );
        isValid = false;
        topScrollView = 'stackcompanyURL';
      }
    }
    if (
      (temCompanyConfigurationData.importApproval == true ||
        temCompanyConfigurationData.importApproval == 'true') &&
      isEmptyNullUndefined(temCompanyConfigurationData.importWorkflowId)
    ) {
      tempError.importWorkflowId.isError = true;
      tempError.importWorkflowId.errorMessage = 'Please select workflow';
      isValid = false;
      topScrollView = 'importWorkflowId';
    }
    if (isEmptyNullUndefined(temCompanyConfigurationData.startCalendarDate)) {
      tempError.startCalendarDate.isError = true;
      tempError.startCalendarDate.errorMessage = (
        <IntlMessages id='error.pleaseEnterCalenderDate' />
      );
      isValid = false;
      topScrollView = 'stackstartCalendarDate';
    }
    if (isEmptyNullUndefined(temCompanyConfigurationData.companyLocale)) {
      tempError.companyLocale.isError = true;
      tempError.companyLocale.errorMessage = (
        <IntlMessages id='error.pleaseEnterLocale' />
      );
      isValid = false;
      topScrollView = 'stackcompanyLocale';
    }

    //////-currency setting-////////

    if (
      temCompanyConfigurationData.currency == null ||
      temCompanyConfigurationData.currency.trim() == ''
    ) {
      tempError.currency.isError = true;
      tempError.currency.errorMessage = (
        <IntlMessages id='error.pleaseSelectCurrency' />
      );
      isValid = false;
      topScrollView = 'currencySettingStack';
    }
    //////end-currency setting-////////

    /////-localSettingsStack-////

    if (
      temCompanyConfigurationData.timezone == null ||
      temCompanyConfigurationData.timezone.trim() == ''
    ) {
      tempError.timezone.isError = true;
      tempError.timezone.errorMessage = (
        <IntlMessages id='error.pleaseSelectTimezone' />
      );
      isValid = false;
      topScrollView = 'localSettingsStack';
    }
    if (isEmptyNullUndefined(temCompanyConfigurationData.dateFormat)) {
      tempError.dateFormat.isError = true;
      tempError.dateFormat.errorMessage = (
        <IntlMessages id='error.pleaseSelectDateFormat' />
      );
      isValid = false;
      topScrollView = 'localSettingsStack';
    }
    if (isEmptyNullUndefined(temCompanyConfigurationData.defaultLanguage)) {
      tempError.defaultLanguage.isError = true;
      tempError.defaultLanguage.errorMessage = (
        <IntlMessages id='error.pleaseSelectLanguage' />
      );
      isValid = false;
      topScrollView = 'localSettingsStack';
    }
    if (isEmptyNullUndefined(temCompanyConfigurationData.preferredLanguage)) {
      tempError.preferredLanguage.isError = true;
      tempError.preferredLanguage.errorMessage = (
        <IntlMessages id='error.pleaseSelectLanguage' />
      );
      isValid = false;
      topScrollView = 'localSettingsStack';
    }
    /////-end localSettingsStack-////

    /////////// contact information //////
    if (
      temCompanyConfigurationData.primaryContactName == null ||
      temCompanyConfigurationData.primaryContactName.trim() == ''
    ) {
      tempError.primaryContactName.isError = true;
      tempError.primaryContactName.errorMessage = (
        <IntlMessages id='error.pleaseEnterPrimaryContactName' />
      );
      isValid = false;
      topScrollView = 'ContactInformationStack';
    }

    if (
      temCompanyConfigurationData.primaryPhone == null ||
      temCompanyConfigurationData.primaryPhone.trim() == ''
    ) {
      tempError.primaryPhone.isError = true;
      tempError.primaryPhone.errorMessage = (
        <IntlMessages id='error.pleaseEnterPrimaryPhoneNumber' />
      );
      isValid = false;
      topScrollView = 'ContactInformationStack';
    } else if (!temCompanyConfigurationData.primaryPhone.match(/^\d{8,11}$/)) {
      tempError.primaryPhone.isError = true;
      tempError.primaryPhone.errorMessage = (
        <IntlMessages id='error.incorrectPhoneNumber' />
      );
      isValid = false;
      topScrollView = 'ContactInformationStack';
    }

    if (
      temCompanyConfigurationData.secondaryPhone == null ||
      temCompanyConfigurationData.secondaryPhone.trim() == ''
    ) {
    } else if (
      !temCompanyConfigurationData.secondaryPhone.match(/^\d{8,11}$/)
    ) {
      tempError.secondaryPhone.isError = true;
      tempError.secondaryPhone.errorMessage = (
        <IntlMessages id='error.incorrectPhoneNumber' />
      );
      isValid = false;
      topScrollView = 'ContactInformationStack';
    }

    if (
      temCompanyConfigurationData.primaryPhoneCountryCode == null ||
      temCompanyConfigurationData.primaryPhoneCountryCode.trim() == ''
    ) {
      tempError.primaryPhoneCountryCode.isError = true;
      tempError.primaryPhoneCountryCode.errorMessage = (
        <IntlMessages id='error.pleaseEnterCountryCode' />
      );
      isValid = false;
      topScrollView = 'ContactInformationStack';
    } else if (
      !temCompanyConfigurationData.primaryPhoneCountryCode.match(
        /^(\+?\d{1,3}|\d{1,4})$/,
      )
    ) {
      tempError.primaryPhoneCountryCode.isError = true;
      tempError.primaryPhoneCountryCode.errorMessage = (
        <IntlMessages id='error.incorrectCountryCode' />
      );
      isValid = false;
      topScrollView = 'ContactInformationStack';
    }

    if (
      temCompanyConfigurationData.primaryEmail == null ||
      temCompanyConfigurationData.primaryEmail.trim() == ''
    ) {
      tempError.primaryEmail.isError = true;
      tempError.primaryEmail.errorMessage = (
        <IntlMessages id='error.pleaseEnterPrimaryEmail' />
      );
      isValid = false;
      topScrollView = 'ContactInformationStack';
    } else if (
      !temCompanyConfigurationData.primaryEmail.match(
        /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
      )
    ) {
      tempError.primaryEmail.isError = true;
      tempError.primaryEmail.errorMessage = (
        <IntlMessages id='error.incorrectEmail' />
      );
      isValid = false;
      topScrollView = 'ContactInformationStack';
    }
    if (
      temCompanyConfigurationData.secondaryEmail == null ||
      temCompanyConfigurationData.secondaryEmail.trim() == ''
    ) {
    } else if (
      !temCompanyConfigurationData?.secondaryEmail?.match(
        /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
      )
    ) {
      tempError.secondaryEmail.isError = true;
      tempError.secondaryEmail.errorMessage = (
        <IntlMessages id='error.incorrectEmail' />
      );
      isValid = false;
      topScrollView = 'ContactInformationStack';
    }

    // --------------
    /////////// end contact information //////

    const scrollElement = document.getElementById(topScrollView);
    if (scrollElement) {
      scrollElement.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
        inline: 'nearest',
      });
    }

    if (isValid) {
      return true;
    } else {
      setFormError(tempError);
      return false;
    }
  };
  const handleSubmitConfirmation = () => {
    const tempAlertProps = {...alertProps};
    if (getValidateConfiguration()) {
      tempAlertProps.isHideShow = true;
      tempAlertProps.alertType = 'Confirmation';
      tempAlertProps.title = (
        <IntlMessages id='companyConfiguration.updateConfiguration' />
      );
      tempAlertProps.message = (
        <span>
          <IntlMessages id='companyConfiguration.areYouSureYouWishUpdate' />
        </span>
      );
      setAlertProps(tempAlertProps);
    }
  };

  const handleAlertNo = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    setAlertProps(tempAlertProps);
  };

  const handleAlertYes = () => {
    const tempAlertProps = {...alertProps};
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;
    if (alertProps.alertType === 'Confirmation') {
      setTimeout(() => {
        setIsActionsDisable(true);
        handleSubmitPlan();
      }, 100);
    }
    setAlertProps(tempAlertProps);
  };

  const textFieldStyled = {
    backgroundColor: 'white',
    mb: 4,
    width: {xs: '100%', xl: '50%', md: '75%'},
  };
  const handleSubmitPlan = async () => {
    const tempCompanyConfigurationData = getMappedsonToPost();
    const payload = {
      ...tempCompanyConfigurationData,
      primaryColor: primaryColor,
      secondaryColor: secondaryColor,
      tertiaryColor: tertiaryColor,
      defaultLanguage: !defaultLanguageOptions.some(
        (option) => option.code === CompanyConfigurationData?.defaultLanguage,
      )
        ? null
        : CompanyConfigurationData?.defaultLanguage,
      preferredLanguage: defaultLanguageOptions.map((lang) => lang.name),
      templateConfigurationRequired:
        CompanyConfigurationData?.templateConfigurationRequired,
    };
    console.log('payload', payload);
    try {
      const response = await jwtAxios.put(
        `${API_ROUTS.company_policy}${selectedCompany.id}`,
        payload,
      );
      if (response.status == 200) {
        setIsEdit(() => false);
        setIsActionsDisable(false);
        // need to do after success where we go.
        setTimeout(() => {
          dispatch(getCompanyConfigurationData(selectedCompany.id));
        }, 500);
      }
    } catch (error) {
      setIsActionsDisable(false);
      if (error?.response?.data?.title) {
        dispatch(fetchError(error?.response?.data?.title));
      } else {
        dispatch(fetchError(error?.message));
      }
    }
  };

  const getMappedsonToPost = () => {
    const tempCompanyConfigurationData = structuredClone(
      CompanyConfigurationData,
    );
    return tempCompanyConfigurationData;
  };

  const handlePageType = () => {
    if (isEdit) {
      handleSubmitConfirmation();
    } else {
      setIsEdit(() => true);
    }
  };

  const handleClosePreviewPage = () => {
    setpreviewPageOpen(false);
  };
  const handleOpenPreviewPage = () => {
    setpreviewPageOpen(true);
  };

  const delayFunctionColorHandler = (value, setterFunction, colorType) => {
    if (timer) {
      clearTimeout(timer);
    }

    timer = setTimeout(() => {
      setterFunction(value);
      document.documentElement.style.setProperty(colorType, value());
    }, 500);

    return timer;
  };

  const getValueById = (queryList, id) => {
    if (!isEmptyNullUndefined(queryList) && !isEmptyNullUndefined(id)) {
      let index = queryList.findIndex((element) => element.id === id);
      if (index !== -1) {
        return queryList[index].query;
      } else {
        return null;
      }
    }
  };

  const createDomCompanyConfiguration = () => {
    return (
      <AppCard>
        {/* ///////////isCustomizationrequired////////// */}
        <Stack
          direction='row'
          sx={{mt: 2, ml: 3}}
          justifyContent='space-between'
          alignItems='center'
          spacing={2}
        >
          <Stack sx={{width: '50%'}}>
            <FormLabel id='demo-row-radio-buttons-group-label'>
              <Stack direction='row'>
                <Stack fontWeight={500}>
                  {
                    <IntlMessages id='companyConfiguration.isCustomizationRequired' />
                  }
                </Stack>
              </Stack>
            </FormLabel>
          </Stack>
          <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
            <RadioGroup
              value={CompanyConfigurationData.isCustomizationrequired}
              onChange={(event) =>
                handleChangeConfigurationData(
                  event,
                  'ratio',
                  structuredClone(CompanyConfigurationData),
                  {...formError},
                )
              }
              row
              aria-labelledby='demo-row-radio-buttons-group-label'
              name='isCustomizationrequired'
            >
              <FormControlLabel
                value={true}
                control={<Radio />}
                label={<IntlMessages id='common.button.Yes' />}
              />
              <FormControlLabel
                value={false}
                control={<Radio />}
                label={<IntlMessages id='common.button.No' />}
              />
            </RadioGroup>
            <Button
              color={footerButton.back.color}
              variant={footerButton.back.variant}
              sx={footerButton.back.sx}
              size={footerButton.back.size}
              onClick={() => handleOpenPreviewPage()}
            >
              <IntlMessages id='common.button.Preview' />
            </Button>
          </Stack>
        </Stack>
        <Stack
          direction='row'
          sx={{mt: 2, ml: 3}}
          justifyContent='space-between'
          alignItems='center'
          spacing={2}
          id='stackchoosePrimaryThemeColour'
        >
          <Stack sx={{width: '50%'}}>
            <FormLabel id='demo-row-radio-buttons-group-label'>
              <Stack direction='row'>
                <Stack fontWeight={500}>
                  {
                    <IntlMessages id='companyConfiguration.choosePrimaryThemeColour' />
                  }
                </Stack>
              </Stack>
            </FormLabel>
          </Stack>
          <Stack sx={{width: '50%'}}>
            <div
              style={{
                height: '30px',
                width: '60px',
                backgroundColor: primaryColor,
                border: '5px solid black',
              }}
            >
              <input
                style={{opacity: 0, cursor: 'pointer'}}
                disabled={!CompanyConfigurationData.isCustomizationrequired}
                type='color'
                onFocus={(event) =>
                  handleClearColorErrorOnfocus(event, {...formError})
                }
                onChange={(event) =>
                  delayFunctionColorHandler(
                    () => event.target.value,
                    setPrimaryColor,
                    '--primary',
                  )
                }
                id='head'
                name='primaryColor'
              ></input>
            </div>
            {formError.primaryColor.isError && (
              <FormHelperText className='Mui-error'>
                {formError.primaryColor.errorMessage}
              </FormHelperText>
            )}
          </Stack>
        </Stack>

        <Stack
          direction='row'
          sx={{mt: 2, ml: 3}}
          justifyContent='space-between'
          alignItems='center'
          spacing={2}
          id='stackchooseSecondaryThemeColour'
        >
          <Stack sx={{width: '50%'}}>
            <FormLabel id='demo-row-radio-buttons-group-label'>
              <Stack direction='row'>
                <Stack fontWeight={500}>
                  {
                    <IntlMessages id='companyConfiguration.chooseSecondaryThemeColour' />
                  }
                </Stack>
                {/* <Stack sx={{color: 'red', ml: 2, mb: 2, fontSize: 14}}>*</Stack> */}
              </Stack>
            </FormLabel>
          </Stack>
          <Stack sx={{width: '50%'}}>
            <div
              style={{
                height: '30px',
                width: '60px',
                backgroundColor: secondaryColor,
                border: '5px solid black',
              }}
            >
              <input
                style={{opacity: 0, cursor: 'pointer'}}
                disabled={!CompanyConfigurationData.isCustomizationrequired}
                type='color'
                onFocus={(event) =>
                  handleClearColorErrorOnfocus(event, {...formError})
                }
                onChange={(event) =>
                  delayFunctionColorHandler(
                    () => event.target.value,
                    setSecondaryColor,
                    '--secondary',
                  )
                }
                id='head'
                name='secondaryColor'
              ></input>
            </div>
            {formError.secondaryColor.isError && (
              <FormHelperText className='Mui-error'>
                {formError.secondaryColor.errorMessage}
              </FormHelperText>
            )}
          </Stack>
        </Stack>

        <Stack
          direction='row'
          sx={{mt: 2, ml: 3}}
          justifyContent='space-between'
          alignItems='center'
          spacing={2}
          id='stackchooseTertiaryThemeColour'
        >
          <Stack sx={{width: '50%'}}>
            <FormLabel id='demo-row-radio-buttons-group-label'>
              <Stack direction='row'>
                <Stack fontWeight={500}>
                  {
                    <IntlMessages id='companyConfiguration.chooseTertiaryThemeColour' />
                  }
                </Stack>
              </Stack>
            </FormLabel>
          </Stack>

          <Stack sx={{width: '50%'}}>
            <div
              style={{
                height: '30px',
                width: '60px',
                backgroundColor: tertiaryColor,
                border: '5px solid black',
              }}
            >
              <input
                style={{opacity: 0, cursor: 'pointer'}}
                disabled={!CompanyConfigurationData.isCustomizationrequired}
                type='color'
                onFocus={(event) =>
                  handleClearColorErrorOnfocus(event, {...formError})
                }
                onChange={(event) =>
                  delayFunctionColorHandler(
                    () => event.target.value,
                    setTertiaryColor,
                    '--tertiary',
                  )
                }
                id='head'
                name='tertiaryColor'
              ></input>
            </div>
            {formError.tertiaryColor.isError && (
              <FormHelperText className='Mui-error'>
                {formError.tertiaryColor.errorMessage}
              </FormHelperText>
            )}
          </Stack>
        </Stack>
        <Divider color='grey' sx={{my: 3}} varint='fullWidth' />

        <Stack
          direction='row'
          sx={{mt: 2, ml: 3}}
          justifyContent='space-between'
          alignItems='center'
          spacing={2}
        >
          <Stack sx={{width: '50%'}}>
            <FormLabel id='demo-row-radio-buttons-group-label'>
              <Stack direction='row'>
                <Stack fontWeight={500}>
                  Is Import Wizard Approval Required ?
                </Stack>
              </Stack>
            </FormLabel>
          </Stack>
          <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
            <RadioGroup
              value={Boolean(CompanyConfigurationData?.importApproval)}
              onChange={(event) =>
                handleChangeConfigurationData(
                  event,
                  'ratio',
                  structuredClone(CompanyConfigurationData),
                  {...formError},
                )
              }
              row
              aria-labelledby='demo-row-radio-buttons-group-label'
              name='importApproval'
            >
              <FormControlLabel
                value={true}
                control={<Radio />}
                label={<IntlMessages id='common.button.Yes' />}
              />
              <FormControlLabel
                value={false}
                control={<Radio />}
                label={<IntlMessages id='common.button.No' />}
              />
            </RadioGroup>
          </Stack>
        </Stack>
        {(CompanyConfigurationData?.importApproval == true ||
          CompanyConfigurationData?.importApproval == 'true') && (
          <>
            <Stack
              direction='row'
              sx={{mt: 2, ml: 3}}
              justifyContent='space-between'
              alignItems='center'
              spacing={2}
              id='importWorkflowId'
            >
              <Stack sx={{width: '50%'}}>
                <FormLabel id='demo-row-radio-buttons-group-label'>
                  <Stack direction='row'>
                    <Stack fontWeight={500}>
                      Select workflow : 
                    </Stack>
                  </Stack>
                </FormLabel>
              </Stack>
              <Stack sx={{width: '50%'}} direction='row' alignItems='center'>
                <GenericSelectWithSearch
                  label={'Select workflow'}
                  name={'importWorkflowId'}
                  value={CompanyConfigurationData?.importWorkflowId || ''}
                  error={formError.importWorkflowId.errorMessage}
                  helperText={formError.importWorkflowId.errorMessage}
                  handleChange={handleChange}
                  optionList={workflowList}
                  labelName={'name'}
                  customStyles={{
                    ...textFieldStyled,
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                    },
                    width: '100%',
                  }}
                />
              </Stack>
            </Stack>
          </>
        )}
        <Divider color='grey' sx={{my: 3}} varint='fullWidth' />

        <Stack
          direction='row'
          sx={{mt: 2, ml: 3}}
          justifyContent='space-between'
          alignItems='center'
          spacing={2}
          id='stackstartCalendarDate'
        >
          <Stack sx={{width: '50%'}}>
            <FormLabel id='demo-row-radio-buttons-group-label'>
              <Stack direction='row'>
                <Stack fontWeight={500}>
                  {/* What will be the starting date of the financial year? */}
                  <IntlMessages id='companyConfiguration.startingDateOfFiscal' />
                </Stack>
              </Stack>
            </FormLabel>
          </Stack>
          <Stack sx={{width: '50%'}}>
            <LocalizationProvider dateAdapter={AdapterDateFns}>
              <DesktopDatePicker
                inputFormat={getCompanyDateFormatForInputs(selectedCompany)}
                value={CompanyConfigurationData.startCalendarDate || null}
                // label='date of financial year'
                label={
                  <IntlMessages id='companyConfiguration.dateOfFinancialYear' />
                }
                name='startCalendarDate'
                onChange={(event) =>
                  handleChangeConfigurationData(
                    event,
                    'startCalendarDate',
                    structuredClone(CompanyConfigurationData),
                    {...formError},
                  )
                }
                renderInput={(params) => (
                  <TextField
                    size='small'
                    helperText={formError.startCalendarDate.errorMessage}
                    variant='outlined'
                    sx={{...requiredSelectStyled}}
                    {...params}
                    error={formError.startCalendarDate.isError}
                  />
                )}
              />
            </LocalizationProvider>
          </Stack>
        </Stack>

        <Stack
          direction='row'
          sx={{mt: 2, ml: 3}}
          justifyContent='space-between'
          alignItems='center'
          spacing={2}
          id='stackcompanyLocale'
        >
          <Stack sx={{width: '50%'}}>
            <FormLabel id='demo-row-radio-buttons-group-label'>
              <Stack direction='row'>
                <Stack fontWeight={500}>
                  {/* Company Locale */}
                  <IntlMessages id='companyConfiguration.companyLocale' />
                </Stack>
              </Stack>
            </FormLabel>
          </Stack>
          <Stack sx={{width: '50%'}}>
            <FormControl sx={{mb: 2}}>
              <InputLabel size='small' id='companyLocale'>
                {/* Company Locale */}
                <IntlMessages id='companyConfiguration.companyLocale' />
              </InputLabel>
              <Select
                name='companyLocale'
                value={CompanyConfigurationData.companyLocale}
                labelId='companyLocale'
                label='Company Locale'
                onChange={(event) =>
                  handleChangeConfigurationData(
                    event,
                    'companyLocale',
                    structuredClone(CompanyConfigurationData),
                    {...formError},
                  )
                }
                variant='outlined'
                size='small'
                sx={{...requiredSelectStyled}}
                style={{marginBottom: '0px'}}
              >
                {locale.map((element) => {
                  return (
                    <MenuItem key={element.key} value={element.value}>
                      {element.name}
                    </MenuItem>
                  );
                })}
              </Select>
              {formError.companyLocale.isError && (
                <FormHelperText className='Mui-error'>
                  {formError.companyLocale.errorMessage}
                </FormHelperText>
              )}
            </FormControl>
          </Stack>
        </Stack>

        <Stack
          direction='row'
          sx={{mt: 2, ml: 3}}
          justifyContent='space-between'
          alignItems='center'
          spacing={2}
          id='stackcompanyURL'
        >
          <Stack sx={{width: '50%'}}>
            <FormLabel id='demo-row-radio-buttons-group-label'>
              <Stack direction='row'>
                <Stack fontWeight={500}>
                  {<IntlMessages id='companyConfiguration.companyURL' />}
                </Stack>
              </Stack>
            </FormLabel>
          </Stack>
          <Stack sx={{width: '50%'}}>
            <TextField
              size='small'
              name='companyUrl'
              label={<IntlMessages id='companyConfiguration.companyURL' />}
              onChange={(event) =>
                handleChangeConfigurationData(
                  event,
                  'companyUrl',
                  structuredClone(CompanyConfigurationData),
                  {...formError},
                )
              }
              variant='outlined'
              value={
                CompanyConfigurationData.companyUrl
                  ? CompanyConfigurationData.companyUrl
                  : ''
              }
              error={formError.companyUrl.isError}
              helperText={formError.companyUrl.errorMessage}
              sx={{
                backgroundColor: 'white',
                mb: 4,
                width: {xs: '100%', xl: '50%', md: '75%'},
              }}
            />
          </Stack>
        </Stack>

        {/* ///////////icon ////////// */}
        <Stack
          direction='row'
          sx={{mt: 2, ml: 3}}
          justifyContent='space-between'
          alignItems='center'
          spacing={2}
        >
          <Stack sx={{width: '50%'}}>
            <FormLabel id='demo-row-radio-buttons-group-label'>
              <Stack direction='row'>
                <Stack fontWeight={500}>
                  {<IntlMessages id='companyConfiguration.companyIcon' />}
                </Stack>
              </Stack>
            </FormLabel>
          </Stack>

          {/* --------------------------------------- */}

          <Stack
            direction='row'
            sx={{
              display: 'flex',
              // justifyContent: 'center',
              justifyContent: 'flex-start',
              alignItems: 'center',
              width: '50%',
            }}
          >
            {CompanyConfigurationData.fileUploadStatus != 'LOADING' &&
              CompanyConfigurationData.icon == null && (
                <Stack
                  sx={{
                    width: '50%',
                    height: '100px',
                    border: '1px dashed #ccc2c2',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor: '#f6f6f6',
                  }}
                >
                  <IconButton
                    color='primary'
                    aria-label='upload document'
                    component='label'
                    sx={{
                      width: '100%',
                      height: '100%',
                      borderRadius: '0px',
                    }}
                  >
                    <input
                      id={'inputFile_'}
                      onChange={(event) => handleCaptureFile(event, 'icon')}
                      hidden
                      type='file'
                      label='File upload'
                      accept={imageIconAcceptInputString}
                      disabled={isUploadingFile}
                    />
                    <GoCloudUpload
                      style={{fontSize: '4.5rem', marginRight: '2rem'}}
                    />
                    <IntlMessages id='companyConfiguration.uploadIcon' />
                  </IconButton>
                </Stack>
              )}
            <Stack
              sx={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                position: 'relative',
                border: '1px solid blue',
              }}
            >
              {CompanyConfigurationData.fileUploadStatus == 'LOADING' && (
                <CircularProgress size={20} />
              )}
              {CompanyConfigurationData.fileUploadStatus != 'LOADING' &&
                CompanyConfigurationData.icon != null && (
                  <Stack>
                    <img
                      src={CompanyConfigurationData?.icon?.path}
                      alt='icon'
                      style={{width: 'auto', height: '100px', maxWidth: '100%'}}
                    />
                    <IconButton
                      //disabled={!checked}
                      color='primary'
                      aria-label='upload document'
                      component='label'
                      style={{
                        position: 'absolute',
                        right: '-14px',
                        top: '20px',
                        fontSize: '1.25rem',
                        color: 'blue',
                        backgroundColor: '#ffffff',
                        padding: '2px',
                        width: '1.75rem',
                        height: '1.75rem',
                        borderRadius: '1rem',
                        border: '1px solid gray',
                      }}
                    >
                      <input
                        id={'inputFile_'}
                        onChange={(event) => handleCaptureFile(event, 'icon')}
                        hidden
                        type='file'
                        label='File upload'
                        accept={imageIconAcceptInputString}
                        disabled={isUploadingFile}
                      />
                      <RiEdit2Fill />
                    </IconButton>

                    <RiDeleteBin4Fill
                      onClick={() => handleDeleteFile('icon')}
                      style={{
                        position: 'absolute',
                        right: '-14px',
                        top: '52px',
                        fontSize: '1.25rem',
                        color: 'blue',
                        backgroundColor: '#ffffff',
                        padding: '2px',
                        width: '1.75rem',
                        height: '1.75rem',
                        borderRadius: '1rem',
                        border: '1px solid gray',
                        cursor: 'pointer',
                      }}
                    />
                  </Stack>
                )}
            </Stack>
          </Stack>
        </Stack>
        {formError.icon.isError && (
          <FormHelperText className='Mui-error' sx={{marginLeft: '530px'}}>
            {formError.icon.errorMessage}
          </FormHelperText>
        )}
        <Stack
          direction='row'
          sx={{mt: 2, ml: 3}}
          justifyContent='space-between'
          alignItems='center'
          spacing={2}
        >
          <Stack sx={{width: '50%'}}>
            <FormLabel id='demo-row-radio-buttons-group-label'>
              <Stack direction='row'>
                <Stack fontWeight={500}>
                  {<IntlMessages id='companyConfiguration.companyBanner' />}
                </Stack>
              </Stack>
            </FormLabel>
          </Stack>

          {/* --------------------------------------- */}

          <Stack
            direction='row'
            sx={{
              display: 'flex',
              // justifyContent: 'center',
              justifyContent: 'flex-start',
              alignItems: 'center',
              width: '50%',
            }}
          >
            {CompanyConfigurationData.bannerFileUploadStatus != 'LOADING' &&
              CompanyConfigurationData.bannerFile == null && (
                <Stack
                  sx={{
                    width: '50%',
                    height: '100px',
                    border: '1px dashed #ccc2c2',
                    display: 'flex',
                    justifyContent: 'center',
                    alignItems: 'center',
                    backgroundColor: '#f6f6f6',
                  }}
                >
                  <IconButton
                    color='primary'
                    aria-label='upload document'
                    component='label'
                    sx={{
                      width: '100%',
                      height: '100%',
                      borderRadius: '0px',
                    }}
                  >
                    <input
                      id={'inputFile_'}
                      onChange={(event) =>
                        handleCaptureFile(event, 'bannerFile')
                      }
                      hidden
                      type='file'
                      label='File upload'
                      accept={imageIconAcceptInputString}
                      disabled={isUploadingFile}
                    />
                    <GoCloudUpload
                      style={{fontSize: '4.5rem', marginRight: '2rem'}}
                    />
                    <IntlMessages id='companyConfiguration.uploadBanner' />
                  </IconButton>
                </Stack>
              )}
            <Stack
              sx={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                position: 'relative',
                border: '1px solid blue',
              }}
            >
              {CompanyConfigurationData.bannerFileUploadStatus == 'LOADING' && (
                <CircularProgress size={20} />
              )}
              {CompanyConfigurationData.bannerFileUploadStatus != 'LOADING' &&
                CompanyConfigurationData.bannerFile != null && (
                  <Stack>
                    <img
                      src={CompanyConfigurationData?.bannerFile?.path}
                      alt='bannerFile'
                      style={{width: 'auto', height: '100px', maxWidth: '100%'}}
                    />
                    <IconButton
                      color='primary'
                      aria-label='upload document'
                      component='label'
                      style={{
                        position: 'absolute',
                        right: '-14px',
                        top: '20px',
                        fontSize: '1.25rem',
                        color: 'blue',
                        backgroundColor: '#ffffff',
                        padding: '2px',
                        width: '1.75rem',
                        height: '1.75rem',
                        borderRadius: '1rem',
                        border: '1px solid gray',
                      }}
                    >
                      <input
                        id={'inputFile_'}
                        onChange={(event) =>
                          handleCaptureFile(event, 'bannerFile')
                        }
                        hidden
                        type='file'
                        label='File upload'
                        accept={imageIconAcceptInputString}
                        disabled={isUploadingFile}
                      />
                      <RiEdit2Fill />
                    </IconButton>

                    <RiDeleteBin4Fill
                      onClick={() => handleDeleteFile('bannerFile')}
                      style={{
                        position: 'absolute',
                        right: '-14px',
                        top: '52px',
                        fontSize: '1.25rem',
                        color: 'blue',
                        backgroundColor: '#ffffff',
                        padding: '2px',
                        width: '1.75rem',
                        height: '1.75rem',
                        borderRadius: '1rem',
                        border: '1px solid gray',
                        cursor: 'pointer',
                      }}
                    />
                  </Stack>
                )}
            </Stack>
          </Stack>
        </Stack>
        {formError.bannerFile.isError && (
          <FormHelperText className='Mui-error' sx={{marginLeft: '530px'}}>
            {formError.bannerFile.errorMessage}
          </FormHelperText>
        )}
        {/* ------------------------------ contect detail  ------------ start--------------- */}

        <Divider color='grey' sx={{my: 3}} varint='fullWidth' />

        <h4>
          <IntlMessages id='company.addCompany.contactInformation' />
        </h4>
        {/* 648 - 734 media screen from large screen */}
        <Stack
          display={{sm: 'flex', xs: 'none'}}
          direction={{xs: 'column', sm: 'row'}}
          sx={{mt: 2}}
          justifyContent='space-between'
          alignItems='flex-start'
          spacing={2}
          id='ContactInformationStack'
        >
          <Stack sx={{mb: 5}} width={{xs: '100%', sm: '50%'}}>
            <TextField
              size='small'
              name='primaryContactName'
              label={
                <IntlMessages id='company.addCompany.primaryContactName' />
              }
              variant='outlined'
              error={formError.primaryContactName.isError}
              helperText={formError.primaryContactName.errorMessage}
              onChange={(event) =>
                handleChangeConfigurationData(
                  event,
                  'textfield',
                  structuredClone(CompanyConfigurationData),
                  {...formError},
                )
              }
              value={
                CompanyConfigurationData.primaryContactName
                  ? CompanyConfigurationData.primaryContactName
                  : ''
              }
              sx={{
                ...textFieldStyled,
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {
                    borderLeftColor: 'red',
                    borderLeftWidth: 3,
                  },
                },
              }}
            />
            <TextField
              size='small'
              multiline
              maxRows={3}
              name='primaryEmail'
              label={<IntlMessages id='company.addCompany.primaryEmail' />}
              onChange={(event) =>
                handleChangeConfigurationData(
                  event,
                  'textfield',
                  structuredClone(CompanyConfigurationData),
                  {...formError},
                )
              }
              variant='outlined'
              error={formError.primaryEmail.isError}
              helperText={formError.primaryEmail.errorMessage}
              value={
                CompanyConfigurationData.primaryEmail
                  ? CompanyConfigurationData.primaryEmail
                  : ''
              }
              sx={{
                ...textFieldStyled,
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {
                    borderLeftColor: 'red',
                    borderLeftWidth: 3,
                  },
                },
              }}
            />
            <Stack
              direction='row'
              width={{xs: '100%', sm: '100%', md: '75%', xl: '50%'}}
              id='stackprimaryPhone'
            >
              <TextField
                size='small'
                name='primaryPhoneCountryCode'
                onChange={(event) =>
                  handleChangeConfigurationData(
                    event,
                    'textfield',
                    structuredClone(CompanyConfigurationData),
                    {...formError},
                  )
                }
                label={<IntlMessages id='company.addCompany.code' />}
                variant='outlined'
                placeholder='###'
                error={formError.primaryPhoneCountryCode.isError}
                helperText={formError.primaryPhoneCountryCode.errorMessage}
                value={
                  CompanyConfigurationData.primaryPhoneCountryCode
                    ? CompanyConfigurationData.primaryPhoneCountryCode
                    : ''
                }
                sx={{
                  ...textFieldStyled,
                  width: '25%',
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              />
              <TextField
                size='small'
                name='primaryPhone'
                onChange={(event) =>
                  handleChangeConfigurationData(
                    event,
                    'textfield',
                    structuredClone(CompanyConfigurationData),
                    {...formError},
                  )
                }
                label={<IntlMessages id='company.addCompany.primaryPhone' />}
                variant='outlined'
                placeholder='#########'
                error={formError.primaryPhone.isError}
                helperText={formError.primaryPhone.errorMessage}
                value={
                  CompanyConfigurationData.primaryPhone
                    ? CompanyConfigurationData.primaryPhone
                    : ''
                }
                sx={{
                  ...textFieldStyled,
                  width: '75%',
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              />
            </Stack>
          </Stack>
          <Stack sx={{mb: 5}} width={{xs: '100%', sm: '50%'}}>
            <TextField
              size='small'
              name='secondaryContactName'
              label={
                <IntlMessages id='company.addCompany.secondaryContactName' />
              }
              onChange={(event) =>
                handleChangeConfigurationData(
                  event,
                  'textfield',
                  structuredClone(CompanyConfigurationData),
                  {...formError},
                )
              }
              variant='outlined'
              error={formError.secondaryContactName.isError}
              helperText={formError.secondaryContactName.errorMessage}
              value={
                CompanyConfigurationData.secondaryContactName
                  ? CompanyConfigurationData.secondaryContactName
                  : ''
              }
              sx={{
                ...textFieldStyled,
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {},
                },
              }}
            />
            <TextField
              size='small'
              multiline
              maxRows={3}
              name='secondaryEmail'
              label={<IntlMessages id='company.addCompany.secondaryEmail' />}
              onChange={(event) =>
                handleChangeConfigurationData(
                  event,
                  'textfield',
                  structuredClone(CompanyConfigurationData),
                  {...formError},
                )
              }
              variant='outlined'
              error={formError.secondaryEmail.isError}
              helperText={formError.secondaryEmail.errorMessage}
              value={
                CompanyConfigurationData.secondaryEmail
                  ? CompanyConfigurationData.secondaryEmail
                  : ''
              }
              sx={{
                ...textFieldStyled,
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {},
                },
              }}
            />
            <Stack
              direction='row'
              width={{xs: '100%', sm: '100%', md: '75%', xl: '50%'}}
              id='stacksecondaryPhone'
            >
              <TextField
                size='small'
                name='secondaryPhoneCountryCode'
                onChange={(event) =>
                  handleChangeConfigurationData(
                    event,
                    'textfield',
                    structuredClone(CompanyConfigurationData),
                    {...formError},
                  )
                }
                label={<IntlMessages id='company.addCompany.code' />}
                variant='outlined'
                placeholder='###'
                error={formError.secondaryPhoneCountryCode.isError}
                helperText={formError.secondaryPhoneCountryCode.errorMessage}
                value={
                  CompanyConfigurationData.secondaryPhoneCountryCode
                    ? CompanyConfigurationData.secondaryPhoneCountryCode
                    : ''
                }
                sx={{
                  ...textFieldStyled,
                  width: '25%',
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {},
                  },
                }}
              />
              <TextField
                size='small'
                name='secondaryPhone'
                onChange={(event) =>
                  handleChangeConfigurationData(
                    event,
                    'textfield',
                    structuredClone(CompanyConfigurationData),
                    {...formError},
                  )
                }
                label={<IntlMessages id='company.addCompany.secondaryPhone' />}
                variant='outlined'
                placeholder='#########'
                error={formError.secondaryPhone.isError}
                helperText={formError.secondaryPhone.errorMessage}
                value={
                  CompanyConfigurationData.secondaryPhone
                    ? CompanyConfigurationData.secondaryPhone
                    : ''
                }
                sx={{
                  ...textFieldStyled,
                  width: '75%',
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {},
                  },
                }}
              />
            </Stack>
          </Stack>
        </Stack>
        {/* end media screen */}

        {/* 737 -  for small screen */}
        <Stack
          display={{sm: 'none', xs: 'flex'}}
          direction={{xs: 'column', sm: 'row'}}
          sx={{mt: 2}}
          justifyContent='space-between'
          alignItems='flex-start'
          spacing={2}
        >
          <Stack sx={{mb: 5}} width={{xs: '100%', sm: '50%'}}>
            <TextField
              size='small'
              name='primaryContactName'
              label={
                <IntlMessages id='company.addCompany.primaryContactName' />
              }
              onChange={(event) =>
                handleChangeConfigurationData(
                  event,
                  'textfield',
                  structuredClone(CompanyConfigurationData),
                  {...formError},
                )
              }
              value={
                CompanyConfigurationData.primaryContactName
                  ? CompanyConfigurationData.primaryContactName
                  : ''
              }
              variant='outlined'
              error={formError.primaryContactName.isError}
              helperText={formError.primaryContactName.errorMessage}
              sx={{
                ...textFieldStyled,
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {
                    borderLeftColor: 'red',
                    borderLeftWidth: 3,
                  },
                },
              }}
            />
            <Stack
              direction='row'
              width={{xs: '100%', sm: '100%', md: '75%', xl: '50%'}}
            >
              <TextField
                size='small'
                name='primaryPhoneCountryCode'
                onChange={(event) =>
                  handleChangeConfigurationData(
                    event,
                    'textfield',
                    structuredClone(CompanyConfigurationData),
                    {...formError},
                  )
                }
                label={<IntlMessages id='company.addCompany.code' />}
                variant='outlined'
                placeholder='###'
                error={formError.primaryPhoneCountryCode.isError}
                helperText={formError.primaryPhoneCountryCode.errorMessage}
                value={
                  CompanyConfigurationData.primaryPhoneCountryCode
                    ? CompanyConfigurationData.primaryPhoneCountryCode
                    : ''
                }
                sx={{
                  ...textFieldStyled,
                  width: '25%',
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              />
              <TextField
                size='small'
                name='primaryPhone'
                onChange={(event) =>
                  handleChangeConfigurationData(
                    event,
                    'textfield',
                    structuredClone(CompanyConfigurationData),
                    {...formError},
                  )
                }
                label={<IntlMessages id='company.addCompany.primaryPhone' />}
                variant='outlined'
                placeholder='#########'
                error={formError.primaryPhone.isError}
                helperText={formError.primaryPhone.errorMessage}
                value={
                  CompanyConfigurationData.primaryPhone
                    ? CompanyConfigurationData.primaryPhone
                    : ''
                }
                sx={{
                  ...textFieldStyled,
                  width: '75%',
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              />
            </Stack>
            <TextField
              size='small'
              multiline
              maxRows={3}
              name='primaryEmail'
              label={<IntlMessages id='company.addCompany.primaryEmail' />}
              onChange={(event) =>
                handleChangeConfigurationData(
                  event,
                  'textfield',
                  structuredClone(CompanyConfigurationData),
                  {...formError},
                )
              }
              variant='outlined'
              error={formError.primaryEmail.isError}
              helperText={formError.primaryEmail.errorMessage}
              value={
                CompanyConfigurationData.primaryEmail
                  ? CompanyConfigurationData.primaryEmail
                  : ''
              }
              sx={{
                ...textFieldStyled,
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {
                    borderLeftColor: 'red',
                    borderLeftWidth: 3,
                  },
                },
              }}
            />
            <TextField
              size='small'
              name='secondaryContactName'
              label={
                <IntlMessages id='company.addCompany.secondaryContactName' />
              }
              onChange={(event) =>
                handleChangeConfigurationData(
                  event,
                  'textfield',
                  structuredClone(CompanyConfigurationData),
                  {...formError},
                )
              }
              variant='outlined'
              error={formError.secondaryContactName.isError}
              helperText={formError.secondaryContactName.errorMessage}
              value={
                CompanyConfigurationData.secondaryContactName
                  ? CompanyConfigurationData.secondaryContactName
                  : ''
              }
              sx={{
                ...textFieldStyled,
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {},
                },
              }}
            />
            <Stack
              direction='row'
              width={{xs: '100%', sm: '100%', md: '75%', xl: '50%'}}
            >
              <TextField
                size='small'
                name='secondaryPhoneCountryCode'
                onChange={(event) =>
                  handleChangeConfigurationData(
                    event,
                    'textfield',
                    structuredClone(CompanyConfigurationData),
                    {...formError},
                  )
                }
                label={<IntlMessages id='company.addCompany.code' />}
                variant='outlined'
                placeholder='###'
                error={formError.secondaryPhoneCountryCode.isError}
                helperText={formError.secondaryPhoneCountryCode.errorMessage}
                value={
                  CompanyConfigurationData.secondaryPhoneCountryCode
                    ? CompanyConfigurationData.secondaryPhoneCountryCode
                    : ''
                }
                sx={{
                  ...textFieldStyled,
                  width: '25%',
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {},
                  },
                }}
              />
              <TextField
                size='small'
                name='secondaryPhone'
                onChange={(event) =>
                  handleChangeConfigurationData(
                    event,
                    'textfield',
                    structuredClone(CompanyConfigurationData),
                    {...formError},
                  )
                }
                label={<IntlMessages id='company.addCompany.secondaryPhone' />}
                variant='outlined'
                placeholder='#########'
                error={formError.secondaryPhone.isError}
                helperText={formError.secondaryPhone.errorMessage}
                value={
                  CompanyConfigurationData.secondaryPhone
                    ? CompanyConfigurationData.secondaryPhone
                    : ''
                }
                sx={{
                  ...textFieldStyled,
                  width: '75%',
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {},
                  },
                }}
              />
            </Stack>
            <TextField
              size='small'
              multiline
              maxRows={3}
              name='secondaryEmail'
              label={<IntlMessages id='company.addCompany.secondaryEmail' />}
              onChange={(event) =>
                handleChangeConfigurationData(
                  event,
                  'textfield',
                  structuredClone(CompanyConfigurationData),
                  {...formError},
                )
              }
              variant='outlined'
              error={formError.secondaryEmail.isError}
              helperText={formError.secondaryEmail.errorMessage}
              value={
                CompanyConfigurationData.secondaryEmail
                  ? CompanyConfigurationData.secondaryEmail
                  : ''
              }
              sx={{
                ...textFieldStyled,
                '& .MuiOutlinedInput-root': {
                  '& fieldset': {},
                },
              }}
            />
          </Stack>
        </Stack>
        {/* end media screen */}

        <h4>
          <IntlMessages id='company.addCompany.localSettings' />
        </h4>
        <Stack
          direction={{xs: 'column', sm: 'row'}}
          sx={{mt: 2}}
          justifyContent='space-between'
          alignItems='flex-start'
          spacing={2}
          id='localSettingsStack'
        >
          <Stack sx={{mb: 5}} width={{xs: '100%', sm: '50%'}}>
            {/* WORK LEFT COMPANY DATE FORMAT */}
            <FormControl>
              <InputLabel size='small' id='dateFormat'>
                <IntlMessages id='company.addCompany.companyDateFormat' />
              </InputLabel>
              <Select
                value={CompanyConfigurationData.dateFormat || ''}
                labelId='dateFormat'
                name='dateFormat'
                onChange={(event) =>
                  handleChangeConfigurationData(
                    event,
                    'textfield',
                    structuredClone(CompanyConfigurationData),
                    {...formError},
                  )
                }
                variant='outlined'
                error={formError.dateFormat.isError}
                label={
                  <IntlMessages id='company.addCompany.companyDateFormat' />
                }
                size='small'
                sx={{
                  ...textFieldStyled,
                  '& fieldset': {
                    borderLeftColor: 'red',
                    borderLeftWidth: 3,
                  },
                }}
              >
                <MenuItem key='dd/MM/yyyy' value='dd/MM/yyyy'>
                  DD/MM/YYYY
                </MenuItem>
                <MenuItem key='MM/dd/yyyy' value='MM/dd/yyyy'>
                  MM/DD/YYYY
                </MenuItem>
                <MenuItem key='yyyy/MM/dd' value='yyyy/MM/dd'>
                  YYYY/MM/DD
                </MenuItem>
                <MenuItem key='yyyy/dd/MM' value='yyyy/dd/MM'>
                  YYYY/DD/MM
                </MenuItem>
              </Select>
              <FormHelperText style={formHelperTextStyle}>
                {formError.dateFormat.errorMessage}
              </FormHelperText>
            </FormControl>
            {/* preferred language select list */}
            <FormControl>
              <InputLabel size='small' id='preferred-language'>
                <IntlMessages id='company.addCompany.preferredLanguage' />
              </InputLabel>
              <Select
                multiple
                value={CompanyConfigurationData?.preferredLanguage || []}
                labelId='preferred-language'
                name='preferredLanguage'
                onChange={(event) => {
                  handleChangeConfigurationData(
                    event,
                    'multiselect',
                    structuredClone(CompanyConfigurationData),
                    {...formError},
                  );
                  // Check if the selected value is in the available options
                  const selectedValue = event.target.value;
                  if (
                    defaultLanguageOptions.some(
                      (option) => option.code === selectedValue,
                    )
                  ) {
                    setCompanyConfigurationData((prevConfig) => ({
                      ...prevConfig,
                      defaultLanguage: selectedValue,
                    }));
                  } else {
                    // If not, set defaultLanguage to null
                    setCompanyConfigurationData((prevConfig) => ({
                      ...prevConfig,
                      defaultLanguage: null,
                    }));
                  }
                }}
                variant='outlined'
                label={
                  <IntlMessages id='company.addCompany.preferredLanguage' />
                }
                error={formError.preferredLanguage.isError}
                size='small'
                sx={{...requiredSelectStyled}}
                renderValue={(selected) => selected.join(', ')}
              >
                {languagesList.map((language, index) => (
                  <MenuItem
                    key={'preferredLanguage_' + index}
                    value={language.name}
                  >
                    <Checkbox
                      checked={
                        CompanyConfigurationData?.preferredLanguage?.indexOf(
                          language.name,
                        ) > -1
                      }
                    />
                    <ListItemText primary={language.name} />
                  </MenuItem>
                ))}
              </Select>
              <FormHelperText style={formHelperTextStyle}>
                {formError.preferredLanguage.errorMessage}
              </FormHelperText>
            </FormControl>
          </Stack>

          <Stack sx={{mb: 5}} width={{xs: '100%', sm: '50%'}}>
            <Autocomplete
              value={
                CompanyConfigurationData.timezone
                  ? CompanyConfigurationData.timezone
                  : null
              }
              onChange={(event, newValue) =>
                handleChangeConfigurationData(
                  {target: {name: 'timezone', value: newValue}},
                  'textfield',
                  structuredClone(CompanyConfigurationData),
                  {...formError},
                )
              }
              options={getAllTimeZonesGMT()}
              getOptionLabel={(option) => option}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label={
                    <IntlMessages id='company.addCompany.defaultTimeZone' />
                  }
                  error={formError.timezone.isError}
                  variant='outlined'
                  size='small'
                  sx={{
                    ...textFieldStyled,
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  }}
                  helperText={formError.timezone.errorMessage}
                  FormHelperTextProps={{style: formHelperTextStyle}}
                />
              )}
            />

            {/* // Update the default language dropdown to use the new defaultLanguageOptions state variable */}
            <FormControl>
              <InputLabel size='small' id='default-language'>
                <IntlMessages id='company.addCompany.defaultLanguage' />
              </InputLabel>
              <Select
                value={
                  CompanyConfigurationData?.defaultLanguage
                    ? CompanyConfigurationData?.defaultLanguage
                    : ''
                }
                labelId='default-language'
                name='defaultLanguage'
                onChange={(event) =>
                  handleChangeConfigurationData(
                    event,
                    'textfield',
                    structuredClone(CompanyConfigurationData),
                    {...formError},
                  )
                }
                variant='outlined'
                error={formError.defaultLanguage.isError}
                label={<IntlMessages id='company.addCompany.defaultLanguage' />}
                size='small'
                sx={{
                  ...textFieldStyled,
                  '& fieldset': {
                    borderLeftColor: 'red',
                    borderLeftWidth: 3,
                  },
                }}
              >
                {defaultLanguageOptions.map((language, index) => (
                  <MenuItem key={'timeZone_' + index} value={language.code}>
                    <ListItemText primary={language.name} />
                  </MenuItem>
                ))}
              </Select>
              <FormHelperText style={formHelperTextStyle}>
                {formError.defaultLanguage.errorMessage}
              </FormHelperText>
            </FormControl>
          </Stack>
        </Stack>

        {/* <h4>
          <IntlMessages id='company.addCompany.currencySetting' />
        </h4> */}
        <Stack
          direction={{xs: 'column', sm: 'row'}}
          sx={{mt: 2}}
          justifyContent='space-between'
          alignItems='flex-start'
          spacing={2}
          id='currencySettingStack'
        >
          <Stack sx={{mb: 5}} width={{xs: '100%', sm: '50%'}}>
            <h4 style={{marginTop: '10px', marginBottom: '5px'}}>
              <IntlMessages id='company.addCompany.currencySetting' />
            </h4>

            <FormControl sx={{mb: 4}}>
              <Autocomplete
                value={
                  getAllCurrency().find(
                    (currency) =>
                      currency.code === CompanyConfigurationData.currency,
                  ) || null
                }
                onChange={(event, newValue) =>
                  handleChangeConfigurationData(
                    {target: {name: 'currency', value: newValue?.code || ''}},
                    'textfield',
                    structuredClone(CompanyConfigurationData),
                    {...formError},
                  )
                }
                options={getAllCurrency()}
                getOptionLabel={(option) => `${option.name} (${option.symbol})`}
                renderOption={(props, option) => (
                  <li {...props}>
                    <ListItemText
                      primary={`${option.name} (${option.symbol})`}
                    />
                  </li>
                )}
                isOptionEqualToValue={(option, value) =>
                  option.code === value.code
                }
                renderInput={(params) => (
                  <TextField
                    {...params}
                    label={
                      <IntlMessages id='company.addCompany.localCurrency' />
                    }
                    error={formError.currency.isError}
                    variant='outlined'
                    size='small'
                    sx={{
                      ...textFieldStyled,
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                    }}
                    helperText={formError.currency.errorMessage}
                    FormHelperTextProps={{style: formHelperTextStyle}}
                  />
                )}
              />
            </FormControl>
          </Stack>
          <Stack sx={{mb: 5}} width={{xs: '100%', sm: '50%'}}>
            <h4 style={{marginTop: '10px', marginBottom: '5px'}}>
              Default User Role
            </h4>
            <FormControl sx={{mb: 4}}>
              <InputLabel size='small' id='default-timezone'>
                {/* <IntlMessages id='company.addCompany.localCurrency' /> */}
                Default Role
              </InputLabel>
              <Select
                value={
                  CompanyConfigurationData.defaultRole
                    ? CompanyConfigurationData.defaultRole
                    : ''
                }
                labelId='-local-currency'
                name='defaultRole'
                onChange={(event) =>
                  handleChangeConfigurationData(
                    event,
                    'textfield',
                    structuredClone(CompanyConfigurationData),
                    {...formError},
                  )
                }
                variant='outlined'
                error={formError.defaultRole.isError}
                label='Default Role'
                size='small'
                sx={{
                  ...textFieldStyled,
                  '& fieldset': {
                    borderLeftColor: 'red',
                    borderLeftWidth: 3,
                  },
                }}
              >
                {roleList?.map((role, index) => (
                  <MenuItem id={`${index}`} key={index} value={role}>
                    {role}
                  </MenuItem>
                ))}
              </Select>
              <FormHelperText style={formHelperTextStyle}>
                {formError.defaultRole.errorMessage}
              </FormHelperText>
            </FormControl>
          </Stack>
        </Stack>

        {/* ------------------------------ contect detail ------------ end--------------- */}
      </AppCard>
    );
  };

  if (authLoading) {
    return <Stack>{domCreactionGridSkeletonLoader()}</Stack>; // You can use a spinner or any loading indicator
  }

  if (!isAuthorized) {
    return <Error403 />;
  }

  return (
    <AppAnimate animation='transition.slideUpIn' delay={500}>
      <AppPageMeta />
      <h2 style={{marginBottom: 20}}>
        {/* <IntlMessages id='companyConfiguration.pageHeaderName' /> */}
        Company Configuration
      </h2>
      {isEdit ? (
        createDomCompanyConfiguration()
      ) : (
        <ViewCompanyConfiguration
          CompanyConfigurationData={companyConfigurationData}
          workflowList={workflowList}
          handleOpenPreviewPage={() => handleOpenPreviewPage()}
        />
      )}
      {isLoading && (
        <Stack sx={{pt: 50, pb: 100}}>
          <AppLoader />
        </Stack>
      )}
      {alertProps.isHideShow && (
        <AlertDialog
          alertProps={alertProps}
          handleYes={() => handleAlertYes()}
          handleNo={() => handleAlertNo()}
        />
      )}
      {/* ////////add Stack for fixed////// */}
      <div style={{marginBottom: '70px'}} />
      <Stack
        sx={{
          bottom: 0,
          zIndex: 10,
          position: 'fixed',
          backdropFilter: 'blur(5px)',
          width: '100%',
          right: 0,
        }}
      >
        {/* ///////////////////////////////////// */}

        <Stack
          direction='row'
          justifyContent='end'
          alignItems='center'
          spacing={2}
          sx={{
            pt: 5,
            ml: 3,
            //// add marging for fixed stack///
            margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
          }}
        >
          {/* <Button 
              color= {footerButton.back.color}
              variant= {footerButton.back.variant}
              sx= {footerButton.back.sx}
              size= {footerButton.back.size}
              onClick={() => handleOpenPreviewPage()}
            >
              Preview
            </Button> */}
          {isEdit && (
            <Button
              color='primary'
              variant='contained'
              onClick={() => setIsEdit(() => false)}
            >
              <IntlMessages id='common.button.Close' />
            </Button>
          )}
          <Button
            disabled={isActionsDisable}
            color='success'
            variant='contained'
            onClick={() => handlePageType()}
          >
            {isEdit ? (
              <IntlMessages id='common.button.Update' />
            ) : (
              <IntlMessages id='common.button.Edit' />
            )}
          </Button>
        </Stack>
      </Stack>
      {isPreviewPageOpen && (
        <div className='colorset-preview'>
          <div style={{width: '50px', height: '50px'}}></div>

          <PreviewPage
            primaryColor={
              isEdit ? primaryColor : companyConfigurationData?.primaryColor
            }
            secondaryColor={
              isEdit ? secondaryColor : companyConfigurationData?.secondaryColor
            }
            tertiaryColor={
              isEdit ? tertiaryColor : companyConfigurationData?.tertiaryColor
            }
            handleClose={() => handleClosePreviewPage()}
          ></PreviewPage>
        </div>
      )}
      <AppInfoView />
    </AppAnimate>
  );
};

export default CompanyConfiguration;
