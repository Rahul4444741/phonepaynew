import React from 'react';
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Button,
  Checkbox,
  FormControlLabel,
  TextField,
  IconButton,
  Box,
  Stack,
  RadioGroup,
  Radio,
  FormLabel,
  ListItemText,
} from '@mui/material';
import {styled} from '@mui/material/styles';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';
import { onlyAcceptWholeNumbers } from 'shared/utils/CommonUtils';

const VisuallyHiddenInput = styled('input')({
  clip: 'rect(0 0 0 0)',
  clipPath: 'inset(50%)',
  height: 1,
  overflow: 'hidden',
  position: 'absolute',
  bottom: 0,
  left: 0,
  whiteSpace: 'nowrap',
  width: 1,
});

const formElementStyle = {
  width: '70%',
  marginBottom: '10px',
};

const headerOptions = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'];
const paragraphOptions = ['p'];
const textFieldOptions = ['text', 'number', 'date', 'email', 'password'];
const buttonOptions = ['reset', 'submit', 'cancel', 'button'];

const shouldShowField = (type, fields) => {
  return fields.includes(type);
};

const shouldHideField = (type, fields) => {
  return !fields.includes(type);
};

const EditElement = ({
  editedElement,
  setEditedElement,
  editDialogOpen,
  setEditDialogOpen,
  handleSaveEdit,
}) => {
  // Function to update edited element data
  const handleEditChange = (e, field, fieldType) => {
    if(fieldType === 'numberType') {
      setEditedElement({
        ...editedElement,
        [field]: onlyAcceptWholeNumbers(e.target.value),
      });
    } else if(field === 'isProgressStatus' && ((e.target.value === true) || (e.target.value === 'true'))) {
      editedElement.options = [
        {
          "label": "Delayed",
          "value": "DELAYED",
          "color": "#DB3535"
        },
        {
          "label": "Completed",
          "value": "COMPLETED",
          "color": "#00AA5A"
        },
        {
          "label": "Inprogress",
          "value": "INPROGRESS",
          "color": "#E5A30E"
        },
        {
          "label": "Not started",
          "value": "NOTSTARTED",
          "color": "#979797"
        }
      ]
      setEditedElement({
        ...editedElement,
        [field]: e.target.value,
      });
    } else {
      setEditedElement({
        ...editedElement,
        [field]: e.target.value,
      });
    }

  };

  const handleOptionChange = (index, field, value) => {
    const newOptions = editedElement.options.map((option, idx) =>
      idx === index ? {...option, [field]: value} : option,
    );
    setEditedElement({
      ...editedElement,
      options: newOptions,
    });
  };

  const handleSelectionType = (index, field, value) => {
    const newOptions = editedElement.options.map((option, idx) =>
      idx === index ? {...option, [field]: value} : option,
    );
    setEditedElement({
      ...editedElement,
      options: newOptions,
    });
  }

  const handleAddOption = () => {
    const newOptions = [
      ...editedElement.options,
      {
        label: `option ${editedElement.options.length + 1}`,
        value: `option ${editedElement.options.length + 1}`,
      },
    ];
    setEditedElement({
      ...editedElement,
      options: newOptions,
    });
  };

  const handleDeleteOption = (index) => {
    const newOptions = editedElement.options.filter((_, idx) => idx !== index);
    setEditedElement({
      ...editedElement,
      options: newOptions,
    });
  };

  const subTypeOptionsByType = (type) => {
    if (type === 'text') {
      return textFieldOptions.map((op, index) => (
        <MenuItem key={index} value={op}>
          {op}
        </MenuItem>
      ));
    }
    if (type === 'button') {
      return buttonOptions.map((op, index) => (
        <MenuItem key={index} value={op}>
          {op}
        </MenuItem>
      ));
    }
    if (type === 'header') {
      return headerOptions.map((op, index) => (
        <MenuItem key={index} value={op}>
          {op}
        </MenuItem>
      ));
    }
    if (type === 'paragraph') {
      return paragraphOptions.map((op, index) => (
        <MenuItem key={index} value={op}>
          {op}
        </MenuItem>
      ));
    }
    return null;
  };

  return (
    <Dialog
      open={editDialogOpen}
      onClose={() => setEditDialogOpen(false)}
      PaperProps={{
        style: {
          width: '40vw', // Set the fixed width of the dialog
          maxWidth: 'none', // Ensure the max width is not restricted
        },
      }}
    >
      <DialogTitle>
        <h2>Edit Element</h2>
      </DialogTitle>
      <DialogContent dividers>
        {shouldShowField(editedElement?.type, [
          'header',
          'paragraph',
          'text',
          'date',
          'number',
          'button',
          'radio-group',
          'checkbox-group',
          'select',
          'textarea',
          'single-checkbox',
          'container'
        ]) && (
          <TextField
            autoFocus
            margin='dense'
            label='Label'
            fullWidth
            value={editedElement?.label}
            onChange={(e) => handleEditChange(e, 'label')}
          />
        )}
        {shouldShowField(editedElement?.type, [
          'container'
        ]) && (
          <TextField
            autoFocus
            margin='dense'
            label='formType'
            fullWidth
            value={editedElement?.formType}
            onChange={(e) => handleEditChange(e, 'formType')}
          />
        )}
        {shouldHideField(editedElement?.type, [
          'date',
          'number',
          'radio-group',
          'checkbox-group',
          'select',
          'textarea',
          'single-checkbox',
          'container'
        ]) && (
          <FormControl fullWidth sx={{mt: 1, mb: 1}}>
            <InputLabel size='small' id='subtype'>
              Subtype
            </InputLabel>
            <Select
              name='subtype'
              label='Subtype'
              labelId='subtype'
              value={editedElement?.subtype || ''}
              onChange={(e) => handleEditChange(e, 'subtype')}
              variant='outlined'
              sx={{width: '100%'}}
            >
              {subTypeOptionsByType(editedElement.type)}
            </Select>
          </FormControl>
        )}

        {shouldHideField(editedElement?.type, [
          'header',
          'paragraph',
          'button',
        ]) && (
          <>
            <TextField
              margin='dense'
              label='Name'
              fullWidth
              value={editedElement?.name}
              onChange={(e) => handleEditChange(e, 'name')}
            />
            {shouldHideField(editedElement?.type, [
              'header',
              'paragraph',
              'button',
              'radio-group',
              'checkbox-group',
              'select',
              'file',
              'single-checkbox',
            ]) && (
              <TextField
                margin='dense'
                label='Placeholder'
                fullWidth
                value={editedElement?.placeholder || ''}
                onChange={(e) => handleEditChange(e, 'placeholder')}
              />
            )}
          </>
        )}

        {shouldShowField(editedElement?.type, [
          'header',
          'paragraph',
          'button',
          'single-checkbox',
        ]) && (
          <TextField
            margin='dense'
            label='Color'
            fullWidth
            value={editedElement?.color || ''}
            onChange={(e) => handleEditChange(e, 'color')}
          />
        )}
        {shouldShowField(editedElement?.type, ['button']) && (
          <TextField
            margin='dense'
            label='Background'
            fullWidth
            value={editedElement?.bgColor || ''}
            onChange={(e) => handleEditChange(e, 'bgColor')}
          />
        )}

        {shouldHideField(editedElement?.type, [
          'header',
          'paragraph',
          'button',
           'container'
        ]) && (
          <>
            <TextField
              margin='dense'
              label='Helper Text'
              fullWidth
              value={editedElement?.helperText || ''}
              onChange={(e) => handleEditChange(e, 'helperText')}
            />
            <FormControlLabel
              control={
                <Checkbox
                  checked={editedElement?.required || false}
                  onChange={(e) =>
                    handleEditChange(
                      {target: {value: e.target.checked}},
                      'required',
                    )
                  }
                />
              }
              label='Required'
            />
          </>
        )}
        {shouldHideField(editedElement?.type, ['header', 'paragraph']) && (
          <>
            <FormControlLabel
              control={
                <Checkbox
                  checked={editedElement?.disabled || false}
                  onChange={(e) =>
                    handleEditChange(
                      {target: {value: e.target.checked}},
                      'disabled',
                    )
                  }
                />
              }
              label='Disabled'
            />
          </>
        )}

        {
          (editedElement?.type === 'text') && (
            <>
              <Box
                sx={{display: 'flex', alignItems: 'center', mb: 2}}
              >
                <Stack
                  direction='row'
                  sx={{mt: 2, ml: 3, width: '100%'}}
                  justifyContent='space-between'
                  alignItems='center'
                  spacing={2}
                >
                  <Stack sx={{width: '50%'}}>
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>
                          {/* <IntlMessages id='learnPage.isMainTile' /> */}
                          Is multiple text field row ?
                        </Stack>
                      </Stack>
                    </FormLabel>
                  </Stack>

                  <Stack sx={{width: '50%'}}>
                    <RadioGroup
                      name='isMultiTextFieldRow'
                      // value={configObj.isMultiTextFieldRow}
                      // onChange={(e) => handleChangeFormData(e, 'ratio')}
                      value={editedElement?.isMultiTextFieldRow}
                      onChange={(e) => handleEditChange(e, 'isMultiTextFieldRow')}
                      row
                      aria-labelledby='demo-row-radio-buttons-group-label'
                    >
                      <FormControlLabel
                        // value={'Single'}
                        value={true}
                        control={<Radio />}
                        label={
                          // <IntlMessages id='common.button.Yes' />
                          'Multiple'
                        }
                      />
                      <FormControlLabel
                        // value={'Multiple'}
                        value={false}
                        control={<Radio />}
                        label={
                          // <IntlMessages id='common.button.No' />
                          'Single'
                        }
                      />
                    </RadioGroup>
                  </Stack>
                </Stack>
                
              </Box>

              {((editedElement?.isMultiTextFieldRow === 'true') || (editedElement?.isMultiTextFieldRow === true)) && (<Box sx={{display: 'flex', alignItems: 'center', mb: 2}}>
                <Stack
                  direction='row'
                  sx={{mt: 2, ml: 3, width: '100%'}}
                  justifyContent='space-between'
                  alignItems='center'
                  spacing={2}
                >
                  <Stack sx={{width: '50%'}}>
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>
                          {/* <IntlMessages id='learnPage.isMainTile' /> */}
                          Text field row size ?
                        </Stack>
                      </Stack>
                    </FormLabel>
                  </Stack>

                  <Stack sx={{width: '50%'}}>
                  <TextField
                    margin='dense'
                    label='Row size'
                    fullWidth
                    value={editedElement?.textFieldRowSize || ''}
                    onChange={(e) => handleEditChange(e, 'textFieldRowSize', 'numberType')}
                  />
                  </Stack>
                </Stack>
              </Box>)}
            </>
          )
        }

        {
          (editedElement?.type === 'select') && (
            <>
              <Box
                sx={{display: 'flex', alignItems: 'center', mb: 2}}
              >
                <Stack
                  direction='row'
                  sx={{mt: 2, ml: 3, width: '100%'}}
                  justifyContent='space-between'
                  alignItems='center'
                  spacing={2}
                >
                  <Stack sx={{width: '50%'}}>
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>
                          {/* <IntlMessages id='learnPage.isMainTile' /> */}
                          Selection type ?
                        </Stack>
                      </Stack>
                    </FormLabel>
                  </Stack>

                  <Stack sx={{width: '50%'}}>
                    <RadioGroup
                      name='isSingleSelect'
                      // value={configObj.isSingleSelect}
                      // onChange={(e) => handleChangeFormData(e, 'ratio')}
                      value={editedElement?.isSingleSelect}
                      onChange={(e) => handleEditChange(e, 'isSingleSelect')}
                      row
                      aria-labelledby='demo-row-radio-buttons-group-label'
                    >
                      <FormControlLabel
                        // value={'Single'}
                        value={true}
                        control={<Radio />}
                        label={
                          // <IntlMessages id='common.button.Yes' />
                          'Single'
                        }
                      />
                      <FormControlLabel
                        // value={'Multiple'}
                        value={false}
                        control={<Radio />}
                        label={
                          // <IntlMessages id='common.button.No' />
                          'Multiple'
                        }
                      />
                    </RadioGroup>
                  </Stack>
                </Stack>
                
              </Box>

              <Box sx={{display: 'flex', alignItems: 'center', mb: 2}}>
                <Stack
                  direction='row'
                  sx={{mt: 2, ml: 3, width: '100%'}}
                  justifyContent='space-between'
                  alignItems='center'
                  spacing={2}
                >
                  <Stack sx={{width: '50%'}}>
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>
                          {/* <IntlMessages id='learnPage.isMainTile' /> */}
                          Is selection menu dynamic ?
                        </Stack>
                      </Stack>
                    </FormLabel>
                  </Stack>

                  <Stack sx={{width: '50%'}}>
                    <RadioGroup
                      name='isSelectMenuDynamic'
                      // value={configObj.isSingleSelect}
                      // onChange={(e) => handleChangeFormData(e, 'ratio')}
                      // value={editedElement?.isSingleSelect || ''}
                      value={editedElement?.isSelectMenuDynamic}
                      onChange={(e) => handleEditChange(e, 'isSelectMenuDynamic')}
                      row
                      aria-labelledby='demo-row-radio-buttons-group-label'
                    >
                      <FormControlLabel
                        // value={'Single'}
                        value={true}
                        control={<Radio />}
                        label={
                          // <IntlMessages id='common.button.Yes' />
                          'Dynamic'
                        }
                      />
                      <FormControlLabel
                        // value={'Multiple'}
                        value={false}
                        control={<Radio />}
                        label={
                          // <IntlMessages id='common.button.No' />
                          'Fixed'
                        }
                      />
                    </RadioGroup>
                  </Stack>
                </Stack>
              </Box>
              {((editedElement?.isSelectMenuDynamic === false) || (editedElement?.isSelectMenuDynamic === 'false')) && <Box sx={{display: 'flex', alignItems: 'center', mb: 2}}>
                <Stack
                  direction='row'
                  sx={{mt: 2, ml: 3, width: '100%'}}
                  justifyContent='space-between'
                  alignItems='center'
                  spacing={2}
                >
                  <Stack sx={{width: '50%'}}>
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>
                          {/* <IntlMessages id='learnPage.isMainTile' /> */}
                          Is selection for progress status ?
                          {/* isProgressStatus */}
                        </Stack>
                      </Stack>
                    </FormLabel>
                  </Stack>

                  <Stack sx={{width: '50%'}}>
                    <RadioGroup
                      name='isProgressStatus'
                      // value={configObj.isSingleSelect}
                      // onChange={(e) => handleChangeFormData(e, 'ratio')}
                      // value={editedElement?.isSingleSelect || ''}
                      value={editedElement?.isProgressStatus} // ch
                      onChange={(e) => handleEditChange(e, 'isProgressStatus')} //ch
                      row
                      aria-labelledby='demo-row-radio-buttons-group-label'
                    >
                      <FormControlLabel
                        // value={'Single'}
                        value={true}
                        control={<Radio />}
                        label={
                          // <IntlMessages id='common.button.Yes' />
                          'Yes'
                        }
                      />
                      <FormControlLabel
                        // value={'Multiple'}
                        value={false}
                        control={<Radio />}
                        label={
                          // <IntlMessages id='common.button.No' />
                          'No'
                        }
                      />
                    </RadioGroup>
                  </Stack>
                </Stack>
              </Box>}
            </>
          )
        }
        

        {(
          ((editedElement?.isSelectMenuDynamic === 'false') || (editedElement?.isSelectMenuDynamic === false)) && (
            editedElement?.type === 'checkbox-group' ||
            editedElement?.type === 'radio-group' ||
            editedElement?.type === 'select'

          )
        ) && (
          <>
            {editedElement.options.map((option, index) => (
              <Box
                key={index}
                sx={{display: 'flex', alignItems: 'center', mb: 2}}
              >
                <TextField
                  margin='dense'
                  label={`Option Label ${index + 1}`}
                  fullWidth
                  size='small'
                  value={option.label}
                  onChange={(e) =>
                    handleOptionChange(index, 'label', e.target.value)
                  }
                  sx={{mr: 1}}
                  // disabled={(editedElement?.isProgressStatus === 'true') || (editedElement?.isProgressStatus === true)}
                />
                <TextField
                  margin='dense'
                  label={`Option Value ${index + 1}`}
                  fullWidth
                  size='small'
                  value={option.value}
                  onChange={(e) =>
                    handleOptionChange(index, 'value', e.target.value)
                  }
                  sx={{mr: 1}}
                  disabled={(editedElement?.isProgressStatus === 'true') || (editedElement?.isProgressStatus === true)}
                />
                {((editedElement?.isProgressStatus === 'true') || (editedElement?.isProgressStatus === true)) && 
                  // <TextField //ch
                  //   margin='dense'
                  //   label={`Option color ${index + 1}`}
                  //   fullWidth
                  //   size='small'
                  //   value={option.color}
                  //   onChange={(e) =>
                  //     handleOptionChange(index, 'color', e.target.value)
                  //   }
                  //   sx={{mr: 1}}
                  // />
                  
                  <Stack >
                    <div
                      style={{
                        height: '30px',
                        width: '60px',
                        backgroundColor: option.color,
                        border: '5px solid black',
                      }}
                    >
                      <input
                        style={{opacity: 0, cursor: 'pointer'}}
                        // disabled={!CompanyConfigurationData.isCustomizationrequired}
                        type='color'
                        // onFocus={(event) =>
                        //   handleClearColorErrorOnfocus(event, {...formError})
                        // }
                        // onChange={(event) =>
                        //   delayFunctionColorHandler(
                        //     () => event.target.value,
                        //     setPrimaryColor,
                        //     '--primary',
                        //   )
                        // }
                        id='head'
                        name='color'
                        value={option.color}
                        onChange={(e) =>
                          handleOptionChange(index, 'color', e.target.value)
                        }
                      ></input>
                    </div>
                    {/* {formError.primaryColor.isError && (
                      <FormHelperText className='Mui-error'>
                        {formError.primaryColor.errorMessage}
                      </FormHelperText>
                    )} */}
                  </Stack>
                }
                {!((editedElement?.isProgressStatus === 'true') || (editedElement?.isProgressStatus === true)) && <IconButton onClick={() => handleDeleteOption(index)}>
                  <DeleteIcon />
                </IconButton>}
              </Box>
            ))}
            {!((editedElement?.isProgressStatus === 'true') || (editedElement?.isProgressStatus === true)) && <Button
              variant='contained'
              color='primary'
              startIcon={<AddIcon />}
              onClick={handleAddOption}
              size='small'
            >
              Add Option
            </Button>}
          </>
        )}

        {(
          ((editedElement?.isSelectMenuDynamic === 'true') || (editedElement?.isSelectMenuDynamic === true)) && (
            editedElement?.type === 'checkbox-group' ||
            editedElement?.type === 'radio-group' ||
            editedElement?.type === 'select'

          )
          ) && (
            <>
              <Box
                sx={{display: 'flex', alignItems: 'center', mb: 2}}
              >
                <Stack
                  direction='row'
                  sx={{mt: 2, ml: 3, width: '100%'}}
                  justifyContent='space-between'
                  alignItems='center'
                  spacing={2}
                >
                  <Stack sx={{width: '50%'}}>
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>
                          Select menu dynamic type ?
                        </Stack>
                      </Stack>
                    </FormLabel>
                  </Stack>

                  <Stack sx={{width: '50%'}}>
                    <FormControl>
                      <InputLabel size='small' id='label_employeeTypes'>
                        Selection menu dynamic type
                      </InputLabel>
                      <Select
                        name='selectMenuDynamicType'
                        labelId='label_employeeTypes'
                        label='Selection menu dynamic type'
                        // value={configObj?.selectMenuDynamicType}
                        // renderValue={(selected) =>
                        //   selected.ratingParameter
                        // }
                        
                        // onChange={(event) => handleselectMenuDynamicType(event)}

                        value={editedElement?.selectMenuDynamicType}
                        onChange={(e) => handleEditChange(e, 'selectMenuDynamicType')}

                        variant='outlined'
                        size='small'
                        sx={{
                          backgroundColor: 'white',
                          mb: 2,
                          '& fieldset': {
                            borderLeftColor: 'red',
                            borderLeftWidth: 3,
                          },
                        }}
                      >
                        
                        <MenuItem key={'employee_functions'} value={'employee_functions'}>
                          <ListItemText primary={'Employee Functions'} />
                        </MenuItem>
                        <MenuItem key={'employee_Grade'} value={'employee_grade'}>
                          <ListItemText primary={'Employee Grade'} />
                        </MenuItem>
                        <MenuItem key={'employee_level'} value={'employee_level'}>
                          <ListItemText primary={'Employee Level'} />
                        </MenuItem>
                        <MenuItem key={'employee'} value={'employee'}>
                          <ListItemText primary={'employee'} />
                        </MenuItem>
                        <MenuItem key={'employee_status'} value={'employee_status'}>
                          <ListItemText primary={'Employee Status'} />
                        </MenuItem>
                        <MenuItem key={'employee_sub_function'} value={'employee_sub_function'}>
                          <ListItemText primary={'Employee Sub Sunction'} />
                        </MenuItem>
                        <MenuItem key={'employee_type'} value={'employee_type'}>
                          <ListItemText primary={'Employee Type'} />
                        </MenuItem>
                        <MenuItem key={'employment_status'} value={'employment_status'}>
                          <ListItemText primary={'Employment Status'} />
                        </MenuItem>
                      </Select>
                    </FormControl>
                  </Stack>
                </Stack>
              </Box>
            </>
          )
        }
        {
          (editedElement?.type === 'container') && (
            <>
              <Box
                sx={{display: 'flex', alignItems: 'center', mb: 2}}
              >
                <Stack
                  direction='row'
                  sx={{mt: 2, ml: 3, width: '100%'}}
                  justifyContent='space-between'
                  alignItems='center'
                  spacing={2}
                >
                  <Stack sx={{width: '50%'}}>
                    <FormLabel id='demo-row-radio-buttons-group-label'>
                      <Stack direction='row'>
                        <Stack fontWeight={500}>
                          {/* <IntlMessages id='learnPage.isMainTile' /> */}
                          Is multiple add container ?
                        </Stack>
                      </Stack>
                    </FormLabel>
                  </Stack>

                  <Stack sx={{width: '50%'}}>
                    <RadioGroup
                      name='isMultiAddContainer'
                      value={editedElement?.isMultiAddContainer}
                      onChange={(e) => handleEditChange(e, 'isMultiAddContainer')}
                      row
                      aria-labelledby='demo-row-radio-buttons-group-label'
                    >
                      <FormControlLabel
                        // value={'Single'}
                        value={true}
                        control={<Radio />}
                        label={
                          // <IntlMessages id='common.button.Yes' />
                          'Yes'
                        }
                      />
                      <FormControlLabel
                        // value={'Multiple'}
                        value={false}
                        control={<Radio />}
                        label={
                          // <IntlMessages id='common.button.No' />
                          'No'
                        }
                      />
                    </RadioGroup>
                  </Stack>
                </Stack>
                
              </Box>

              {(
                (
                  editedElement?.type === 'select'
                )
                ) && (
                  <>
                    <Box sx={{display: 'flex', alignItems: 'center', mb: 2}}>
                      <Stack
                        direction='row'
                        sx={{mt: 2, ml: 3, width: '100%'}}
                        justifyContent='space-between'
                        alignItems='center'
                        spacing={2}
                      >
                        <Stack sx={{width: '50%'}}>
                          <FormLabel id='demo-row-radio-buttons-group-label'>
                            <Stack direction='row'>
                              <Stack fontWeight={500}>
                                {/* <IntlMessages id='learnPage.isMainTile' /> */}
                                Is selection menu dynamic ?
                              </Stack>
                            </Stack>
                          </FormLabel>
                        </Stack>

                        <Stack sx={{width: '50%'}}>
                          <RadioGroup
                            name='isSelectMenuDynamic'
                            // value={configObj.isSingleSelect}
                            // onChange={(e) => handleChangeFormData(e, 'ratio')}
                            // value={editedElement?.isSingleSelect || ''}
                            value={editedElement?.isSelectMenuDynamic}
                            onChange={(e) => handleEditChange(e, 'isSelectMenuDynamic')}
                            row
                            aria-labelledby='demo-row-radio-buttons-group-label'
                          >
                            <FormControlLabel
                              // value={'Single'}
                              value={true}
                              control={<Radio />}
                              label={
                                // <IntlMessages id='common.button.Yes' />
                                'Dynamic'
                              }
                            />
                            <FormControlLabel
                              // value={'Multiple'}
                              value={false}
                              control={<Radio />}
                              label={
                                // <IntlMessages id='common.button.No' />
                                'Fixed'
                              }
                            />
                          </RadioGroup>
                        </Stack>
                      </Stack>
                    </Box>
                  </>
                )
              }
                  
            </>
          )
        }

        
      </DialogContent>
      <DialogActions>
        <Button onClick={() => setEditDialogOpen(false)} color='error'>
          Cancel
        </Button>
        <Button onClick={handleSaveEdit} color='primary'>
          Save
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default EditElement;
