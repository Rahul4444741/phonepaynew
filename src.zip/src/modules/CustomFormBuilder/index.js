import React, {useState} from 'react';
import {
  Box,
  Button,
  Checkbox,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  FormControl,
  FormControlLabel,
  FormHelperText,
  IconButton,
  InputLabel,
  MenuItem,
  Select,
  Stack,
  TextField,
  Typography,
} from '@mui/material';
import ViewForm from './ViewForm';
import {AppAnimate, AppCard, AppInfoView} from '@crema';
import AppPageMeta from '../../@crema/core/AppPageMeta';
import {
  Title as TitleIcon,
  TextFields as TextFieldsIcon,
  Subject as ParagraphIcon,
  LooksOne as NumberIcon,
  DateRange as DateRangeIcon,
  Autorenew as AutocompleteIcon,
  CheckBox as CheckBoxIcon,
  RadioButtonChecked as RadioButtonCheckedIcon,
  SelectAll as SelectAllIcon,
  UploadFile as UploadFileIcon,
} from '@mui/icons-material';
import {DragDropContext, Droppable, Draggable} from '@hello-pangea/dnd';
import {BsTextareaResize} from 'react-icons/bs';
import SmartButtonIcon from '@mui/icons-material/SmartButton';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import RenderFormElement from './RenderFormElement';
import IntlMessages from '@crema/utility/IntlMessages';
import {footerButton} from 'shared/constants/AppConst';
import {apiCatchErrorMessage, isEmptyNullUndefined} from 'shared/utils/CommonUtils';
import ViewJson from './ViewJson';
import EditElement from './EditElement';
import SyncAltIcon from '@mui/icons-material/SyncAlt';
import KeyboardDoubleArrowLeftIcon from '@mui/icons-material/KeyboardDoubleArrowLeft';
import CalendarViewMonthIcon from '@mui/icons-material/CalendarViewMonth';
import TodayIcon from '@mui/icons-material/Today';
import { API_ROUTS } from 'shared/constants/ApiRouts';
import { useDispatch, useSelector } from 'react-redux';
import jwtAxios from '@crema/services/auth/jwt-auth';
// import { Router } from 'react-router-dom/cjs/react-router-dom';
import Router, {useRouter} from 'next/router';
import { fetchError, showMessage } from 'redux/actions';
import { useEffect } from 'react';

const textFieldStyled = {
  backgroundColor: 'white',
  mb: 2,
  width: {xs: '100%', xl: '50%', md: '75%'},
};

const initialFormData = [];
const initialForm = {
  name: null,
  status: null,
  formData: null,
};
const initialFormError = {
  name: {isError: false, errorMessage: ''},
  status: {isError: false, errorMessage: ''},
  formData: {isError: false, errorMessage: ''},
};

const CustomFormBuilder = () => {
  const dispatch = useDispatch();
  const router = useRouter();
  const {id, replica, view} = router.query;
  let selectedCompany = useSelector(({company}) => company.selectedCompany);


  const [form, setForm] = useState(initialForm);
  const [formError, setFormError] = useState(initialFormError);

  const [formData, setFormData] = useState(initialFormData);

  const [draggedItemType, setDraggedItemType] = useState('');
  const [jsonFormData, setJsonFormData] = useState('');

  const [editedElement, setEditedElement] = useState(null);
  const [editedElementIndex, setEditedElementIndex] = useState(null);
  const [editedParentElementIndex, setEditedParentElementIndex] = useState(null);
  

  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [previewDialogOpen, setPreviewDialogOpen] = useState(false);
  const [jsonDialogOpen, setJsonDialogOpen] = useState(false);
  const [comboElementIndex, setComboElementIndex] = useState(null);
  const [isLoading, setIsLoading] = useState(false)
  const [data, setData] = useState(null)

  useEffect(() => {
    // getBackendData();
    if(id) {
      getSavedFormData(id)
    } else if(replica) {
      // getReplicaFormData(replica)
      getSavedFormData(replica)
    } else if (view) {
      // getSavedFormData(view)
      getSavedFormData(view)
      replica
    }
  }, []);

  const getSavedFormData = (id) => {
    const getFormData = async () => {
      setIsLoading(() => true);
      try {
        const response = await jwtAxios.get(
          `${API_ROUTS.goalForm}/${id}`,
        );
        if (response.status == 200) {
          const tempInitialForm = {...initialForm}
          tempInitialForm.name = response.data.name
          tempInitialForm.status = response.data.status

          let tempgoalFormField = structuredClone(response.data.goalFormField)
          let tempcontainerFormField = structuredClone(response.data.containerFormField)

          tempgoalFormField.sort((a, b) => a[0].parentSequenceNo - b[0].parentSequenceNo)

          tempgoalFormField = tempgoalFormField.map((e,i) => {
            console.log('e', e[0].isMultiField)
            if((e[0].isMultiField === false) || (e[0].isMultiField === "false")) {
              console.log('++++++++')

                      // if(e[0].type === 'container') {
                      //       e[0].container = e[0].container.map((containerE, containerPI) => {
                      //         if((containerE[0].isMultiField === false) || (containerE[0].isMultiField === "false")) {
                      //           console.log('++++++++')
                      //           return containerE[0]
                      //         } else {
                      //           console.log('--------')
                      //           containerE.sort((a,b) => a.sequenceNo - b.sequenceNo)
                      //           return containerE
                      //         }
                      //       })
                      // }


              return e[0]
            } else {
              console.log('--------')
              e.sort((a,b) => a.sequenceNo - b.sequenceNo)
              return e
            }
            // return e
          })


          tempcontainerFormField.sort((a, b) => a[0].parentSequenceNo - b[0].parentSequenceNo)

          console.log('tempcontainerFormField', tempcontainerFormField)

          tempcontainerFormField = tempcontainerFormField.map((e,i) => {
            console.log('e--------->', e[0].container)
            if((e[0].isMultiField === false) || (e[0].isMultiField === "false")) {
              console.log('++++++++')
              console.log('++++e++++', e[0])

                      if(e[0].type === 'container') {
                            e[0].container.sort((a,b) => a[0].parentSequenceNo - b[0].parentSequenceNo)
                            e[0].container = e[0].container.map((containerE, containerPI) => {
                              if((containerE[0].isMultiField === false) || (containerE[0].isMultiField === "false")) {
                                console.log('LLLLLLLLLL')
                                console.log('++++++++')
                                return containerE[0]
                              } else {
                                console.log('--------')
                                console.log('PPPPPPPPPPPPP')
                                console.log('PPPPPPPPPPPPP', containerE)
                                containerE.sort((a,b) => a.sequenceNo - b.sequenceNo)
                                return containerE
                              }
                            })
                      }


              return e[0]
            } else {
              // console.log('--------')
              // console.log('---e-----', e)

              // e.sort((a,b) => a.sequenceNo - b.sequenceNo)
              // return e
            }
            // return e
          })

          tempcontainerFormField.forEach((e,i) => {
            tempgoalFormField.splice(e.parentSequenceNo, 0, e)
          })
          

          

          setForm(() => tempInitialForm)
          setData(() => response.data)
          console.log('tempgoalFormField', tempgoalFormField)
          setFormData(() => tempgoalFormField)
          
        } else {
          
        }
      } catch (error) {
        apiCatchErrorMessage(error, dispatch, fetchError);
        
      }
    };
    getFormData();
  };

  const handleFormChange = (event, fieldType) => {
    let tempForm = {...form};
    let tempError = {...formError};

    if (fieldType == 'textfield' || fieldType == 'dropdown') {
      tempForm[event.target.name] = event.target.value;
      tempError[event.target.name].isError = false;
      tempError[event.target.name].errorMessage = '';
    }

    setForm(tempForm);
    setFormError(tempError);
  };

  const handleValidateForm = () => {
    let tempForm = {...form};
    let tempError = {...formError};
    let isValid = true;

    if (isEmptyNullUndefined(form.name)) {
      tempError.name.isError = true;
      tempError.name.errorMessage = 'Please enter name';
      isValid = false;
    }

    if (isEmptyNullUndefined(form.status)) {
      tempError.status.isError = true;
      tempError.status.errorMessage = 'Please select status';
      isValid = false;
    }

    if (isEmptyNullUndefined(formData)) {
      tempError.formData.isError = true;
      tempError.formData.errorMessage = 'Please create form to proceed*';
      isValid = false;
    }

    if (isValid) {
      // if(id) {
      //   UpdateFormPage();
      // } else {
      //   submitFormPage();
      // }

      if(!isEmptyNullUndefined(id)) {
        submitFormPage(data?.id, false);
      } else {
        submitFormPage(null, false);
      }
    } else {
      console.log('tempError', tempError);
      setFormError(tempError);
    }
  };

  // const submitForm = () => {
  //   let payload = {
  //     ...form,
  //     formData: formData,
  //   };

  //   console.log('payload', payload);
  // };

  console.log('formData', formData);

  const addFormElement = (type, insetInSpecificIndex, element, parentIndex) => {
    let tempError = {...formError};
    const lastElement = formData.length;

    const newElement = {
      label: `${type.charAt(0).toUpperCase() + type.slice(1)} Field`,
      name: `${type}-${Date.now()}`,
      type,
      subtype: null,
      color: null,
      bgColor: null,
      values: null,
      options: null,
      placeholder: null,
      required: false,
      disabled: false,
      helperText: null,
      sequenceNo: lastElement,

      container: [],
      // new fields added 5-sep
      formType: null, //"BASE"
      isMultiAddContainer: null, // if it is container so add more button or not
      isSelectMenuDynamic: null, // if true so in employee portal get dropdown dynamically
      isSingleSelect: null, // selection is single select or multiple select
      options: [], // if selection is not dynamic so munu item come from option
      selectMenuDynamicType: null // if isSelectMenuDynamic is true so what is dynamic type
    };

    if (type === 'empty') {
      // newElement.subtype = 'h1';
      // newElement.label = `New ${type.charAt(0).toUpperCase() + type.slice(1)}`;
    }

    if (type === 'container') {
      newElement.label = `New ${type.charAt(0).toUpperCase() + type.slice(1)}`;
    }

    if (type === 'header') {
      newElement.subtype = 'h1';
      newElement.label = `New ${type.charAt(0).toUpperCase() + type.slice(1)}`;
    }
    if (type === 'paragraph') {
      newElement.subtype = 'p';
      newElement.label = `New ${type.charAt(0).toUpperCase() + type.slice(1)}`;
    }

    if (type === 'button') {
      newElement.subtype = 'button';
      newElement.label = `New ${type.charAt(0).toUpperCase() + type.slice(1)}`;
      newElement.bgColor = 'green';
      newElement.color = 'black';
    }

    if (
      type === 'checkbox-group' ||
      type === 'radio-group' ||
      type === 'select'
    ) {
      newElement.options = [
        {label: 'Option 1', value: 'option-1'},
        {label: 'Option 2', value: 'option-2'},
      ];
    }

    if (type === 'single-checkbox') {
      newElement.label = 'checkbox label';
    }

    tempError.formData.isError = false;
    tempError.formData.errorMessage = '';
    setFormError(tempError);

    if(!isEmptyNullUndefined(element)) {
      // Create a new array with the new element inserted at the specified index
      
      const updatedFormData = JSON.parse(JSON.stringify(formData));
      if(!isEmptyNullUndefined(parentIndex)) {
        const comboElement = [updatedFormData[parentIndex].container[insetInSpecificIndex], newElement]
        updatedFormData[parentIndex].container.splice(insetInSpecificIndex, 1, comboElement);
      } else {
        // const updatedFormData = JSON.parse(JSON.stringify(formData));
        const comboElement = [updatedFormData[insetInSpecificIndex], newElement]
        updatedFormData.splice(insetInSpecificIndex, 1, comboElement);
        
      }
      setFormData(updatedFormData);


    }else if (!isEmptyNullUndefined(insetInSpecificIndex)) {
      // Create a new array with the new element inserted at the specified index
      const updatedFormData = JSON.parse(JSON.stringify(formData));
      updatedFormData.splice(insetInSpecificIndex, 0, newElement);

      setFormData(updatedFormData);

    } else {
      const updatedFormData = JSON.parse(JSON.stringify(formData));
      setFormData([updatedFormData, newElement]);
      // setFormData([...formData, [newElement]]);

    }

  };

  const addFormContainer = (type, insetInSpecificIndex, element, parentIndex) => {
    let tempFormData = JSON.parse(JSON.stringify(formData))
    let tempError = {...formError};
    const lastElement = formData.length;

    const newElement = {
      label: `${type.charAt(0).toUpperCase() + type.slice(1)} Field`,
      name: `${type}-${Date.now()}`,
      type,
      subtype: null,
      color: null,
      bgColor: null,
      values: null,
      options: null,
      placeholder: null,
      required: false,
      disabled: false,
      helperText: null,
      sequenceNo: lastElement,
      parentSequenceNo: lastElement,
      container: [],

      // new fields added 5-sep
      formType: null, //"BASE"
      isMultiAddContainer: null, // if it is container so add more button or not
      isSelectMenuDynamic: null, // if true so in employee portal get dropdown dynamically
      isSingleSelect: null, // selection is single select or multiple select
      options: [], // if selection is not dynamic so munu item come from option
      selectMenuDynamicType: null // if isSelectMenuDynamic is true so what is dynamic type
    };

    if (type === 'container') {
      newElement.label = `New ${type.charAt(0).toUpperCase() + type.slice(1)}`;
    }

    if (type === 'header') {
      newElement.subtype = 'h1';
      newElement.label = `New ${type.charAt(0).toUpperCase() + type.slice(1)}`;
    }
    if (type === 'paragraph') {
      newElement.subtype = 'p';
      newElement.label = `New ${type.charAt(0).toUpperCase() + type.slice(1)}`;
    }

    if (type === 'button') {
      newElement.subtype = 'button';
      newElement.label = `New ${type.charAt(0).toUpperCase() + type.slice(1)}`;
      newElement.bgColor = 'green';
      newElement.color = 'black';
    }

    if (
      type === 'checkbox-group' ||
      type === 'radio-group' ||
      type === 'select'
    ) {
      newElement.options = [
        {label: 'Option 1', value: 'option-1'},
        {label: 'Option 2', value: 'option-2'},
      ];
    }

    if (type === 'single-checkbox') {
      newElement.label = 'checkbox label';
    }

    if (type === 'startDate') { // preconfig
      newElement.label = 'Start Date';
      newElement.type = 'date'
    }

    if (type === 'endDate') { // preconfig
      newElement.label = 'End Date';
      newElement.type = 'date'
    }

    tempError.formData.isError = false;
    tempError.formData.errorMessage = '';
    setFormError(tempError);

    /*__________________NOTE_________________________
    1. if element is present:-
        create combo

    2. if element is absent and insetInSpecificIndex present:-

    3. if nor element is present nor insetInSpecificIndex present:-

    4. if parentIndex is present then it is a parent container position


    _______________________________________________*/

    if(!isEmptyNullUndefined(parentIndex)) {

      if(!isEmptyNullUndefined(element)) {
        const comboElement = [tempFormData[parentIndex].container[insetInSpecificIndex], newElement]
        tempFormData[parentIndex].container.splice(insetInSpecificIndex, 1, comboElement);
        setFormData(tempFormData)

      } else if(!isEmptyNullUndefined(insetInSpecificIndex)) {

        tempFormData[parentIndex].container.splice(insetInSpecificIndex, 0, newElement);
        setFormData(tempFormData);
      } else {

        tempFormData[parentIndex].container.push(newElement)
        console.log('+++++++++',tempFormData[parentIndex])
        setFormData(tempFormData)
      }
    } 
    else if(!isEmptyNullUndefined(element)) {
      // Create a new array with the new element inserted at the specified index
      const updatedFormData = JSON.parse(JSON.stringify(formData));
      const comboElement = [updatedFormData[insetInSpecificIndex], newElement]
      updatedFormData.splice(insetInSpecificIndex, 1, comboElement);

      setFormData(updatedFormData);
    } else if (!isEmptyNullUndefined(insetInSpecificIndex)) {
      // Create a new array with the new element inserted at the specified index
      const updatedFormData = [...formData];
      updatedFormData.splice(insetInSpecificIndex, 0, newElement);
      setFormData(updatedFormData);

    } else {
      setFormData([...formData, newElement]);
      // setFormData([...formData, [newElement]]);

    }

  };

  // Function to open edit dialog and set current element
  const handleEdit = (element, index, parentIndex) => {
    setEditedElement({...element});
    setEditedElementIndex(index);
    setEditedParentElementIndex(parentIndex);
    setEditDialogOpen(true);
  };

  const handleEditCombo = (element, index, comboIndex, parentIndex) => {
    setEditedElement({...element});
    setEditedElementIndex(index);
    setComboElementIndex(comboIndex);
    setEditedParentElementIndex(parentIndex);
    setEditDialogOpen(true);
  };

  const handleDeleteCombo = (index, comboIndex, formData, element, parentIndex) => {
    // first need to check other field is empty or not
    // if other field is empty then remove whole row
    // if other field is not empty then make single field which is expended

    console.log('index', index)
    console.log('comboIndex', comboIndex)
    console.log('parentIndex', parentIndex)

    let fieldOne = null
    let fieldTwo = null

    if(!isEmptyNullUndefined(parentIndex)) {
      fieldOne = formData[parentIndex].container[index][0]
      fieldTwo = formData[parentIndex].container[index][1]
    } else {
      fieldOne = formData[index][0]
      fieldTwo = formData[index][1]
    }

    // if(comboIndex == 0) {
    //   console.log(fieldTwo)
    //   if(fieldTwo.type == "empty") {
    //     formData.splice(index, 1)
    //   } else {
    //     formData[index] = fieldTwo
    //   }
    // } else if(comboIndex == 1) {
    //   if(fieldOne.type == "empty") {
    //     formData.splice(index, 1)
    //   } else {
    //     formData[index] = fieldOne
    //   }
    // }

    if(comboIndex == 0) {
      console.log(fieldTwo)
      if(fieldTwo.type == "empty") {
        if(!isEmptyNullUndefined(parentIndex)) {
          formData[parentIndex].container[index].splice(index, 1)
        } else {
          formData.splice(index, 1)
        }
      } else {
        if(!isEmptyNullUndefined(parentIndex)) {
          formData[parentIndex].container[index] = fieldTwo
        } else {
          formData[index] = fieldTwo
        }
        
      }
    } else if(comboIndex == 1) {
      if(fieldOne.type == "empty") {
        if(!isEmptyNullUndefined(parentIndex)) {
          formData[parentIndex].container[index].splice(index, 1)
        } else {
          formData.splice(index, 1)
        }
      } else {
        if(!isEmptyNullUndefined(parentIndex)) {
          formData[parentIndex].container[index] = fieldOne
        } else {
          formData[index] = fieldOne
        }
      }
    }

    setFormData(() => formData)
  }

  const handleInterchange = (element, index, formData, parentIndex) => {
    let newElement = []
    newElement.push(element[1])
    newElement.push(element[0])

    if(!isEmptyNullUndefined(parentIndex)) {
      formData[parentIndex].container[index] = newElement
    } else {
      formData[index] = newElement
    }


    console.log('newElement', newElement)
    console.log('formData', formData)

    setFormData(() => formData)
  }

  // const handleAddEmptyField = (element, index, formData) => {
    // let newComboElement = []
    // newComboElement.push(formData[index])
    // newComboElement.push()
    // addFormElement("empty", index, element);

  // }

  // Function to save edited element
  // const handleSaveEdit = () => {
  //   console.log('editedElement', editedElement);
  //   setFormData(
  //     formData.map((el, index) =>
  //       index === editedElementIndex ? {...editedElement} : el,
  //     ),
  //   );
  //   setEditDialogOpen(false);
  //   setEditedElement(null);
  // };

  const handleSaveEdit = () => {
    let tempformData = JSON.parse(JSON.stringify(formData));
    console.log('editedElement', editedElement);

    const settingEditE = (el, index) => {
        console.log('el', el);
        if (Array.isArray(el)) {
            el[comboElementIndex] = { ...editedElement };
            return el;
        } else {
            console.log('editedElement from parent', editedElement);
            return { ...editedElement };
        }
    };

    const settingEditESelectedParent = (pEl, pIndex) => {
        let tempeditedElement = JSON.parse(JSON.stringify(editedElement));
        console.log('settingEditESelectedParent pEl', pEl);
        let newPEl = pEl.container.map((containerE, containerIndex) => {
            if (containerIndex === editedElementIndex) {
                console.log('=====containerIndex', containerIndex);
                return settingEditE(containerE, containerIndex);
            } else {
                return containerE; // return the original element if it's not edited
            }
        });
        console.log('newPEl', newPEl);
        return { ...pEl, container: newPEl }; // Return the updated parent element with modified container
    };

    if (!isEmptyNullUndefined(editedParentElementIndex)) {
        console.log('editedParentElementIndex', editedParentElementIndex);
        const updatedFormData = tempformData.map((el, parentElementIndex) => {
            if (parentElementIndex === editedParentElementIndex) {
                return settingEditESelectedParent(JSON.parse(JSON.stringify(el)), parentElementIndex);
            } else {
                return el;
            }
        });
        console.log('---++++', updatedFormData);
        setFormData(updatedFormData);
    } else {
        setFormData(
            tempformData.map((el, index) =>
                index === editedElementIndex ? settingEditE(el, index) : el,
            ),
        );
    }
    setEditDialogOpen(false);
    setEditedElement(null);
    setEditedParentElementIndex(null);
};


  const handleDelete = (element, index, parentIndex) => {
    let tempFormData = JSON.parse(JSON.stringify(formData))
    // setFormData(formData.filter((element) => element.name !== name));
    // console.log('index', index)
    if(!isEmptyNullUndefined(parentIndex)) {
      console.log('tempFormData[parentIndex].container.splice(index,1)', tempFormData[parentIndex].container.splice(index,1)) 
    } else {
      tempFormData.splice(index, 1)
    }
    setFormData(() => tempFormData)
  };

  const onDragStart = (e, type) => {
    setDraggedItemType(type);
  };

  const onDrop = (e, isContainer) => {
    console.log('onDrop e', e)
    e.preventDefault();
    // const newType = e.dataTransfer.getData('text/plain');
    // addFormElement(draggedItemType);
    addFormContainer(draggedItemType);
  };

  const onDropBetweenElement = (e, index) => {
    console.log('onDrop e', e)
    e.preventDefault();
    // const newType = e.dataTransfer.getData('text/plain');
    // addFormElement(draggedItemType, index);
    addFormContainer(draggedItemType, index);
  }

  const onDropBetweenParentContainerElement = (e, index, element, parentIndex) => {
    console.log('onDrop e', e)
    e.preventDefault();
    // const newType = e.dataTransfer.getData('text/plain');
    // addFormElement(draggedItemType, index);
    addFormContainer(draggedItemType, index, null, parentIndex);
  }





  const onDropParentContainer = (e, parentIndex) => {
    console.log('onDrop e', e)
    e.preventDefault();
    // const newType = e.dataTransfer.getData('text/plain');
    // addFormElement(draggedItemType);
    addFormContainer(draggedItemType, null, null, parentIndex);
  };



  const onDropInContainer = (e, element, index, draggedItemType, parentIndex) => {
    e.preventDefault();
    // addFormElementInsideContainer(draggedItemType, index);
    // addFormElement(draggedItemType, index, element);
    addFormContainer(draggedItemType, index, element, parentIndex);
  }

  const onDragOver = (e) => {
    e.preventDefault();
  };

  const onDragEnd = (result) => {
    // console.log('result', result)
    // if (!result.destination) return;

    // const reorderedItems = Array.from(formData);
    // console.log('reorderedItems', reorderedItems)
    // const [movedItem] = reorderedItems.splice(result.source.index, 1);
    // console.log('movedItem', movedItem)




    // reorderedItems.splice(result.destination.index, 0, movedItem);

    // // Update sequenceNo for all items
    // const updatedItems = reorderedItems.map((item, index) => ({
    //   ...item,
    //   sequenceNo: index,
    // }));

    // setFormData(updatedItems);
    /////////////////////////////

    if (!result.destination) {
      return;
    }
    let tempformData = structuredClone(formData);

    let selectedSections = result.draggableId.split('-')[1];
    console.log('selectedSections', selectedSections)

    const reorder = (list, startIndex, endIndex) => {
      const result = Array.from(list);
      const [removed] = result.splice(startIndex, 1);
      result.splice(endIndex, 0, removed);
      return result;
    };

    let movedItems = reorder(
      tempformData,
      result.source.index,
      result.destination.index,
    );

    console.log('movedItems', movedItems)

    // tempformData[selectedSections] = movedItems;
    setFormData(() => movedItems)
  };  

  const UpdateFormPage = async (isDraft) => {
    // setIsLoading(true);
    let tempFormData = structuredClone(formData);

    let aaa = tempFormData.map((e, parentI) => {
      if (!Array.isArray(e)) {
        e.isMultiField = false;

        // e.parentSequenceNo = parentI;
        // e.sequenceNo = parentI;

        e.parentSequenceNo = parentI;
        e.sequenceNo = parentI;
        return [e];
      } else {

        // console.log('---------e', e)
        // console.log('---------e.length', e.length)
        if(e.length === 2) {
          e[0].isMultiField = true
          e[1].isMultiField = true

          e[0].parentSequenceNo = parentI
          e[1].parentSequenceNo = parentI

          e[0].sequenceNo = 0
          e[1].sequenceNo = 1

          if(e[0].label.includes('Empty')) {
            e[0].label = `Empty-parent-${parentI}-child-0`
            console.log('tttttttttttttttttttttttttttt')
          }
          if(e[1].label.includes('Empty')) {
            e[1].label = `Empty-parent-${parentI}-child-1`
          }
        } else {
          e[0].isMultiField = true

          e[0].parentSequenceNo = parentI

          e[0].sequenceNo = 0
        }
      }
      return e;
    });



    console.log('aaa', aaa);
    const payload = {
      id: data.id,
      companyId: selectedCompany?.id,
      status: form.status,
      name: form.name,
      goalFormField : aaa,
      containerFormField: [],
      formType:"BASE"

    };
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.goalFormSave}`,
        payload,
      );
      console.log(response)
      if (response.status == 200) {
        console.log('workingggg')
        dispatch(
          showMessage(
            `${response.data.name} form is successfully created`
          ),
        );
        // history.push('/drag-form-builder-list')
        Router.push('/drag-form-builder-list')
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
    // setIsLoading(false);
  };

  const submitFormPage = async (updateId, isDraft) => {
    // setIsLoading(true);
    console.log('formData', formData);
    let tempFormData = structuredClone(formData);

    let aaa = tempFormData.map((e, parentI) => {

      if (!Array.isArray(e)) {


        if(e.type === 'container') {
                    ////////////////////////////////
                    e.container = e.container.map((containerE, containerPI) => {
                      if (!Array.isArray(containerE)) {


                        
                
                
                        containerE.isMultiField = false;
                
                        containerE.parentSequenceNo = containerPI;
                        containerE.sequenceNo = 0;
                        console.log('containerE', [containerE])
                        return [containerE];
                      } else {
                
                        // console.log('---------containerE', containerE)
                        // console.log('---------containerE.length', containerE.length)
                        if(containerE.length === 2) {
                          containerE[0].isMultiField = true
                          containerE[1].isMultiField = true
                
                          containerE[0].parentSequenceNo = containerPI
                          containerE[1].parentSequenceNo = containerPI
                
                          containerE[0].sequenceNo = 0
                          containerE[1].sequenceNo = 1
                
                          if(containerE[0].label.includes('Empty')) {
                            containerE[0].label = `Empty-parent-${containerPI}-child-0`
                            console.log('tttttttttttttttttttttttttttt')
                          }
                          if(containerE[1].label.includes('Empty')) {
                            containerE[1].label = `Empty-parent-${containerPI}-child-1`
                          }
                        } else {
                          containerE[0].isMultiField = true
                
                          containerE[0].parentSequenceNo = containerPI
                
                          containerE[0].sequenceNo = 0
                
                        }
                      }

                      console.log('containerE return', containerE)
                      return containerE;
                    })
                    ////////////////////////////////
        
        } else {
          e.formType = "BASE"
        }


        e.isMultiField = false;

        e.parentSequenceNo = parentI;
        e.sequenceNo = 0;
        return [e];
      } else {

        // console.log('---------e', e)
        // console.log('---------e.length', e.length)
        if(e.length === 2) {
          e[0].isMultiField = true
          e[1].isMultiField = true

          e[0].parentSequenceNo = parentI
          e[1].parentSequenceNo = parentI

          e[0].sequenceNo = 0
          e[1].sequenceNo = 1

          e[0].formType = "BASE"
          e[1].formType = "BASE"

          if(e[0].label.includes('Empty')) {
            e[0].label = `Empty-parent-${parentI}-child-0`
            console.log('tttttttttttttttttttttttttttt')
          }
          if(e[1].label.includes('Empty')) {
            e[1].label = `Empty-parent-${parentI}-child-1`
          }
        } else {
          e[0].isMultiField = true

          e[0].parentSequenceNo = parentI

          e[0].sequenceNo = 0

          e[0].formType = "BASE"
        }
      }
      return e;
    });

    let goalFormFieldPayload = []
    let containerFormFieldPayload = []

    aaa.forEach((e,i) => {
      if(e[0].type === 'container') {
        containerFormFieldPayload.push(e)
      } else {
        goalFormFieldPayload.push(e)
      }
    })



    console.log('aaa', aaa);
    const payload = {
    companyId: selectedCompany?.id,
    status: form.status,
    name: form.name,
    // goalFormField : aaa,
    // containerFormField: [],

    goalFormField : goalFormFieldPayload,
    containerFormField: containerFormFieldPayload,
    formType:"BASE"
    };

    if(!isEmptyNullUndefined(updateId)) {
      payload.id = updateId
    }

    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.goalFormSave}`,
        payload,
      );
      console.log(response)
      if (response.status == 200) {
        console.log('workingggg')
        dispatch(
          showMessage(
            `${response.data.name} form is successfully created`
          ),
        );
        // history.push('/drag-form-builder-list')
        Router.push('/drag-form-builder-list')
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
    // setIsLoading(false);
  };

  const submitFormPagee = async (isDraft) => {
    // setIsLoading(true);
    console.log('formData', formData);
    let tempFormData = structuredClone(formData);

    let aaa = tempFormData.map((e, parentI) => {
      if (!Array.isArray(e)) {
        e.isMultiField = false;

        // e.parentSequenceNo = parentI;
        // e.sequenceNo = parentI;

        e.parentSequenceNo = parentI;
        e.sequenceNo = parentI;
        return [e];
      } else {

        // console.log('---------e', e)
        // console.log('---------e.length', e.length)
        if(e.length === 2) {
          e[0].isMultiField = true
          e[1].isMultiField = true

          e[0].parentSequenceNo = parentI
          e[1].parentSequenceNo = parentI

          e[0].sequenceNo = 0
          e[1].sequenceNo = 1

          if(e[0].label.includes('Empty')) {
            e[0].label = `Empty-parent-${parentI}-child-0`
            console.log('tttttttttttttttttttttttttttt')
          }
          if(e[1].label.includes('Empty')) {
            e[1].label = `Empty-parent-${parentI}-child-1`
          }
        } else {
          e[0].isMultiField = true

          e[0].parentSequenceNo = parentI

          e[0].sequenceNo = 0
        }
      }
      return e;
    });



    console.log('aaa', aaa);
    const payload = {
    companyId: selectedCompany?.id,
    status: form.status,
    name: form.name,
    goalFormField : aaa,
    containerFormField: [],
    };
    try {
      const response = await jwtAxios.post(
        `${API_ROUTS.goalFormSave}`,
        payload,
      );
      console.log(response)
      if (response.status == 200) {
        console.log('workingggg')
        dispatch(
          showMessage(
            `${response.data.name} form is successfully created`
          ),
        );
        // history.push('/drag-form-builder-list')
        Router.push('/drag-form-builder-list')
      }
    } catch (error) {
      apiCatchErrorMessage(error, dispatch, fetchError);
    }
    // setIsLoading(false);
  };

  const renderFormElement = (element, index) => {
    if(Array.isArray(element)) {
      return (
        <Draggable  key={'r-' + index} draggableId={'r-' + index} index={index}>
          {(provided) => (
            <Box
            onDragOver={onDragOver} onDrop={e => console.log(e)}
              ref={provided.innerRef}
              {...provided.draggableProps}
              {...provided.dragHandleProps}
              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: 1,
                border: '1px solid transparent',
                borderRadius: 1,
                mb: 2,
                '&:hover': {
                  borderColor: 'grey',
                  backgroundColor: 'white',
                  '.action-buttons': {
                    visibility: 'visible',
                  },
                },
              }}
            >
              <div style={{display: 'flex', width: '100%'}}>
                <div style={{width: 'calc(50% - 25px)', display: 'flex'}}>
                  <div style={{width: 'calc(100% - 90px)'}}>
                    <RenderFormElement element={element[0]} />
                  </div>
                  <div style={{width:'90px'}}>
                    <Box className='action-buttons' sx={{visibility: 'hidden'}}>
                      <IconButton style={{visibility: (element[0].type == "empty") ? "hidden" : "inherit"}} onClick={() => handleEditCombo(element[0], index, 0)}>
                        <EditIcon />
                      </IconButton>
                      <IconButton onClick={() =>handleDeleteCombo(index, 0, JSON.parse(JSON.stringify(formData)), JSON.parse(JSON.stringify(element)))}>
                        <DeleteIcon />
                      </IconButton>
                    </Box>
                  </div>
                </div>
                <div style={{display: 'flex', width: 'calc(50% - 25px)'}}>
                  <div style={{width: 'calc(100% - 90px)'}}>
                    <RenderFormElement element={element[1]} />
                  </div>
                  <div style={{width:'90px'}}>
                    <Box className='action-buttons' sx={{visibility: 'hidden'}}>
                      <IconButton style={{visibility: (element[1]?.type == "empty") ? "hidden" : "inherit"}} onClick={() => handleEditCombo(element[1], index, 1)}>
                        <EditIcon />
                      </IconButton>
                      <IconButton onClick={() => handleDeleteCombo(index, 1, JSON.parse(JSON.stringify(formData)), JSON.parse(JSON.stringify(element)))}>
                        <DeleteIcon />
                      </IconButton>
                    </Box>
                  </div>
                </div>
                <div style={{width:'50px'}}>
                  <Box className='action-buttons' sx={{visibility: 'hidden'}}>
                    <IconButton onClick={() => handleInterchange(element, index, JSON.parse(JSON.stringify(formData)))}>
                      <SyncAltIcon />
                    </IconButton>
                  </Box>
                </div>
              </div>
              
              
            </Box>
          )}
        </Draggable>
      )
    } else {
      return (
        // <Draggable key={element.name} draggableId={element.name} index={index}>
        <Draggable key={'r-' + index} draggableId={'r-' + index} index={index}>
          {(provided) => (
            <Box
            onDragOver={onDragOver} onDrop={e => onDropInContainer(e, element, index, JSON.parse(JSON.stringify(draggedItemType)))}
              ref={provided.innerRef}
              {...provided.draggableProps}
              {...provided.dragHandleProps}
              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: 1,
                border: '1px solid transparent',
                borderRadius: 1,
                mb: 2,
                '&:hover': {
                  borderColor: 'grey',
                  backgroundColor: 'white',
                  '.action-buttons': {
                    visibility: 'visible',
                  },
                },
              }}
            >
              <div style={{display: 'flex', width: '100%'}}>
                <div style={{width: 'calc(100% - 50px)', display: 'flex'}}>
                  <div style={{width: 'calc(100% - 90px)'}}>
                    <RenderFormElement element={element} />
                  </div>
                  <div style={{width:'90px'}}>
                    <Box className='action-buttons' sx={{visibility: 'hidden'}}>
                      <IconButton onClick={() => handleEdit(element, index)}>
                        <EditIcon />
                      </IconButton>
                      <IconButton onClick={() => handleDelete(element, index)}>
                        <DeleteIcon />
                      </IconButton>
                    </Box>
                  </div>
                </div>
                <div style={{width:'50px'}}>
                  <Box className='action-buttons' sx={{visibility: 'hidden'}}>
                    <IconButton 
                      // onClick={() => handleAddEmptyField(element, index, JSON.parse(JSON.stringify(formData)))}
                      onClick={() => addFormElement("empty", index, element)}
                    >
                      <KeyboardDoubleArrowLeftIcon />
                    </IconButton>
                  </Box>
                </div>
              </div>


              {/* <RenderFormElement element={element} />
              <Box className='action-buttons' sx={{visibility: 'hidden'}}>
                <IconButton onClick={() => handleEdit(element, index)}>
                  <EditIcon />
                </IconButton>
                <IconButton onClick={() => handleDelete(element.name)}>
                  <DeleteIcon />
                </IconButton>
              </Box> */}
            </Box>
          )}
        </Draggable>
      );
    }
    console.log('element',Array.isArray(element))
    
  };

  const renderFormElementNotDrage = (element, index, parentIndex) => {
    if(Array.isArray(element)) {
      return (

            <Box
            onDragOver={onDragOver} onDrop={e => console.log(e)}

              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: 1,
                border: '1px solid transparent',
                borderRadius: 1,
                mb: 2,
                '&:hover': {
                  borderColor: 'grey',
                  backgroundColor: 'white',
                  '.action-buttons': {
                    visibility: 'visible',
                  },
                },
              }}
            >
              <div style={{display: 'flex', width: '100%'}}>
                <div style={{width: 'calc(50% - 25px)', display: 'flex'}}>
                  <div style={{width: 'calc(100% - 90px)'}}>
                    <RenderFormElement element={element[0]} />
                  </div>
                  <div style={{width:'90px'}}>
                    <Box className='action-buttons' sx={{visibility: 'hidden'}}>
                      <IconButton style={{visibility: (element[0].type == "empty") ? "hidden" : "inherit"}} onClick={() => handleEditCombo(element[0], index, 0, parentIndex)}>
                        <EditIcon />
                      </IconButton>
                      <IconButton onClick={() =>handleDeleteCombo(index, 0, JSON.parse(JSON.stringify(formData)), JSON.parse(JSON.stringify(element)), parentIndex)}>
                        <DeleteIcon />
                      </IconButton>
                    </Box>
                  </div>
                </div>
                <div style={{display: 'flex', width: 'calc(50% - 25px)'}}>
                  <div style={{width: 'calc(100% - 90px)'}}>
                    <RenderFormElement element={element[1]} />
                  </div>
                  <div style={{width:'90px'}}>
                    <Box className='action-buttons' sx={{visibility: 'hidden'}}>
                      <IconButton style={{visibility: (element[1].type == "empty") ? "hidden" : "inherit"}} onClick={() => handleEditCombo(element[1], index, 1, parentIndex)}>
                        <EditIcon />
                      </IconButton>
                      <IconButton onClick={() => handleDeleteCombo(index, 1, JSON.parse(JSON.stringify(formData)), JSON.parse(JSON.stringify(element)), parentIndex)}>
                        <DeleteIcon />
                      </IconButton>
                    </Box>
                  </div>
                </div>
                <div style={{width:'50px'}}>
                  <Box className='action-buttons' sx={{visibility: 'hidden'}}>
                    <IconButton onClick={() => handleInterchange(element, index, JSON.parse(JSON.stringify(formData)), parentIndex)}>
                      <SyncAltIcon />
                    </IconButton>
                  </Box>
                </div>
              </div>
              
              
            </Box>

      )
    } else {
      return (
        // <Draggable key={element.name} draggableId={element.name} index={index}>
            <Box
            onDragOver={onDragOver} onDrop={e => onDropInContainer(e, element, index, JSON.parse(JSON.stringify(draggedItemType)), parentIndex)}
             
              sx={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: 1,
                border: '1px solid transparent',
                borderRadius: 1,
                mb: 2,
                '&:hover': {
                  borderColor: 'grey',
                  backgroundColor: 'white',
                  '.action-buttons': {
                    visibility: 'visible',
                  },
                },
              }}
            >
              <div style={{display: 'flex', width: '100%'}}>
                <div style={{width: 'calc(100% - 50px)', display: 'flex'}}>
                  <div style={{width: 'calc(100% - 90px)'}}>
                    <RenderFormElement element={element} />
                  </div>
                  <div style={{width:'90px'}}>
                    <Box className='action-buttons' sx={{visibility: 'hidden'}}>
                      <IconButton onClick={() => handleEdit(element, index, parentIndex)}>
                        <EditIcon />
                      </IconButton>
                      <IconButton onClick={() => handleDelete(element, index, parentIndex)}>
                        <DeleteIcon />
                      </IconButton>
                    </Box>
                  </div>
                </div>
                <div style={{width:'50px'}}>
                  <Box className='action-buttons' sx={{visibility: 'hidden'}}>
                    <IconButton 
                      // onClick={() => handleAddEmptyField(element, index, JSON.parse(JSON.stringify(formData)))}
                      onClick={() => addFormElement("empty", index, element, parentIndex)}
                    >
                      <KeyboardDoubleArrowLeftIcon />
                    </IconButton>
                  </Box>
                </div>
              </div>


              {/* <RenderFormElement element={element} />
              <Box className='action-buttons' sx={{visibility: 'hidden'}}>
                <IconButton onClick={() => handleEdit(element, index)}>
                  <EditIcon />
                </IconButton>
                <IconButton onClick={() => handleDelete(element.name)}>
                  <DeleteIcon />
                </IconButton>
              </Box> */}
            </Box>
        
      );
    }
    console.log('element',Array.isArray(element))
    
  };



  const renderFormContainer = (element, index) => {


      return (
        <Draggable key={'r-' + index} draggableId={'r-' + index} index={index}>
          {(provided) => (
            <Box
              // onDragOver={onDragOver} 
              // onDrop={e => onDropInContainer(e, element, index, JSON.parse(JSON.stringify(draggedItemType)))}
              ref={provided.innerRef}
              {...provided.draggableProps}
              {...provided.dragHandleProps}
              sx={{
                  border: '1px dashed #ccc',
                // display: 'flex',
                // alignItems: 'center',
                // justifyContent: 'space-between',
                padding: 1,
              //   // border: '1px solid transparent',
                // borderRadius: 1,
                mb: 2,
              //   '&:hover': {
              //     borderColor: 'grey',
              //     backgroundColor: 'white',
              //     '.action-buttons': {
              //       visibility: 'visible',
              //     },
              //   },
              }}
            >
              <Stack direction={'row'} sx={{borderBottom: '1px dashed #ccc', justifyContent: 'space-between', display: 'flex'}}>
                <div>
                  {element.label}
                </div>
                <div>
                  
                </div>
                <Box 
                  sx={{
                    '&:hover': {
                      borderColor: 'grey',
                      // backgroundColor: 'white',
                      '.action-buttons': {
                        visibility: 'visible',
                      },
                    },
                  }}
                >
                  <div style={{display: 'flex', width: '100%'}}>
                    <div style={{width: 'calc(100% - 50px)', display: 'flex'}}>
                      <div style={{width: 'calc(100% - 90px)'}}>
                        <RenderFormElement element={element} />
                      </div>
                      <div style={{width:'90px'}}>
                        <Box className='action-buttons' sx={{visibility: 'hidden', display: 'flex'}}>
                          <IconButton onClick={() => handleEdit(element, index)}>
                            <EditIcon />
                          </IconButton>
                          <IconButton onClick={() => handleDelete(element, index)}>
                            <DeleteIcon />
                          </IconButton>
                        </Box>
                      </div>
                    </div>
                  </div>
                </Box>
              
              
              </Stack>
              {(element?.container?.length > 0) ? (
                <>
                  {element.container.map((childrenElement, childrenIndex) =>
                          <div style={{display: 'block'}}>
                            <div 
                              style={{
                                width: '100%', 
                                // background: 'blue', 
                                height: '25px'
                              }}
                              onDrop={e => onDropBetweenParentContainerElement(e, childrenIndex, childrenElement, index)}
                              onDragOver={onDragOver}
                            ></div>
                            {console.log('element-----',element)}

                            {renderFormElementNotDrage(childrenElement, childrenIndex, index)}
                          </div>

                          
                          )}

                <div 
                  style={{width: '100%', height: '50px'}}
                  onDrop={e => onDropParentContainer(e, index)}
                  onDragOver={onDragOver}
                >
                </div>
                
                </>




              ) : (
                <div 
                  style={{width: '100%', height: '100px'}}
                  onDrop={e => onDropParentContainer(e, index)}
                  onDragOver={onDragOver}
                >
                </div>

              )}
              
            </Box>
          )}
        </Draggable>
      )

    
  };

  const renderToolbar = () => {
    return (
      <Stack>
        <Button
          draggable
          onDragStart={(e) => onDragStart(e, 'header')}
          sx={{mr: 2, ml: 2, mb: 2}}
          variant='outlined'
          startIcon={<TitleIcon />}
        >
          Header
        </Button>
        <Button
          draggable
          onDragStart={(e) => onDragStart(e, 'paragraph')}
          sx={{mr: 2, ml: 2, mb: 2}}
          variant='outlined'
          startIcon={<ParagraphIcon />}
        >
          Paragraph
        </Button>
        <Button
          draggable
          onDragStart={(e) => onDragStart(e, 'text')}
          sx={{mr: 2, ml: 2, mb: 2}}
          variant='outlined'
          startIcon={<TextFieldsIcon />}
        >
          Text Field
        </Button>
        <Button
          draggable
          onDragStart={(e) => onDragStart(e, 'number')}
          sx={{mr: 2, ml: 2, mb: 2}}
          variant='outlined'
          startIcon={<NumberIcon />}
        >
          Number Field
        </Button>
        <Button
          draggable
          onDragStart={(e) => onDragStart(e, 'date')}
          sx={{mr: 2, ml: 2, mb: 2}}
          variant='outlined'
          startIcon={<DateRangeIcon />}
        >
          Date Field
        </Button>
        <Button
          draggable
          onDragStart={(e) => onDragStart(e, 'checkbox-group')}
          sx={{mr: 2, ml: 2, mb: 2}}
          variant='outlined'
          startIcon={<CheckBoxIcon />}
        >
          Checkbox Group
        </Button>
        <Button
          draggable
          onDragStart={(e) => onDragStart(e, 'radio-group')}
          sx={{mr: 2, ml: 2, mb: 2}}
          variant='outlined'
          startIcon={<RadioButtonCheckedIcon />}
        >
          Radio Group
        </Button>
        <Button
          draggable
          onDragStart={(e) => onDragStart(e, 'select')}
          sx={{mr: 2, ml: 2, mb: 2}}
          variant='outlined'
          startIcon={<SelectAllIcon />}
        >
          Select
        </Button>
        <Button
          draggable
          onDragStart={(e) => onDragStart(e, 'file')}
          sx={{mr: 2, ml: 2, mb: 2}}
          variant='outlined'
          startIcon={<UploadFileIcon />}
        >
          File Upload
        </Button>
        <Button
          draggable
          onDragStart={(e) => onDragStart(e, 'textarea')}
          sx={{mr: 2, ml: 2, mb: 2}}
          variant='outlined'
          startIcon={<BsTextareaResize />}
        >
          Text Area
        </Button>
        <Button
          draggable
          onDragStart={(e) => onDragStart(e, 'button')}
          sx={{mr: 2, ml: 2, mb: 2}}
          variant='outlined'
          startIcon={<SmartButtonIcon />}
        >
          Button
        </Button>
        <Button
          draggable
          onDragStart={(e) => onDragStart(e, 'single-checkbox')}
          sx={{mr: 2, ml: 2, mb: 2}}
          variant='outlined'
          startIcon={<SmartButtonIcon />}
        >
          Single Checkbox
        </Button>
        <Button
          draggable
          onDragStart={(e) => onDragStart(e, 'container')}
          sx={{mr: 2, ml: 2, mb: 2}}
          variant='outlined'
          startIcon={<CalendarViewMonthIcon />}
        >
          container
        </Button>
      </Stack>
    );
  };

  const renderPreConfigToolbar = () => {
    return (
      <Stack>
        <Button
          draggable
          onDragStart={(e) => onDragStart(e, 'startDate')}
          sx={{mr: 2, ml: 2, mb: 2}}
          variant='outlined'
          startIcon={<TodayIcon />}
        >
          Start Date
        </Button>
        <Button
          draggable
          onDragStart={(e) => onDragStart(e, 'endDate')}
          sx={{mr: 2, ml: 2, mb: 2}}
          variant='outlined'
          startIcon={<TodayIcon />}
        >
          End Date
        </Button>
      </Stack>
    );
  }

  const handleViewJson = () => {
    setJsonFormData(JSON.stringify(formData, null, 2));
    setJsonDialogOpen(true);
  };

  return (
    <Stack marginBottom={'50px'}>
      <AppAnimate animation='transition.slideUpIn' delay={500}>
        <AppPageMeta />
        <h2>Create form</h2>
        <AppCard sx={{ml:4,mr:4}}>
          <Stack
            // display={{xs: 'flex', sm: 'flex'}}
            direction={{xs: 'column', sm: 'row'}}
            sx={{mt: 2}}
            justifyContent='space-between'
            alignItems='flex-start'
            spacing={2}
          >
            <Stack width={{xs: '100%', sm: '50%'}}>
              <TextField
                size='small'
                maxRows={3}
                name='name'
                labelId='name'
                label={'Name'}
                variant='outlined'
                onChange={(event) => handleFormChange(event, 'textfield')}
                value={form?.name || ''}
                error={formError.name.isError}
                helperText={formError.name.errorMessage}
                sx={{
                  ...textFieldStyled,
                  '& fieldset': {
                    borderLeftWidth: 3,
                    borderLeftColor: 'red',
                  },
                }}
              />
            </Stack>

            <Stack width={{xs: '100%', sm: '50%'}}>
              <FormControl
                sx={{
                  ...textFieldStyled,
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderLeftColor: 'red',
                      borderLeftWidth: 3,
                    },
                  },
                }}
              >
                <InputLabel size='small' id='status'>
                  <IntlMessages id='configuration.dialogbox.Status' />
                </InputLabel>
                <Select
                  size='small'
                  name='status'
                  label='Status'
                  labelId='status'
                  value={form?.status || ''}
                  error={formError.status?.isError}
                  helperText={formError.status?.errorMessage}
                  onChange={(event) => handleFormChange(event, 'dropdown')}
                  variant='outlined'
                  sx={{...textFieldStyled, width: '100%'}}
                >
                  <MenuItem key='Active' value='ACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Active' />
                  </MenuItem>
                  <MenuItem key='Inactive' value='INACTIVE'>
                    <IntlMessages id='configuration.dialogbox.Status.Inactive' />
                  </MenuItem>
                </Select>
                <FormHelperText style={{color: '#d32f2f'}}>
                  {formError.status.errorMessage}
                </FormHelperText>
              </FormControl>
            </Stack>
          </Stack>
        </AppCard>

        <Stack
          display='flex'
          direction='row'
          justifyContent='space-between'
          sx={{mb: 10}}
        >
          <Box sx={{flexBasis: '70%', padding: 2}}>
            <AppCard sx={{height: '80vh', overflowY: 'auto'}}>
              <Stack
                display={'flex'}
                direction={'row'}
                justifyContent={'space-between'}
                alignItems={'center'}
                spacing={2}
              >
                <Typography variant='h2'>Dropzone</Typography>
                <Stack>
                  {formError.formData.isError && (
                    <FormHelperText style={{color: '#d32f2f',fontSize:'16px'}}>
                      {formError.formData.errorMessage}
                    </FormHelperText>
                  )}
                </Stack>
                <Stack
                  display={'flex'}
                  direction={'row'}
                  justifyContent={'space-between'}
                  alignItems={'center'}
                  spacing={2}
                >
                  <Button
                    onClick={() => handleViewJson()}
                    disabled={isEmptyNullUndefined(formData)}
                  >
                    View Json Data
                  </Button>
                  <Button onClick={() => setFormData([])}>Clear All</Button>
                </Stack>
              </Stack>
              <Divider width='100%' sx={{mt: 2, mb: 2}} />
              
              <DragDropContext onDragEnd={onDragEnd}>
                <Droppable droppableId='dropzone'>
                  {(provided) => (
                    <Stack
                      {...provided.droppableProps}
                      ref={provided.innerRef}
                      // onDrop={onDrop}
                      // onDragOver={onDragOver}
                      sx={{
                        minHeight: '70vh',
                        overflowY: 'auto',
                        border: '1px dashed #ccc',
                        backgroundColor: '#f9f9f9',
                        padding: 2,
                        mb: 2,
                      }}
                    >
                      {
                      formData && (formData.length > 0) ? (


                        <>

                          {formData.map((element, index) =>
                          <>
                            <div 
                              style={{
                                width: '100%', 
                                // background: 'blue', 
                                height: '25px'
                              }}
                              onDrop={e => onDropBetweenElement(e, index)}
                              onDragOver={onDragOver}
                            ></div>
                            {console.log('element-----',element)}
                            {/* if element is container then there is seperate render function */}

                            {element.type === "container" ? (
                              renderFormContainer(element, index)
                            ) : (
                              renderFormElement(element, index)
                            )}
                          </>
                          )}
                          <div 
                            style={{
                              width: '100%', 
                              // background: 'blue', 
                              height: '100px'
                            }}
                            
                            onDrop={onDrop}
                            onDragOver={onDragOver}
                          ></div>

                        </>


                      ) : (



                        <div 
                          style={{width: '100%', height: '100vh'}}
                          // onDrop(true) container true
                          onDrop={e => onDrop(e, true)}
                          onDragOver={onDragOver}
                        >
                        </div>
                      )
                      }
                      {provided.placeholder}
                    </Stack>
                  )}
                </Droppable>
              </DragDropContext>
            </AppCard>
          </Box>
          <Box sx={{flexBasis: '30%', padding: 2}}>
            <AppCard sx={{height: '80vh', overflowY: 'auto'}}>
              <Typography variant='h2'>Toolbar</Typography>
              <Divider width='100%' sx={{mt: 2, mb: 2}} />
              {renderToolbar()}
              <Typography variant='h2'>Pre Config</Typography>
              <Divider width='100%' sx={{mt: 2, mb: 2}} />
              {renderPreConfigToolbar()}
            </AppCard>
          </Box>
        </Stack>
        <AppInfoView />
      </AppAnimate>




      {/* ////////////////// ignore below /////////////////////// */}

      {/* Fixed stack for buttons */}
      <Stack
        sx={{
          bottom: 0,
          zIndex: 10,
          position: 'fixed',
          backdropFilter: 'blur(5px)',
          width: '100%',
          right: 0,
        }}
      >
        <Stack
          direction='row'
          justifyContent='end'
          alignItems='center'
          spacing={2}
          sx={{
            pt: 5,
            ml: 3,
            margin: {xs: '0 5% 1% 0', xl: '0 17% 1% 0'},
          }}
        >
          
          <Button
            color={footerButton.back.color}
            variant={footerButton.back.variant}
            sx={footerButton.back.sx}
            size={footerButton.back.size}
            onClick={() => Router.push('/drag-form-builder-list')}
          >
            <IntlMessages id='common.button.Back' />
          </Button>
          <Button
            color={footerButton.back.color}
            variant={footerButton.back.variant}
            sx={footerButton.back.sx}
            size={footerButton.back.size}
            disabled={isEmptyNullUndefined(formData)}
            onClick={() => setPreviewDialogOpen(true)}
          >
            {/* Preview */}
            <IntlMessages id='common.button.Preview' />
          </Button>

          <Button
            color={footerButton.saveDraft.color}
            variant={footerButton.saveDraft.variant}
            sx={footerButton.saveDraft.sx}
            size={footerButton.saveDraft.size}
            // onClick={() => handleValidateBeforeSubmit(true)}
          >
            <IntlMessages id='common.button.SaveDraft' />
          </Button>

          <Button
            id='health-hnsurance-submit-button'
            color={footerButton.submit.color}
            variant={footerButton.submit.variant}
            sx={footerButton.submit.sx}
            size={footerButton.submit.size}
            onClick={() => handleValidateForm()}
          >
            {id ? <IntlMessages id='common.button.Update' /> : <IntlMessages id='common.button.Submit' />}
          </Button>
        </Stack>
      </Stack>

      {/* Edit Element configuration */}
      {editDialogOpen && (
        <EditElement
          editedElement={editedElement}
          setEditedElement={setEditedElement}
          editDialogOpen={editDialogOpen}
          setEditDialogOpen={setEditDialogOpen}
          handleSaveEdit={handleSaveEdit}
        />
      )}

      {/* Form Preview */}
      {previewDialogOpen && (
        <ViewForm
          formData={formData}
          previewDialogOpen={previewDialogOpen}
          setPreviewDialogOpen={setPreviewDialogOpen}
        />
      )}

      {/* Generated Form JSON  */}
      {jsonDialogOpen && (
        <ViewJson
          formData={jsonFormData}
          jsonDialogOpen={jsonDialogOpen}
          setJsonDialogOpen={setJsonDialogOpen}
        />
      )}
    </Stack>
  );
};

export default CustomFormBuilder;
