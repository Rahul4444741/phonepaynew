import jwtAxios from '@crema/services/auth/jwt-auth';
import {
  Button,
  CircularProgress,
  FormControl,
  InputLabel,
  MenuItem,
  Paper,
  Select,
  Stack,
} from '@mui/material';
import axios from 'axios';
import SelectEmployee from 'modules/Common/SelectEmployee';
import React, {useEffect, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {fetchError, showInfo} from 'redux/actions';

import {API_ROUTS} from 'shared/constants/ApiRouts';
import {footerButton} from 'shared/constants/AppConst';
import {
  apiCatchErrorMessage,
  isEmptyNullUndefined,
} from 'shared/utils/CommonUtils';
import {domCreactionGridSkeletonLoader} from 'shared/utils/domCreaction';

const textFieldStyled = {
  backgroundColor: 'white',
  mb: 2,
  width: {xs: '100%', xl: '60%', md: '75%'},
};

const initialForm = {
  companyId: null,
  annualCycleId: null,
  employeeId: [],
};

const Dashboard = () => {
  const dispatch = useDispatch();
  let selectedCompany = useSelector(({company}) => company.selectedCompany);
  let companyData = useSelector(({company}) => company.companyData);
  const [form, setForm] = useState(initialForm);

  const [loading, setLoading] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [empId, setEmpId] = useState(null);
  const [data, setData] = useState(null);

  const [annualCycle, setAnnualCycle] = useState([]);

  const CancelToken = axios.CancelToken;
  const source = CancelToken.source();
  const source2 = CancelToken.source();

  useEffect(() => {
    getAllActiveAnnualCycle(selectedCompany.id);
  }, [selectedCompany]);

  // useEffect(() => {
  //   if (
  //     !isEmptyNullUndefined(annualCycle) &&
  //     !isEmptyNullUndefined(selectedCompany)
  //   ) {
  //     getDashbordData();
  //   }
  // }, [annualCycle, selectedCompany]);

  const getAllActiveAnnualCycle = async (companyId) => {
    setIsLoading(true);
    try {
      const res = await jwtAxios.get(
        `${API_ROUTS.annualCycle}/${companyId}/ALL`,
      );
      if (res.status == 200) {
        if (res.data.length == 0) {
          dispatch(showInfo('You have no annual cycle for selected company'));
          setAnnualCycle([]);
        } else {
          setAnnualCycle(res.data);
        }
      } else {
        setAnnualCycle([]);
      }
    } catch (error) {
      if (!axios.isCancel(error)) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
      setAnnualCycle([]);
    } finally {
      setIsLoading(false);
    }
  };

  const getDashbordData = async () => {
    setLoading(true);
    const payload = {
      companyId: form.companyId,
      annualCycleId: form.annualCycleId,
      employeeId: empId ? [empId] : [],
    };
    try {
      const response = await jwtAxios.post(`${API_ROUTS.dashData}`, payload);
      if (response.status == 200) {
        setData(response.data);
      }
    } catch (e) {
      dispatch(fetchError(e.response?.data?.detail));
    } finally {
      setLoading(false);
    }
  };

  const handleEmployeeSelect = (employee) => {
    setEmpId(employee ? employee.id : null);
  };
  const handleChange = (event, fieldType, name) => {
    let tempForm = {...form};

    if (fieldType == 'textfield' || fieldType == 'dropdown') {
      tempForm[event.target.name] = event.target.value;
    }
    setForm(() => tempForm);
  };

  return (
    <Stack spacing={2}>
      <Stack direction='row'>
        <Paper
          elevation={3}
          sx={{
            width: '100%',
            padding: 2,
            borderRadius: '10px',
            mr: 3,
          }}
        >
          <Stack direction='row' spacing={2} sx={{width: '100%'}}>
            {/* Company Dropdown */}
            <Stack direction='row' sx={{flex: 1}}>
              {isLoading ? (
                domCreactionGridSkeletonLoader('70px')
              ) : (
                <FormControl
                  sx={{
                    ...textFieldStyled,
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                    },
                  }}
                >
                  <InputLabel
                    sx={{backgroundColor: '#ffffff', padding: '0px 0.5rem'}}
                    size='small'
                    id='Type-companyId'
                  >
                    Select Company
                  </InputLabel>
                  <Select
                    value={form.companyId || ''}
                    id='companyId'
                    name='companyId'
                    onChange={(event) => handleChange(event, 'dropdown')}
                    variant='outlined'
                    size='small'
                  >
                    <MenuItem value={null} name={null} size='small' key={null}>
                      {'None'}
                    </MenuItem>
                    {companyData?.map((t) => (
                      <MenuItem
                        value={t.displayName}
                        id={t.id}
                        name={t.displayName}
                        size='small'
                        key={t.id}
                      >
                        {t.displayName}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              )}
            </Stack>

            {/* Annual Cycle Dropdown */}
            <Stack direction='row' sx={{flex: 1}}>
              {isLoading ? (
                domCreactionGridSkeletonLoader('70px')
              ) : (
                <FormControl
                  sx={{
                    ...textFieldStyled,
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': {
                        borderLeftColor: 'red',
                        borderLeftWidth: 3,
                      },
                      width: '100%',
                    },
                  }}
                >
                  <InputLabel
                    sx={{backgroundColor: '#ffffff', padding: '0px 0.5rem'}}
                    size='small'
                    id='Type-annualCycleId'
                  >
                    Select Annual Cycle
                  </InputLabel>
                  <Select
                    value={form.annualCycleId || ''}
                    id='annualCycleId'
                    name='annualCycleId'
                    onChange={(event) => handleChange(event, 'dropdown')}
                    variant='outlined'
                    size='small'
                  >
                    <MenuItem value={null} name={null} size='small' key={null}>
                      {'None'}
                    </MenuItem>
                    {annualCycle?.map((t) => (
                      <MenuItem
                        value={t.cycleName}
                        id={t.id}
                        name={t.cycleName}
                        size='small'
                        key={t.id}
                      >
                        {t.cycleName}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              )}
            </Stack>

            {/* Employee Selector */}
            <Stack sx={{flex: 1}}>
              {isLoading ? (
                domCreactionGridSkeletonLoader('70px')
              ) : (
                <SelectEmployee
                  onEmployeeSelect={handleEmployeeSelect}
                  customSx={{
                    ...textFieldStyled,
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': {
                        borderLeftColor: 'gray',
                        borderLeftWidth: 3,
                      },
                    },
                    width: '100%',
                  }}
                />
              )}
            </Stack>

            {/* Load Button */}
            <Stack sx={{flex: 1}}>
              {isLoading ? (
                domCreactionGridSkeletonLoader('70px')
              ) : (
                <Button
                  variant={footerButton.submit.variant}
                  color={footerButton.submit.color}
                  sx={footerButton.submit.sx}
                  size={footerButton.submit.size}
                  disabled={
                    loading ||
                    isEmptyNullUndefined(form.companyId) ||
                    isEmptyNullUndefined(form.annualCycleId)
                  }
                  onClick={getDashbordData}
                >
                  {loading ? (
                    <CircularProgress
                      sx={{
                        width: '15px !important',
                        margin: '4px !important',
                        height: '15px !important',
                      }}
                    />
                  ) : (
                    'Load'
                  )}
                </Button>
              )}
            </Stack>
          </Stack>
        </Paper>
      </Stack>

      {data && (
        <Stack
          sx={{
            flexGrow: 1,
            border: '1px solid #ddd',
            borderRadius: '8px',
            overflow: 'hidden',
            boxShadow: '0px 4px 8px rgba(0, 0, 0, 0.1)',
            marginTop: 2,
          }}
        >
          <iframe
            src={data}
            title='Dashboard Content'
            style={{
              width: '100%',
              height: 'calc(100vh - 200px)', // Adjust to leave space for the header and other components
              border: 'none',
            }}
          />
        </Stack>
      )}
    </Stack>
  );
};

export default Dashboard;
