import React from 'react';
import ForgetPasswordJwtAuth from './ForgetPasswordJwtAuth';

const ForgetPassword = () => {
  return <ForgetPasswordJwtAuth />;
};

export default ForgetPassword;
