import React from 'react';
import {Box, Button} from '@mui/material';
import AppGridContainer from '../../../../@crema/core/AppGridContainer';
import Grid from '@mui/material/Grid';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import IntlMessages from '../../../../@crema/utility/IntlMessages';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputAdornment from '@mui/material/InputAdornment';
import IconButton from '@mui/material/IconButton';
import {Visibility, VisibilityOff} from '@mui/icons-material';
import {Form} from 'formik';
import jwtAxios from '@crema/services/auth/jwt-auth';
import { change_password } from 'shared/constants/ApiRouts';
import { apiCatchErrorMessage, isEmptyNullUndefined } from 'shared/utils/CommonUtils';
import AlertDialog from 'modules/Common/AlertDialog';
import FormHelperText from '@mui/material/FormHelperText';
import AppInfoView from '../../../../@crema/core/AppInfoView';
import {useDispatch, useSelector} from 'react-redux';
import {
  updateCompanyData,
  showMessage,
  fetchError,
} from '../../..//../redux/actions';
import { passwordRegex } from 'shared/constants/AppConst';
import { useAuthMethod } from '@crema/utility/AuthHooks';

const ChangePasswordForm = () => {
  const {logout} = useAuthMethod();
  const dispatch = useDispatch();
  const [oldPassword, setOldPassword] = React.useState({
    password: '',
    showPassword: false,
  });
  const [newPassword, setNewPassword] = React.useState({
    password: '',
    showPassword: false,
  });
  const [retypeNewPassword, setRetypeNewPassword] = React.useState({
    password: '',
    showPassword: false,
  });

  const onOldPassword = (prop) => (event) => {
    const tempError = { ...formError }
    tempError.oldPassword.isError = false;
    tempError.oldPassword.errorMessage = ''
    setOldPassword({...oldPassword, [prop]: event.target.value});
    setFormError(() => tempError)
  };

  const onShowOldPassword = () => {
    setOldPassword({
      ...oldPassword,
      showPassword: !oldPassword.showPassword,
    });
  };

  const onDownOldPassword = (event) => {
    event.preventDefault();
  };

  const onNewPassword = (prop) => (event) => {
    const tempError = { ...formError }
    tempError.newPassword.isError = false;
    tempError.newPassword.errorMessage = ''
    setNewPassword({...newPassword, [prop]: event.target.value});
    setFormError(() => tempError)
  };

  const onShowNewPassword = () => {
    setNewPassword({
      ...newPassword,
      showPassword: !newPassword.showPassword,
    });
  };

  const onDownNewPassword = (event) => {
    event.preventDefault();
  };

  const onRetypeNewPassword = (prop) => (event) => {
    const tempError = { ...formError }
    tempError.retypeNewPassword.isError = false;
    tempError.retypeNewPassword.errorMessage = ''
    setRetypeNewPassword({...retypeNewPassword, [prop]: event.target.value});
    setFormError(() => tempError)
  };

  const onShowRetypeNewPassword = () => {
    setRetypeNewPassword({
      ...retypeNewPassword,
      showPassword: !retypeNewPassword.showPassword,
    });
  };

  const onDownRetypeNewPassword = (event) => {
    event.preventDefault();
  };

  const [alertProps, setAlertProps] = React.useState({
    isHideShow: false,
    message: '',
    title: '',
    alertType: '',
    actionParams: null,
  })

  const [formError, setFormError] = React.useState({
    oldPassword: {isError: false, errorMessage: ''},
    newPassword: {isError: false, errorMessage: ''},
    retypeNewPassword: {isError: false, errorMessage: ''}
  })

  const handleAlertNo = () => {
    const tempAlertProps = { ...alertProps };
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '',
    tempAlertProps.title = '',
    tempAlertProps.message = '',
    tempAlertProps.actionParams = null;
    setAlertProps(() => tempAlertProps);
  }

  const handleAlertYes = () => {
    const tempAlertProps = { ...alertProps };
    tempAlertProps.isHideShow = false;
    tempAlertProps.alertType = '';
    tempAlertProps.title = '';
    tempAlertProps.message = '';
    tempAlertProps.actionParams = null;

    if (alertProps.alertType === 'Confirmation') {
      setTimeout(() => {
        // submitFormmessage(selectedCompany.id)
        submitChangePassword()
      }, 100)
    }
    setAlertProps(() => tempAlertProps)
  }

  const handleSubmitConfirmation = () => {
    const tempAlertProps = { ...alertProps };
    if(getValidate()) {
      tempAlertProps.isHideShow = true;
      tempAlertProps.alertType = 'Confirmation';
      tempAlertProps.title = 'send Notification';
      tempAlertProps.message = 'Are you sure you wish to change password?';
      setAlertProps(() => tempAlertProps)
    }
  }

  const getValidate = () => {
    let isValid = true;
    // const tempSelectedEmployeeData = { ...selectedEmployeeData }
    const tempOldPassword = { ...oldPassword }
    const tempNewPassword = { ...newPassword }
    const tempRetypeNewPassword = { ...retypeNewPassword }
    const tempError = { ...formError };

    if (!isEmptyNullUndefined(tempNewPassword.password)) {
      if (
        !tempNewPassword.password.match(passwordRegex)
      ) {
        tempError.newPassword.isError = true;
        // tempError.newPassword.errorMessage =
        //   'must contain minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character';
        tempError.newPassword.errorMessage = <IntlMessages id='errorMessage.new_password_regex'/>;
        isValid = false;
      }
    }
    if ((!isEmptyNullUndefined(tempNewPassword.password)) && (!isEmptyNullUndefined(tempRetypeNewPassword.password))) {
      if((tempNewPassword.password) != (tempRetypeNewPassword.password)) {
        tempError.retypeNewPassword.isError = true;
        // tempError.retypeNewPassword.errorMessage = 'Passwords must match'
        tempError.retypeNewPassword.errorMessage = <IntlMessages id='errorMessage.Please_Enter_old_password'/>
        isValid = false
      }
    }
    if (isEmptyNullUndefined(tempOldPassword.password)) {
      tempError.oldPassword.isError = true;
      // tempError.oldPassword.errorMessage = 'Please Enter old password';
      tempError.oldPassword.errorMessage = <IntlMessages id='errorMessage.Passwords_must_match'/>;
      isValid = false;
    }
    if (isEmptyNullUndefined(tempNewPassword.password)) {
      tempError.newPassword.isError = true;
      // tempError.newPassword.errorMessage = 'Please Enter new password'
      tempError.newPassword.errorMessage = <IntlMessages id='errorMessage.Please_Enter_new_password'/>;
      isValid = false
    }
    if (isEmptyNullUndefined(tempRetypeNewPassword.password)) {
      tempError.retypeNewPassword.isError = true;
      // tempError.retypeNewPassword.errorMessage = 'Please Re-enter new password'
      tempError.retypeNewPassword.errorMessage = <IntlMessages id='errorMessage.Please_Re-enter_new_password'/>
      isValid = false
    }

    if (isValid) {
      return true;
    } else {
      setFormError(() => tempError)
      
    }
  }

  const submitChangePassword = () => {
      let data = {
      "currentPassword": oldPassword.password,
      "newPassword": newPassword.password
      }
    const submitForm = async (companyID) => {
      
      try {
        const response = await jwtAxios.post(`${change_password}`,
          data,
          // {params: planData},
          {},
        )
        if(response.status == 200) {
          dispatch(
            showMessage(
              'Password updated successfully..!',
            ),
          );
          logout();
        }
      } catch (error) {
        apiCatchErrorMessage(error, dispatch, fetchError);
      }
    }
    submitForm()
  }

  return (
    <>
      <Form autoComplete='off'>
        <AppGridContainer spacing={4}>
          <Grid item xs={12} md={6}>
            <FormControl sx={{width: '100%'}} variant='outlined'>
              <InputLabel htmlFor='oldPassword'>
                <IntlMessages id='common.oldPassword' />
              </InputLabel>
              <OutlinedInput
                id='oldPassword'
                type={oldPassword.showPassword ? 'text' : 'password'}
                value={oldPassword.password}
                error={formError.oldPassword.isError}
                onChange={onOldPassword('password')}
                name='oldPassword'
                endAdornment={
                  <InputAdornment position='end'>
                    <IconButton
                      aria-label='toggle password visibility'
                      onClick={onShowOldPassword}
                      onMouseDown={onDownOldPassword}
                      edge='end'
                    >
                      {oldPassword.showPassword ? (
                        <VisibilityOff />
                      ) : (
                        <Visibility />
                      )}
                    </IconButton>
                  </InputAdornment>
                }
                label={<IntlMessages id='common.oldPassword' />}
              />
              {formError.oldPassword.isError && <FormHelperText style={{ color: '#d32f2f' }}>
                  {formError.oldPassword.errorMessage}
              </FormHelperText>}
            </FormControl>
          </Grid>
          <Grid item xs={12} md={6} sx={{p: '0 !important'}} />
          <Grid item xs={12} md={6}>
            <FormControl sx={{width: '100%'}} variant='outlined'>
              <InputLabel htmlFor='newPassword'>
                <IntlMessages id='common.newPassword' />
              </InputLabel>
              <OutlinedInput
                id='newPassword'
                type={newPassword.showPassword ? 'text' : 'password'}
                value={newPassword.password}
                name='newPassword'
                error={formError.newPassword.isError}
                onChange={onNewPassword('password')}
                endAdornment={
                  <InputAdornment position='end'>
                    <IconButton
                      aria-label='toggle password visibility'
                      onClick={onShowNewPassword}
                      onMouseDown={onDownNewPassword}
                      edge='end'
                    >
                      {newPassword.showPassword ? (
                        <VisibilityOff />
                      ) : (
                        <Visibility />
                      )}
                    </IconButton>
                  </InputAdornment>
                }
                label={<IntlMessages id='common.newPassword' />}
              />
              {formError.newPassword.isError && <FormHelperText style={{ color: '#d32f2f' }}>
                  {formError.newPassword.errorMessage}
              </FormHelperText>}
            </FormControl>
          </Grid>
          <Grid item xs={12} md={6}>
            <FormControl sx={{width: '100%'}} variant='outlined'>
              <InputLabel htmlFor='retypeNewPassword'>
                <IntlMessages id='common.retypeNewPassword' />
              </InputLabel>
              <OutlinedInput
                id='retypeNewPassword'
                type={retypeNewPassword.showPassword ? 'text' : 'password'}
                value={retypeNewPassword.password}
                name='retypeNewPassword'
                error={formError.retypeNewPassword.isError}
                onChange={onRetypeNewPassword('password')}
                endAdornment={
                  <InputAdornment position='end'>
                    <IconButton
                      aria-label='toggle password visibility'
                      onClick={onShowRetypeNewPassword}
                      onMouseDown={onDownRetypeNewPassword}
                      edge='end'
                    >
                      {retypeNewPassword.showPassword ? (
                        <VisibilityOff />
                      ) : (
                        <Visibility />
                      )}
                    </IconButton>
                  </InputAdornment>
                }
                label={<IntlMessages id='common.retypeNewPassword' />}
              />
              {formError.retypeNewPassword.isError && <FormHelperText style={{ color: '#d32f2f' }}>
                  {formError.retypeNewPassword.errorMessage}
              </FormHelperText>}
            </FormControl>
          </Grid>
          <Grid item xs={12} md={12}>
            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
              }}
            >
              <Button
                sx={{
                  position: 'relative',
                  minWidth: 100,
                }}
                color='primary'
                variant='contained'
                type='submit'
                // onClick={() => submitChangePassword()}
                onClick={() => handleSubmitConfirmation()}
              >
                <IntlMessages id='common.saveChanges' />
              </Button>
              <Button
                sx={{
                  position: 'relative',
                  minWidth: 100,
                  ml: 2.5,
                }}
                color='primary'
                variant='outlined'
                type='cancel'
              >
                <IntlMessages id='common.cancel' />
              </Button>
            </Box>
          </Grid>
        </AppGridContainer>
      </Form>
      {alertProps.isHideShow && (
        <AlertDialog
          alertProps={alertProps}
          handleYes={() => handleAlertYes()}
          handleNo={() => handleAlertNo()}
        />
      )}
      <AppInfoView />
    </>
    
  );
};

export default ChangePasswordForm;
